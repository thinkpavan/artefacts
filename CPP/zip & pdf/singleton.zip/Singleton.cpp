/* Dave Pallot */
/* 2000 */

#include "Singleton.h"
#include <iostream>

Singleton* Singleton::m_instance = 0;

Singleton::Singleton()
{
	m_buffer = new char[40];
	::memset(m_buffer, 0, 40);
}


Singleton::~Singleton()
{
	delete[] m_buffer;
}

Singleton* Singleton::instance()
{
	if (m_instance == 0)
	{
		m_instance = new Singleton();
	}

	return m_instance;
}


void Singleton::destroy()
{
	delete m_instance;
	m_instance = 0;
}


void Singleton::func1()
{
	::strcpy(m_buffer, "Func 1 called");;
}


int Singleton::func2()
{
	std::cout << m_buffer << std::endl;
	return 0;
}


