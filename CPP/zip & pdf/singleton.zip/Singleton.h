/* Dave Pallot */
/* 2000 */

class Singleton
{
private:
	Singleton();
	virtual ~Singleton();

public:
	static Singleton* m_instance;
	static Singleton* instance();
	static void destroy();

public:
	void func1();
	int func2();

private:
	char* m_buffer;
};