/* Dave Pallot */

#include "singleton.h"

int main(int argc, char* argv[])
{
	// Create a singleton
	Singleton::instance();

	Singleton::instance()->func1();
	Singleton::instance()->func2();

	// Kill the singleton
	Singleton::destroy();

	return 0;
}

