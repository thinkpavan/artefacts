/********************************************************\
|*                                                      *|
|*   Program:              WinVi                        *|
|*   Author:               Raphael Molle                *|
|*   Compiler:             several                      *|
|*   --------------------- --------------------------   *|
|*   � Copyright 1994-2006 by Raphael Molle, Berlin     *|
|*   � Copyleft by GPL     See file COPYING for more    *|
|*                         info about terms of use      *|
|*                                                      *|
\********************************************************/

/* revision log:
 *		3-Dec-2000	first publication of source code
 *	   13-Mar-2003	clipboard paste with codepage conversion
 */

#include <windows.h>
#include <memory.h>
#include <stdlib.h>
#include "winvi.h"
#include "page.h"

extern INT OemCodePage, AnsiCodePage;

CHAR BinaryFormat[] = "WinVi bin %lu:";
CHAR BinaryPart[24];

static VOID EbcdicConvert(char huge *dst, LPSTR src, INT n)
{
	while (n--) {
		INT orig   = (BYTE)*src++;
		INT mapped = MapTable[1][orig];

		*dst++ = mapped != 127 ? mapped : orig;
	}
}

BOOL ClipboardCopy(void)
{	HGLOBAL	  hMem;
	char huge *pMem;
	LONG	  lSize;
	BOOL	  WideCharConvert = FALSE;
	UINT	  Codepage = 0;

	/*prepare resources...*/
	if (!SelectCount) {
		Error(209);
		return (FALSE);
	}
	if (!OpenClipboard(hwndMain)) {
		ErrorBox(MB_ICONEXCLAMATION, 302);
		return (FALSE);
	}
	lSize = SelectCount + sizeof(BinaryPart);
	if (!(GetVersion() & 0x80000000U) && CharSet <= 1
		&& (Codepage = (CharSet == 1 ? OemCodePage : AnsiCodePage)) != 0) {
			/*copy as wide chars...*/
			lSize <<= 1;
			WideCharConvert = TRUE;
	}
	hMem = GlobalAlloc(GMEM_MOVEABLE | GMEM_ZEROINIT, lSize);
	if (!hMem) {
		CloseClipboard();
		ErrorBox(MB_ICONEXCLAMATION, 304);
		return (FALSE);
	}
	pMem = GlobalLock(hMem);
	if (pMem == NULL) {
		CloseClipboard();
		GlobalFree(hMem);
		ErrorBox(MB_ICONEXCLAMATION, 305);
		return (FALSE);
	}

	/*copy into memory...*/
	{	POSITION Pos;
		ULONG    Bytes = SelectCount;
		UINT     i;
		BOOL	 NullbyteFound = FALSE;

		Pos = SelectStart;
		while (Bytes) {
			LPSTR p, pNull;

			CharAt(&Pos);	/*normalize position and enforce page load*/
			i = Pos.p->Fill - Pos.i;
			if (i > Bytes) i = (UINT)Bytes;
			p = Pos.p->PageBuf + Pos.i;
			if (!NullbyteFound && (pNull = _fmemchr(p, '\0', i)) != NULL) {
				if (ErrorBox(MB_ICONINFORMATION|MB_OKCANCEL, 328) == IDCANCEL) {
					CloseClipboard();
					GlobalUnlock(hMem);
					GlobalFree(hMem);
					return (FALSE);
				}
				NullbyteFound = TRUE;
				i = pNull - p + 1;
				if (CharSet == 2) EbcdicConvert(pMem, p, i);
				else if (WideCharConvert) {
					MultiByteToWideChar(Codepage, 0, p, i, (USHORT*)pMem, i);
					pMem += i;
				} else hmemcpy(pMem, p, i);
				pMem  += i;
				Bytes -= --i;
				Pos.i += i;
				i = wsprintf(BinaryPart, BinaryFormat, Bytes);
				if (WideCharConvert) {
					MultiByteToWideChar(Codepage, 0, BinaryPart, i,
													 (USHORT*)pMem, i);
					pMem += i;
				} else hmemcpy(pMem, BinaryPart, i);
				pMem += i;
				continue;
			}
			if (CharSet == 2) EbcdicConvert(pMem, Pos.p->PageBuf + Pos.i, i);
			else if (WideCharConvert) {
				MultiByteToWideChar(Codepage, 0, Pos.p->PageBuf + Pos.i, i,
												 (USHORT*)pMem, i);
				pMem += i;
			} else hmemcpy(pMem, Pos.p->PageBuf + Pos.i, i);
			pMem  += i;
			Bytes -= i;
			Pos.i += i;
		}
	}

	/*unlock...*/
	GlobalUnlock(hMem);

	/*clear previous clipboard contents...*/
	if (!EmptyClipboard()) {
		CloseClipboard();
		GlobalFree(hMem);
		ErrorBox(MB_ICONEXCLAMATION, 303);
		return (FALSE);
	}

	/*finally, publish...*/
	SetClipboardData(WideCharConvert ? CF_UNICODETEXT
									 : CharSet == 1 ? CF_OEMTEXT
													: CF_TEXT, hMem);
	CloseClipboard();
	CheckClipboard();
	return (TRUE);
}

BOOL ClipboardCut(void)
{
	if (!ClipboardCopy()) return (FALSE);
	DeleteSelected(17);
	GetXPos(&CurrCol);
	ShowEditCaret();
	return (TRUE);
}

BOOL ClipboardPaste(void)
{
	HGLOBAL  hMem = 0;
	LPSTR	 lpMem;
	UINT	 uFormat = CharSet == 1 ? CF_OEMTEXT : CF_TEXT;
	LONG	 lSize;
	MODEENUM SaveMode;
	BOOL	 FreeConversionMemory = FALSE;

	if (IsViewOnly()) return(FALSE);

	/*prepare resources...*/
	if (!OpenClipboard(hwndMain)) {
		ErrorBox(MB_ICONEXCLAMATION, 302);
		return (FALSE);
	}

	/*if running on Windows NT, first try to get wide chars...*/
	if (!(GetVersion() & 0x80000000U) && CharSet <= 1) {
		UINT Cp;

		if (CharSet == 0 /*ANSI*/)
			 Cp = AnsiCodePage ? AnsiCodePage : 0;
		else Cp = OemCodePage  ? OemCodePage  : 0;
		if (Cp) {
			HGLOBAL	hWideCharMem = GetClipboardData(CF_UNICODETEXT);
			USHORT	*lpWideCharMem;

			if (hWideCharMem) {
				lSize		  = GlobalSize(hWideCharMem);
				lpWideCharMem = GlobalLock(hWideCharMem);
				if (lpWideCharMem != NULL) {
					INT nSizeRequired =
						WideCharToMultiByte(Cp, 0, lpWideCharMem, lSize >> 1,
											NULL, 0, NULL, NULL);

					hMem = GlobalAlloc(GMEM_MOVEABLE, nSizeRequired);
					if (hMem) {
						lpMem = GlobalLock(hMem);
						if (lpMem != NULL) {
							lSize = WideCharToMultiByte
											(Cp, 0, lpWideCharMem, lSize >> 1,
											 lpMem, nSizeRequired, NULL, NULL);
							FreeConversionMemory = TRUE;
						} else {
							GlobalFree(hMem);
							hMem = 0;
						}
					}
				}
				GlobalUnlock(hWideCharMem);
			}
		}
	}
	if (!hMem) {
		hMem = GetClipboardData(uFormat);
		if (!hMem) {
			CloseClipboard();
			Error(306);
			return (FALSE);
		}
		lSize = GlobalSize(hMem);
		#if !defined(WIN32)
			if (lSize > 65535) {
				CloseClipboard();
				ErrorBox(MB_ICONSTOP, 307);
				return (FALSE);
			}
		#endif
		lpMem = GlobalLock(hMem);
		if (lpMem == NULL) {
			CloseClipboard();
			ErrorBox(MB_ICONEXCLAMATION, 305);
			return (FALSE);
		}
		if (CharSet == 2 /*EBCDIC*/) {
			HGLOBAL	hConvMem = GlobalAlloc(GMEM_MOVEABLE, lSize);

			if (hConvMem) {
				LPBYTE lpConvMem = GlobalLock(hConvMem);
				if (lpConvMem != NULL) {
					BYTE   ReverseMap[256];
					INT	   i, j;
					LPBYTE lpMem2 = lpMem;

					for (i = 0; i < 256; ++i) ReverseMap[i] = i;
					for (i = 0; i < 256; ++i)
						if ((j = MapTable[1][i]) != 127) ReverseMap[j] = i;
					lpMem = lpConvMem;
					for (i = lSize; i >= 0; --i)
						*lpConvMem++ = ReverseMap[*lpMem2++];
					GlobalUnlock(hMem);
					hMem = hConvMem;
					FreeConversionMemory = TRUE;
				} else GlobalFree(hConvMem);
			}
		}
	}
	SaveMode = Mode;
	if (Mode != InsertMode && Mode != ReplaceMode) {
		StartUndoSequence();
		Mode = InsertMode;
	}
	if (SelectCount) DeleteSelected(17);
	else EnterDeleteForUndo(&CurrPos, 0, 1);	/*force new undo element*/
	Mode = SaveMode;
	HideEditCaret();

	if (lSize) {
		LPSTR lp;
		LONG  lRemain;

		lp = _fmemchr(lpMem, '\0', (size_t)lSize);
		if (lp != NULL && (lp-lpMem+sizeof(BinaryPart)) <= (size_t)lSize
					   && lp[1]==BinaryFormat[0]
					   && _fmemcmp(lp+1, BinaryFormat, 10) == 0) {
			/*insert first part of null containing binary data...*/
			if (*lpMem) InsertBuffer(lpMem, (UINT)(lp-lpMem), 0);
			lRemain = strtoul(lp+11, &lp, 10);
			if (*lp != ':') lSize = 0;
			else {
				if (lSize >= (lp - lpMem) + lRemain) lSize = lRemain;
				else lSize = 0;
				lpMem = lp + 1;
			}
		} else if (lp) lSize = lp-lpMem;
	}
	/*insert clipboard now...*/
	if (lSize) InsertBuffer(lpMem, (UINT)lSize, 1);
	GetXPos(&CurrCol);
	ShowEditCaret();

	/*clean up...*/
	GlobalUnlock(hMem);
	if (FreeConversionMemory) GlobalFree(hMem);
	CloseClipboard();
	return (TRUE);
}
