/********************************************************\
|*                                                      *|
|*   Program:              WinVi                        *|
|*   Author:               Raphael Molle                *|
|*   Compiler:             several                      *|
|*   --------------------- --------------------------   *|
|*   � Copyright 1994-2002 by Raphael Molle, Berlin     *|
|*   � Copyleft by GPL     See file COPYING for more    *|
|*                         info about terms of use      *|
|*                                                      *|
\********************************************************/

/* revision log:
 *     22-Jul-2002	split from search.c
 *     27-Jul-2002	CheckFlag for interactive substitute confirmation
 *     15-Aug-2002  suppress of MessageBeep when Messagebox is called
 */

#include <windows.h>
#include <malloc.h>
#include <string.h>
#include <ctype.h>
#include "winvi.h"
#include "page.h"
#include "resource.h"

#if !defined(DM_REPOSITION)
# define DM_REPOSITION (DM_SETDEFID+1)
#endif

extern INT		SearchErrNo;
extern BOOL		MatchValid;
extern POSITION	StartPos, EndMatch;
extern CHAR		SrchDispBuf[100];

BOOL SearchAgain(WORD Flags)
	/*Flags: 1=Reverse (search in opposite direction)
	 *		 2=pop up dialog if not searched before
	 */
{	BOOL  Return;
	ULONG OldLength;

	HideEditCaret();
	if (Flags & 2 && !MatchValid) {
		SearchDialog();
		return (TRUE);
	}
	OldLength = SelectCount;
	if (OldLength) {
		InvalidateArea(&SelectStart, SelectCount, 1);
		SelectCount = 0;
		UpdateWindow(hwndMain);
	}
	SelectStart = CurrPos;
	Return = SearchAndStatus(&SelectStart, (WORD)((Flags & 1) | 2));
	if (Return) {
		if ((OldLength==0 && Mode!=InsertMode) ||
				ComparePos(&SelectStart, &CurrPos) == 0) {
			if (CountBytes(&EndMatch) - CountBytes(&StartPos) == OldLength) {
				SelectStart = CurrPos;
				Return = SearchAndStatus(&SelectStart, (WORD)(Flags & 1));
			}
		}
		if (Return) {
			NewPosition(&SelectStart);
			UpdateWindow(hwndMain);
			SelectStart   = StartPos;
			SelectBytePos = CountBytes(&StartPos);
			SelectCount   = CountBytes(&EndMatch) - SelectBytePos;
			InvalidateArea(&SelectStart, SelectCount, 0);
			UpdateWindow(hwndMain);
		}
	}
	CheckClipboard();
	ShowEditCaret();
	GetXPos(&CurrCol);
	return (Return);
}

extern char CommandBuf[280];
BOOL Magic, HexInput;

void ReplaceSearched(HWND hDlg)
{	MODEENUM SaveMode = Mode;
	LONG	 Length;

	Magic	 = IsDlgButtonChecked(hDlg, IDC_MAGIC);
	HexInput = IsDlgButtonChecked(hDlg, IDC_HEXSEARCH);
	GetDlgItemText(hDlg, IDC_REPLACESTRING, CommandBuf, sizeof(CommandBuf));
	hwndErrorParent = hDlg;			/*change parent of message box*/
	if ((Magic && !CheckParenPairs()) ||
		!BuildReplaceString(CommandBuf, &Length,
							&CurrPos, SelectCount,
							(WORD)(HexInput | 2 | (Magic ? 0 : 4)))) {
			hwndErrorParent = hwndMain;			/*change parent of message box*/
			return;
	}
	hwndErrorParent = hwndMain;			/*change parent of message box*/
	Mode = InsertMode;
	StartUndoSequence();
	if (SelectCount) DeleteSelected(19);
	HideEditCaret();
	{	LPREPLIST lpRep = &RepList;

		while (Length > (LONG)sizeof(lpRep->Buf)) {
			InsertBuffer(lpRep->Buf, sizeof(lpRep->Buf), 0);
			Length -= sizeof(lpRep->Buf);
			if ((lpRep = lpRep->Next) == NULL) break;
		}
		if (Length && lpRep != NULL) InsertBuffer(lpRep->Buf, Length, 0);
		FreeRepList();
	}
	GoBackAndChar(&CurrPos);
	Mode = SaveMode;
	FindValidPosition(&CurrPos, (WORD)(Mode==InsertMode));
	SendMessage(hDlg, DM_SETDEFID, IDOK, 0);
	SetFocus(GetDlgItem(hDlg, IDOK));
	EnableWindow(GetDlgItem(hDlg, IDC_REPLACE), FALSE);
}

char SearchBuf[256];
BOOL WholeWord, ReplaceOpen;

PSTR SetupSearchString(HWND hDlg, int *Error)
{	PSTR pS = SearchBuf, pD = CommandBuf;
	BOOL Ok = TRUE, OpenBracket = FALSE;

	Magic		   = IsDlgButtonChecked(hDlg, IDC_MAGIC);
	HexInput	   = IsDlgButtonChecked(hDlg, IDC_HEXSEARCH);
	WholeWord	   = IsDlgButtonChecked(hDlg, IDC_WHOLEWORD);
	IgnoreCaseFlag = IsDlgButtonChecked(hDlg, IDC_MATCHCASE) == FALSE;
	WrapScanFlag   = IsDlgButtonChecked(hDlg, IDC_WRAPSCAN);
	*CommandBuf	   = IsDlgButtonChecked(hDlg, IDC_FORWARD) ? '/' : '?';
	GetDlgItemText(hDlg, IDC_SEARCHSTRING, SearchBuf, sizeof(SearchBuf));
	if (WholeWord) {
		*++pD = '\\';
		*++pD = '<';
	}
	for (;;) {
		switch (*++pD = *pS++) {
			case '\\':
				if (Magic) {
					switch (*pS) {
						case '\0':
							break;
						case '%':
							*++pD = *pS++;
							if (!ISHEX(*pS)) break;
							*++pD = *pS++;
							if (ISHEX(*pS)) *++pD = *pS++;
							continue;
						case '0': case '1': case '2': case '3':
							*++pD = *pS++;
							if (*pS >= '0' && *pS <= '7') *++pD = *pS++;
							if (*pS >= '0' && *pS <= '7') *++pD = *pS++;
							continue;
						default:
							*++pD = *pS++;
							continue;
					}
				}
				if (HexInput) Ok = FALSE;
				break;
			case '/': case '?':
				if (HexInput) {
					Ok = FALSE;
					break;
				}
				if (*pD != *CommandBuf) continue;
				/*FALLTHROUGH*/
			case '\0':
				break;
			case '[':
				OpenBracket = TRUE;
				/*FALLTHROUGH*/
			case '*': case '.':
				if (HexInput && !Magic) {
					Ok = FALSE;
					break;
				}
				if (!MagicFlag != !Magic) break;
				continue;
			case '^': case '$':
				if (!Magic) {
					if (HexInput) Ok = FALSE;
					break;
				}
				continue;
			case '-': case ']':
				if (Magic && OpenBracket) {
					if (!(OpenBracket = *pD != ']') && !MagicFlag) break;
					continue;
				}
				/*FALLTHROUGH*/
			default:
				if (HexInput) {
					if (ISHEX(*pD)) {
						pD[2] = *pD;
						*pD++ = '\\'; *pD++ = '%';
						if (ISHEX(*pS)) *++pD = *pS++;
					} else if (*pD-- != ' ') {
						Ok = FALSE;
						break;
					}
				}
				continue;
		}
		if (!Ok) {
			if (Error != NULL) *Error = 239;
			return (NULL);
		}
		if (*pD == '\0') break;
		pD[1] = *pD;
		*pD++ = '\\';
	}
	if (WholeWord) lstrcpy(pD, "\\>");
	return (BuildMatchList(CommandBuf, *CommandBuf, Error));
}

void SearchOk(HWND hDlg)
{	int  ErrNo = 0;
	HWND hSearchButton, hFocus;
	BOOL OldSuppress = SuppressStatusBeep;

	SuppressStatusBeep = TRUE;
	hFocus = GetFocus();
	EnableWindow(hSearchButton = GetDlgItem(hDlg, IDOK), FALSE);
	if (SetupSearchString(hDlg, &ErrNo)) {
		if (!MatchValid) ErrNo = SearchErrNo;
		else if (!SearchAgain(0)) ErrNo = 238;
	}
	SuppressStatusBeep = OldSuppress;
	EnableWindow(hSearchButton, TRUE);
	if (hFocus == hSearchButton) SetFocus(hSearchButton);
	if (!ErrNo) {
		extern void HorizontalScrollIntoView(void);

		if (!ReplaceOpen) {
			if (!ViewOnlyFlag)
				EnableWindow(GetDlgItem(hDlg, IDC_SHOWREPLACE), TRUE);
		} else {
			EnableWindow(GetDlgItem(hDlg, IDC_REPLACE), TRUE);
			SendMessage(hDlg, DM_SETDEFID, IDC_REPLACE, 0);
			SendDlgItemMessage(hDlg, IDOK, BM_SETSTYLE,
							   (WPARAM)BS_PUSHBUTTON, TRUE);
		}
		/*main window does not have the focus...*/
		HorizontalScrollIntoView();
	} else {
		if (ReplaceOpen)
			 EnableWindow(GetDlgItem(hDlg, IDC_REPLACE),	 FALSE);
		else EnableWindow(GetDlgItem(hDlg, IDC_SHOWREPLACE), FALSE);
		hwndErrorParent = hDlg;			/*change parent of message box*/
		ErrorBox(ErrNo==216 || ErrNo==217 ? MB_ICONINFORMATION : MB_ICONSTOP,
				 ErrNo);
		hwndErrorParent = hwndMain;		/*reset to normal value*/
	}
}

void EnableControls(HWND hDlg, BOOL Enable)
{
	EnableWindow(GetDlgItem(hDlg, IDC_SEARCHSTRING),  Enable);
	EnableWindow(GetDlgItem(hDlg, IDC_REPLACESTRING), Enable);
	EnableWindow(GetDlgItem(hDlg, IDOK),			  Enable);
	EnableWindow(GetDlgItem(hDlg, IDC_REPLACE),		  Enable);
	EnableWindow(GetDlgItem(hDlg, IDC_REPLACEALL),	  Enable);
}

BOOL ReplacingAll = FALSE;

void GlobalSubst(HWND hDlg)
{	PSTR p = CommandBuf;
	int	 n;

	Magic	 = IsDlgButtonChecked(hDlg, IDC_MAGIC);
	HexInput = IsDlgButtonChecked(hDlg, IDC_HEXSEARCH);
	ReplacingAll = TRUE;
	p += n = wsprintf(p, ":%%s//");
	n += GetDlgItemText(hDlg, IDC_REPLACESTRING, p, sizeof(CommandBuf)-n);
	while (*p) {
		switch (*p) {
			case '\\':
				if (Magic) {
					if	 (*++p >= '0' && *p <= '7') {
						if (*p >= '0' && *p <= '3') ++p;
						if (*p >= '0' && *p <= '7') ++p;
						if (*p >= '0' && *p <= '7') ++p;
						continue;
					}
					if (*p == '%') {
						if (ISHEX(p[1])) ++p;
						if (ISHEX(p[1])) ++p;
					}
					break;
				}
				/*FALLTHROUGH*/
			case '&':
				if (*p=='&' && !Magic!=MagicFlag) break;
				/*FALLTHROUGH*/
			case '/':
				if (n+1 < sizeof(CommandBuf)) {
					memmove(p+1, p, lstrlen(p)+1);
					*p++ = '\\';
					++n;
				}
				break;
			default:
				if (HexInput) {
					if (!ISHEX(*p)) {
						if (*p != ' ') {
							hwndErrorParent = hDlg;
							ErrorBox(MB_ICONSTOP, 239);
							hwndErrorParent = hwndMain;
							return;
						}
						memmove(p, p+1, lstrlen(p));
						--n;
						continue;
					}
					if (n+2 < sizeof(CommandBuf)) {
						memmove(p+2, p, lstrlen(p)+1);
						*p++ = '\\';
						*p++ = '%';
						if (ISHEX(p[1])) ++p;
						n += 2;
					}
				}
		}
		++p;
	}
	if (n+2 < sizeof(CommandBuf)) lstrcpy(p, "/g");
	SendMessage(hDlg, DM_SETDEFID, IDCANCEL, 0);
	SetFocus(GetDlgItem(hDlg, IDCANCEL));
	EnableControls(hDlg, FALSE);
	CommandExec(CommandBuf);
	EnableControls(hDlg, TRUE);
	ReplacingAll = FALSE;
}

HWND hwndSearch;

BOOL CALLBACK SearchCallback(HWND hDlg, UINT uMsg, WPARAM wPar, LPARAM lPar)
{	extern BOOL SearchBoxPosition, HexEditTextSide;
	extern int  SearchBoxX, SearchBoxY;
	static RECT DlgRect;
	static BOOL Enabled;
	static char CloseString[10];

	PARAM_NOT_USED(lPar);
	switch (uMsg) {
		RECT r;

		case WM_INITDIALOG:
			GetWindowRect(hDlg, &DlgRect);
			GetWindowRect(GetDlgItem(hDlg, IDC_REPLACE), &r);
			SetWindowPos(hDlg, 0, SearchBoxX, SearchBoxY,
								  DlgRect.right - DlgRect.left,
								  r.top - DlgRect.top,
						 SearchBoxPosition ? SWP_NOZORDER
										   : SWP_NOZORDER | SWP_NOMOVE);
			SendMessage(hDlg, DM_REPOSITION, 0, 0);
			EnableWindow(GetDlgItem(hDlg, IDC_SHOWREPLACE), FALSE);
			if (HexInput != (HexEditMode && !HexEditTextSide)) {
				HexInput ^= TRUE;
				*SearchBuf = '\0';
			}
			if (SelectCount &&
					(HexInput ? 3 : 1) * SelectCount < sizeof(SearchBuf)) {
				POSITION SelPos;
				int		 i, c;
				PSTR	 p = SearchBuf;

				SelPos = SelectStart;
				for (i=(int)SelectCount; i; --i) {
					if ((c = CharAt(&SelPos)) == C_CRLF) c = '\r';
					if (Advance(&SelPos, 1) != 1) break;
					if (HexInput) p += wsprintf(p, "%02x ", c);
					else *p++ = c;
				}
				if (HexInput) --p;
				*p = '\0';
				if (*SearchBuf && !ViewOnlyFlag)
					EnableWindow(GetDlgItem(hDlg, IDC_SHOWREPLACE), TRUE);
			} else {
				PSTR p;

				if ((p = ExtractIdentifier(NULL)) != NULL)
					lstrcpyn(SearchBuf, p, sizeof(SearchBuf));
			}
			Enabled = *SearchBuf!='\0';
			if (Enabled) {
				EnableWindow(GetDlgItem(hDlg, IDOK), TRUE);
				SetDlgItemText(hDlg, IDC_SEARCHSTRING, SearchBuf);
				SendMessage(hDlg, DM_SETDEFID, IDOK, 0L);
			} else {
				SendMessage(hDlg, DM_SETDEFID, IDCANCEL, 0L);
				EnableWindow(GetDlgItem(hDlg, IDOK), FALSE);
			}
			EnableWindow(GetDlgItem(hDlg, IDC_REPLACESTRING), FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_REPLACE),       FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_REPLACEALL),    FALSE);
			CheckDlgButton(hDlg, *SrchDispBuf=='?' ? IDC_BACKWARD : IDC_FORWARD,
								 TRUE);
			CheckDlgButton(hDlg, IDC_MATCHCASE,	!IgnoreCaseFlag);
			CheckDlgButton(hDlg, IDC_MAGIC,		Magic);
			CheckDlgButton(hDlg, IDC_HEXSEARCH, HexInput);
			CheckDlgButton(hDlg, IDC_WHOLEWORD,	WholeWord);
			CheckDlgButton(hDlg, IDC_WRAPSCAN,	WrapScanFlag);
			LOADSTRING(hInst, 909, CloseString, sizeof(CloseString));
			ReplaceOpen = FALSE;
			PostMessage(hDlg, WM_COMMAND, 4569, 0);	/*for Wine*/
			return (TRUE);

		case WM_COMMAND:
			switch (COMMAND) {
				case 4569:
					/*Disable/enable again for Wine...*/
					EnableWindow(GetDlgItem(hDlg, IDOK), Enabled);
					break;
				case IDOK:
					SearchOk(hDlg);
					break;
				case IDCANCEL:
					if (ReplacingAll) Interrupted = TRUE;
					PostMessage(hDlg, WM_CLOSE, 0, 0);
					break;
				case IDC_SEARCHSTRING:
					GetDlgItemText(hDlg, IDC_SEARCHSTRING, CommandBuf, 2);
					if (Enabled != (*CommandBuf != '\0')) {
						if (Enabled ^= TRUE) {
							EnableWindow(GetDlgItem(hDlg, IDOK), TRUE);
							SendMessage(hDlg, DM_SETDEFID, IDOK, 0L);
						} else {
							SendMessage(hDlg, DM_SETDEFID, IDCANCEL, 0L);
							EnableWindow(GetDlgItem(hDlg, IDOK), FALSE);
						}
						if (ReplaceOpen) {
						  EnableWindow(GetDlgItem(hDlg,IDC_REPLACE),   Enabled);
						  EnableWindow(GetDlgItem(hDlg,IDC_REPLACEALL),Enabled);
						}
					}
					break;
				case IDC_SHOWREPLACE:
					EnableWindow(GetDlgItem(hDlg, IDC_REPLACESTRING), TRUE);
					EnableWindow(GetDlgItem(hDlg, IDC_REPLACE), SelectCount!=0);
					EnableWindow(GetDlgItem(hDlg, IDC_REPLACEALL),	  TRUE);
					SetWindowPos(hDlg, 0,0,0, DlgRect.right-DlgRect.left,
											  DlgRect.bottom-DlgRect.top,
								 SWP_NOZORDER | SWP_NOMOVE);
					SendMessage(hDlg, DM_REPOSITION, 0, 0);
					SetFocus(GetDlgItem(hDlg, IDC_REPLACESTRING));
					SendMessage(hDlg, DM_SETDEFID, IDC_REPLACE, 0L);
					EnableWindow(GetDlgItem(hDlg, IDC_SHOWREPLACE),  FALSE);
					ReplaceOpen = TRUE;
					break;
				case IDC_REPLACE:
					ReplaceSearched(hDlg);
					SetDlgItemText(hDlg, IDCANCEL, CloseString);
					break;
				case IDC_REPLACEALL:
					SetupSearchString(hDlg, NULL);
					GlobalSubst(hDlg);
					SetDlgItemText(hDlg, IDCANCEL, CloseString);
			}
			return (TRUE);

		case WM_MOVE:
		case WM_CLOSE:
			SearchBoxPosition = TRUE;
			GetWindowRect(hDlg, &r);
			SearchBoxX = r.left;
			SearchBoxY = r.top;
			if (uMsg == WM_CLOSE) {
				DestroyWindow(hDlg);
				hwndSearch = NULL;
			}
			return (TRUE);
	}
	return (FALSE);
}

void SearchDialog(void)
{	static DLGPROC DlgProc;

	if (!DlgProc)
		 DlgProc = (DLGPROC)MakeProcInstance((FARPROC)SearchCallback, hInst);
	if (hwndSearch) BringWindowToTop(hwndSearch);
	else hwndSearch =
		 CreateDialog(hInst, MAKEINTRES(IDD_SEARCH), hwndMain, DlgProc);
}

BOOL CALLBACK SubstChkCallback(HWND hDlg, UINT uMsg, WPARAM wPar, LPARAM lPar)
{	SEARCHCONFIRMRESULT	Result;
	static RECT			Rect;
	static BOOL			RectDefined = FALSE;

	PARAM_NOT_USED(lPar);
	switch (uMsg) {
		case WM_INITDIALOG:
			if (RectDefined)
				SetWindowPos(hDlg, 0, Rect.left, Rect.top, 0, 0,
				                      SWP_NOZORDER | SWP_NOSIZE);
			return (TRUE);

		case WM_COMMAND:
			switch (wPar) {
				case IDOK:
					Result = ConfirmReplace;
					break;
				case 100:
					Result = ConfirmSkip;
					break;
				case IDCANCEL:
					Result = ConfirmAbort;
					break;
			}
			GetWindowRect(hDlg, &Rect);
			RectDefined = TRUE;
			EndDialog(hDlg, Result);
			return (TRUE);
	}
	return (FALSE);
}

SEARCHCONFIRMRESULT ConfirmSubstitute(void)
{	SEARCHCONFIRMRESULT	Res;
	static DLGPROC		DlgProc;

	if (!DlgProc)
		 DlgProc = (DLGPROC)MakeProcInstance((FARPROC)SubstChkCallback, hInst);
	Res = DialogBox(hInst, MAKEINTRES(IDD_SUBSTCONFIRM), hwndMain, DlgProc);
	return (Res);
}
