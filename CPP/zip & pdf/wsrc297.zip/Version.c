/********************************************************\
|*                                                      *|
|*   Program:              WinVi                        *|
|*   Author:               Raphael Molle                *|
|*   Compiler:             several                      *|
|*   --------------------- --------------------------   *|
|*   � Copyright 1994-2006 by Raphael Molle, Berlin     *|
|*   � Copyleft by GPL     See file COPYING for more    *|
|*                         info about terms of use      *|
|*                                                      *|
\********************************************************/

/* revision log:
 *		3-Dec-2000	first publication of source code
 */

static char Version[] = "Version 2.97";

char *GetViVersion(void) {
	extern unsigned Language;

	Version[5] = Language == 10000 ? '\363' : 'o';
	return (Version);
}
