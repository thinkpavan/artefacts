/********************************************************\
|*                                                      *|
|*   Program:              WinVi                        *|
|*   Author:               Raphael Molle                *|
|*   Compiler:             several                      *|
|*   --------------------- --------------------------   *|
|*   � Copyright 1994-2004 by Raphael Molle, Berlin     *|
|*   � Copyleft by GPL     See file COPYING for more    *|
|*                         info about terms of use      *|
|*                                                      *|
\********************************************************/

/* revision log:
 *      3-Dec-2000	first publication of source code
 *     22-Jul-2002	use of private myassert.h
 *     14-Nov-2002	fixed failure to count single lf at start of read buffer
 *	   22-Jun-2004	reload last buffer if CharAt() yields EOF
 */

#include <windows.h>
/*#include <io.h>*/
#include <errno.h>
#include <string.h>
#include <malloc.h>
#include "myassert.h"
#include "winvi.h"
#include "page.h"

#if defined(WIN32)
#  define GLOBALHANDLE(p) GlobalHandle(p)
#else
#  define GLOBALHANDLE(p) (HGLOBAL)LOWORD(GlobalHandle(HIWORD(p)))
#endif

#define  ALLOC_PPAGE  LPPAGE
#define  PAGEALLOC(s) (LPPAGE)_fcalloc(1, s)
#define  PAGEFREE(p)  _ffree(p)

extern BOOL		SessionEnding;
POSITION		MarkPos[27];
static HFILE	TmpFile = HFILE_ERROR;
static char		TmpFileName[260];
static OFSTRUCT	Of;
static char		ErrorUseVirtual[170], ErrorNoGlobalMem[50];
static char		ErrorFatal[30], ErrorPleaseSave[60];

BOOL EnvEntryMatches(LPSTR e, PSTR m)
{
	while (*e == ' ') ++e;
	while (*e == *m) {
		++e; ++m;
	}
	while (*e == ' ') ++e;
	if (*e == '=' && *m == '\0') {
		e += lstrlen(e);
		do; while (*--e == ' ');
		*++e = '\0';
		return (TRUE);
	}
	return (FALSE);
}

void GetSystemTmpDir(PSTR Path, INT Len)
{
	#if defined(WIN32)
		GetTempPath(Len, Path);
	#else
		static LPSTR TmpDir;

		if (!TmpDir) {
			TmpDir = GetDOSEnvironment();
			do {
				if (EnvEntryMatches(TmpDir, "TMP") ||
					EnvEntryMatches(TmpDir, "TEMP"))
						break;
				TmpDir += lstrlen(TmpDir) + 1;
			} while (*TmpDir);
			if (*TmpDir) {
				do; while (*TmpDir++ != '=');
				while (*TmpDir == ' ') ++TmpDir;
			}
		}
		lstrcpyn(Path, TmpDir, Len);
	#endif
}

BOOL CreateTmpFile(void)
{	int  c;
	WORD w;

	if (SessionEnding) return (FALSE);
	if (!DefaultTmpFlag && TmpDirectory!=NULL)
		lstrcpyn(TmpFileName, TmpDirectory, sizeof(TmpFileName));
	else GetSystemTmpDir(TmpFileName, sizeof(TmpFileName));
	if (*TmpFileName && (c=TmpFileName[lstrlen(TmpFileName)-1])!='\\' && c!='/')
		lstrcat(TmpFileName, "\\");
	#if defined(WIN32)
		w = MAKEWORD(GetCurrentTime()&255, GetCurrentProcessId()&255);
	#else
		w = (WORD)GetCurrentTask();
	#endif
	c = 0;
	do {
		wsprintf(TmpFileName + lstrlen(TmpFileName), "~wvi%04x.tmp", w);
		TmpFile = OpenFile(TmpFileName, &Of,
						  OF_CREATE | OF_READ | OF_WRITE | OF_SHARE_DENY_WRITE);
		++w;
	} while (TmpFile == HFILE_ERROR && ++c <= 5);
	return  (TmpFile != HFILE_ERROR);
}

static LONG LastTmpOffset = 0L;

void RemoveTmpFile(void)
{
	if (TmpFile != HFILE_ERROR) {
		_lclose(TmpFile);
		OpenFile(TmpFileName, &Of, OF_DELETE);
		TmpFile = HFILE_ERROR;
	}
	LastTmpOffset = 0;
}

static int PagesOccupied;
ULONG	   AccessTime;

BOOL AllocPageMem(LPPAGE Page)
{	HGLOBAL h;

	if ((((LONG)(PagesOccupied+1)*PAGESIZE) >> 10) > PageThreshold) {
		if (TmpFile != HFILE_ERROR || CreateTmpFile()) {
			LPPAGE p, ToSave = NULL;

			for (p=FirstPage; p; p=p->Next)
				if (p->PageBuf && (ToSave == NULL
						|| p->LastAccess < ToSave->LastAccess))
					ToSave = p;
			if (ToSave->PageFilePos == -1) {
				ToSave->PageFilePos = LastTmpOffset;
				LastTmpOffset += PAGESIZE;
			}
			if (ToSave->Flags & ISSAFE
				|| (_llseek(TmpFile,ToSave->PageFilePos,0)==ToSave->PageFilePos
				    && _lwrite(TmpFile,ToSave->PageBuf,PAGESIZE)==PAGESIZE)) {
				h = GLOBALHANDLE(ToSave->PageBuf);
				GlobalUnlock(h);
				GlobalFree(h);
				--PagesOccupied;
				ToSave->PageBuf = NULL;
				ToSave->Flags |= ISSAFE;
			} else {
				static BOOL AlreadyAsked;
				static int	Answer;

				if (!AlreadyAsked) {
					Answer = MessageBox(hwndMain, ErrorUseVirtual, "WinVi",
										MB_YESNO | MB_ICONQUESTION);
					AlreadyAsked = TRUE;
				}
				if (Answer != IDYES) return (FALSE);
			}
		}
	}
	h = GlobalAlloc(GPTR, PAGESIZE);
	if (h) {
		Page->PageBuf = (LPBYTE)GlobalLock(h);
		if (Page->PageBuf != NULL) {
			Page->LastAccess = ++AccessTime;
			++PagesOccupied;
			return (TRUE);
		}
		GlobalFree(h);
	}
	return (FALSE);
}

BOOL IncompleteLastLine(void)
{	POSITION Pos;

	Pos.p = LastPage;
	while (Pos.p && Pos.p->Fill==0) Pos.p = Pos.p->Prev;
	if (Pos.p == NULL) return (FALSE);
	Pos.i = Pos.p->Fill-1;
	return (!(CharFlags[CharAt(&Pos)] & 1));
}

LPPAGE NewPage(void)
{	ALLOC_PPAGE	pPage;

	pPage = PAGEALLOC(sizeof(PAGE));
	if (pPage != NULL) {
		pPage->PageFilePos = -1;
		if (AllocPageMem(pPage)) return (pPage);
		PAGEFREE(pPage);
	}
	MessageBox(hwndMain, ErrorNoGlobalMem, NULL, MB_OK | MB_ICONSTOP);
	return (NULL);
}

BOOL ReloadPage(LPPAGE p)
{	BOOL Result = TRUE;

	if (p->PageFilePos == -1 || TmpFile == HFILE_ERROR || !AllocPageMem(p)) {
		static BOOL ErrorDisplayed;

		if (!ErrorDisplayed && !SessionEnding) {
			ErrorDisplayed = TRUE;
			MessageBox(hwndMain, ErrorPleaseSave, ErrorFatal,
					   MB_OK | MB_ICONSTOP);
		}
		return (FALSE);
	}
	if (_llseek(TmpFile, p->PageFilePos, 0)   != p->PageFilePos) Result = FALSE;
	if (_lread (TmpFile, p->PageBuf, p->Fill) != p->Fill)		 Result = FALSE;
	return (Result);
}

void FreeAllPages(void)
{	LPPAGE lp = FirstPage, lp2;

	if (!*ErrorUseVirtual) {
		LOADSTRING(hInst, 120, ErrorUseVirtual,  sizeof(ErrorUseVirtual));
		LOADSTRING(hInst, 121, ErrorNoGlobalMem, sizeof(ErrorNoGlobalMem));
		LOADSTRING(hInst, 123, ErrorFatal,       sizeof(ErrorFatal));
		LOADSTRING(hInst, 124, ErrorPleaseSave,  sizeof(ErrorPleaseSave));
	}
	while (lp) {
		lp2 = lp->Next;
		if (lp->PageBuf) {
			HGLOBAL h = GLOBALHANDLE(lp->PageBuf);

			GlobalUnlock(h);
			GlobalFree(h);
			--PagesOccupied;
		}
		PAGEFREE(lp);
		lp = lp2;
	}
	RemoveTmpFile();
	FirstPage = LastPage = ScreenStart.p = CurrPos.p = NewPage();
	FirstPage->PageNo = 1;
	ScreenStart.i = CurrPos.i = 0;
	SelectCount = FirstVisible = 0;
	memset (LineInfo, 0, (VisiLines+2) * sizeof(LINEINFO));
	memset (MarkPos,  0, sizeof(MarkPos));
}

int CharAt(PPOSITION Pos)
{	int c;

	if (!Pos->p) return (C_ERROR);
	while (Pos->i >= Pos->p->Fill) {
		if (!Pos->p->Next) {
			/*CharAt *MUST* make sure the page is loaded, even at EOF...*/
			/*Next line added because of crash at 2004-06-22 after :substitute*/
			if (!Pos->p->PageBuf && !ReloadPage(Pos->p)) return (C_ERROR);
			return (C_EOF);
		}
		Pos->i -= Pos->p->Fill;
		Pos->p	= Pos->p->Next;
	}
	if (!Pos->p->PageBuf && !ReloadPage(Pos->p)) return (C_ERROR);
	if (Pos->p->LastAccess != AccessTime) Pos->p->LastAccess = ++AccessTime;
	if ((c = Pos->p->PageBuf[Pos->i])  == '\r' && Pos->i < Pos->p->Fill-1
		  && Pos->p->PageBuf[Pos->i+1] == '\n') return (C_CRLF);
	return (c);
}

int CharAndAdvance(PPOSITION Pos)
{	int c;

	if (!Pos->p) return (C_ERROR);
	while (Pos->i >= Pos->p->Fill) {
		if (!Pos->p->Next) return (C_EOF);
		Pos->i -= Pos->p->Fill;
		Pos->p	= Pos->p->Next;
	}
	if (!Pos->p->PageBuf && !ReloadPage(Pos->p)) return (C_ERROR);
	if (Pos->p->LastAccess != AccessTime) Pos->p->LastAccess = ++AccessTime;
	c = Pos->p->PageBuf[Pos->i];
	++Pos->i;
	if (c == '\r' && CharAt(Pos) == '\n') {
		++Pos->i;
		c = C_CRLF;
	}
	while (Pos->i >= Pos->p->Fill && Pos->p->Next) {
		Pos->i = 0;
		Pos->p = Pos->p->Next;
	}
	return (c);
}

int AdvanceAndChar(PPOSITION Pos)
{	int c;

	if (!(CharFlags[c = CharAndAdvance(Pos)] & 0x20)) c = CharAt(Pos);
	return (c);
}

ULONG GoBack(PPOSITION Pos, ULONG Amount)
{	ULONG Ret = 0;

	while (Amount > Pos->i) {
		Ret += Pos->i;
		Amount -= Pos->i;
		if (!Pos->p->Prev) {
			Pos->i = 0;
			return (Ret);
		}
		Pos->p = Pos->p->Prev;
		Pos->i = Pos->p->Fill;
	}
	Pos->i -= (int)Amount;
	return (Ret + Amount);
}

int GoBackAndChar(PPOSITION Pos)
{	int c;

	if (!GoBack(Pos, 1)) return (C_EOF);
	if ((c = CharAt(Pos)) == '\n') {
		if (Pos->i > 0) {
			if (Pos->p->PageBuf[Pos->i-1] == '\r') {
				--Pos->i;
				c = C_CRLF;
			}
		} else {
			/* CR+LF should always be in same page,
			 * but there may be rare exceptions...
			 */
			if (GoBack(Pos, 1)) {
				if (Pos->p->PageBuf == NULL) ReloadPage(Pos->p);
				if (Pos->p->PageBuf[Pos->i] == '\r') c = C_CRLF;
				else Advance(Pos, 1);
			}
		}
	}
	return (c);
}

ULONG Advance(PPOSITION Pos, ULONG Amount)
{	ULONG Ret = 0;

	for (;;) {
		int n = Pos->p->Fill - Pos->i;

		if ((ULONG)n > Amount) {
			Pos->i += (int)Amount;
			return (Ret + Amount);
		}
		Ret += n;
		Amount -= n;
		if (!Pos->p->Next) {
			Pos->i += n;
			return (Ret);
		}
		Pos->p = Pos->p->Next;
		Pos->i = 0;
	}
}

void CorrectLineInfo(LPPAGE OldPage, UINT OldInx, LPPAGE NewPage, UINT NewInx,
					 ULONG OldCount, INT CountDiff)
{	int i;

	LineInfo[0].Pos = ScreenStart;
	for (i=CurrLine; i<=VisiLines; ++i) {
		if (LineInfo[i].Pos.p == OldPage && LineInfo[i].Pos.i >= OldInx) {
			LineInfo[i].Pos.p  = NewPage;
			LineInfo[i].Pos.i -= OldInx - NewInx;
			if (!i) ScreenStart = LineInfo[0].Pos;
		}
		if (LineInfo[i].ByteCount > OldCount)
			LineInfo[i].ByteCount += CountDiff;
	}
}

int CountNewlinesInBuf(LPBYTE Buf, INT Len, LONG NewLineCounter[5])
{	int    Ret = 0;
	LPBYTE Ptr = Buf + Len;

	while (Ptr-- > Buf) {
		if (CharFlags[*Ptr] & 1) {
			++Ret;
			if (*Ptr == '\n' && Ptr > Buf) {
				if (*--Ptr != '\r') {
					++Ptr;
					if (NewLineCounter) ++NewLineCounter[2];
				} else if (NewLineCounter) ++NewLineCounter[0];
			} else if (NewLineCounter) switch (*Ptr) {
				case '\r':		++NewLineCounter[1];	break;
				case '\n':		++NewLineCounter[2];	break;
				case '\036':	++NewLineCounter[3];	break;
				case '\0':		++NewLineCounter[4];	break;
			}
		}
	}
	return (Ret);
}

void UnsafePage(PPOSITION Pos)
{
	Pos->p->Flags &= ~ISSAFE;
	if (HexEditMode && Pos->p->Fill) {
		if (Pos->p->PageBuf == NULL) ReloadPage(Pos->p);
		if (Pos->p->PageBuf == NULL) {
			assert(Pos->p->PageBuf != NULL);
		} else {
			if (Pos->p->PageBuf[0]=='\n' && Pos->p->Prev!=NULL)
				Pos->p->Prev->Flags |= CHECK_CRLF;
			if (Pos->p->PageBuf[Pos->p->Fill-1]=='\r')
				Pos->p->Flags |= CHECK_CRLF;
		}
	}
}

BOOL Reserve(PPOSITION Pos, INT Amount, WORD Flags)
	/* Amount may be:  <0 (delete bytes),
	 *					1 (insert one byte), or
	 *					2 (insert two consecutive bytes, i.e. cr/lf)
	 * Flags: 1=contains newline
	 * return value: state of success
	 */
{	LPPAGE Page;

	if (Flags & 1) LinesInFile += Amount > 0 ? 1 : -1;
	if (Amount < 0) {
		EnterDeleteForUndo(Pos, -Amount, 0);
		do {
			if (CharAt(Pos) == C_EOF || !Pos->p->PageBuf) return (FALSE);
			if (Pos->i < Pos->p->Fill) {
				_fmemcpy(Pos->p->PageBuf + Pos->i,
						 Pos->p->PageBuf + Pos->i + 1,
						 Pos->p->Fill    - Pos->i - 1);
				UnsafePage(Pos);
				CorrectLineInfo(Pos->p, Pos->i+1, Pos->p, Pos->i,
								CountBytes(Pos), -1);
			}
			assert(Pos->p->Fill);
			--Pos->p->Fill;
		} while (++Amount);
		if (Flags & 1) {
			Page = Pos->p;
			do {
				--Page->Newlines;
				Page = Page->Next;
			} while (Page != NULL);
		}
		return (TRUE);
	}
	EnterInsertForUndo(Pos, Amount);
	if (Pos->i==0 && Pos->p->Prev && Pos->p->Prev->Fill+Amount < PAGESIZE) {
		CharAt(&ScreenStart);
		Pos->p = Pos->p->Prev;
		Pos->i = Pos->p->Fill;
		if (!Pos->p->PageBuf && !ReloadPage(Pos->p)) return (FALSE);
		Pos->p->Fill += Amount;
		UnsafePage(Pos);
		if (Flags & 1) {
			Page = Pos->p;
			do {
				++Page->Newlines;
				Page = Page->Next;
			} while (Page != NULL);
		}
		if (ScreenStart.p==Pos->p->Next && ScreenStart.i==0)
			LineInfo[0].Pos = ScreenStart = *Pos;
		CorrectLineInfo(NULL, 0, NULL, 0, CountBytes(Pos), Amount);
		return (TRUE);
	}
	if (Pos->p->Fill + Amount > PAGESIZE) {
		Page = NewPage();
		if (!Page) return (FALSE);
		if (!Pos->p->PageBuf && !ReloadPage(Pos->p))
			return (FALSE);
		assert((ULONG)Pos->i <= PAGESIZE);
		assert(Page->PageBuf);
		assert(Pos->p->PageBuf);
		if (Pos->i < Pos->p->Fill) {
			_fmemcpy(Page->PageBuf, Pos->p->PageBuf + Pos->i,
									Page->Fill = Pos->p->Fill - Pos->i);
			UnsafePage(Pos);
		} else Page->Fill = 0;
		Page->Next = Pos->p->Next;
		if (Page->Next == NULL) LastPage = Page;
		else Page->Next->Prev = Page;
		Page->Prev = Pos->p;
		Page->Newlines = Pos->p->Newlines;
		Pos->p->Newlines -= CountNewlinesInBuf(Page->PageBuf, Page->Fill, NULL);
		Pos->p->Next = Page;
		Pos->p->Fill = Pos->i;
		if (Pos->i + Amount > PAGESIZE) {
			CorrectLineInfo(Pos->p, Pos->i, Page, 0, 0, 0);
			Pos->p = Page;
			Pos->i = 0;
		} else {
			CorrectLineInfo(Pos->p, Pos->i+1, Page, 1, 0, 0);
			if (Flags & 1) ++Pos->p->Newlines;
		}
		while (Page) {
			Page->PageNo = Page->Prev->PageNo + 1;
			if (Flags & 1) ++Page->Newlines;
			Page = Page->Next;
		}
	} else if (Flags & 1)
		for (Page = Pos->p; Page; Page = Page->Next)
			++Page->Newlines;
	assert(Pos->i + Amount <= PAGESIZE);
	assert(Pos->p->Fill + Amount <= PAGESIZE);
	if (!Pos->p->PageBuf && !ReloadPage(Pos->p))
		return (FALSE);
	UnsafePage(Pos);
	if (Pos->i < Pos->p->Fill)
		_fmemmove(Pos->p->PageBuf + Pos->i + Amount,
				  Pos->p->PageBuf + Pos->i, Pos->p->Fill - Pos->i);
	else if (LineInfo[0].Pos.p==Pos->p->Next && !LineInfo[0].Pos.i) {
		LineInfo[0].Pos = ScreenStart = *Pos;
	}
	Pos->p->Fill += Amount;
	CorrectLineInfo(Pos->p, Pos->i+1, Pos->p, Pos->i + Amount+1,
					CountBytes(Pos), Amount);
	return (TRUE);
}

ULONG CountBytes(PPOSITION Pos)
{	ULONG  Ret  = Pos->i;
	LPPAGE Page = Pos->p;

	if (Page != NULL) {
		while ((Page = Page->Prev) != NULL) Ret += Page->Fill;
	} else {
		//assert(Page != NULL);
	}
	return (Ret);
}

ULONG CountLines(PPOSITION Pos)
{	ULONG  Ret;

	if (HexEditMode) return (CountBytes(Pos) >> 4);
	if (CharAt(Pos) == C_ERROR) return (0);
	Ret = Pos->p->Prev ? Pos->p->Prev->Newlines : 0;
	Ret += CountNewlinesInBuf(Pos->p->PageBuf, Pos->i, NULL);
	return (Ret);
}

void VerifyPageStructure(void)
	/*correct cr/lf sequences across page boundaries and count newlines...*/
{	LPPAGE Test, CrFound = NULL;
	ULONG  NlCount = 0, NlDiff = 0;

	for (Test=FirstPage; Test; Test=Test->Next) {
		if (Test->Fill && (Test->Flags & CHECK_CRLF || CrFound != NULL)) {
			if (!Test->PageBuf && !ReloadPage(Test)) continue;
			if (CrFound!=NULL && Test->PageBuf[0]=='\n') {
				if (CrFound->Fill < PAGESIZE) {
					--Test->Fill;
					_fmemmove(Test->PageBuf, Test->PageBuf+1, Test->Fill);
					CrFound->PageBuf[CrFound->Fill++] = '\n';
				} else if (Test->Fill < PAGESIZE) {
					_fmemmove(Test->PageBuf+1, Test->PageBuf, Test->Fill);
					++Test->Fill;
					Test->PageBuf[0] = '\r';
					--CrFound->Fill;
					do --CrFound->Newlines;
					while ((CrFound = CrFound->Next) != Test);
					--NlCount;
				} else {
					--Test->Fill;
					_fmemmove(Test->PageBuf, Test->PageBuf+1, Test->Fill);
					--CrFound->Fill;
					do --CrFound->Newlines;
					while ((CrFound = CrFound->Next) != Test);
					CrFound = NewPage();
					CrFound->Next = Test;
					CrFound->Prev = Test->Prev;
					CrFound->Prev->Next = CrFound;
					Test->Prev = CrFound;
					lstrcpy(CrFound->PageBuf, "\r\n");
					CrFound->Fill = 2;
					CrFound->Newlines = NlCount;
				}
			}
			NlCount += CountNewlinesInBuf(Test->PageBuf, Test->Fill, NULL);
			if (Test->Newlines != NlCount) {
				NlDiff = NlCount - Test->Newlines;
				Test->Newlines += NlDiff;
			}
			CrFound = Test->PageBuf[Test->Fill-1]=='\r' ? Test : NULL;
			Test->Flags &= ~CHECK_CRLF;
		} else NlCount = Test->Newlines += NlDiff;
	}
	LinesInFile = NlCount;
}
