/********************************************************\
|*                                                      *|
|*   Program:              WinVi                        *|
|*   Author:               Raphael Molle                *|
|*   Compiler:             several                      *|
|*   --------------------- --------------------------   *|
|*   � Copyright 1994-2006 by Raphael Molle, Berlin     *|
|*   � Copyleft by GPL     See file COPYING for more    *|
|*                         info about terms of use      *|
|*                                                      *|
\********************************************************/

/* revision log:
 *      3-Dec-2000	first publication of source code
 *     15-Aug-2002	check of running shell when changing to another file
 *      6-Oct-2002	settings for new global variable TabExpandDomains (Win32)
 *     27-Nov-2002	multiple profiles, automatic profile selection
 *     11-Jan-2003	mappings/abbreviations, configurable permanent settings
 *     21-Oct-2003	optional tab expansion with forward slash
 *      6-Apr-2004	saving and restoring font glyph availability
 *      6-Jan-2005	setting system default colors before loading profile
 *     19-Apr-2005	hexmode and charset changed in SwitchMatchingProfile
 *                	even if profile does not change
 *      7-Mar-2006	read caret shapes from registry
 */

#include <windows.h>
#include <commdlg.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <direct.h>
#if !defined(__LCC__)
# include <dos.h>
#endif
#include <stdio.h>
#include "winvi.h"
#include "paint.h"
#include "colors.h"
#include "page.h"
#include "map.h"

extern PCSTR	   ApplName;
extern RECT		   WholeWindow;
extern INT		   x, y, Width, Height;
extern BOOL		   Maximized, RefreshFlag, AutoPermanent;
extern INT		   OemCodePage, AnsiCodePage;
extern CHAR		   CurrProfile[64];
extern CHAR const  DefaultProfile[];
extern PMAP		   FirstMapping;
extern COLORREF	   CustomColors[16];
extern signed char CaretProps[20];

BOOL			  LcaseFlag;
BOOL			  UseRegistry = TRUE;

static LPCSTR	  ProfileSection		= "Ramo's WinVi";
static LPCSTR	  pfDrivePathUNC		= "ActivateDrivePathUNC";
static LPCSTR	  pfExtensions			= "ActivateExtensions";
static LPCSTR	  pfLanguage			= "Language";
static LPCSTR	  pfFontFace	 		= "FontName";
static LPCSTR	  pfFontSize	 		= "FontSize";
static LPCSTR	  pfFontAttr	 		= "FontAttributes";
static LPCSTR	  pfFontCharSet			= "FontCharSet";
static LPCSTR	  pfFontGlyphsAvail		= "FontGlyphsAvailable";
static LPCSTR	  pfHexFontFace 		= "HexFontName";
static LPCSTR	  pfHexFontSize 		= "HexFontSize";
static LPCSTR	  pfHexFontAttr			= "HexFontAttributes";
static LPCSTR	  pfHexFontCharSet		= "HexFontCharSet";
static LPCSTR	  pfHexFontGlyphsAvail	= "HexFontGlyphsAvailable";
static LPCSTR	  pfXPos 				= "X-Position";
static LPCSTR	  pfYPos 				= "Y-Position";
static LPCSTR	  pfWidth				= "Width";
static LPCSTR	  pfHeight				= "Height";
static LPCSTR	  pfMaximized			= "Maximized";
static LPCSTR	  pfCaretProps			= "CaretProperties";
static LPCSTR	  pfNewline				= "Newline";
static LPCSTR	  pfHexMode				= "HexMode";
static LPCSTR	  pfCharSet				= "CharacterSet";
static LPCSTR	  pfFgColor				= "TextColor";
static LPCSTR	  pfBkColor				= "BackgroundColor";
static LPCSTR	  pfSelFgColor			= "SelectedText";
static LPCSTR	  pfSelBkColor			= "SelectedBackground";
static LPCSTR	  pfShmFgColor			= "ShowMatchText";
static LPCSTR	  pfShmBkColor			= "ShowMatchBackground";
static LPCSTR	  pfEolColor			= "EolColor";
static LPCSTR	  pfCustomColors		= "CustomColors";
static LPCSTR	  pfTerse				= "Terse";
static LPCSTR	  pfLcaseFnames			= "LowerCaseFnames";
static LPCSTR	  pfReadOnly			= "ReadOnly";
static LPCSTR	  pfAutoRestore			= "AutoRestore";
static LPCSTR	  pfAutoIndent			= "AutoIndent";
static LPCSTR	  pfAutoWrite			= "AutoWrite";
static LPCSTR	  pfShowMatch			= "ShowMatch";
static LPCSTR	  pfWrapScan			= "WrapScan";
static LPCSTR	  pfWrapPos				= "WrapPos";
static LPCSTR	  pfIgnoreCase			= "IgnoreCase";
static LPCSTR	  pfMagic				= "Magic";
static LPCSTR	  pfQuitIfMore			= "QuitIfMoreFiles";
static LPCSTR	  pfTabStop				= "TabStop";
static LPCSTR	  pfUndoLimit			= "UndoLimit";
static LPCSTR	  pfShiftWidth			= "ShiftWidth";
static LPCSTR	  pfDefaultInsert		= "DefaultInsert";
static LPCSTR	  pfLineNumber			= "LineNumber";
static LPCSTR	  pfHexLineNumber		= "HexModeLineNumber";
static LPCSTR	  pfTags				= "Tags";
static LPCSTR	  pfTmpDirectory		= "TmpDirectory";
static LPCSTR	  pfPageThreshold		= "PageThreshold";
static LPCSTR	  pfBitmap				= "Bitmap";
static LPCSTR	  pfRefreshBkgnd		= "RefreshBackground";
static LPCSTR	  pfFullRowExtend		= "FullRowExtend";
static LPCSTR	  pfBreakLine			= "BreakLine";
static LPCSTR	  pfSearchBoxX			= "SearchBox-X";
static LPCSTR	  pfSearchBoxY			= "SearchBox-Y";
static LPCSTR	  pfOemCodePage			= "OemCodePage";
static LPCSTR	  pfAnsiCodePage		= "AnsiCodePage";
static LPCSTR	  pfRecentFiles			= "RecentFiles";
static LPCSTR	  pfRecentFile			= "RecentFile%d";
static LPCSTR	  pfRecentDir			= "RecentDir%d";
static LPCSTR	  pfMaxScroll			= "MaxScroll";
static LPCSTR	  pfShell				= "Shell";
static LPCSTR	  pfShellCommand		= "ShellCommand";
static LPCSTR	  pfTabExpWithSlash		= "TabExpandWithSlash";
static LPCSTR	  pfHelpUrl				= "HelpURL";
static LPCSTR	  pfMapping				= "MapAbbrev%d";
static LPCSTR	  pfMappingName			= "DisplayName";
static LPCSTR	  pfMappingInput		= "Input";
static LPCSTR	  pfMappingReplace		= "Replace";
static LPCSTR	  pfMappingFlags		= "Flags";
static LPCSTR	  pfPrintBorderLeft		= "PrintBorderLeft";
static LPCSTR	  pfPrintBorderTop		= "PrintBorderTop";
static LPCSTR	  pfPrintBorderRight	= "PrintBorderRight";
static LPCSTR	  pfPrintBorderBottom	= "PrintBorderBottom";
static LPCSTR	  pfPrintNumbers		= "PrintNumbers";
static LPCSTR	  pfPrintFontFace		= "PrintFontFace";
static LPCSTR	  pfPrintFontAttr		= "PrintFontAttributes";
static LPCSTR	  pfPrintFontCharSet	= "PrintFontCharSet";
static LPCSTR	  pfPrintFontSize1		= "PrintFontSize1";
static LPCSTR	  pfPrintFontSize2		= "PrintFontSize2";
static LPCSTR	  pfPrintFrame			= "PrintFrame";
static LPCSTR	  pfPrintFrame2			= "PrintFrame2";
static LPCSTR	  pfPrintFrame3			= "PrintFrame3";
static LPCSTR	  pfPrintHeader			= "PrintHeader";
static LPCSTR	  pfPrintFooter			= "PrintFooter";
static LPCSTR	  pfPrintOrientation	= "PrintOrientation";
static LPCSTR	  pfoPortrait			= "Portrait";
static LPCSTR	  pfoLandscape			= "Landscape";
static LPCSTR	  pfoDoubleColumn		= "DoubleColumn";
static LPCSTR	  pfAutoPermanent		= "PermanentSettings";
#if defined(WIN32)
	static LPCSTR pfTabExpandDomains	= "TabExpandDomains";
#endif

static CHAR		  KeyPrefix[]			= "Software\\Ramo\\WinVi";
static HKEY		  hKey					= INVALID_HANDLE_VALUE;
static CHAR		  ProfileBuffer[76];

BOOL SwitchProfile(PROFILEOP Operation, PSTR Profile)
{	BOOL Result = TRUE;

	#if defined(WIN32)
		switch (Operation) {
			case ProfileDelete:
				{	HKEY hKey2;

					if (RegOpenKeyEx(HKEY_CURRENT_USER, KeyPrefix, 0,
							KEY_CREATE_SUB_KEY, &hKey2) == ERROR_SUCCESS) {
						LONG ErrNo;
						INT  i;

						i = 0;
						do wsprintf(ProfileBuffer, "%s\\MapAbbrev%d",
									CurrProfile, ++i);
						while (RegDeleteKey(hKey2, ProfileBuffer)
							   == ERROR_SUCCESS);
						ErrNo = RegDeleteKey(hKey2, CurrProfile);
						RegCloseKey(hKey2);
						if (ErrNo != ERROR_SUCCESS) {
							ErrorBox(MB_ICONSTOP, 115, CurrProfile, ErrNo);
							Result = FALSE;
						}
					}
				}
				lstrcpy(CurrProfile, DefaultProfile);
				break;

			case ProfileSaveAndClear:
				lstrcpy(Profile, CurrProfile);
				*CurrProfile = '\0';
				break;

			case ProfileRestore:
				lstrcpy(CurrProfile, Profile);
				break;

			case ProfileAdd:
				{	HKEY hKey2;

					wsprintf(ProfileBuffer, "%s\\%s", KeyPrefix, Profile);
					if (RegOpenKeyEx(HKEY_CURRENT_USER, ProfileBuffer, 0,
							KEY_QUERY_VALUE, &hKey2) == ERROR_SUCCESS) {
						RegCloseKey(hKey2);
						return(FALSE);
					}
				}
				/*FALLTHROUGH*/
			case ProfileSwitchAndLoad:
				UseRegistry = TRUE;
				if (Profile != CurrProfile) lstrcpy(CurrProfile, Profile);
				break;
		}
		if (hKey != INVALID_HANDLE_VALUE) {
			RegCloseKey(hKey);
			hKey = INVALID_HANDLE_VALUE;
		}
		if (Operation == ProfileSwitchAndLoad) LoadSettings();
	#endif
	return (Result);
}

static INT MatchDrivePathUNC(PSTR MatchAgainst, LPCSTR Filename)
{	CHAR Name[300];
	PSTR p;
	INT  Result = -1;

	if (Filename == NULL) Filename = "";
	if (*Filename=='\0' || (Filename[1]!=':' && strspn(Filename, "\\/") == 0)) {
		/*match working directory and relative filename...*/
		if (!GetCurrentDirectory(sizeof(Name) - 1, Name)) *Name = '\0';
		p = Name + strlen(Name);
		if (*Filename != '\0' && p > Name && p[-1] != '\\' && p[-1] != '/')
			*p++ = '\\';
		lstrcpyn(p, Filename, sizeof(Name) - (p-Name));
	} else if (Filename[1] == ':' && strspn(Filename + 2, "\\/") == 0) {
		/*match working directory on another drive and filename*/
		INT olddrive = _getdrive();

		_chdrive(*Filename & 31);
		if (!GetCurrentDirectory(sizeof(Name), Name)) *Name = '\0';
		_chdrive(olddrive);
		p = Name + strlen(Name);
		if (*Filename != '\0' && p > Name && p[-1] != '\\' && p[-1] != '/')
			*p++ = '\\';
		lstrcpyn(p, Filename + 2, sizeof(Name) - (p-Name));
	} else if (strspn(Filename, "\\/") == 1) {
		/*match drive or share of working directory and filename...*/
		p = Name;
		if (!GetCurrentDirectory(sizeof(Name), Name)) *Name = '\0';
		if (Name[0] != '\0' && Name[1] == ':') p = Name + 2;
		else {
			INT  Slashes = 4;

			for (;;) {
				if (*p == '\0') break;
				if ((*p == '\\' || *p == '/') && --Slashes == 0) break;
				++p;
			}
			if (Slashes > 1) return (-1);
		}
		lstrcpyn(p, Filename, sizeof(Name) - (p-Name));
	} else {
		/*match filename only...*/
		lstrcpyn(Name, Filename, sizeof(Name));
	}
	p = Name;
	while ((p = strstr(p, "..")) != NULL && p > Name) {
		if (	   (p[-1] == '\\' || p[-1] == '/')
				&& (p[2]  == '\\' || p[2]  == '/' || p[2] == '\0')) {
			PSTR p2 = p-1;

			do; while (--p2 > Name && *p2 != '\\' && *p2 != '/');
			memmove(p2, p + 2, lstrlen(p + 1));
			p = p2;
		} else ++p;
	}
	p = MatchAgainst;
	for (;;) {
		PSTR p2, p3 = Name;
		BOOL Failed = FALSE;

		if ((p2 = strpbrk(p, ",;")) == NULL) p2 = p + lstrlen(p);
		if ((*p == '\\' || *p == '/') && p[1] != '\\' && p[1] != '/') {
			/*no drive or share, match against path only...*/
			if (p3[0] != '\0' && p3[1] == ':') p3 += 2;
			else if ((*p3=='\\' || *p3=='/') && (p3[1]=='\\' || p3[1]=='/')) {
				++p3;
				do; while (*++p3 != '\0' && *p3   != '\\' && *p3 != '/');
				do;	while (*p3   != '\0' && *++p3 != '\\' && *p3 != '/');
			}
		}
		while (p < p2) {
			switch (*p) {
				case '\\':
				case '/':
					if (*p3 == '\\' || *p3 == '/') break;
					if (*p3 == '\0' && p+1 == p2) --p3;
					else Failed = TRUE;
					break;

				default:
					if ((INT)(DWORD)AnsiUpper((LPSTR)(INT)(BYTE)*p) !=
						(INT)(DWORD)AnsiUpper((LPSTR)(INT)(BYTE)*p3))
							Failed = TRUE;
			}
			if (Failed) break;
			++p;
			++p3;
		}
		if (*p3 != '\0' && *p3     != '\\' && *p3     != '/' &&
			 p3 > Name  &&  p3[-1] != '\\' &&  p3[-1] != '/') Failed = TRUE;
		if (!Failed && p3-Name > Result) Result = p3-Name;
		if (*p2 == '\0') break;
		p = p2 + 1;
	}
	return (Result);
}

static BOOL MatchExtension(PCSTR MatchAgainst, LPCSTR Filename)
{	PCSTR p = MatchAgainst, p2;
	INT  n;

	if (Filename == NULL) return (FALSE);
	for (;;) {
		if ((p2 = strpbrk(p, ",;")) == NULL) p2 = p + lstrlen(p);
		n = p2 - p;
		if (n > 0 && lstrlen(Filename) >= n
				  && strnicmp(p, Filename + lstrlen(Filename) - n, n) == 0)
			return (TRUE);
		if (*p2 == '\0') return (FALSE);
		p = p2 + 1;
	}
}

INT SelectDefaultNewline = 0;	/*0=autodetect, 1=CR/LF, 2=LF, 3=CR*/
INT SelectDefaultHexMode = 0;	/*0=text, 1=hex*/
INT SelectDefaultCharSet = 0;	/*0=ansi, 1=pc (oem), 2=ebcdic*/

VOID SwitchToMatchingProfile(LPCSTR Filename)
{	HKEY hKey2, hKey3;
	INT  i = 0, n;
	INT  MaxMatchDrivePathUNC = 0;
	BOOL MatchedExtension = FALSE;
	CHAR NewProfile[64];

	*NewProfile = '\0';
	#if defined(WIN32)
	if (RegOpenKeyEx(HKEY_CURRENT_USER, KeyPrefix, 0,
					 KEY_ENUMERATE_SUB_KEYS, &hKey2) == ERROR_SUCCESS) {
		for (;;) {
			DWORD	 Size1 = sizeof(ProfileBuffer);
			FILETIME Time;
			CHAR	 KeyName[sizeof(KeyPrefix) + 64];
			DWORD	 dwType;
			CHAR	 Buf[260];
			DWORD	 Size2 = sizeof(Buf);

			if (RegEnumKeyEx(hKey2, i++, ProfileBuffer, &Size1, NULL,
							 NULL, NULL, &Time) != ERROR_SUCCESS) break;
			if (lstrcmp(ProfileBuffer, DefaultProfile) == 0) continue;
			lstrcpy(KeyName, KeyPrefix);
			lstrcat(KeyName, "\\");
			lstrcat(KeyName, ProfileBuffer);
			if (RegOpenKeyEx(HKEY_CURRENT_USER, KeyName, 0, KEY_QUERY_VALUE,
							 &hKey3) != ERROR_SUCCESS) continue;
			if (RegQueryValueEx(hKey3, pfDrivePathUNC, NULL, &dwType, Buf,
							    &Size2) != ERROR_SUCCESS) *Buf = '\0';
			if (((n = *Buf) == 0 || (n = MatchDrivePathUNC(Buf, Filename)) != 0)
					&& n >= MaxMatchDrivePathUNC) {
				BOOL b;

				Size2 = sizeof(Buf);
				if (RegQueryValueEx(hKey3, pfExtensions, NULL, &dwType, Buf,
								    &Size2) != ERROR_SUCCESS) *Buf = '\0';
				if ((!(b = *Buf!='\0')
							|| (b = MatchExtension(Buf, Filename)) != 0)
						&& (b || !MatchedExtension)) {
					if (n >  MaxMatchDrivePathUNC || 
					   (n == MaxMatchDrivePathUNC && b && !MatchedExtension)) {
							MaxMatchDrivePathUNC = n;
							MatchedExtension	 = b;
							lstrcpy(NewProfile, ProfileBuffer);
					}
				}
			}
			RegCloseKey(hKey3);
		}
		RegCloseKey(hKey2);
	}
	if (hKey != INVALID_HANDLE_VALUE) {
		RegCloseKey(hKey);
		hKey = INVALID_HANDLE_VALUE;
	}
	#endif
	if (*NewProfile == '\0') lstrcpy(NewProfile, DefaultProfile);
	if (lstrcmp(CurrProfile, NewProfile) != 0) {
		lstrcpy(CurrProfile, NewProfile);
		LoadSettings();
	} else {
		/*choose hex mode and character set*/
		if (HexEditMode != SelectDefaultHexMode) ToggleHexMode();
		SetCharSet(SelectDefaultCharSet, 0);
	}
}

VOID AddAllProfileNames(HWND hwndCombobox)
{
	SendMessage(hwndCombobox, CB_ADDSTRING, 0, (LPARAM)DefaultProfile);
	SendMessage(hwndCombobox, CB_SETCURSEL, 0, 0);
	#if defined(WIN32)
	{	HKEY	 hKey2;
		FILETIME Time;
		INT		 i = 0;

		if (RegOpenKeyEx(HKEY_CURRENT_USER, KeyPrefix, 0,
						 KEY_ENUMERATE_SUB_KEYS, &hKey2) == ERROR_SUCCESS) {
			for (;;) {
				DWORD Size = sizeof(ProfileBuffer);

				if (RegEnumKeyEx(hKey2, i++, ProfileBuffer, &Size, NULL,
								 NULL, NULL, &Time) != ERROR_SUCCESS)
					break;
				if (lstrcmp(ProfileBuffer, DefaultProfile) != 0)
					SendMessage(hwndCombobox, CB_ADDSTRING,
								0, (LPARAM)ProfileBuffer);
			}
			RegCloseKey(hKey2);
		}
	}
	#endif
}

CHAR Subkey[24];

static INT MyGetProfileString(LPCSTR Key, LPCSTR Default, LPSTR Buf, INT Size)
{
	#if defined(WIN32)
		if (UseRegistry) {
			if (hKey == INVALID_HANDLE_VALUE) {
				CHAR KeyName[sizeof(KeyPrefix) + 90];

				lstrcpy(KeyName, KeyPrefix);
				if (*CurrProfile != '\0') {
					lstrcat(KeyName, "\\");
					lstrcat(KeyName, CurrProfile);
				}
				if (*Subkey != '\0') {
					lstrcat(KeyName, "\\");
					lstrcat(KeyName, Subkey);
				}
				if (RegOpenKeyEx(HKEY_CURRENT_USER, KeyName, 0,
								 KEY_QUERY_VALUE | KEY_SET_VALUE,
								 &hKey) != ERROR_SUCCESS) {
					hKey = INVALID_HANDLE_VALUE;
					if (*CurrProfile == '\0') UseRegistry = FALSE;
				}
			}
			if (UseRegistry /*may have changed*/) {
				DWORD dwSize = Size;
				DWORD dwType;
				LONG  dwValue;

				if (hKey != INVALID_HANDLE_VALUE &&
						RegQueryValueEx(hKey, Key, NULL, &dwType, Buf, &dwSize)
						== ERROR_SUCCESS) {
					if (dwType == REG_DWORD && dwSize == sizeof(LONG)) {
						memcpy(&dwValue, Buf, sizeof(LONG));
						snprintf(Buf, Size, "%ld", dwValue);
					}
				} else lstrcpyn(Buf, Default, Size);
				return (lstrlen(Buf));
			}
		}
	#endif
	{	INT Result;

		Result = GetProfileString(ProfileSection, Key, Default, Buf, Size);
		#if defined(WIN32)
			if (!UseRegistry && lstrcmp(Buf, Default) != 0) {
				/*first use after switch to registry, save key to registry...*/
				if (hKey == INVALID_HANDLE_VALUE) {
					CHAR  KeyName[sizeof(KeyPrefix) + 64];
					DWORD Disposition;

					lstrcpy(KeyName, KeyPrefix);
					if (*CurrProfile != '\0') {
						lstrcat(KeyName, "\\");
						lstrcat(KeyName, CurrProfile);
					}
					if (RegCreateKeyEx(HKEY_CURRENT_USER, KeyName, 0, NULL,
									   REG_OPTION_NON_VOLATILE,
									   KEY_QUERY_VALUE | KEY_SET_VALUE, NULL,
									   &hKey, &Disposition) != ERROR_SUCCESS)
						hKey = INVALID_HANDLE_VALUE;
				}
				if (hKey != INVALID_HANDLE_VALUE)
					RegSetValueEx(hKey, Key, 0, REG_SZ, Buf, lstrlen(Buf) + 1);
			}
		#endif
		return (Result);
	}
}

static DWORD MyGetProfileLong(LPCSTR Key, DWORD Default, WORD SysDefaultMask)
{	CHAR Buf[16];

	MyGetProfileString(Key, "", Buf, sizeof(Buf));
	if (!*Buf) {
		wUseSysColors |= SysDefaultMask;
		return (Default);
	}
	return (strtol(Buf, NULL, 0));
}

static INT MyGetProfileInt(LPCSTR Key, INT Default)
{
	return ((INT)MyGetProfileLong(Key, Default, 0));
}

static VOID MyGetProfileNewString(LPCSTR Key, LPCSTR Default, LPSTR *pResult)
{	CHAR Buf[260];

	MyGetProfileString(Key, Default, Buf, sizeof(Buf));
	AllocString(pResult, Buf);
}

static BOOL MyGetProfileBool(LPCSTR Key, BOOL Default)
{	CHAR Buf[4];

	MyGetProfileString(Key, "", Buf, sizeof(Buf));
	if (!*Buf) return (Default);
	return (*Buf == '1' || (*Buf = LCASE(*Buf)) == 'y' || *Buf == 't');
}

#if defined(WIN32)
static BOOL RegKey(VOID)
{
	if (hKey == INVALID_HANDLE_VALUE) {
		CHAR  KeyName[sizeof(KeyPrefix) + 90];
		DWORD Disposition;

		lstrcpy(KeyName, KeyPrefix);
		if (*CurrProfile != '\0') {
			lstrcat(KeyName, "\\");
			lstrcat(KeyName, CurrProfile);
		}
		if (*Subkey != '\0') {
			lstrcat(KeyName, "\\");
			lstrcat(KeyName, Subkey);
		}
		if (RegCreateKeyEx(HKEY_CURRENT_USER, KeyName, 0, NULL,
						   REG_OPTION_NON_VOLATILE,
						   KEY_QUERY_VALUE | KEY_SET_VALUE,
						   NULL, &hKey, &Disposition) != ERROR_SUCCESS) {
			hKey = INVALID_HANDLE_VALUE;
			UseRegistry = FALSE;
		}
	}
	return (hKey != INVALID_HANDLE_VALUE);
}
#endif

static VOID MyWriteProfileString(LPCSTR Key, LPCSTR Value)
{
	#if defined(WIN32)
		if (RegKey()) {
			if (Value == NULL) RegDeleteValue(hKey, Key);
			else RegSetValueEx(hKey, Key, 0, REG_SZ, Value, lstrlen(Value) + 1);
			return;
		}
	#endif
	WriteProfileString(ProfileSection, Key, Value);
}

static VOID MyWriteProfileInt(LPCSTR Key, PCSTR Format, LONG Value)
{	CHAR Buf[16];

	#if defined(WIN32)
		if (RegKey()) {
			if (RegSetValueEx(hKey, Key, 0, REG_DWORD,
							  (PBYTE)&Value, sizeof(LONG)) == ERROR_SUCCESS)
				return;
		}
	#endif
	snprintf(Buf, sizeof(Buf), Format, Value);
	MyWriteProfileString(Key, Buf);
}

static VOID MyWriteProfileBool(LPCSTR Key, BOOL Value)
{
	MyWriteProfileString(Key, Value ? "Yes" : "No");
}

/*  ^^^  elementary functions handling win.ini and registry  ^^^  */
/*----------------------------------------------------------------*/
/*  vvv  functions using the elementary functions above      vvv  */

PCSTR LdFormat  = "%ld";
PCSTR L6xFormat = "0x%06lx";
BOOL  SearchBoxPosition;
INT   SearchBoxX, SearchBoxY;

VOID SaveSettings(VOID)
{
	if (!UnsafeSettings) return;
	SwitchProfile(ProfileSaveAndClear, ProfileBuffer);
	if (  (UINT)((WholeWindow.left + WholeWindow.right) / 2)
				< (UINT)GetSystemMetrics(SM_CXSCREEN) &&
		  (UINT)((WholeWindow.top + WholeWindow.bottom) / 2)
				< (UINT)GetSystemMetrics(SM_CYSCREEN)) {
		MyWriteProfileInt(pfXPos,	LdFormat, WholeWindow.left);
		MyWriteProfileInt(pfYPos,	LdFormat, WholeWindow.top);
	}
	MyWriteProfileInt(pfWidth,	LdFormat, WholeWindow.right -WholeWindow.left);
	MyWriteProfileInt(pfHeight, LdFormat, WholeWindow.bottom-WholeWindow.top);
	MyWriteProfileBool(pfMaximized, IsZoomed(hwndMain));
	if (SearchBoxPosition) {
		MyWriteProfileInt(pfSearchBoxX, LdFormat, SearchBoxX);
		MyWriteProfileInt(pfSearchBoxY, LdFormat, SearchBoxY);
	}
	SwitchProfile(ProfileRestore, ProfileBuffer);
}

extern CHAR DrivePathUNC[260], Extensions[80];

VOID SaveProfileSettings(VOID)
{
	MyWriteProfileString(pfDrivePathUNC,  *DrivePathUNC ? DrivePathUNC : NULL);
	MyWriteProfileString(pfExtensions,	  *Extensions   ? Extensions   : NULL);
	MyWriteProfileBool  (pfAutoPermanent, AutoPermanent);
}

VOID SaveColorSettings(VOID)
{	INT  i, n;
	CHAR Buf[16*9], *p;

	if (wUseSysColors & 2)
		MyWriteProfileString(pfFgColor,	   NULL);
	else MyWriteProfileInt(pfFgColor,	   L6xFormat,	 TextColor);
	if (wUseSysColors & 1)
		MyWriteProfileString(pfBkColor,	   NULL);
	else MyWriteProfileInt(pfBkColor,	   L6xFormat,	 BackgroundColor);
	if (wUseSysColors & 8)
		MyWriteProfileString(pfSelFgColor, NULL);
	else MyWriteProfileInt(pfSelFgColor,   L6xFormat,	 SelTextColor);
	if (wUseSysColors & 4)
		MyWriteProfileString(pfSelBkColor, NULL);
	else MyWriteProfileInt(pfSelBkColor,   L6xFormat,	 SelBkgndColor);
	MyWriteProfileInt	  (pfShmFgColor,   L6xFormat,	 ShmTextColor);
	MyWriteProfileInt	  (pfShmBkColor,   L6xFormat,	 ShmBkgndColor);
	MyWriteProfileInt	  (pfEolColor,	   L6xFormat,	 EolColor);
	MyWriteProfileString(pfBitmap,
						 *BitmapFilename ? (LPSTR)BitmapFilename : (LPSTR)NULL);
	for (n = 15; n >= 0; --n)
		if (CustomColors[n] != 0) break;
	p = Buf;
	for (i = 0;;) {
		if (CustomColors[i] != 0)
			p += snprintf(p, 9, L6xFormat, CustomColors[i] & 0xffffffUL);
		if (++i > n) break;
		*p++ = ',';
	}
	MyWriteProfileString(pfCustomColors, n >= 0 ? Buf : NULL);
}

VOID SaveFiletypeSettings(VOID)
{	static CHAR *NewlineStrings[] = {NULL, "crlf", "lf", "cr"};
	static CHAR *HexModeStrings[] = {NULL, "hex"};
	static CHAR *CharSetStrings[] = {NULL, "oem", "ebcdic"};
	
	MyWriteProfileString(pfNewline, NewlineStrings[SelectDefaultNewline]);
	MyWriteProfileString(pfHexMode, HexModeStrings[SelectDefaultHexMode]);
	MyWriteProfileString(pfCharSet, CharSetStrings[SelectDefaultCharSet]);
	#if defined(WIN32)
		if (OemCodePage==0)
			 MyWriteProfileString(pfOemCodePage,  NULL);
		else MyWriteProfileInt	 (pfOemCodePage,  LdFormat, OemCodePage);
		if (AnsiCodePage==0)
			 MyWriteProfileString(pfAnsiCodePage, NULL);
		else MyWriteProfileInt	 (pfAnsiCodePage, LdFormat, AnsiCodePage);
	#endif
}

static VOID WriteFontAttributes(LPCSTR ProfileKey, PLOGFONT LogFont)
{	CHAR Buf[16];

	snprintf(Buf, sizeof(Buf), "%d", LogFont->lfWeight);
	if (LogFont->lfItalic)	  lstrcat(Buf, ",i");
	if (LogFont->lfUnderline) lstrcat(Buf, ",u");
	if (LogFont->lfStrikeOut) lstrcat(Buf, ",s");
	MyWriteProfileString(ProfileKey, Buf);
}

static VOID SaveFont(PLOGFONT LogFont, LPCSTR FaceKey, LPCSTR HeightKey,
									   LPCSTR AttrKey, LPCSTR CharsetKey)
{
	if (*LogFont->lfFaceName) {
		MyWriteProfileString(FaceKey,				 LogFont->lfFaceName);
		MyWriteProfileInt	(HeightKey,	 LdFormat,   LogFont->lfHeight);
		MyWriteProfileInt	(CharsetKey, LdFormat,   LogFont->lfCharSet);
		WriteFontAttributes(AttrKey, LogFont);
	}
}

static VOID SaveGlyphsAvail(LPCSTR Key, BYTE GlyphsAvail[32])
{	CHAR AvailBuffer[68], *p;
	INT	 i;

	for (p = AvailBuffer, i = 0; i < 32; ++i) {
		snprintf(p, 3, "%02x", *GlyphsAvail++);
		p += 2;
	}
	MyWriteProfileString(Key, AvailBuffer);
}

extern LOGFONT TextLogFont, HexLogFont;

VOID SaveFontSettings(VOID)
{
	if (wUseSysColors & 2)
		MyWriteProfileString(pfFgColor,	   NULL);
	else MyWriteProfileInt(pfFgColor,	   L6xFormat,	 TextColor);
	SaveFont(&TextLogFont, pfFontFace, pfFontSize, pfFontAttr, pfFontCharSet);
	SaveFont(&HexLogFont,  pfHexFontFace, pfHexFontSize, pfHexFontAttr,
						   pfHexFontCharSet);
	SaveGlyphsAvail(pfFontGlyphsAvail,	  TextGlyphsAvail);
	SaveGlyphsAvail(pfHexFontGlyphsAvail, HexGlyphsAvail);
}

VOID SaveEditSettings(VOID)
{
	MyWriteProfileBool(pfReadOnly,				  ReadOnlyFlag);
	MyWriteProfileBool(pfAutoIndent,			  AutoIndentFlag);
	MyWriteProfileBool(pfAutoWrite,				  AutoWriteFlag);
	MyWriteProfileBool(pfWrapScan,				  WrapScanFlag);
	MyWriteProfileBool(pfWrapPos,				  WrapPosFlag);
	MyWriteProfileBool(pfIgnoreCase,			  IgnoreCaseFlag);
	MyWriteProfileBool(pfMagic,					  MagicFlag);
	MyWriteProfileBool(pfQuitIfMore,			  QuitIfMoreFlag);
	MyWriteProfileInt (pfUndoLimit,		LdFormat, UndoLimit);
	MyWriteProfileInt (pfShiftWidth,	LdFormat, ShiftWidth);
	MyWriteProfileBool(pfDefaultInsert,			  DefaultInsFlag);
	MyWriteProfileBool(pfFullRowExtend,			  FullRowFlag);
	MyWriteProfileString(pfTmpDirectory, DefaultTmpFlag ? NULL : TmpDirectory);
	MyWriteProfileString(pfTags,
						 Tags!=NULL && lstrcmp(Tags, "tags") ? Tags : NULL);
	MyWriteProfileInt (pfPageThreshold, LdFormat, PageThreshold);
}

VOID SaveDisplaySettings(VOID)
{
	MyWriteProfileBool(pfTerse,					  TerseFlag);
	MyWriteProfileBool(pfAutoRestore,			  AutoRestoreFlag);
	MyWriteProfileBool(pfShowMatch,				  ShowMatchFlag);
	MyWriteProfileInt (pfTabStop,		LdFormat, TabStop);
	MyWriteProfileInt (pfMaxScroll,		LdFormat, MaxScroll);
	MyWriteProfileBool(pfLineNumber,			  NumberFlag);
	MyWriteProfileString(pfHexLineNumber, HexNumberFlag ? "hexadecimal" : NULL);
	MyWriteProfileBool(pfRefreshBkgnd,			  RefreshFlag);
}

VOID SaveFileSettings(VOID)
{
	MyWriteProfileBool(pfLcaseFnames,			  LcaseFlag);
	MyWriteProfileBool(pfQuitIfMore,			  QuitIfMoreFlag);
	MyWriteProfileString(pfTmpDirectory, DefaultTmpFlag ? NULL : TmpDirectory);
	MyWriteProfileString(pfTags,
						 Tags!=NULL && lstrcmp(Tags, "tags") ? Tags : NULL);
	#if defined(WIN32)
		MyWriteProfileString(pfTabExpandDomains, strcmp(TabExpandDomains, "*")
												 ? TabExpandDomains : NULL);
	#endif
	MyWriteProfileInt(pfPageThreshold, LdFormat, PageThreshold);
}

LPSTR Shell, ShellCommand;
BOOL  TabExpandWithSlash;
LPSTR HelpURL = NULL;
PCSTR DefaultHelpURL = "file://%EXEPATH/WinVi-%LANG.htm#";

VOID SaveShellSettings(VOID)
{	CHAR *p;

	MyWriteProfileString(pfShell,		 Shell);
	MyWriteProfileString(pfShellCommand, ShellCommand);
	MyWriteProfileBool  (pfTabExpWithSlash, TabExpandWithSlash);
	MyWriteProfileString(pfHelpUrl,
						 HelpURL == NULL || lstrcmp(HelpURL, DefaultHelpURL)==0
						 ? NULL : HelpURL);
}

VOID SaveMappingSettings(VOID)
{	PMAP		This;
	INT			i = 0;

	#if defined(WIN32)
		if (hKey != INVALID_HANDLE_VALUE) {
			RegCloseKey(hKey);
			hKey = INVALID_HANDLE_VALUE;
		}
		for (This = FirstMapping; This != NULL; This = This->Next) {
			wsprintf(Subkey, pfMapping, ++i);
			if (RegKey()) {
				MyWriteProfileString(pfMappingName,	   This->Name);
				MyWriteProfileString(pfMappingInput,   This->InputDisplay);
				MyWriteProfileString(pfMappingReplace, This->Replace);
				MyWriteProfileInt   (pfMappingFlags,   LdFormat, This->Flags);
				RegCloseKey(hKey);
				hKey = INVALID_HANDLE_VALUE;
			}
		}
		*Subkey = '\0';
		/*remove any remaining old mappings/abbreviations now...*/
		if (RegKey()) {
			CHAR Name[24];

			for (;;) {
				wsprintf(Name, pfMapping, ++i);
				if (RegDeleteKey(hKey, Name) != ERROR_SUCCESS) break;
			}
		}
	#endif
}

extern INT		  nPrtLeft, nPrtTop, nPrtRight, nPrtBottom;
extern BOOL		  LineNumbering, Frame, Frame2, Frame3;
extern BOOL		  OverrideOrientation, DoubleColumn;
extern INT		  nOrientation;
extern LPSTR	  Header, Footer;
extern LOGFONT	  lf;
extern CHOOSEFONT cf;

VOID SavePrintSettings(VOID)
{	static PSTR Fmt = "%d";

	MyWriteProfileInt	(pfPrintBorderLeft,   Fmt, nPrtLeft);
	MyWriteProfileInt	(pfPrintBorderTop,    Fmt, nPrtTop);
	MyWriteProfileInt	(pfPrintBorderRight,  Fmt, nPrtRight);
	MyWriteProfileInt	(pfPrintBorderBottom, Fmt, nPrtBottom);
	MyWriteProfileString(pfPrintOrientation,
		OverrideOrientation ? (DoubleColumn ? pfoDoubleColumn :
							   (nOrientation ? pfoLandscape : pfoPortrait))
							: NULL);
	MyWriteProfileBool(pfPrintNumbers,		LineNumbering);
	if (lf.lfHeight) {
		WriteFontAttributes	(pfPrintFontAttr,   &lf);
		MyWriteProfileString(pfPrintFontFace,		 lf.lfFaceName);
		MyWriteProfileInt	(pfPrintFontCharSet,Fmt, lf.lfCharSet);
		MyWriteProfileInt	(pfPrintFontSize1,  Fmt, lf.lfHeight);
		MyWriteProfileInt	(pfPrintFontSize2,  Fmt, cf.iPointSize);
	}
	MyWriteProfileBool	(pfPrintFrame,  Frame);
	MyWriteProfileBool	(pfPrintFrame2, Frame2);
	MyWriteProfileBool	(pfPrintFrame3, Frame3);
	MyWriteProfileString(pfPrintHeader, Header ? Header : "");
	MyWriteProfileString(pfPrintFooter, Footer ? Footer : "");
}

VOID SaveLanguage(LPSTR pLang)
{
	MyWriteProfileString(pfLanguage, pLang);
}

CHAR ViLang[4];

VOID SaveAllSettings(VOID)
{	extern LPSTR NewLangStr;

	SaveSettings();
	SaveColorSettings();
	SaveFontSettings();
	SaveEditSettings();
	SaveDisplaySettings();
	SaveFileSettings();
	SaveShellSettings();
	SaveMappingSettings();
	SavePrintSettings();
	SaveLanguage(NewLangStr != NULL ? NewLangStr : ViLang);
}

/*  ^^^  functions for saving settings   ^^^  */
/*--------------------------------------------*/
/*  vvv  functions for loading settings  vvv  */

static VOID GetFontAttributes(LPCSTR ProfileKey, PLOGFONT LogFont)
{	CHAR Buf[16], *p;

	if (MyGetProfileString(ProfileKey, "", Buf, sizeof(Buf))) {
		LogFont->lfWeight = (INT)strtol(Buf, &p, 10);
		--p;
		while (*++p == ',') {
			switch (*++p) {
				case 'i':	LogFont->lfItalic	 = TRUE;	continue;
				case 'u':	LogFont->lfUnderline = TRUE;	continue;
				case 's':	LogFont->lfStrikeOut = TRUE;	continue;
			}
			break;
		}
	}
}

static VOID LoadPrintSettings(VOID)
{	static CHAR PrintBuf[82];

	nPrtLeft   = (INT)MyGetProfileLong(pfPrintBorderLeft,   nPrtLeft,   0);
	nPrtTop    = (INT)MyGetProfileLong(pfPrintBorderTop,    nPrtTop,    0);
	nPrtRight  = (INT)MyGetProfileLong(pfPrintBorderRight,  nPrtRight,  0);
	nPrtBottom = (INT)MyGetProfileLong(pfPrintBorderBottom, nPrtBottom, 0);
	MyGetProfileString(pfPrintOrientation, "", PrintBuf, sizeof(PrintBuf));
	switch (*PrintBuf) {
		case 'd': case 'D': /*double column*/
			OverrideOrientation = nOrientation = DoubleColumn = TRUE;
			break;

		case 'l': case 'L': /*landscape*/
			OverrideOrientation = nOrientation = TRUE;
			DoubleColumn = FALSE;
			break;

		case 'p': case 'P': /*portrait*/
			OverrideOrientation = TRUE;
			nOrientation = DoubleColumn = FALSE;
			break;

		default:
			OverrideOrientation = nOrientation = DoubleColumn = FALSE;
			break;
	}
	LineNumbering =		 MyGetProfileBool(pfPrintNumbers,	   LineNumbering);
	MyGetProfileString(pfPrintFontFace, "",lf.lfFaceName,sizeof(lf.lfFaceName));
	GetFontAttributes(pfPrintFontAttr, &lf);
	lf.lfCharSet  = (INT)MyGetProfileLong(pfPrintFontCharSet, lf.lfCharSet,	 0);
	lf.lfHeight   = (INT)MyGetProfileLong(pfPrintFontSize1,	  lf.lfHeight,	 0);
	cf.iPointSize = (INT)MyGetProfileLong(pfPrintFontSize2,	  cf.iPointSize, 0);
	Frame		  =		 MyGetProfileBool(pfPrintFrame,		  Frame);
	Frame2		  =		 MyGetProfileBool(pfPrintFrame2,	  Frame2);
	Frame3		  =		 MyGetProfileBool(pfPrintFrame3,	  Frame3);
	MyGetProfileString(pfPrintHeader, "&n", PrintBuf, sizeof(PrintBuf));
	if (Header) _ffree(Header);
	if (!*PrintBuf) Header = NULL;
	else if ((Header = _fcalloc(lstrlen(PrintBuf) + 1, 1)) != NULL)
		lstrcpy(Header, PrintBuf);
	{	CHAR Def[10];

		LOADSTRING(hInst, 247, Def, sizeof(Def));
		MyGetProfileString(pfPrintFooter, Def, PrintBuf, sizeof(PrintBuf));
	}
	if (Footer) _ffree(Footer);
	if (!*PrintBuf) Footer = NULL;
	else if ((Footer = _fcalloc(lstrlen(PrintBuf) + 1, 1)) != NULL)
		lstrcpy(Footer, PrintBuf);
}

static VOID LoadFontInfo(LPCSTR FaceKey, LPCSTR HeightKey, LPCSTR AttrKey,
						 LPCSTR CharsetKey, PLOGFONT LogFont,
						 LPCSTR GlyphsAvailKey, BYTE GlyphsAvail[32])
{	extern INT HexTextHeight, TextTextHeight;
	CHAR	   AvailBuffer[68], *p;
	INT		   i;

	if (MyGetProfileString(FaceKey, "Courier",
						   LogFont->lfFaceName, sizeof(LogFont->lfFaceName))) {
		LogFont->lfHeight  = MyGetProfileInt(HeightKey, 0);
		if (!LogFont->lfHeight) {
			HDC hDC = GetDC(NULL);

			if (hDC) {
				LogFont->lfHeight =
					-MulDiv(10/*pt*/, GetDeviceCaps(hDC, LOGPIXELSY), 72);
				ReleaseDC(NULL, hDC);
			} else LogFont->lfHeight = 10;
		}
		GetFontAttributes(AttrKey, LogFont);
		LogFont->lfCharSet = MyGetProfileInt(CharsetKey, DEFAULT_CHARSET);
										  /*don't care ansi, etc.*/
		if (MyGetProfileString(GlyphsAvailKey, "",
							   AvailBuffer, sizeof(AvailBuffer))) {
			for (i = 0, p = AvailBuffer; i < 32 && p[0] && p[1]; ++i) {
				*GlyphsAvail = *p & 15;
				if (*p > '9') *GlyphsAvail += 9;
				*GlyphsAvail <<= 4;
				*GlyphsAvail += *++p & 15;
				if (*p++ > '9') *GlyphsAvail += 9;
				++GlyphsAvail;
			}
			if ((LogFont == &TextLogFont) == !HexEditMode) {
				GlyphsAvail -= 32;
				for (i = 0; i <= 255; ++i)
					if (GlyphsAvail[i >> 3] & (1 << (i & 7)))
						 CharFlags[i] &= ~2;
					else CharFlags[i] |=  2;
			}
			GlyphsAvail = NULL;
		}
		if (LogFont == &TextLogFont) {
			if (TextFont) DeleteObject(TextFont);
			NewFont(&TextFont, LogFont, &TextTextHeight, GlyphsAvail);
			if (!HexEditMode) TextHeight = TextTextHeight;
		} else {
			if (HexFont) DeleteObject(HexFont);
			NewFont(&HexFont,  LogFont, &HexTextHeight, GlyphsAvail);
			if (HexEditMode) TextHeight = HexTextHeight;
		}
		if (GlyphsAvail) SaveGlyphsAvail(GlyphsAvailKey, GlyphsAvail);
	}
}

UINT GetDefaultLanguage(BOOL SysDefault)
{	UINT uLanguage;
	CHAR SysLang[16];
	CHAR *p = SysLang;

	GetProfileString("intl", "sLanguage", "", SysLang, sizeof(SysLang));
	MyGetProfileString(pfLanguage, "", ViLang, sizeof(ViLang));
	if (!SysDefault && *ViLang) p = ViLang;
	p[0] = LCASE(p[0]);
	p[1] = LCASE(p[1]);
	if		(p[0]=='d' && p[1]=='e') /*German*/  uLanguage =  7000;
	else if (p[0]=='e' && p[1]=='s') /*Spanish*/ uLanguage = 10000;
	else if (p[0]=='f' && p[1]=='r') /*French*/  uLanguage = 12000;
	else				    /*default: English*/ uLanguage =  9000;
	return (uLanguage);
}

static VOID LoadFontSettings(VOID)
{	extern BOOL	IsFixedFont;

	LoadFontInfo(pfFontFace, pfFontSize, pfFontAttr, pfFontCharSet,
				 &TextLogFont, pfFontGlyphsAvail, TextGlyphsAvail);
	LoadFontInfo(pfHexFontFace, pfHexFontSize, pfHexFontAttr, pfHexFontCharSet,
				 &HexLogFont, pfHexFontGlyphsAvail, HexGlyphsAvail);
	AveCharWidth = 0;		/*will be set again in first paint operation*/
	IsFixedFont	 = FALSE;	/*...*/
	AdjustWindowParts(ClientRect.bottom, ClientRect.bottom);
}

static VOID LoadMappingSettings(VOID)
{	INT  i = 0;
	CHAR Value[256];
	PMAP ThisMapping, *MapPtr;

	FreeMappings(FirstMapping);
	FirstMapping = NULL;
	#if defined(WIN32)
		MapPtr = &FirstMapping;
		if (hKey != INVALID_HANDLE_VALUE) {
			RegCloseKey(hKey);
			hKey = INVALID_HANDLE_VALUE;
		}
		for (;;) {
			wsprintf(Subkey, pfMapping, ++i);
			if (!MyGetProfileString(pfMappingName, "", Value, sizeof(Value)))
				break;
			ThisMapping = calloc(1, sizeof(*ThisMapping));
			if (ThisMapping == NULL) break;
			AllocString(&ThisMapping->Name, Value);
			MyGetProfileString(pfMappingInput, "", Value, sizeof(Value));
			if (!TranslateMapping(&ThisMapping->InputMatch, Value)) continue;
			AllocString(&ThisMapping->InputDisplay, Value);
			MyGetProfileString(pfMappingReplace, "", Value, sizeof(Value));
			if (!TranslateMapping(&ThisMapping->ReplaceMap, Value)) continue;
			AllocString(&ThisMapping->Replace, Value);
			ThisMapping->Flags = MyGetProfileLong(pfMappingFlags, 0, 0);
			RegCloseKey(hKey);
			hKey = INVALID_HANDLE_VALUE;
			*MapPtr = ThisMapping;
			MapPtr = &ThisMapping->Next;
		}
		if (hKey != INVALID_HANDLE_VALUE) {
			RegCloseKey(hKey);
			hKey = INVALID_HANDLE_VALUE;
		}
		*Subkey = '\0';
	#endif
}

COLORREF ShmTextColor  = RGB(255,255,255);
COLORREF ShmBkgndColor = RGB(255,000,000);
COLORREF EolColor	   = RGB(128,000,000);
BOOL	 SuppressAsterisk;

static VOID GetIndexList(VOID);

VOID LoadSettings(VOID)
{
	SwitchProfile(ProfileSaveAndClear, ProfileBuffer);
	x				= MyGetProfileInt(pfXPos,	   x);
	y				= MyGetProfileInt(pfYPos,	   y);
	Width			= MyGetProfileInt(pfWidth,	   Width);
	Height			= MyGetProfileInt(pfHeight,	   Height);
	Maximized		= MyGetProfileBool(pfMaximized, FALSE);
	memset(CaretProps, 0, sizeof(CaretProps));
	MyGetProfileString(pfCaretProps, "", CaretProps, sizeof(CaretProps));
	WholeWindow.left   = x;
	WholeWindow.top    = y;
	WholeWindow.right  = x + Width;
	WholeWindow.bottom = y + Height;
	SearchBoxX		= MyGetProfileInt(pfSearchBoxX, -500);
	if (SearchBoxX != -500) {
		SearchBoxY	= MyGetProfileInt(pfSearchBoxY, 50);
		SearchBoxPosition = TRUE;
	}
	SwitchProfile(ProfileRestore, ProfileBuffer);
	LoadFontSettings();
	wUseSysColors	= 0;
	TabStop			= MyGetProfileInt(pfTabStop,		TabStop);
	ShiftWidth		= MyGetProfileInt(pfShiftWidth,		ShiftWidth);
	MaxScroll		= MyGetProfileInt(pfMaxScroll,		MaxScroll);
	TextColor		= GetSysColor(COLOR_WINDOWTEXT);
	BackgroundColor	= GetSysColor(COLOR_WINDOW);
	SelTextColor	= GetSysColor(COLOR_HIGHLIGHTTEXT);
	SelBkgndColor	= GetSysColor(COLOR_HIGHLIGHT);
	TextColor		= MyGetProfileLong(pfFgColor,		TextColor,		 2);
	BackgroundColor	= MyGetProfileLong(pfBkColor,		BackgroundColor, 1);
	SelTextColor	= MyGetProfileLong(pfSelFgColor,	SelTextColor,	 8);
	SelBkgndColor	= MyGetProfileLong(pfSelBkColor,	SelBkgndColor,	 4);
	ShmTextColor	= MyGetProfileLong(pfShmFgColor,	ShmTextColor,	 0);
	ShmBkgndColor	= MyGetProfileLong(pfShmBkColor,	ShmBkgndColor,	 0);
	EolColor		= MyGetProfileLong(pfEolColor,		EolColor,		 0);
	UndoLimit		= MyGetProfileLong(pfUndoLimit,		UndoLimit,		 0);
	{	CHAR Buf[16*9];

		memset(CustomColors, 0, sizeof(CustomColors));
		if (MyGetProfileString(pfCustomColors, "", Buf, sizeof(Buf))) {
			CHAR *p = Buf;
			INT  i  = 0;

			do {
				if (*p++ != '0' || LCASE(*p++) != 'x') break;
				CustomColors[i] = strtol(p, &p, 16);
				if (*p != ',') break;
				do ++i; while (*++p == ',');
			} while (i < 16);
		}
	}
	MyGetProfileString(pfDrivePathUNC, "", DrivePathUNC,sizeof(DrivePathUNC));
	MyGetProfileString(pfExtensions,   "", Extensions,	sizeof(Extensions));
	MyGetProfileString(pfBitmap,    "", BitmapFilename,	sizeof(BitmapFilename));
	MyGetProfileNewString(pfShell,		  "",			&Shell);
	MyGetProfileNewString(pfShellCommand, "%0 /c %1",	&ShellCommand);
	TabExpandWithSlash = MyGetProfileBool(pfTabExpWithSlash, FALSE);
	MyGetProfileNewString(pfHelpUrl,	DefaultHelpURL,	&HelpURL);
	if (*Shell == '\0') {
		static PSTR	 CmdName = "c:\\command.com";
		static HFILE hf		 = (HFILE)INVALID_HANDLE_VALUE;

		if (hf == (HFILE)INVALID_HANDLE_VALUE) {
			if (GetVersion() & 0x80000000U) {
				/*not NT...*/
				OFSTRUCT TmpOf;

				hf = OpenFile(CmdName, &TmpOf, OF_READ);
				if (hf != (HFILE)INVALID_HANDLE_VALUE) _lclose(hf);
				else CmdName += 3;	/*can hopefully be found in path*/
			} else	 CmdName = "cmd.exe";
			hf = 0;	/*not used as handle anymore, prevent further checks only*/
		}
		AllocString(&Shell, CmdName);
	}
	{	static CHAR	Value[8];
		extern CHAR	*CrLfAttribute;

		MyGetProfileString(pfNewline, "", Value, sizeof(Value));
		switch (LCASE(Value[0])) {
			case 'c': SelectDefaultNewline =
						 Value[1] != '\0' && LCASE(Value[2]) == 'l' ? 1 : 3;
					  break;

			case 'l': SelectDefaultNewline = 2;
					  break;

			default:  SelectDefaultNewline = 0;
		}
		SetDefaultNl();

		MyGetProfileString(pfHexMode, "", Value, sizeof(Value));
		SelectDefaultHexMode = LCASE(Value[0]) == 'h';
		if (HexEditMode != SelectDefaultHexMode) ToggleHexMode();

		MyGetProfileString(pfCharSet, "", Value, sizeof(Value));
		switch (LCASE(Value[0])) {
			case 'o':
			case 'p': SelectDefaultCharSet = 1;
					  break;

			case 'e': SelectDefaultCharSet = 2;
					  break;

			default:  SelectDefaultCharSet = 0;
		}
		SetCharSet(SelectDefaultCharSet, 0);
	}
	ReleaseBmp(0);
	#if defined(WIN32)
		MyGetProfileString(pfTabExpandDomains, "*",
						   TabExpandDomains, sizeof(TabExpandDomains));
	#endif
	TerseFlag		= MyGetProfileBool(pfTerse, 		FALSE);
	#if defined(WIN32)
		LcaseFlag	= MyGetProfileBool(pfLcaseFnames,	FALSE);
	#else
		LcaseFlag	= MyGetProfileBool(pfLcaseFnames,	TRUE);
	#endif
	ReadOnlyFlag	= MyGetProfileBool(pfReadOnly,		FALSE);
	AutoRestoreFlag	= MyGetProfileBool(pfAutoRestore,	TRUE);
	AutoIndentFlag	= MyGetProfileBool(pfAutoIndent,	FALSE);
	AutoWriteFlag	= MyGetProfileBool(pfAutoWrite,		FALSE);
	ShowMatchFlag	= MyGetProfileBool(pfShowMatch,		FALSE);
	WrapScanFlag	= MyGetProfileBool(pfWrapScan,		TRUE);
	WrapPosFlag		= MyGetProfileBool(pfWrapPos,		FALSE);
	IgnoreCaseFlag	= MyGetProfileBool(pfIgnoreCase,	TRUE);
	MagicFlag		= MyGetProfileBool(pfMagic,			TRUE);
	QuitIfMoreFlag	= MyGetProfileBool(pfQuitIfMore,	FALSE);
	DefaultInsFlag	= MyGetProfileBool(pfDefaultInsert,	TRUE);
	NumberFlag		= MyGetProfileBool(pfLineNumber,	FALSE);
	RefreshFlag		= MyGetProfileBool(pfRefreshBkgnd,	FALSE);
	FullRowFlag		= MyGetProfileBool(pfFullRowExtend,	TRUE);
	BreakLineFlag	= MyGetProfileBool(pfBreakLine,		FALSE);
	SuppressAsterisk= MyGetProfileBool("SuppressCaptionAsterisk", FALSE);
	AutoPermanent	= MyGetProfileBool(pfAutoPermanent,FALSE);
	MyGetProfileNewString(pfHexLineNumber, "", &TmpDirectory);
	HexNumberFlag	= LCASE(*TmpDirectory) == 'h';
	MyGetProfileNewString(pfTmpDirectory,  "", &TmpDirectory);
	MyGetProfileNewString(pfTags, "tags", &Tags);
	DefaultTmpFlag	= !*TmpDirectory;
	PageThreshold	= MyGetProfileLong(pfPageThreshold,	PageThreshold, 0);
	MakeBackgroundBrushes();
	OemCodePage		= MyGetProfileInt(pfOemCodePage,  0);
	AnsiCodePage	= MyGetProfileInt(pfAnsiCodePage, 0);
	{	extern VOID SetNewCodePage(VOID);

		SetNewCodePage();
	}
	LoadPrintSettings();
	LoadMappingSettings();
	ChangeLanguage(GetDefaultLanguage(FALSE));
	#if defined(WIN32)
		if (!UseRegistry) {
			/*just for copying win.ini file entries to registry...*/
			SwitchProfile(ProfileSaveAndClear, ProfileBuffer);
			GetIndexList();
			SwitchProfile(ProfileRestore, ProfileBuffer);
			SaveAllSettings();
		}
	#endif
}

/******** list of recently used files... ********/

#define NUMFILES 6

static INT  Index[NUMFILES] = {-1,-1,-1,-1,-1,-1};
static CHAR Buff[264];
static INT  AlreadyInsertedLruFiles;

static VOID GetIndexList(VOID)
{	INT  i;
	CHAR *p;
	BOOL Free[NUMFILES];

	MyGetProfileString(pfRecentFiles, "", Buff, sizeof(Buff));
	for (i=0; i<NUMFILES; ++i) Free[i] = TRUE;
	for (i=0, p=Buff; *p; ++p) {
		INT n = strtol(p, &p, 10);

		if (n>=0 && n<NUMFILES && Free[n]) {
			Index[i++] = n;
			Free[n] = FALSE;
		}
		if (*p == '\0') break;
	}
	#if defined(WIN32)
		if (!UseRegistry) {
			/*first use after switch to registry, dup entries by loading...*/
			for (i=0; i<NUMFILES; ++i) {
				PSTR Value;

				Value = Buff + 1 + snprintf(Buff, sizeof(Buff), pfRecentDir, i);
				MyGetProfileString(Buff, "", Value, sizeof(Buff)-(Value-Buff));
				Value = Buff + 1 + snprintf(Buff, sizeof(Buff), pfRecentFile,i);
				MyGetProfileString(Buff, "", Value, sizeof(Buff)-(Value-Buff));
			}
		}
	#endif
}

static VOID WriteIndexList(VOID)
{	CHAR *p = Buff;
	INT  i;

	Buff[1] = '\0';
	for (i=0; i<NUMFILES; ++i)
		if (Index[i] != -1) {
			*p++ = ',';
			p += snprintf(p, sizeof(Buff)-(p-Buff), "%d", Index[i]);
		}
	MyWriteProfileString(pfRecentFiles, Buff+1 /*skip initial comma*/);
}

VOID InitFileList(VOID)
{
	AlreadyInsertedLruFiles = 0;
}

VOID InsertFileList(HMENU hMenu)
{	INT  i;
	CHAR Key[16];

	SwitchProfile(ProfileSaveAndClear, ProfileBuffer);
	GetIndexList();
	for (i=0; i<NUMFILES; ++i) {
		if (Index[i] == -1) break;
		snprintf(Key,  sizeof(Key),  pfRecentFile, Index[i]);
		snprintf(Buff, sizeof(Buff), "&%d   ", i+1);
		if (!MyGetProfileString(Key, "", Buff+5, sizeof(Buff)-5))
			continue;
		if (lstrlen(Buff) > 32) {
			CHAR *p = Buff + lstrlen(Buff) - 32;

			while (p>Buff && *p!='\\' && *p!='/') --p;
			if (p > Buff+14) {
				memmove(Buff+8, p, lstrlen(p)+1);
				Buff[5] = Buff[6] = Buff[7] = '.';
			}
		}
		{	PSTR p = strchr(Buff+5, '&');

			while (p!=NULL && lstrlen(Buff)<sizeof(Buff)-1) {
				memmove(p+1, p, lstrlen(p)+1);
				p = strchr(p+2, '&');
			}
		}
		if (i >= AlreadyInsertedLruFiles) {
			if (!AlreadyInsertedLruFiles) {
				/*insert another separator...*/
				InsertMenu(hMenu, 13, MF_BYPOSITION | MF_SEPARATOR, 0, NULL);
			}
			InsertMenu(hMenu, 13+i, MF_BYPOSITION | MF_STRING, 3000+i, Buff);
			++AlreadyInsertedLruFiles;
		} else {
			ModifyMenu(hMenu, 13+i, MF_BYPOSITION | MF_STRING, 3000+i, Buff);
		}
	}
	SwitchProfile(ProfileRestore, ProfileBuffer);
}

VOID  AddToFileList(LPCSTR FileName)
{	INT  i, j;
	CHAR Key[16];

	if (!*FileName) return;
	SwitchProfile(ProfileSaveAndClear, ProfileBuffer);
	GetIndexList();
	for (i=0; i<NUMFILES; ++i) {
		if (Index[i] != -1) {
			snprintf(Key, sizeof(Key), pfRecentFile, Index[i]);
			MyGetProfileString(Key, "", Buff, sizeof(Buff));
			if (lstrcmpi(Buff, FileName) == 0) {
				INT  j, k = Index[i];
				BOOL Differs = lstrcmp(Buff, FileName) != 0;

				snprintf(Key, sizeof(Key), pfRecentDir, Index[i]);
				if (MyGetProfileString(Key, "", Buff, sizeof(Buff))) {
					CHAR Dir[260];

					_getcwd(Dir, sizeof(Dir));
					if (lstrcmpi(Dir, Buff) != 0) {
						if ( (FileName[1]!=':' ||
							 (FileName[2]!='\\' && FileName[2]!='/')) &&
							((FileName[0]!='\\' && FileName[0]!='/') ||
							  FileName[1]!=FileName[0]))
							continue;
					}
					if (lstrcmp(Dir, Buff) != 0)
						MyWriteProfileString(Key, Dir);
				}
				if (Differs) {
					snprintf(Key, sizeof(Key), pfRecentFile, Index[i]);
					MyGetProfileString(Key, "", Buff, sizeof(Buff));
					MyWriteProfileString(Key, FileName);
				}
				for (j=i; j>0; --j) Index[j] = Index[j-1];
				Index[0] = k;
				WriteIndexList();
				SwitchProfile(ProfileRestore, ProfileBuffer);
				return;
			}
		}
	}
	{	BOOL Occupied[NUMFILES];

		for (i=0; i<NUMFILES; ++i) Occupied[i] = FALSE;
		for (i=0; i<NUMFILES; ++i) {
			if (Index[i] == -1) break;
			Occupied[Index[i]] = TRUE;
		}
		if (i == NUMFILES) j = Index[--i];
		else for (j=0; j<NUMFILES && Occupied[j]; ++j);
	}
	while (i > 0) {
		Index[i] = Index[i-1];
		--i;
	}
	Index[0] = j;
	WriteIndexList();
	snprintf(Key, sizeof(Key), pfRecentFile, j);
	MyWriteProfileString(Key, FileName);
	snprintf(Key, sizeof(Key), pfRecentDir, j);
	_getcwd(Buff, sizeof(Buff));
	MyWriteProfileString(Key, Buff);
	SwitchProfile(ProfileRestore, ProfileBuffer);
}

VOID FileListCommand(INT Command)
{
	if (Command>=3000 && Command<3000+NUMFILES && Index[Command-=3000]!=-1) {
		CHAR Key[16];

		if (ExecRunning()) {
			ErrorBox(MB_ICONSTOP, 236);
			return;
		}
		if (!AskForSave(hwndMain, 1)) return;
		SwitchProfile(ProfileSaveAndClear, ProfileBuffer);
		snprintf(Key, sizeof(Key), pfRecentDir, Index[Command]);
		lstrcpy(Buff, ":cd ");
		if (MyGetProfileString(Key, "", Buff+4, sizeof(Buff)-4)) {
			NewStatus(0, Buff, NS_BUSY);
			#if defined(WIN32)
				SetCurrentDirectory(Buff+4);
			#else
				if (Buff[4] && Buff[5]==':') _chdrive(Buff[4] & 31);
				_chdir(Buff+4);
			#endif
		}
		snprintf(Key, sizeof(Key), pfRecentFile, Index[Command]);
		if (MyGetProfileString(Key, "", Buff, sizeof(Buff))) {
			extern CHAR CommandBuf[260];

			SwitchProfile(ProfileRestore, ProfileBuffer);
			lstrcpyn(CommandBuf, Buff, sizeof(CommandBuf));
			NewStatus(0, "", NS_NORMAL);
			CommandWithExclamation = TRUE;	/*prevent another AskForSave()*/
			Open(CommandBuf, 0);
			CommandWithExclamation = FALSE;
		} else {
			SwitchProfile(ProfileRestore, ProfileBuffer);
			Error(412);
		}
	}
}

/************* Debug settings... ****************/

BOOL DebugMessages(VOID)
{
	return (MyGetProfileBool("Debug", FALSE));
}
