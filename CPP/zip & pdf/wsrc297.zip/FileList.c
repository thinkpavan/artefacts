/********************************************************\
|*                                                      *|
|*   Program:              WinVi                        *|
|*   Author:               Raphael Molle                *|
|*   Compiler:             several                      *|
|*   --------------------- --------------------------   *|
|*   � Copyright 1994-2001 by Raphael Molle, Berlin     *|
|*   � Copyleft by GPL     See file COPYING for more    *|
|*                         info about terms of use      *|
|*                                                      *|
\********************************************************/

/* revision log:
 *		3-Dec-2000	first publication of source code
 */

#include <windows.h>
#include <string.h>
#include "resource.h"
#include "winvi.h"
#include "pathexp.h"

typedef struct tagFILELIST {
	struct tagFILELIST *Next;
	BYTE Flags;
	char FileName[1];
} FILELIST, *PFILELIST;
PFILELIST pFileList, pLastFile;

int nCurrFileListEntry, nNumFileListEntries;

BOOL RemoveFirstFileListEntry(void)
{	PFILELIST p;
	HLOCAL hFile;

	p = pFileList;
	if (p == NULL) return (FALSE);
	pFileList = pFileList->Next;
	hFile = LocalHandle(p);
	LocalUnlock(hFile);
	LocalFree(hFile);
	if (nCurrFileListEntry) --nCurrFileListEntry;
	--nNumFileListEntries;
	return (TRUE);
}

void ClearFileList(void)
{
	while (nNumFileListEntries) RemoveFirstFileListEntry();
}

static int AppendSingle(LPCSTR lp1, LPCSTR lp2, int nLen)
{	HLOCAL	  hFile;
	PFILELIST pFile;

	hFile = LocalAlloc(LMEM_FIXED, lstrlen(lp1) + nLen + sizeof(FILELIST));
	if (!hFile) return (-1);
	pFile = (PFILELIST)LocalLock(hFile);
	if (pFile == NULL) {
		LocalFree(hFile);
		return (-1);
	}
	pFile->Next  = NULL;
	pFile->Flags = 0;
	lstrcpy(pFile->FileName, lp1);
	_fmemcpy(pFile->FileName + lstrlen(lp1), lp2, nLen);
	pFile->FileName[lstrlen(lp1) + nLen] = '\0';
	if (pFileList) pLastFile->Next = pFile;
	else pFileList = pFile;
	pLastFile = pFile;
	return (nNumFileListEntries++);
}

int AppendToFileList(LPCSTR lpFile, int nLen, int Flags)
	/*Flags: 1=initial parameter list or next command, expand wildcards
	 */
{	char   FNameBuf[260];
	char   *p	  = FNameBuf, *PathEnd = FNameBuf;
	LPCSTR lp	  = lpFile;
	int	   nRet	  = -1;
	BOOL   Expand = FALSE;

	while (nLen-- && p-FNameBuf < sizeof(FNameBuf)-1) {
		switch (*p++ = *lp++) {
			case '"':
				--p;
				break;
			case '*': case '?':
				Expand = TRUE;
				break;
			case '/': case '\\':
				PathEnd = p;
				Expand = FALSE;
				break;
			case '\0':	/*should not occur*/
				nLen = 0;
		}
	}
	*p = '\0';
	if (!++nLen && Flags & 1 && Expand) {
		FIND_DATA Data;
		HANDLE    FindHandle;

		FindHandle = FIND_FIRST(FNameBuf, &Data);
		if (FindHandle != INVALID_HANDLE_VALUE) {
			*PathEnd = '\0';
			do {
				if (!IS_DIRECTORY(&Data) && !IS_HIDDEN(&Data)) {
					nRet = AppendSingle(FNameBuf, FOUND_NAME(&Data),
										  lstrlen(FOUND_NAME(&Data)));
					if (nRet == -1) break;
				}
			} while (FIND_NEXT(FindHandle, &Data));
			FIND_CLOSE(FindHandle);
			return (nRet);
		}
	}
	return (AppendSingle(FNameBuf, lp, nLen));
}

LPSTR GetFileListEntry(int nEntry)
{	PFILELIST p;

	p = pFileList;
	if (p == NULL) return (NULL);
	while (nEntry--) {
		p = p->Next;
		if (p == NULL) return (NULL);
	}
	return (p->FileName);
}

BOOL CALLBACK ArgsCallback(HWND hDlg, UINT uMsg, WPARAM wPar, LPARAM lPar)
{	int   i;
	LPSTR lp;
	HWND  hwndListBox;

	PARAM_NOT_USED(lPar);
	switch (uMsg) {
		case WM_INITDIALOG:
			i = 0;
			hwndListBox = GetDlgItem(hDlg, IDC_LISTBOX);
			if (hwndListBox) {
				while ((lp = GetFileListEntry(i++)) != NULL)
					SendMessage(hwndListBox, LB_ADDSTRING, 0, (LPARAM)lp);
				SendMessage(hwndListBox, LB_SETCURSEL, nCurrFileListEntry, 0);
			}
			return (TRUE);

		case WM_COMMAND:
			if (COMMAND == IDC_LISTBOX) {
				if (NOTIFICATION == LBN_DBLCLK) wPar = IDOK;
				else if (NOTIFICATION == LBN_SELCHANGE)
					SendMessage(hDlg, DM_SETDEFID, IDOK, 0);
			}
			if (COMMAND == IDOK) {
				i = (int)SendDlgItemMessage(hDlg,IDC_LISTBOX,LB_GETCURSEL,0,0);
				if (i==LB_ERR || ((lp=GetFileListEntry(i)) == NULL)
							  || !AskForSave(hDlg, 1))
					return (TRUE);
				nCurrFileListEntry = i;
				Unsafe = FALSE;		/*already asked for save*/
				Open(lp, 0);
			}
			if (COMMAND==IDOK || COMMAND==IDCANCEL)
				EndDialog(hDlg, COMMAND==IDOK);
			return (TRUE);
	}
	return (FALSE);
}

void ArgsCmd(void)
{	static DLGPROC Callback;

	if (!Callback)
		 Callback = (DLGPROC)MakeProcInstance((FARPROC)ArgsCallback, hInst);
	DialogBox(hInst, MAKEINTRES(IDD_ARGS), hwndMain, Callback);
}

int FindOrAppendToFileList(LPCSTR Fname)
{	int j;

	for (j = 0; j < nNumFileListEntries; ++j) {
		LPSTR pName;

		pName = GetFileListEntry(j);
		if (pName != NULL && !lstrcmpi(pName, Fname)) return (j);
	}
	return (AppendToFileList(Fname, lstrlen(Fname), 0));
}
