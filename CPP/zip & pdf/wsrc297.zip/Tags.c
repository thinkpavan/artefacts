/********************************************************\
|*                                                      *|
|*   Program:              WinVi                        *|
|*   Author:               Raphael Molle                *|
|*   Compiler:             several                      *|
|*   --------------------- --------------------------   *|
|*   � Copyright 1994-2002 by Raphael Molle, Berlin     *|
|*   � Copyleft by GPL     See file COPYING for more    *|
|*                         info about terms of use      *|
|*                                                      *|
\********************************************************/

/* revision log:
 *		3-Dec-2000	first publication of source code
 *     15-Nov-2002	tag back in same file with NewPosition() (uses scrolling)
 */

#include <windows.h>
#include <string.h>
#include <malloc.h>
#include "winvi.h"
#include "page.h"

static LPSTR TagsFile;
static char  TagCommand[264];

typedef struct tagTAGSTACK {
	struct tagTAGSTACK FAR *Next;
	ULONG					Pos;
	char					FName[1];
} TAGSTACK, FAR *LPTAGSTACK;
static LPTAGSTACK TagStack = NULL;

static VOID PushTag(VOID)
{	LPTAGSTACK SavePos;

	if (CurrFile == NULL || !*CurrFile) return;
	if ((SavePos = _fcalloc(sizeof(TAGSTACK) + lstrlen(CurrFile), 1)) == NULL)
		return;
	SavePos->Next = TagStack;
	SavePos->Pos  = CountBytes(&CurrPos);
	lstrcpy(SavePos->FName, CurrFile);
	TagStack = SavePos;
}

VOID PopTag(BOOL Jump)
{
	if (TagStack != NULL) {
		LPTAGSTACK ToFree;
		if (Jump) {
			if (lstrcmpi(TagStack->FName, CurrFile) != 0) {
				lstrcpy(TagCommand, ":e ");
				lstrcat(TagCommand, TagStack->FName);
				if (!CommandExec(TagCommand)) return;
				JumpAbsolute(TagStack->Pos);
				NewScrollPos();
			} else {
				POSITION p;

				p.p = FirstPage;
				while (p.p->Next && TagStack->Pos > p.p->Fill) {
					TagStack->Pos -= p.p->Fill;
					p.p = p.p->Next;
				}
				if (TagStack->Pos > p.p->Fill) p.i = p.p->Fill;
				else p.i = (short)TagStack->Pos;
				NewPosition(&p);
			}
			if (!HexEditMode) Position(1, '^', 0);	/*position to first non-space*/
			else ShowEditCaret();					/*show caret only*/
		}
		ToFree   = TagStack;
		TagStack = TagStack->Next;
		_ffree(ToFree);
	} else Error(330);
}

BOOL IsTagStackEmpty(VOID)
{
	return (TagStack == NULL);
}

static HFILE OpenNextTagsFile(VOID)
{	LPSTR p;
	int   c;
	HFILE File;
	static OFSTRUCT Of;

	for (p=TagsFile; *p && *p!=',' && *p!=';'; ++p);
	c = *p;
	*p = '\0';
	if (*TagsFile) {
		File = OpenFile(TagsFile, &Of, OF_READ);
		if (c) {
			*p = c;
			TagsFile = ++p;
		} else TagsFile = p;
	} else File = HFILE_ERROR;
	return (File);
}

static int Fill;

static int NextChar(HFILE hf)
{	static char	Buf[128];
	static int	Index;

	if (Index >= Fill) {
		Index = 0;
		if ((Fill = _lread(hf, Buf, sizeof(Buf))) <= 0) {
			Fill = 0;
			return ('\0');
		}
	}
	return (Buf[Index++]);
}

static VOID CombinePath(LPSTR Buffer, int Size)
{	LPSTR p1 = TagsFile, p2;

	while (p1 > Tags) {
		switch (*--p1) {
			case ',': case ';':
				if (p1 == TagsFile-1) continue;
				/*FALLTHROUGH*/
			case '/': case '\\':
				break;
			default:
				continue;
		}
		break;
	}
	if (*p1=='/' || *p1=='\\') {
		int i;

		for (p2=p1; p2>Tags && p2[-1]!=',' && p2[-1]!=';'; --p2);
		if ((i = p1 - p2 + 1) < Size - lstrlen(Buffer)) {
			_fmemmove(Buffer + i, Buffer, lstrlen(Buffer) + 1);
			_fmemcpy (Buffer, p2, i);
		}
	}
}

extern char Buffer[300];

BOOL Tag(PSTR Identifier, WORD Flags)
	/* Flags: 1=change file even if modified (command ":tag! ...")
	 *		  2=display tag command in status line
	 */
{	HFILE hf;
	PSTR  p;

	if (Flags & 2) {
		wsprintf(Buffer, ":tag%s %s",
			(LPSTR)(Flags & 1 ? "!" : ""), (LPSTR)Identifier);
		NewStatus(0, Buffer, NS_BUSY);
	}
	TagsFile = Tags;
	StartInterruptCheck();
	while (*TagsFile) {
		if ((hf = OpenNextTagsFile()) != HFILE_ERROR) {
			int c, i, Delimiter;

			Fill = 0;
			do {
				p = Identifier;
				for (;;) {
					if (!(c = NextChar(hf))) break;
					if (c==' ' || c=='\t') {
						BOOL ClearStatus = FALSE;

						if (p==Identifier) continue;
						if (*p) break;

						/*matched, extract file name...*/
						do; while ((c=NextChar(hf)) == ' ' || c=='\t');
						lstrcpy(TagCommand, ":e ");
						i = 3;
						if (Flags & 1) TagCommand[2] = '!';
						{	BOOL WithinQuotes = FALSE, Done = FALSE;
							do {
								switch (c) {
									case ' ':
									case '\t': if (WithinQuotes) break;
											   /*FALLTHROUGH*/
									case '\0':
									case '\r':
									case '\n': Done = TRUE;
											   break;
									case '"':  WithinQuotes ^= TRUE^FALSE;
								}
								if (Done) break;
								TagCommand[i] = c;
								c = NextChar(hf);
							} while (++i < sizeof(TagCommand)-1);
						}
						TagCommand[i] = '\0';

						PushTag();
						if (TagCommand[3]!='\\' && TagCommand[3]!='/'
												&& TagCommand[4]!=':')
							CombinePath(TagCommand+3, sizeof(TagCommand)-3);
						if (lstrcmpi(TagCommand+3, CurrFile)) {
							if (!CommandExec(TagCommand)) {
								_lclose(hf);
								NewStatus(0, "", NS_NORMAL);
								Enable();
								PopTag(FALSE);
								ShowEditCaret();
								return (FALSE);
							}
						} else ClearStatus = Flags & 2;

						/*extract positioning command now...*/
						while (c==' ' || c=='\t') c = NextChar(hf);
						i = 1;
						Delimiter = '\0';
						while (c && c!='\r' && c !='\n') {
							if (c == Delimiter) Delimiter = '\0';
							else if (Delimiter == '\0') {
								if (c=='/' || c=='?') Delimiter = c;
								else if (c==';') break;
							}
							TagCommand[i] = c;
							if (++i == sizeof(TagCommand)-1) break;
							if (c == '\\') {
								c = NextChar(hf);
								if (c!='\0' && c!='\r' && c!='\n') {
									TagCommand[i] = c;
									if (++i == sizeof(TagCommand)-1) break;
									c = NextChar(hf);
								}
							} else c = NextChar(hf);
						}
						_lclose(hf);
						TagCommand[i] = '\0';
						{	BOOL SaveMagic		= MagicFlag;
							BOOL SaveIgnoreCase	= IgnoreCaseFlag;
							BOOL SaveWrapScan	= WrapScanFlag;

							SaveMatchList();
							MagicFlag	   =
							IgnoreCaseFlag = FALSE;
							WrapScanFlag   = TRUE;
							if (!CommandExec(TagCommand)) ClearStatus = FALSE;
							WrapScanFlag   = SaveWrapScan;
							IgnoreCaseFlag = SaveIgnoreCase;
							MagicFlag	   = SaveMagic;
							RestoreMatchList();
						}
						Enable();
						ShowEditCaret();
						if (ClearStatus) NewStatus(0, "", NS_NORMAL);
						return (TRUE);
					}
					if (c != *p) break;
					++p;
					continue;
				}
				while (c && c!='\n') c = NextChar(hf);
				if (CheckInterrupt()) {
					TagsFile = "";
					break;
				}
			} while (c);
			_lclose(hf);
		}
	}
	Enable();
	ShowEditCaret();
	Error(Interrupted ? 218 : 329);
	return (FALSE);
}

PSTR ExtractIdentifier(PPOSITION pPos)
{	PSTR		p = TagCommand;
	int			c;
	POSITION	Pos;

	Pos = CurrPos;
	if (!(CharFlags[c = CharAt(&Pos)] & 8)) return (NULL);
	do {
		if (pPos != NULL) *pPos = Pos;
		if (!GoBack(&Pos, 1)) {
			*p++ = c;
			break;
		}
	} while (CharFlags[c = CharAt(&Pos)] & 8);
	while (CharFlags[c = AdvanceAndChar(&Pos)] & 8)
		if (p-TagCommand < sizeof(TagCommand)-1) *p++ = c;
	*p = '\0';
	return (*TagCommand ? TagCommand : NULL);
}

VOID TagCurrentPosition(VOID)
{	PSTR p;

	if ((p = ExtractIdentifier(NULL)) != NULL) Tag(p, 2);
}
