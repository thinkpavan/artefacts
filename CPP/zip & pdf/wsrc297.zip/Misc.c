/********************************************************\
|*                                                      *|
|*   Program:              WinVi                        *|
|*   Author:               Raphael Molle                *|
|*   Compiler:             several                      *|
|*   --------------------- --------------------------   *|
|*   � Copyright 1994-2003 by Raphael Molle, Berlin     *|
|*   � Copyleft by GPL     See file COPYING for more    *|
|*                         info about terms of use      *|
|*                                                      *|
\********************************************************/

/* revision log:
 *     11-Jan-2003	extracted from paint.c
 *     12-Jan-2003	added FormatShell and Help
 */

#include <windows.h>
#include <shellapi.h>
#include "winvi.h"

static char ErrBuf1[200], ErrBuf2[280];
extern char Buffer[300];

void Error(INT StringNo, ...)
{
	LOADSTRING(hInst, StringNo, ErrBuf1, sizeof(ErrBuf1));
	if (!*ErrBuf1) return;
	wvsprintf(Buffer, ErrBuf1, (char*)(&StringNo+1));
	NewStatus(0, Buffer, NS_ERROR);
}

char ErrorTitle[16] = {'\0'};

INT ErrorBox(INT Flags, INT StringNo, ...)
{
	LOADSTRING(hInst, StringNo, ErrBuf1, sizeof(ErrBuf1));
	if (!*ErrBuf1 /*error string not defined in resource string table*/)
		return(IDCANCEL);
	if (!*ErrorTitle) LOADSTRING(hInst, 314, ErrorTitle, sizeof(ErrorTitle));
	wvsprintf(ErrBuf2, ErrBuf1, (char*)(&StringNo+1));
	return (MessageBox(hwndErrorParent, ErrBuf2,
			Flags & MB_ICONINFORMATION ? ApplName : ErrorTitle, MB_OK | Flags));
}

BOOL Confirm(HWND hParent, INT nQuestion, ...)
{	CHAR Title[20];
	CHAR Format[80];
	CHAR Question[256];
	INT	 Answer;

	LOADSTRING(hInst, 341,		 Title,  sizeof(Title));
	LOADSTRING(hInst, nQuestion, Format, sizeof(Format));
	wvsprintf(Question, Format, (char*)(&nQuestion+1));
	Answer = MessageBox(hParent, Question, Title, MB_YESNO | MB_ICONQUESTION);
	return (Answer == IDYES);
}

INT FormatShell(LPSTR Result, LPSTR FormatString, LPSTR Cmd0, LPSTR Cmd1)
{	LPSTR p;
	INT   Flags = 0, Length = 0;
	BOOL  Cmd1Done = FALSE;

	for (;;) {
		switch (*FormatString++) {
			case '\0':
				if (!Cmd1Done) {
					if (Result != NULL) {
						*Result++ = ' ';
						lstrcpy(Result, Cmd1);
					}
					Length += lstrlen(Cmd1) + 1;
				} else if (Result != NULL) *Result = '\0';
				return (Length);

			case '%':
				switch (*FormatString++) {
					case '0':	p = Cmd0;
								break;

					case '1':	p = Cmd1;
								Cmd1Done = TRUE;
								break;

					case '%':	++FormatString;
								/*FALLTHROUGH*/
					default:	--FormatString;
								if (Result != NULL) *Result++ = '%';
								++Length;
								continue;
				}
				while (*p != '\0') {
					if (   (*p == '\'' && Flags & 1)
						|| (*p == '"'  && Flags & 2)
						|| (*p == '\\' && Flags)) {
							if (Result != NULL) *Result++ = '\\';
							++Length;
					}
					if (Result != NULL) *Result++ = *p;
					++Length;
					++p;
				}
				break;

			case '\'':
				Flags ^= 1;
				if (Result != NULL) *Result++ = '\'';
				++Length;
				break;

			case '"':
				Flags ^= 2;
				/*FALLTHROUGH*/
			default:
				if (Result != NULL) *Result++ = FormatString[-1];
				++Length;
		}
	}
}

extern CHAR  QueryString[150];
extern DWORD QueryTime;

BOOL ShowUrl(LPSTR Url)
{	
	BYTE  Command[260];
	HKEY  Key;
	DWORD Type;
	BYTE  Value[180];
	DWORD Size;

	do {	/*no loop, for break only*/
		Key = INVALID_HANDLE_VALUE;
		if (RegOpenKeyEx(HKEY_CLASSES_ROOT, ".htm", 0, KEY_QUERY_VALUE, &Key)
			!= ERROR_SUCCESS) break;
		Size = sizeof(Value);
		if (RegQueryValueEx(Key, NULL, NULL, &Type, Value, &Size)
			!= ERROR_SUCCESS) break;
		RegCloseKey(Key);
		Key = INVALID_HANDLE_VALUE;
		if (lstrlen(Value) > sizeof(Value) - 20) break;
		lstrcat(Value, "\\shell\\open\\command");
		if (RegOpenKeyEx(HKEY_CLASSES_ROOT, Value, 0, KEY_QUERY_VALUE, &Key)
			!= ERROR_SUCCESS) break;
		Size = sizeof(Value);
		if (RegQueryValueEx(Key, NULL, NULL, &Type, Value, &Size)
			!= ERROR_SUCCESS) break;
		RegCloseKey(Key);
		if (FormatShell(NULL, Value, "", Url) >= sizeof(Command)) break;
		FormatShell(Command,  Value, "", Url);
		WinExec(Command, SW_NORMAL);
		if (lstrlen(Command) < sizeof(QueryString)) {
			lstrcpy(QueryString, Command);
			QueryTime = GetTickCount();
		}
		return (TRUE);
	} while (FALSE);
	if (Key != INVALID_HANDLE_VALUE) RegCloseKey(Key);
	return (FALSE);
}

PCSTR HelpAnchors[] = {
	/*HelpAll*/				NULL,
	/*HelpEditTextmode*/	"EditTextmode",
	/*HelpEditHexmode*/		"EditHexmode",
	/*HelpInsertmode*/		"Insertmode",
	/*HelpReplacemode*/		"Replacemode",
	/*HelpEditC*/			"EditC",
	/*HelpEditD*/			"EditD",
	/*HelpEditY*/			"EditY",
	/*HelpEditZ*/			"EditZ",
	/*HelpEditMark*/		"EditMark",
	/*HelpEditFT*/			"EditFT",
	/*HelpEditZZ*/			"EditZZ",
	/*HelpEditShift*/		"EditShift",
	/*HelpEditShell*/		"EditShell",
	/*HelpEditDoublequote*/	"EditDoublequote",
	/*HelpPrint*/			"Print",
	/*HelpSearch*/			"Search",
	/*HelpSearchDlg*/		"SearchDlg",
	/*HelpSettingsProfile*/	"SettingsProfile",
	/*HelpSettingsFiletype*/"SettingsFiletype",
	/*HelpSettingsDisplay*/	"SettingsDisplay",
	/*HelpSettingsEdit*/	"SettingsEdit",
	/*HelpSettingsFiles*/	"SettingsFiles",
	/*HelpSettingsMapping*/	"SettingsMapping",
	/*HelpSettingsShell*/	"SettingsShell",
	/*HelpSettingsColors*/	"SettingsColors",
	/*HelpSettingsFonts*/	"SettingsFonts",
	/*HelpSettingsPrint*/	"SettingsPrint",
	/*HelpSettingsLanguage*/"SettingsLang",
	/*HelpExCommand*/		"ExCommand",
	/*HelpExRead*/			"ExRead",
	/*HelpExEdit*/			"ExEdit",
	/*HelpExNext*/			"ExNext",
	/*HelpExRewind*/		"ExRewind",
	/*HelpExWrite*/			"ExWrite",
	/*HelpExFilename*/		"ExFilename",
	/*HelpExArgs*/			"ExArgs",
	/*HelpExVi*/			"ExVi",
	/*HelpExCd*/			"ExCd",
	/*HelpExTag*/			"ExTag",
	/*HelpExShell*/			"ExShell",
	/*HelpExSubstitute*/	"ExSubstitute"
};
PCSTR		HelpUrlPrefix = "file://c:/Bin/WinViNfo.htm";
HELPCONTEXT	HelpContext;

VOID Help(VOID)
{	extern LPSTR HelpURL;

	if (HelpContext >= 0
			&& HelpContext < sizeof(HelpAnchors) / sizeof(HelpAnchors[0])) {
		CHAR Url[260], *p;

		lstrcpyn(Url, HelpURL, sizeof(Url));
		while ((p = strstr(Url, "%EXEPATH")) != NULL) {
			PSTR Tail = NULL;

			if (!AllocString(&Tail, p + 8)) break;
			if (!GetModuleFileName(hInst, p, sizeof(Url) - (p - Url))) break;
			while (*p != '\0') {
				if (*p == '\\') *p = '/';
				++p;
			}
			do; while (--p > Url && *p != '/' && *p != '\\');
			lstrcpyn(p, Tail, sizeof(Url) - (p - Url));
			_ffree(Tail);
		}
		while ((p = strstr(Url, "%LANG")) != NULL) {
			PSTR p2;

			p2 = Language ==  7000 ? "de" :
				 Language == 10000 ? "es" :
				 Language == 12000 ? "fr" : "en";
			lstrcpy(p, p2);
			memmove(p + 2, p + 5, lstrlen(p + 4));
		}
		if (HelpContext != HelpAll && lstrlen(HelpAnchors[HelpContext])
									  + lstrlen(Url) + 1 < sizeof(Url))
			lstrcat(Url, HelpAnchors[HelpContext]);
		else {
			INT Len = lstrlen(Url);

			if (Len && Url[--Len] == '#') Url[Len] = '\0';
		}
		ShowUrl(Url);
	}
}
