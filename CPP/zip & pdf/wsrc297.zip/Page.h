/********************************************************\
|*                                                      *|
|*   Program:              WinVi                        *|
|*   Author:               Raphael Molle                *|
|*   Compiler:             several                      *|
|*   --------------------- --------------------------   *|
|*   � Copyright 1994-2002 by Raphael Molle, Berlin     *|
|*   � Copyleft by GPL     See file COPYING for more    *|
|*                         info about terms of use      *|
|*                                                      *|
\********************************************************/

/* revision log:
 *		3-Dec-2000	first publication of this source file
 */

#define PAGESIZE	 4000
#define PAGESPERSEGMENT 8

typedef struct tagPAGE {
	LPBYTE		   PageBuf;				 /*character buffer of page			*/
	struct tagPAGE FAR *Next, FAR *Prev; /*page chaining					*/
	ULONG		   LastAccess;			 /*last access (used for paging)	*/
	LONG		   PageFilePos;			 /*position on paging file			*/
	UINT		   Fill;				 /*used amount of bytes in PageBuf	*/
	UINT		   PageNo;				 /*length of chain in Prev			*/
	ULONG		   Newlines;			 /*no of newline character sequences*/
	DWORD		   Flags;				 /*page status flags				*/
} PAGE, *PPAGE, FAR *LPPAGE;
extern LPPAGE FirstPage, LastPage;

#define ISSAFE	   1					 /*bits in PAGE.Flags*/
#define CHECK_CRLF 2

typedef struct tagPOSITION {
	LPPAGE p;
	UINT   i;
} POSITION, *PPOSITION;
extern POSITION ScreenStart, CurrPos;

typedef struct {
	POSITION Pos;
	ULONG	 ByteCount;
	ULONG	 Pixels;			/*line width needed for horizontal scrollbar*/
	INT 	 nthContdLine;
	INT 	 Flags;
} LINEINFO, *PLINEINFO;
extern PLINEINFO LineInfo;
/*LineInfo:		   describes visible screen lines and one invisible line*/

/*Flags used in LineInfo.Flags...*/
#define LIF_VALID			 1	/*position is correct						  */
#define LIF_CONTD_NEXTLINE	 2	/*line has no eol character (continued or EOF)*/
#define LIF_EMPTY_LINE		 4	/*special cursor for empty lines			  */
#define LIF_EOF 			 8	/*line displayed as eof ('~')				  */
#define LIF_REFRESH_LINE	16	/*line must be repainted					  */
#define LIF_REFRESH_BKGND	32	/*moved background should be refreshed		  */

extern BYTE CharFlags[260], MapTable[2][260];
#define C_CRLF	256
#define C_EOF	257
#define C_ERROR 258
#define C_UNDEF 259

extern POSITION SelectStart;
extern BOOL		Selecting;
extern ULONG	SelectBytePos;

/*paint.c*/
void   Jump(PPOSITION);
long   NewPosition(PPOSITION);
int    ComparePos(PPOSITION, PPOSITION);
void   InvalidateArea(PPOSITION, LONG, UINT);

/*file.c*/
void   SetAltFileName(LPCSTR, PPOSITION);

/*input.c*/
void   FindValidPosition(PPOSITION, WORD);
void   AdvanceToCurr(PPOSITION, /*INT,*/ INT);

/*search.c*/
BOOL   SearchIt(PPOSITION, INT);
BOOL   SearchAndStatus(PPOSITION, WORD);
BOOL   BuildReplaceString(PBYTE, LONG *, PPOSITION, LONG, WORD);

/*page.c*/
void   GetSystemTmpDir(PSTR, INT);
BOOL   IncompleteLastLine(void);
LPPAGE NewPage(void);
BOOL   ReloadPage(LPPAGE);
void   FreeAllPages(void);
void   UnsafePage(PPOSITION);
BOOL   Reserve(PPOSITION, INT, WORD);
int    CharAt(PPOSITION);
int    CharAndAdvance(PPOSITION);
int    AdvanceAndChar(PPOSITION);
ULONG  GoBack(PPOSITION, ULONG);
int    GoBackAndChar(PPOSITION);
ULONG  Advance(PPOSITION, ULONG);
int    CountNewlinesInBuf(LPBYTE, INT, LONG[5]);
void   CorrectLineInfo(LPPAGE, UINT, LPPAGE, UINT, ULONG, INT);
ULONG  CountBytes(PPOSITION);
ULONG  CountLines(PPOSITION);
void   VerifyPageStructure(void);

/*insdel.c*/
BOOL   InsertBuffer(LPSTR, ULONG, WORD);
BOOL   Yank(PPOSITION, ULONG, WORD);
BOOL   EnterDeleteForUndo(PPOSITION, ULONG, WORD);
BOOL   EnterInsertForUndo(PPOSITION, ULONG);

/*tags.c*/
PSTR   ExtractIdentifier(PPOSITION);
