/********************************************************\
|*                                                      *|
|*   Program:              WinVi                        *|
|*   Author:               Raphael Molle                *|
|*   Compiler:             several                      *|
|*   --------------------- --------------------------   *|
|*   � Copyright 1994-2004 by Raphael Molle, Berlin     *|
|*   � Copyleft by GPL     See file COPYING for more    *|
|*                         info about terms of use      *|
|*                                                      *|
\********************************************************/

/* revision log:
 *      3-Dec-2000	first publication of source code
 *     24-Dec-2000	dialogbox for "Insert File" (:r) requires file to exist
 *     22-Jun-2002	explicit directory specification for WinMe and WinXP
 *	   20-Jul-2002	allow writing when executing shell command
 *     22-Jul-2002	use of private myassert.h
 *     29-Jul-2002	reduce flicker by earlier graying save button after write
 *     15-Aug-2002	check of ViewOnly flag before inserting file (":r")
 *     12-Sep-2002	+EBCDIC quick hack (Christian Franke)
 *     25-Oct-2002	keep previous Interruptable flag after write operations
 *      8-Jan-2003	not asking for save if file only contains one CR or LF
 *     10-Jan-2003	configurable contents for new files (CR/LF, CR or LF)
 */

#define _WIN32_WINNT 0x0400	/*needed for OPENFILENAME definition in commdlg.h*/

#include <windows.h>
#include <shellapi.h>
#include <commdlg.h>
#include <string.h>
#include <malloc.h>
#include "myassert.h"
#include "winvi.h"
#include "map.h"
#include "page.h"

#if !defined(WIN32)
#	include <cderr.h>
#	include <dos.h>
#	include <direct.h>
#	include <ctype.h>
#	include <io.h>
#endif

extern LONG  xOffset;
extern CHAR  QueryString[150];
extern DWORD QueryTime;
extern BOOL  ReadOnlyParam;

OPENFILENAME Ofn = {0};
CHAR		 Buffer[300], AltFileName[260];
static CHAR	 CustFilter[262] = "\0*.*\0";
static CHAR	 CurrFileName[262] = ".\\";
static CHAR	 FileTitle[260];
static CHAR	 SmallBuf[40];
CONST CHAR	 *CrLfAttribute = "";
LONG		 AltFilePos;
UINT		 AltFileCset;
BOOL		 NotEdited = FALSE;
PSTR		 Brackets = "\253%s\273";
POSITION	 ReadPos;

/*CharFlags:
 *		1:	line terminating character (NUL, CR, LF, CR_LF, RS)
 *		2:	non-display character (shown with caret or hex: ^A...^_, 7f...9f)
 *		4:	used but no meaning yet
 *		8:	letter/digit/underline (for word detection)
 *	   16:	space (TAB, BLANK)
 *	   32:	sentinel character (EOF, ERROR)
 *	   64:	path separator characters ('\\' and '/')
 *	 0x80:	not used yet
 */
BYTE CharFlags[260] = {
	3,2,2,2,2,2,2,2, 2,18,3,2,2,3,2,2,	2,2,2,2,2,2,2,2, 2,2,2,2,2,2,3,2,
   16,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,64,	8,8,8,8,8,8,8,8, 8,8,0,0,0,0,0,0,
	0,8,8,8,8,8,8,8, 8,8,8,8,8,8,8,8,	8,8,8,8,8,8,8,8, 8,8,8,0,64,0,0,8,
	0,8,8,8,8,8,8,8, 8,8,8,8,8,8,8,8,	8,8,8,8,8,8,8,8, 8,8,8,0,0,0,0,2,

	2,2,0,0,0,0,0,0, 0,0,8,0,8,2,2,2,	2,0,0,0,0,0,0,0, 0,0,8,0,8,2,2,8,
	0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,	0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
	8,8,8,8,8,8,8,8, 8,8,8,8,8,8,8,8,	8,8,8,8,8,8,8,0, 8,8,8,8,8,8,8,8,
	8,8,8,8,8,8,8,8, 8,8,8,8,8,8,8,8,	8,8,8,8,8,8,8,0, 8,8,8,8,8,8,8,8,

	3, 32+7, 32+7, 0 /*CR/LF, EOF, error, undef*/
};

/*MapTable[0] contains OEM character set replacement characters.
 *MapTable[1] contains EBCDIC replacement characters.
 */
BYTE MapTable[2][260] = {{
	0,1,2,3,4,5,6,7,				8,9,10,11,12,13,14,15,
			16,17,18,19,20,21,22,23,		24,25,26,27,28,29,30,31,
	32,33,34,35,36,37,38,39,		40,41,42,43,44,45,46,47,
			48,49,50,51,52,53,54,55,		56,57,58,59,60,61,62,63,
	64,65,66,67,68,69,70,71,		72,73,74,75,76,77,78,79,
			80,81,82,83,84,85,86,87,		88,89,90,91,92,93,94,95,
	96,97,98,99,100,101,102,103,	104,105,106,107,108,109,110,111,
			112,113,114,115,116,117,118,119, 120,121,122,123,124,125,126,127,
	0307,0374,0351,0342,0344,0340,0345,0347,
						0352,0353,0350,0357,0356,0354,0304,0305,
			0311,0346,0306,0364,0366,0362,0373,0371,
						0377,0326,0334,0242,0243,0245,127,0204,
	0341,0355,0363,0372,0361,0321,0252,0272,
						0277,127,0254,0275,0274,0241,0253,0273,
			0225,0225,0225,'|','|','|','|','+', '+','|','|','+','+','+','+','+',
	'+',0227,0227,'|',0227,'+','|','|', '+','+',0227,0227,'|',0227,'+',0227,
			0227,0227,0227,'+','+','+','+','+',
						'+','+','+','=','_','|','|',0257,
	127,0337,127,127,127,127,127,127, 127,127,127,127,127,127,127,127,
			127,0261,127,127,127,127,0367,127,
			  			0272,0225,0267,127,127,0262,127,0267,
	0311, '~', 0114, 0363
},{

	/* EBCDIC => ASCII Table */
	#define xxx 127
	/*       x0,  x1   x2   x3   x4   x5   x6   x7
					   x8   x9   xA   xB   xC   xD   xE   xF */
	/*0x*/  xxx, xxx, xxx, xxx, xxx,'\t', xxx, xxx,
					  xxx, xxx, xxx, xxx, xxx, xxx, xxx, xxx,
	/*1x*/  xxx, xxx, xxx, xxx, xxx, xxx, xxx, xxx,
					  xxx, xxx, xxx, xxx, xxx, xxx, xxx, xxx,
	/*2x*/  xxx, xxx, xxx, xxx, xxx,'\n', xxx, xxx,
					  xxx, xxx, xxx, xxx, xxx, xxx, xxx, xxx,
	/*3x*/  xxx, xxx, xxx, xxx, xxx, xxx, xxx, xxx,
					  xxx, xxx, xxx, xxx, xxx, xxx, xxx, xxx,
	/*4x*/  ' ', xxx, xxx, xxx, xxx, xxx, xxx, xxx,
					  xxx, xxx, '[', '.', '<', '(', '+', '!',
	/*5x*/  '&', xxx, xxx, xxx, xxx, xxx, xxx, xxx,
					  xxx, xxx, ']', '$', '*', ')', ';', '^',
	/*6x*/  '-', '/', xxx, xxx, xxx, xxx, xxx, xxx,
					  xxx, xxx, '|', ',', '%', '_', '>', '?',
	/*7x*/  xxx, xxx, xxx, xxx, xxx, xxx, xxx, xxx,
					  xxx, '`', ':', '#', '@','\'', '=', '"',
	/*8x*/  xxx, 'a', 'b', 'c', 'd', 'e', 'f', 'g',
					  'h', 'i', xxx, xxx, xxx, xxx, xxx, xxx,
	/*9x*/  xxx, 'j', 'k', 'l', 'm', 'n', 'o', 'p',
					  'q', 'r', xxx, xxx, xxx, xxx, xxx, xxx,
	/*Ax*/  xxx, '~', 's', 't', 'u', 'v', 'w', 'x',
					  'y', 'z', xxx, xxx, xxx, xxx, xxx, xxx,
	/*Bx*/  xxx, xxx, xxx, xxx, xxx, xxx, xxx, xxx,
					  xxx, xxx, xxx, xxx, xxx, xxx, xxx, xxx,
	/*Cx*/  '{', 'A', 'B', 'C', 'D', 'E', 'F', 'G',
					  'H', 'I', xxx, xxx, xxx, xxx, xxx, xxx,
	/*Dx*/  '}', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
					  'Q', 'R', xxx, xxx, xxx, xxx, xxx, xxx,
	/*Ex*/ '\'', xxx, 'S', 'T', 'U', 'V', 'W', 'X',
					  'Y', 'Z', xxx, xxx, xxx, xxx, xxx, xxx,
	/*Fx*/  '0', '1', '2', '3', '4', '5', '6', '7',
					  '8', '9', xxx, xxx, xxx, xxx, xxx, xxx,
    0311, '~',0114,0363  /*CR/LF, EOF, error, undef (same as in MapTable[0])*/
}};

#undef xxx


void SetUnsafe(void)
{
	if (!Unsafe) {
		Unsafe = TRUE;
		EnableToolButton(IDB_SAVE, TRUE);
		GenerateTitle(TRUE);
	}
}

void SetSafe(BOOL FileChanged)
{
	if (Unsafe) {
		Unsafe = FALSE;
		GenerateTitle(TRUE);
		if (FileChanged) SetSafeForUndo(TRUE);
	}
}

#if defined(WIN32)
	FILETIME LastTime, TmpTime;
    #define _lclose(hf) CloseHandle((HANDLE)(hf))
#else
	OFSTRUCT LastOf,   TmpOf;
#endif

void CheckReadOnly(void)
{
	if (ReadOnlyParam || ReadOnlyFlag || ViewOnlyFlag) ReadOnlyFile = TRUE;
	else if (!NotEdited && *CurrFile) {
		#if defined(WIN32)
			HANDLE hf;

			if ((hf = CreateFile(CurrFile, GENERIC_READ,
								 FILE_SHARE_READ | FILE_SHARE_WRITE,
								 NULL, OPEN_EXISTING,
								 FILE_ATTRIBUTE_NORMAL,
								 NULL)) != INVALID_HANDLE_VALUE) {
				BY_HANDLE_FILE_INFORMATION FileInfo;
				if (GetFileInformationByHandle(hf, &FileInfo))
					ReadOnlyFile = 0 !=
						(FileInfo.dwFileAttributes & FILE_ATTRIBUTE_READONLY);
				CloseHandle(hf);
			}
		#else
			unsigned Attr;

			/*WARNING: CurrFile MUST be a pointer into DS!*/
			if (_dos_getfileattr(*(PSTR*)&CurrFile, &Attr)==0)
				if (Attr & _A_RDONLY) ReadOnlyFile = TRUE;
		#endif
	}
}

BOOL AskForSave(HWND hwndParent, WORD Flags)
	/*Flags: 1=check auto-write
	 *		 2=called from ":cd", different MessageBox if unsafe
	 */
{	INT			i, c;
	LPSTR		p;
	POSITION	StartPos;
	static CHAR	Str[120];

	if (!Unsafe || CommandWithExclamation) return (TRUE);
	StartPos.p = FirstPage;
	StartPos.i = 0;
	c = CharAndAdvance(&StartPos);
	i = (c == C_EOF || c == C_CRLF || c == '\r' || c == '\n')
		&& CharAt(&StartPos) == C_EOF ? IDNO : IDCANCEL;
	CheckReadOnly();
	if (ReadOnlyFile) {
		LOADSTRING(hInst, (Flags & 2 ? 244 : 207) + (*CurrFile=='\0'),
				   Str, sizeof(Str));
		p = _fcalloc(lstrlen(Str) + lstrlen(CurrFile) + 1, 1);
		if (p != NULL) {
			wsprintf(p, Str, (LPSTR)CurrFile);
			if (i != IDNO) {
			   i = MessageBox(hwndParent, p, ApplName,
							  MB_OKCANCEL | MB_ICONEXCLAMATION | MB_DEFBUTTON2);
			   if (i == IDOK) i = IDNO;
			}
		}
	} else {
		if (Flags&1 && AutoWriteFlag && *CurrFile!='\0')
			return (WriteCmd(-1, -1, "", 0));
		LOADSTRING(hInst, 205 + (*CurrFile=='\0'), Str, sizeof(Str));
		p = _fcalloc(lstrlen(Str) + lstrlen(CurrFile) + 1, 1);
		if (p != NULL) {
			wsprintf(p, Str, (LPSTR)CurrFile);
			if (i != IDNO)
				i = MessageBox(hwndParent, p, ApplName,
							   MB_YESNOCANCEL | MB_ICONQUESTION);
		}
	}
	if (p != NULL) _ffree(p);
	return (i==IDNO || (i==IDYES && WriteCmd(-1, -1, "", 0)));
}

void LowerCaseFname(LPSTR Fname)
{
	if (!LcaseFlag) return;
	AnsiLowerBuff(Fname, lstrlen(Fname));
}

extern CHAR FileNameBuf2[260];

void InitOfn(HWND hParent, WORD Flags)
	/*Flags: 1=Save dialog instead of open,
	 *		 2=Read command (no CREATEPROMPT)
	 */
{	static CHAR AllFilter[30];

	if (!(Flags & 1)) *FileName = '\0';
	if (!*AllFilter) {
		LOADSTRING(hInst, 291, AllFilter, sizeof(AllFilter));
		SeparateAllStrings(AllFilter);
	}
	#if defined(WIN32)
		GetCurrentDirectory(sizeof(FileNameBuf2), FileNameBuf2);
	#else
		_getcwd(FileNameBuf2, sizeof(FileNameBuf2));
	#endif
	Ofn.lStructSize 	  = sizeof(OPENFILENAME);
	Ofn.hwndOwner		  = hParent;
	Ofn.hInstance		  = hInst;
	Ofn.lpstrFilter 	  = AllFilter;
	Ofn.lpstrCustomFilter = CustFilter;
	Ofn.nMaxCustFilter	  = sizeof(CustFilter);
	Ofn.nFilterIndex	  = 1;
	Ofn.lpstrFile		  = FileName;
	Ofn.nMaxFile		  = sizeof(FileName);
	Ofn.lpstrFileTitle	  = FileTitle;
	Ofn.nMaxFileTitle	  = sizeof(FileTitle);
	Ofn.lpstrInitialDir	  = FileNameBuf2;	/*new: explicit dir specification*/
											/*    required in WinMe and WinXP*/
	if (Flags & 2) {
		static CHAR Title[30];

		if (!*Title) LOADSTRING(hInst, 280, Title, sizeof(Title));
		Ofn.lpstrTitle	  = *Title ? (LPSTR)Title : (LPSTR)NULL;
	} else Ofn.lpstrTitle = NULL;
	if (Flags & 1)
		Ofn.Flags		  = OFN_HIDEREADONLY  | OFN_OVERWRITEPROMPT;
	else {
		Ofn.Flags = Flags & 2
					? OFN_FILEMUSTEXIST | OFN_HIDEREADONLY | OFN_NOCHANGEDIR
					: OFN_PATHMUSTEXIST | OFN_CREATEPROMPT;
		if (ReadOnlyFlag || ViewOnlyFlag) Ofn.Flags |= OFN_READONLY;
	}
	Ofn.lpstrDefExt 	  = "";
}

void SetAltFileName(LPCSTR FName, PPOSITION Pos)
{
	lstrcpy(AltFileName, FName);
	AltFilePos  = Pos ? CountBytes(Pos) : 0;
	AltFileCset = CharSet;
}


void WatchMessage(LPSTR FileName)
{
	#if defined(WIN32)
		CHAR Message[340], Format[80];

		if (!LOADSTRING(hInst, 253, Format, sizeof(Format)))
			lstrcpy(Format, "Modified on disk: %s");
		wsprintf(Message, Format, FileName);
		MessageBox(hwndMain, Message, ApplName, MB_OK | MB_ICONEXCLAMATION);
	#endif
}

#if defined(WIN32)

static CHAR	  WatchName[MAX_PATH+2];
static HANDLE WatchEvents[2] = {INVALID_HANDLE_VALUE, 0};
							   /*0: ChangeNotification, 1:QuitEvent*/

DWORD WINAPI WatchFileThread(LPVOID Unused)
{	LPSTR	 p1, p2;
	FILETIME FileTime;
	BOOL	 Done;

	PARAM_NOT_USED(Unused);
	p1 = strrchr(WatchName, '\\');
	p2 = strrchr(WatchName, '/' );
	if (p1 != NULL || p2 != NULL) {
		if (p1 == NULL || (p2 != NULL && p2 > p1)) p1 = p2;
		*p1++ = '\0';
	} else {
		memmove(p1=WatchName+2, WatchName, lstrlen(WatchName)+1);
		WatchName[0] = '.';
		WatchName[1] = '\0';
	}
	WatchEvents[0] = FindFirstChangeNotification(WatchName, FALSE,
					   FILE_NOTIFY_CHANGE_SIZE | FILE_NOTIFY_CHANGE_LAST_WRITE);
	if (WatchEvents[0] == INVALID_HANDLE_VALUE) return (1);
	p1[-1] = '\\';
	Done = FALSE;
	do {
		HANDLE hFile;
		DWORD  WaitResult;
		INT    i;

		WaitResult = WaitForMultipleObjects(2, WatchEvents, FALSE, INFINITE);
		switch (WaitResult) {
			case WAIT_OBJECT_0:
				/*directory modified*/
				break;
			default:
				/*quit signal or error*/
				Done = TRUE;
				break;
		}
		if (Done) break;
		for (i=0; i<3; ++i) {
			hFile = CreateFile(WatchName, 0, FILE_SHARE_READ | FILE_SHARE_WRITE,
							   NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL,
							   NULL);
			if (hFile != INVALID_HANDLE_VALUE) break;
			Sleep(200);	/*try again after 200 ms...*/
		}
		if (hFile != INVALID_HANDLE_VALUE) {
			BOOL Ok = GetFileTime(hFile, NULL, NULL, &FileTime);

			CloseHandle(hFile);
			if (Ok && (FileTime.dwLowDateTime  != LastTime.dwLowDateTime ||
					   FileTime.dwHighDateTime != LastTime.dwHighDateTime)) {
				static BOOL FlashState;

				FlashState = FALSE;
				while (!CaretActive) {
					INT i;

					FlashWindow(hwndMain, FlashState ^= TRUE ^ FALSE);
					for (i=0; i<5 && !CaretActive; ++i) Sleep(100);
				}
				if (FlashState) FlashWindow(hwndMain, FlashState = FALSE);
				PostMessage(hwndMain, WM_USER+1236, 0, (LPARAM)(LPSTR)p1);
				break;
			}
			Sleep(200);	/*avoid drawbacks from change notification bursts*/
		}
	} while (FindNextChangeNotification(WatchEvents[0]));
	FindCloseChangeNotification(WatchEvents[0]);
	ExitThread(0);		/*...not necessary to warn once more*/
	return (0);
}

#endif

BOOL WatchFile(const CHAR *FileName)
{
	#if defined(WIN32)
		static HANDLE hThread = 0;
		static DWORD  dwThreadId;

		if (WatchEvents[1] == 0) {
			WatchEvents[1] = CreateEvent(NULL, FALSE, FALSE, NULL);
			if (WatchEvents[1] == 0) return (FALSE);
		}
		if (hThread != 0) {
			SetEvent(WatchEvents[1]);
			if (WaitForSingleObject(hThread, 2000) == WAIT_TIMEOUT)
				TerminateThread(hThread, 2);
			CloseHandle(hThread);
		}
		ResetEvent(WatchEvents[1]);
		if (FileName == NULL ||
				(LastTime.dwHighDateTime==0 && LastTime.dwLowDateTime==0)) {
			hThread = 0;
			return (TRUE);
		}
		lstrcpyn(WatchName, (LPSTR)FileName, sizeof(WatchName)-2);
		hThread = CreateThread(NULL, 1024, WatchFileThread, (LPVOID)NULL,
							   0, &dwThreadId);
		return (hThread != 0);
	#else
		return (FALSE);
	#endif
}

INT		   CountedDefaultNl = 1;	/*1=CR/LF, 2=LF, 3=CR*/
extern INT SelectDefaultNewline;
extern INT DefaultNewLine;

VOID SetDefaultNl(VOID)
{	CONST INT  DefaultNls[3]   = {C_CRLF, '\n',	   '\r' };
	CONST CHAR *NlIndicator[3] = {  "", " [Lf]", " [Cr]"};
	INT		   Nl;

	Nl = (SelectDefaultNewline ? SelectDefaultNewline : CountedDefaultNl) - 1;
	DefaultNewLine = DefaultNls [Nl];
	CrLfAttribute  = NlIndicator[Nl];
}

void New(HWND hParent, BOOL SaveAltFile)
{
	PARAM_NOT_USED(hParent);
	if (!AskForSave(hwndMain, 0)) return;
	Unsafe = FALSE;
	EnableToolButton(IDB_SAVE, FALSE);
	DisableUndo();
	NewStatus(0, "", NS_NORMAL);
	if (SaveAltFile && CurrFile && *CurrFile)
		SetAltFileName(CurrFile, &CurrPos);
	CurrFileName[2] = '\0';
	CurrFile = CurrFileName+2;
	NotEdited = FALSE;
	FreeAllPages();
	SwitchToMatchingProfile("");
	if (SelectDefaultNewline > 1) FirstPage->PageBuf[0] = DefaultNewLine;
	else lstrcpy(FirstPage->PageBuf, "\r\n");
	FirstPage->Fill = 2 - (SelectDefaultNewline > 1);
	FirstPage->Newlines = 1;
	LinesInFile = 1;
	CurrCol.ScreenLine = CurrCol.PixelOffset = 0;
	if (!(CountedDefaultNl = SelectDefaultNewline)) CountedDefaultNl = 1;
	SetDefaultNl();
	ReadOnlyFile = ReadOnlyFlag || ViewOnlyFlag;
	InvalidateText();
	GenerateTitle(TRUE);
	NewPosition(&CurrPos);	/*for updating line/col status fields*/
	NewScrollPos();
	WatchFile(NULL);
	ShowEditCaret();
}

void ShowFileName(void)
{
	*Buffer = Brackets[0];
	if (*CurrFile) lstrcpy(Buffer+1, CurrFile);
	else LOADSTRING(hInst, 901, Buffer+1, sizeof(Buffer)-1);
	lstrcat(Buffer, Brackets+3);
	CheckReadOnly();
	if (ReadOnlyFile) {
		LOADSTRING(hInst, 282, SmallBuf, sizeof(SmallBuf));
		lstrcat(Buffer, SmallBuf);
	}
	if (NotEdited)	{
		LOADSTRING(hInst, 283, SmallBuf, sizeof(SmallBuf));
		lstrcat(Buffer, SmallBuf);
	}
	if (Unsafe) {
		LOADSTRING(hInst, 284, SmallBuf, sizeof(SmallBuf));
		lstrcat(Buffer, SmallBuf);
	}
	lstrcat(Buffer, CrLfAttribute);
	LOADSTRING(hInst, 288, SmallBuf, sizeof(SmallBuf));
	wsprintf(Buffer + lstrlen(Buffer), SmallBuf,
			 CountLines(&CurrPos) + 1, LinesInFile + IncompleteLastLine());
	NewStatus(0, Buffer, NS_NORMAL);
}

void FileError(LPCSTR FName, INT DosErrorCode, INT Range)
{	static CHAR ErrStr[60];

	if (DosErrorCode > 0 && DosErrorCode <= Range &&
			LOADSTRING(hInst, DosErrorCode+400, ErrStr, sizeof(ErrStr)) &&
			LOADSTRING(hInst, 114, SmallBuf, sizeof(SmallBuf)))
		wsprintf(Buffer, SmallBuf, (LPCSTR)FName, (LPSTR)ErrStr);
	else {
		if (!LOADSTRING(hInst, 115, SmallBuf, sizeof(SmallBuf)))
			lstrcpy(SmallBuf, "%s: file error %d");
		wsprintf(Buffer, SmallBuf, (LPCSTR)FName, DosErrorCode);
	}
	NewStatus(0, Buffer, NS_ERROR);
}

#if defined(WIN32)

static void File32Error(LPCSTR FName)
{	LPSTR ErrorMessage = NULL;
	DWORD ErrorCode    = GetLastError();

	if (LOADSTRING(hInst, 114, SmallBuf, sizeof(SmallBuf)) &&
		FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER |
					  FORMAT_MESSAGE_FROM_SYSTEM,
					  NULL, ErrorCode,
					  MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
					  (LPSTR)&ErrorMessage, 0, NULL) &&
		ErrorMessage) {
			LPSTR p;
			INT   MaxLen = sizeof(Buffer)-lstrlen(FName)-lstrlen(SmallBuf);

			if (lstrlen(ErrorMessage) > MaxLen) ErrorMessage[MaxLen] = '\0';
			while ((p = strchr(ErrorMessage, '\r')) != NULL ||
				   (p = strchr(ErrorMessage, '\n')) != NULL)
				*p = (p[1]=='\n' && p[2]=='\0') || p[1]=='\0' ? '\0' : ' ';
			wsprintf(Buffer, SmallBuf, (LPCSTR)FName, (LPSTR)ErrorMessage);
			LocalFree(ErrorMessage);
	}
	if (ErrorMessage == NULL) {
		*SmallBuf = '\0';
		if (ErrorCode == ERROR_BAD_PATHNAME)
			LOADSTRING(hInst, 116, SmallBuf, sizeof(SmallBuf));
		if (!*SmallBuf && !LOADSTRING(hInst, 115, SmallBuf, sizeof(SmallBuf)))
			lstrcpy(SmallBuf, "%s: file error %d");
		wsprintf(Buffer, SmallBuf, (LPCSTR)FName, ErrorCode);
	}
	NewStatus(0, Buffer, NS_ERROR);
}

#endif

VOID JumpAbsolute(ULONG SkipBytes)
{
	CurrPos.p = FirstPage;
	if (SkipBytes) {
		do {
			if (SkipBytes < CurrPos.p->Fill) {
				CurrPos.i = (INT)SkipBytes;
				break;
			}
			SkipBytes -= CurrPos.p->Fill;
			CurrPos.p  = CurrPos.p->Next;
			if (CurrPos.p == NULL) {
				CurrPos.p = LastPage;
				CurrPos.i = CurrPos.p->Fill;
				break;
			}
		} while (SkipBytes);
		FindValidPosition(&CurrPos, 4);
	}
	Jump(&CurrPos);
}

static ULONG SkipBytes;
extern BOOL  SuppressPaint;
extern INT	 nCurrFileListEntry;

BOOL OpenFileName(BOOL DontCreate)
{
	InitOfn(hwndMain, (WORD)(DontCreate ? 2 : 0));
	StopMap(TRUE);
	if (!GetOpenFileName(&Ofn)) {
		static CHAR Buf[40];
		DWORD       dwError;

		switch (dwError = CommDlgExtendedError()) {
			case 0:  /*normal cancel*/
				break;
			default: /*error*/
				if (FreeSpareMemory()) break;
				if (!LOADSTRING(hInst, 290, SmallBuf, sizeof(SmallBuf)))
					lstrcpy(SmallBuf, "Unexpected error %04lx");
				wsprintf(Buf, SmallBuf, dwError);
				MessageBox(hwndMain, Buf, NULL, MB_OK | MB_ICONSTOP);
		}
		return (FALSE);
	}
	LowerCaseFname(FileName);
	return (TRUE);
}

BOOL Open(LPCSTR FName, WORD Flags)
	/* Flags: 1=read and insert into current file (command ":read")
	 */
{	INT  hf, i;
	LONG NlCnt[5];
	UINT AltCset = AltFileCset;
	BOOL ReadPosAfterScreenStart, LowerCaseFlag;
	BOOL IsReadOnly = ReadOnlyParam || ReadOnlyFlag || ViewOnlyFlag;

	if (FName != NULL && lstrlen(FName) >= MAX_PATH) {
		Error(411);
		return (FALSE);
	}
	NlCnt[0] = NlCnt[1] = NlCnt[2] = NlCnt[3] = NlCnt[4] = 0;
	if (Flags & 1) {
		if (!FName || !*FName) {
			if (ViewOnlyFlag) {
				Error(236);
				return (FALSE);
			}
			if (!OpenFileName(TRUE)) return (FALSE);
		} else lstrcpy(FileName, FName);
		FName = FileName;
		if (!strchr(FileName, '\\') && !strchr(FileName, '/')) {
			FName += 2;
			memmove(FileName+2, FileName, lstrlen(FileName)+1);
			FileName[0] = '.';
			FileName[1] = '\\';
		}
		SetAltFileName(FName, NULL);
		if (ViewOnlyFlag) {
			Error(236);
			return (FALSE);
		}
	} else {
		MoreFilesWarned = FALSE;
		if (ExecRunning()) {
			Error(236);
			if (*FName) SetAltFileName(FName, NULL);
			return (FALSE);
		}
		if (!AskForSave(hwndMain, 1)) {
			if (*FName) SetAltFileName(FName, NULL);
			return (FALSE);
		}
		LowerCaseFlag = !*FName;
		if (LowerCaseFlag) {
			if (!OpenFileName(FALSE)) {
				#if defined(WIN32)
					SetCurrentDirectory(FileNameBuf2);
				#else
					isalpha(FileNameBuf2[0]) && FileNameBuf2[1]==':'
						? _chdir(FileNameBuf2) || _chdrive(*FileNameBuf2 & 31)
						: _chdir(FileNameBuf2);
				#endif
				return (FALSE);
			}
			IsReadOnly = (Ofn.Flags & OFN_READONLY) != 0;
			nCurrFileListEntry = FindOrAppendToFileList(FileName);
			FName = FileName;
		}
		Unsafe = NotEdited = FALSE;
		EnableToolButton(IDB_SAVE, FALSE);
		DisableUndo();
		if (FName != CurrFile && (CurrFileName[2] || IsAltFile))
			SetAltFileName(CurrFileName+2, &CurrPos);
		lstrcpy(CurrFileName+2, FName);
		if (!LowerCaseFlag) LowerCaseFname(CurrFileName+2);
		CurrFile = CurrFileName+2;
		GenerateTitle(TRUE);
		FName = CurrFile;
		if (CurrFile[1] != ':' && !_fstrchr(CurrFile, '\\') &&
								  !_fstrchr(CurrFile, '/'))
			CurrFile = CurrFileName;
	}
	DragAcceptFiles(hwndMain, FALSE);
	i = wsprintf(Buffer, Brackets, FName);
	LOADSTRING(hInst, 286, Buffer+i, sizeof(Buffer)-i);
	NewStatus(0, Buffer, NS_BUSY);
	if (Flags & 1) {
		#if defined(WIN32)
			hf = (HFILE)
				 CreateFile(FileName, GENERIC_READ,
				 			FILE_SHARE_READ | FILE_SHARE_WRITE,
							NULL, OPEN_EXISTING,
							FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN,
							NULL);
		#else
			hf = OpenFile(FileName, &TmpOf, OF_READ);
		#endif
	} else {
		WatchFile(NULL);
		FreeAllPages();
		#if defined(WIN32)
			hf = (HFILE)
				 CreateFile(CurrFile, GENERIC_READ,
				 			FILE_SHARE_READ | FILE_SHARE_WRITE,
							NULL, OPEN_EXISTING,
							FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN,
							NULL);
		#else
			hf = OpenFile(CurrFile, &LastOf, OF_READ);
		#endif
	}
	if (hf != HFILE_ERROR) do {		/*no loop, for break only*/
		LPPAGE	   Page, NewPg;
		BOOL	   CrAlreadyGot = FALSE, NotFirst = FALSE;
		INT		   PageNo;
		LONG	   Length  = _llseek(hf, 0L, 2);
		LONG	   ToRead  = Length;
		LONG	   FileNls = 0, PageNls, ReadNls;

		_llseek(hf, 0L, 0);
		if (Flags & 1) {
			CurrPos = ReadPos;
			ReadPosAfterScreenStart = ComparePos(&ReadPos, &ScreenStart) > 0;
			if (CurrPos.i) {
				if (CurrPos.i < CurrPos.p->Fill) {
					CharAt(&CurrPos);
					Page = NewPage();
					if (Page == NULL) {
						_lclose(hf);
						Error(313);
						DragAcceptFiles(hwndMain, TRUE);
						return (FALSE);
					}
					assert(Page->PageBuf);
					assert(CurrPos.p->PageBuf);
					_fmemcpy(Page->PageBuf, CurrPos.p->PageBuf + CurrPos.i,
							 Page->Fill  =  CurrPos.p->Fill    - CurrPos.i);
					CurrPos.p->Fill = CurrPos.i;
					Page->Next = CurrPos.p->Next;
					if (Page->Next != NULL) Page->Next->Prev = Page;
					else LastPage = Page;
					CurrPos.p->Next = Page;
					Page->Prev = CurrPos.p;
					Page->Newlines = CurrPos.p->Newlines;
					CurrPos.p->Newlines -= CountNewlinesInBuf
										   (Page->PageBuf, Page->Fill, NULL);
				}
				PageNls = CurrPos.p->Newlines;
			} else PageNls = CurrPos.p->Prev ? CurrPos.p->Prev->Newlines : 0;
			PageNo = CurrPos.p->PageNo;
			if (Length) {
				Page = NewPage();
				if (Page == NULL) {
					_lclose(hf);
					Error(313);
					DragAcceptFiles(hwndMain, TRUE);
					return (FALSE);
				}
				Page->Fill = 0;
				if (CurrPos.i) {
					Page->Next = CurrPos.p->Next;
					if (Page->Next != NULL) Page->Next->Prev = Page;
					else LastPage = Page;
					CurrPos.p->Next = Page;
					Page->Prev = CurrPos.p;
				} else {
					--PageNo;
					Page->Prev = CurrPos.p->Prev;
					if (Page->Prev != NULL) Page->Prev->Next = Page;
					else FirstPage = Page;
					CurrPos.p->Prev = Page;
					Page->Next = CurrPos.p;
				}
				CurrPos.p = Page;
				CurrPos.i = 0;
			} else Page = CurrPos.p;
		} else {
			#if defined(WIN32)
				GetFileTime((HANDLE)hf, NULL, NULL, &LastTime);
				WatchFile(CurrFile);
			#endif
			if (!IsReadOnly) {
				#if defined(WIN32)
					BY_HANDLE_FILE_INFORMATION FileInfo;
					if (GetFileInformationByHandle((HANDLE)hf, &FileInfo) &&
							FileInfo.dwFileAttributes & FILE_ATTRIBUTE_READONLY)
						IsReadOnly = TRUE;
				#else
					unsigned Attr;
					/*WARNING: CurrFile MUST be a pointer into DS!*/
					if (_dos_getfileattr(*(PSTR*)&CurrFile, &Attr)==0)
						if (Attr & _A_RDONLY) IsReadOnly = TRUE;
				#endif
			}
			ReadOnlyFile = IsReadOnly;
			LinesInFile = 0;
			if (IsAltFile) {
				SetCharSet(AltCset, 2);
				UpdateWindow(hwndMain);
			}
			PageNls = PageNo = 0;
			Page = FirstPage;
			CurrFile = CurrFileName+2;
		}
		xOffset = 0;
		Interrupted = FALSE;
		Disable(Length > 50000L);
		SuppressPaint = TRUE;
		while (ToRead > 0) {
			INT len;

			if (NotFirst) {
				NewPg = NewPage();
				if (NewPg == NULL) break;
				NewPg->Next = Page->Next;
				if (NewPg->Next != NULL) NewPg->Next->Prev = NewPg;
				else LastPage = NewPg;
				Page->Next = NewPg;
				NewPg->Prev = Page;
				Page = NewPg;
			} else {
				NotFirst = TRUE;
				NewPg = Page;	/*used as error flag*/
			}
			Page->PageBuf[0] = '\r';
			Page->PageNo = ++PageNo;
			len = _lread(hf, Page->PageBuf+CrAlreadyGot, PAGESIZE-CrAlreadyGot);
			if (len <= 0) {
				/*read error*/
				Page->Fill = 0;
				Page->Newlines = PageNls;
				break;
			}
			ToRead -= len;
			if (CrAlreadyGot) ++len;
			CrAlreadyGot = (ToRead>0 && len && Page->PageBuf[len-1]=='\r');
			if (CrAlreadyGot) --len;
			Page->Fill = len;
			FileNls += ReadNls = CountNewlinesInBuf(Page->PageBuf, len, NlCnt);
			Page->Newlines = PageNls += ReadNls;
			MessageLoop(FALSE);
			if (!hwndMain) {
				_lclose(hf);
				DragAcceptFiles(hwndMain, TRUE);
				return (FALSE);
			}
			if (Interrupted) {
				#if 0
				//	if (MessageBox(hwndMain,"Continue?","Interrupted",MB_YESNO)
				//		== IDNO) break;
				//	Interrupted = FALSE;
				#endif
				break;
			}
		}
		SuppressPaint = FALSE;
		Length -= ToRead;
		_lclose(hf);
		wsprintf(Buffer, Brackets, FName);
		if (!(Flags & 1)) {
			if (ReadOnlyFile && !ExecRunning()) {
				LOADSTRING(hInst, 282, SmallBuf, sizeof(SmallBuf));
				lstrcat(Buffer, SmallBuf);
			}
			CountedDefaultNl = NlCnt[0] > 0		   ? 1 :
							   NlCnt[1] > NlCnt[2] ? 3 :
							   NlCnt[2] > 0		   ? 2 : 1;
			SetDefaultNl();
			lstrcat(Buffer, CrLfAttribute);
		}
		if (TerseFlag) lstrcpy(SmallBuf, " %ld/%ld");
		else LOADSTRING(hInst, 289, SmallBuf, sizeof(SmallBuf));
		wsprintf(Buffer + lstrlen(Buffer), SmallBuf, FileNls, Length);
		NewStatus(0, Buffer, NS_NORMAL);
		if (ToRead > 0) {
			if (NewPg == NULL) {
				/*serious error, error box already confirmed*/
				New(hwndMain, FALSE);
				Page = FirstPage;
			} else if (Interrupted) {
				LOADSTRING(hInst, 218, Buffer, sizeof(Buffer));
				NewStatus(0, Buffer, NS_ERROR);
			} else MessageBox(hwndMain, "Read Error", NULL, MB_OK|MB_ICONSTOP);
			if (!(Flags & 1)) NotEdited = TRUE;
		}
		while ((Page = Page->Next) != NULL) {
			Page->Newlines += FileNls;
			Page->PageNo = ++PageNo;
		}
		LinesInFile += FileNls;
		if (Flags & 1) EnterInsertForUndo(&CurrPos, Length);
		else {
			AddToFileList(FName);
			SwitchToMatchingProfile(FName);
		}
	} while (FALSE);
	else if (Flags & 1) {
		#if defined(WIN32)
			File32Error(FName);
		#else
			FileError(FName, TmpOf.nErrCode, 88);
		#endif
	} else {
		#if defined(WIN32)
			DWORD ErrorValue = GetLastError();
		#else
			DWORD ErrorValue = LastOf.nErrCode;
		#endif

		NotEdited = TRUE;
		CurrPos.p->Fill = 2;
		lstrcpy(CurrPos.p->PageBuf, "\r\n");
		LinesInFile = 1;
		DefaultNewLine = C_CRLF;
		CrLfAttribute = "";
		CurrFile = CurrFileName+2;
		if (DefaultNewLine != C_CRLF) {
			*CurrPos.p->PageBuf = DefaultNewLine;
			--CurrPos.p->Fill;
		}
		if (ErrorValue == 2) {
			i = wsprintf(Buffer, Brackets, (LPSTR)CurrFile);
			LOADSTRING(hInst, 285, Buffer+i, sizeof(Buffer)-i);
			i += lstrlen(Buffer+i);
			ReadOnlyFile = IsReadOnly;
			if (ReadOnlyFile && !ExecRunning())
				LOADSTRING(hInst, 282, Buffer+i, sizeof(Buffer)-i);
			lstrcat(Buffer, CrLfAttribute);
			NewStatus(0, Buffer, NS_NORMAL);
		} else {
			#if defined(WIN32)
				File32Error(CurrFile);
			#else
				FileError(CurrFile, LastOf.nErrCode, 88);
			#endif
		}
		SwitchToMatchingProfile(CurrFile);
	}
	if (Flags & 1) {
		if (ReadPosAfterScreenStart && GoBackAndChar(&CurrPos) != C_EOF) {
			InvalidateArea(&CurrPos, 1, 15);
			UpdateWindow(hwndMain);
			CharAndAdvance(&CurrPos);
		} else Jump(&CurrPos);
	} else JumpAbsolute(SkipBytes);
	NewScrollPos();
	if (Disabled) Enable();
	if (Mode != CommandMode && !DefaultInsFlag) {
		GotChar('\033', 1);
		//Mode = CommandMode;
		//SwitchCursor(SWC_TEXTCURSOR);
	}
	if (!HexEditMode) Position(1, '^', 0);	/*position to first non-space*/
	else {
		NewPosition(&CurrPos);
		ShowEditCaret();
	}
	DragAcceptFiles(hwndMain, TRUE);
	return (hf != HFILE_ERROR);
}

BOOL EditCmd(LPCSTR FName)
{	BOOL Ok;

	SkipBytes = IsAltFile ? AltFilePos : 0;
	if (!FName || !*FName) FName = CurrFile;
	Ok = Open(FName, 0);
	SkipBytes = 0;
	return (Ok);
}

BOOL ReadCmd(LONG Line, LPCSTR FName)
{
	StartUndoSequence();
	if (Line != -1) {
		ReadPos.i = 0;
		ReadPos.p = FirstPage;
	} else {
		ReadPos = CurrPos;
		if (HexEditMode) {
			/*read at current position...*/
			if (Mode != InsertMode) Advance(&ReadPos, 1);
			Line = 0;
		} else Line = 1;
	}
	while (Line--) {
		INT c;

		do; while (!((c = CharFlags[CharAndAdvance(&ReadPos)]) & 1));
		if (c & 0x20) break;
	}
	if (!Open(FName, 1)) return (FALSE);
	SetUnsafe();
	return (TRUE);
}

BOOL NextCmd(LPCSTR FNames)
{	extern INT nCurrFileListEntry;

	while (*FNames == ' ') ++FNames;
	if (*FNames) {
		if (!AskForSave(hwndMain, 1)) return (FALSE);
		ClearFileList();
		do {
			LPCSTR lp = FNames;
			if (*FNames == '"') {
				++FNames;
				do; while (*++lp && *lp != '"');
			} else while (*lp && *lp != ' ') ++lp;
			AppendToFileList(FNames, lp-FNames, 1);
			if (*lp == '"') ++lp;
			while (*lp == ' ') ++lp;
			FNames = lp;
		} while (*FNames);
		nCurrFileListEntry = 0;
		FNames = GetFileListEntry(nCurrFileListEntry);
		if (FNames == NULL) return (FALSE);
	} else {
		FNames = GetFileListEntry(nCurrFileListEntry+1);
		if (FNames == NULL) {
			/*error: no more files*/
			Error(220);
			return (FALSE);
		}
		if (!AskForSave(hwndMain, 1)) return (FALSE);
		++nCurrFileListEntry;
	}
	Unsafe = FALSE;		/*already asked for save*/
	Open(FNames, 0);
	return (TRUE);
}

void FilenameCmd(LPSTR FName)
{
	if (*FName) {
		if (lstrlen(FName) >= MAX_PATH) {
			Error(411);
			return;
		}
		if (CurrFile && *CurrFile) SetAltFileName(CurrFile, NULL);
		lstrcpy(CurrFileName+2, FName);
		CurrFile = CurrFileName + 2;
		GenerateTitle(TRUE);
		EnableToolButton(IDB_SAVE, TRUE);
		NotEdited = TRUE;
		SwitchToMatchingProfile(FName);
		WatchFile(NULL);
	}
	ShowFileName();
}

void Save(LPCSTR FName)
{
	WriteCmd(-1, -1, FName, 0);
}

#if defined(WIN32)
DWORD TimeDiff(FILETIME *q1, FILETIME *q2)
{
	if (q1->dwHighDateTime == q2->dwHighDateTime)
		return (q1->dwLowDateTime >= q2->dwLowDateTime
			  ? q1->dwLowDateTime -  q2->dwLowDateTime
			  : q2->dwLowDateTime -  q1->dwLowDateTime);
	if (q1->dwHighDateTime == q2->dwHighDateTime+1)
		if (q1->dwLowDateTime < q2->dwLowDateTime)
			return (q1->dwLowDateTime - q2->dwLowDateTime);
	if (q2->dwHighDateTime == q1->dwHighDateTime+1)
		if (q2->dwLowDateTime < q1->dwLowDateTime)
			return (q2->dwLowDateTime - q1->dwLowDateTime);
	return (0xffffffff);
}
#endif

BOOL SetSafeAfterWrite;

BOOL WriteCmd(LONG StartLine, LONG EndLine, LPCSTR FName, WORD Flags)
	/*Flags: 1=Write command with '!', don't ask for overwrite
	 */
{	POSITION StartPos, EndPos;
	INT      c = 0;
	BOOL     KeepEnabled = FALSE, AskIfExists = TRUE;
	BOOL     IsCurrFile  = FALSE, Ret = TRUE;
	BOOL	 SetReadOnly = FALSE, ReadOnlyError;
	BOOL	 SavInterruptable = Interruptable;
	LPCSTR   Name = FName;
	LONG     Newlines, Length;
	#if WRITE_WITH_CREAT
		INT	 OpenMode = OF_WRITE | OF_CREATE;
	#else
		INT	 OpenMode = OF_WRITE | OF_REOPEN | OF_VERIFY;
	#endif

	if (FName != NULL && lstrlen(FName) >= MAX_PATH) {
		Error(411);
		return (FALSE);
	}
	SetSafeAfterWrite = TRUE;	/*may also be altered by shell execution*/
	if (!Name) KeepEnabled = TRUE;
	else if (!*Name) {
		Name = CurrFile;
		IsCurrFile  = TRUE;
		AskIfExists = NotEdited;
	} else {
		KeepEnabled = TRUE;
		if (Name[0]=='>' && Name[1]=='>') {
			++Name;
			do; while (*++Name == ' ');
			if (!*Name) {
				Name = CurrFile;
				IsCurrFile = TRUE;
			}
			AskIfExists = FALSE;
			OpenMode = OF_WRITE;
		}
	}
	if (Flags & 1) AskIfExists = FALSE;
	HideEditCaret();
	if (!Name || !*Name) {
		DWORD dwError = 0;

		lstrcpy(FileName, CurrFileName+2);
		InitOfn(hwndMain, 1);
		StopMap(TRUE);
		while (!GetSaveFileName(&Ofn)) {
			static CHAR Buf[40];
			DWORD       LastError = dwError;

			switch (dwError = CommDlgExtendedError()) {
				case 0:	/*normal cancel*/
					break;

				case FNERR_INVALIDFILENAME:
					if (!LastError) {
						*FileName = '\0';
						continue;
					}
					/*FALLTHROUGH*/
				default:
					if (FreeSpareMemory()) continue;
					if (!LOADSTRING(hInst, 290, SmallBuf, sizeof(SmallBuf)))
						lstrcpy(SmallBuf, "Unexpected error %04lx");
					wsprintf(Buf, SmallBuf, dwError);
					MessageBox(hwndMain, Buf, NULL, MB_OK | MB_ICONSTOP);
			}
			#if defined(WIN32)
				SetCurrentDirectory(FileNameBuf2);
			#else
				isalpha(FileNameBuf2[0]) && FileNameBuf2[1]==':'
					? _chdir(FileNameBuf2) || _chdrive(*FileNameBuf2 & 31)
					: _chdir(FileNameBuf2);
			#endif
			ShowEditCaret();
			return(FALSE);
		}
		LowerCaseFname(FileName);
		IsCurrFile = TRUE;
		if (FName==NULL && CurrFile && *CurrFile) {
			/*Save as, remember previous file name...*/
			SetAltFileName(CurrFile, &CurrPos);
			SwitchToMatchingProfile(FileName);
		}
		lstrcpy(CurrFileName+2, FileName);
		FName = CurrFile = CurrFileName+2;
		GenerateTitle(TRUE);
		AskIfExists = FALSE;
	} else lstrcpy(FileName, Name);
	if (!IsCurrFile) SetAltFileName(FileName, NULL);
	if (Mode != CommandMode && !DefaultInsFlag) GotChar('\033', 1);
	ReadOnlyError = (ReadOnlyParam || ReadOnlyFile
								   || ViewOnlyFlag && !ExecRunning())
					&& !lstrcmp(FileName, CurrFile);
	if (ReadOnlyError) {
		if (((ReadOnlyFlag || ReadOnlyParam) && !(Flags & 1)) || ViewOnlyFlag) {
			Error(112, (LPSTR)FileName);
			ShowEditCaret();
			return (FALSE);
		}
	}

	StartPos.p = FirstPage;
	StartPos.i = 0;
	Newlines = LinesInFile;
	if (StartLine > 1) {
		LONG i = StartLine-1;

#if 0	/*faster method of skipping pages before specified line range...*/
		while (StartPos.p->Newlines < i && StartPos.p->Next)
			StartPos.p = StartPos.p->Next;
		if (StartPos.p->Prev) i -= StartPos.p->Prev->Newlines;
#else	/*safer method...*/
		do {
			do; while (!(CharFlags[c = CharAndAdvance(&StartPos)] & 1));
			--Newlines;
		} while (--i && c != C_EOF);
#endif
		KeepEnabled = TRUE;
		SetSafeAfterWrite = FALSE;
	} else {
		if (StartLine == -1) EndLine = -2;	/*unspecified range -> write all*/
		StartLine = 1;
	}
	if (EndLine != -2) {
		LONG i = StartLine;

		EndPos = StartPos;
		Newlines = Length = 0;
		do {
			do ++Length; while (!(CharFlags[c = CharAndAdvance(&EndPos)] & 1));
			if (c == C_EOF) break;
			++Newlines;
		} while (++i <= EndLine);
		if (c != C_EOF) {
			KeepEnabled = TRUE;
			SetSafeAfterWrite = FALSE;
		}
	} else {
		Length = StartPos.p->Fill - StartPos.i;
		for (EndPos.p=StartPos.p->Next; EndPos.p!=NULL; EndPos.p=EndPos.p->Next)
			Length += EndPos.p->Fill;
		EndPos.p = LastPage;
		EndPos.i = LastPage->Fill;
	}
	if (c != C_EOF) {
		HFILE  hf;
		BOOL   FileExists;
		INT	   i;
		INT    ErrorVal		= 0;
		PSTR   DispFileName = FileName;

		if (!strchr(FileName, '\\') && !strchr(FileName, '/')) {
			if (lstrlen(FileName) < sizeof(FileName)-2) {
				memmove(FileName+2, FileName, lstrlen(FileName)+1);
				FileName[0] = '.';
				FileName[1] = '\\';
				DispFileName += 2;
			}
		}
		i = wsprintf(Buffer, Brackets, (LPSTR)DispFileName);
		LOADSTRING(hInst, 293, Buffer+i, sizeof(Buffer)-i);
		NewStatus(0, Buffer, NS_BUSY);
		DragAcceptFiles(hwndMain, FALSE);

		/*open for checking file date/time first...*/
		#if defined(WIN32)
			hf = (HFILE)
				 CreateFile(FileName, GENERIC_READ, 0, NULL,
							OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL,
							NULL);
		#else
			hf = OpenFile(FileName, &TmpOf, OF_READ);
			/*...OF_EXIST does not work on network drives*/
		#endif
		FileExists = hf!=HFILE_ERROR;
		if (FileExists) {
			if (AskIfExists || (FName!=NULL && !*FName)) {
				INT TextId = 0;

				if (AskIfExists) TextId = 203;
				else if (!NotEdited) {
					#if defined(WIN32)
						do {	/*no loop, for break only*/
							static WORD  TmpDosDate,  TmpDosTime;
							static WORD LastDosDate, LastDosTime;

							if (LastTime.dwHighDateTime==0 &&
								LastTime.dwLowDateTime ==0) break;
							GetFileTime((HANDLE)hf, NULL, NULL, &TmpTime);
							FileTimeToDosDateTime(&TmpTime,
												  &TmpDosDate, &TmpDosTime);
							FileTimeToDosDateTime(&LastTime,
												  &LastDosDate, &LastDosTime);
							if (TmpDosDate == LastDosDate &&
								TmpDosTime == LastDosTime) break;
							TextId = 204;
							#if 1
							{	static CHAR *Mon[] =
									{"Nul", "Jan", "Feb", "Mar",
									 "Apr", "May", "Jun", "Jul",
									 "Aug", "Sep", "Oct", "Nov",
									 "Dec", "m13", "m14", "m15"};
								if (TimeDiff(&TmpTime, &LastTime) <= 20000000) {
									/*2 seconds bug with Samba filesystem*/
									break;
								} else QueryString[0] = '\0';
								wsprintf(QueryString + lstrlen(QueryString),
								  "Original:\t%02d-%s-%02d %02d:%02d:%02d UTC\n"
										   "\t0x%08x.%08x\n\n"
								   "Current:\t%02d-%s-%02d %02d:%02d:%02d UTC\n"
										   "\t0x%08x.%08x",
									LastDosDate & 31,
									(LPSTR)Mon[(LastDosDate >> 5) & 15],
									((LastDosDate >> 9) + 80) % 100,
									LastDosTime >> 11,
									(LastDosTime >> 5) & 63,
									(LastDosTime & 31) << 1,
									LastTime.dwHighDateTime,
									LastTime.dwLowDateTime,
									TmpDosDate & 31,
									(LPSTR)Mon[(TmpDosDate >> 5) & 15],
									((TmpDosDate >> 9) + 80) % 100,
									TmpDosTime >> 11,
									(TmpDosTime >> 5) & 63,
									(TmpDosTime & 31) << 1,
									TmpTime.dwHighDateTime,
									TmpTime.dwLowDateTime);
								QueryTime = GetTickCount();
							}
							#endif
						} while (FALSE);
					#else
						if (memcmp(TmpOf.reserved, LastOf.reserved,
								   sizeof(TmpOf.reserved)))
							TextId = 204;
					#endif
				}
				if (TextId) {
					static CHAR Buf[70];

					LOADSTRING(hInst, TextId, Buf, sizeof(Buf));
					if (MessageBox(hwndMain, Buf, ApplName,
							MB_OKCANCEL | MB_DEFBUTTON2 | MB_ICONEXCLAMATION)
							!= IDOK) {
						_lclose(hf);
						ShowEditCaret();
						NewStatus(0, "", NS_NORMAL);
						DragAcceptFiles(hwndMain, TRUE);
						return (FALSE);
					}
					OpenMode = OF_WRITE | OF_CREATE;
				}
			}
			_lclose(hf);
		} else OpenMode = OF_WRITE | OF_CREATE;
		i = wsprintf(Buffer, Brackets, (LPSTR)DispFileName);
		LOADSTRING(hInst, 287, Buffer+i, sizeof(Buffer)-i);
		NewStatus(0, Buffer, NS_BUSY);
		if (IsCurrFile) WatchFile(NULL);

		/*now open for writing...*/
		#if defined(WIN32)
		{	DWORD CreateAttr = FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN;

			if (FileExists && Flags & 1) {
				/*reset read-only attribute in file system...*/
				DWORD Attr = GetFileAttributes(FileName);

				if (Attr != 0xffffffff && Attr & FILE_ATTRIBUTE_READONLY) {
					SetFileAttributes(FileName, Attr&~FILE_ATTRIBUTE_READONLY);
					SetReadOnly = TRUE;
					CreateAttr = Attr | FILE_FLAG_SEQUENTIAL_SCAN;
				}
			}
			hf = (HFILE)
				 CreateFile(FileName, GENERIC_WRITE, 0, NULL,
							#if WRITE_WITH_CREAT
							  OpenMode==OF_WRITE ? OPEN_ALWAYS : CREATE_ALWAYS,
							#else
							  OPEN_ALWAYS,
							#endif
							CreateAttr, NULL);
		}
		#else
			hf = OpenFile(FileName, &TmpOf, OpenMode);
		#endif
		if (hf != HFILE_ERROR) {
			INT  i, n;

			if (ReadOnlyError) ReadOnlyFile = FALSE;
			Interrupted = FALSE;
			Disable(Length > 50000L);
			Length = 0;
			if (OpenMode == OF_WRITE) _llseek(hf, 0L, 2);
			do {
				while (StartPos.p != EndPos.p) {
					n = StartPos.p->Fill - StartPos.i;
					if (n > 0) {
						if (!StartPos.p->PageBuf && !ReloadPage(StartPos.p)) {
							ErrorVal = 108;
							break;
						}
						i = _lwrite(hf, StartPos.p->PageBuf + StartPos.i, n);
						if (i != n) {
							ErrorVal = 107;
							break;
						}
						Length += i;
					}
					StartPos.p = StartPos.p->Next;
					StartPos.i = 0;
					if (!StartPos.p) {
						ErrorVal = 109;
						break;
					}
					MessageLoop(FALSE);
				}
				n = EndPos.i - StartPos.i;
				if (!ErrorVal && n > 0) {
					if (!StartPos.p->PageBuf && !ReloadPage(StartPos.p)) {
						ErrorVal = 108;
						break;
					}
					i = _lwrite(hf, StartPos.p->PageBuf + StartPos.i, n);
					if (i != n) {
						ErrorVal = 107;
						break;
					}
					Length += i;
				}
			} while (FALSE);
			if (!ErrorVal) {
				#if defined(WIN32)
					SetEndOfFile((HANDLE)hf);
    				i = !CloseHandle((HANDLE)(hf));
				#else
					_chsize(hf, _llseek(hf, 0L, 1));
					i = _lclose(hf);
				#endif
				if (i) ErrorVal = 107;
			} else _lclose(hf);
			AddToFileList(DispFileName);
			Enable();
			Interruptable = SavInterruptable;
		}
		#if 1
			else ErrorVal = 1;
		#else
		//	else ErrorVal = OpenMode==OF_WRITE ? 111 : 110;
		#endif
		if (ErrorVal) {
			PSTR p;

			if (ErrorVal == 1) {
				#if defined(WIN32)
					#define ERRORVALUE GetLastError()
				#else
					#define ERRORVALUE TmpOf.nErrCode
				#endif
				if (ReadOnlyError && ERRORVALUE==5)
					 Error(112, (LPSTR)DispFileName);
				else {
					#if defined(WIN32)
						File32Error(DispFileName);
					#else
						FileError(DispFileName, TmpOf.nErrCode, 88);
					#endif
				}
				p = Buffer;
			} else {
				LOADSTRING(hInst, ErrorVal, Buffer, sizeof(Buffer));
				p = Buffer + lstrlen(Buffer) + 1;
				wsprintf(p, Buffer, (LPSTR)DispFileName);
				NewStatus(0, p, NS_ERROR);
			}
			MessageBox(hwndMain, p, ApplName, MB_OK | MB_ICONEXCLAMATION);
			SetSafeAfterWrite = Ret = FALSE;
		} else {
			if (!KeepEnabled && SetSafeAfterWrite)
				EnableToolButton(IDB_SAVE, FALSE);
			i = wsprintf(Buffer, Brackets, (LPSTR)DispFileName);
			if (!FileExists)
				LOADSTRING(hInst, 285, Buffer+i, sizeof(Buffer)-i);
			lstrcat(Buffer, CrLfAttribute);
			if (TerseFlag) lstrcpy(SmallBuf, " %ld/%ld");
			else LOADSTRING(hInst, 289, SmallBuf, sizeof(SmallBuf));
			wsprintf(Buffer + lstrlen(Buffer), SmallBuf, Newlines, Length);
			NewStatus(0, Buffer, NS_NORMAL);
		}
		if (SetSafeAfterWrite) SetSafe(IsCurrFile);
		else if (IsCurrFile) SetUnsafe();
		if (hf!=HFILE_ERROR) {
			#if defined(WIN32)
				if (SetReadOnly) {
					/*set read-only attribute in file system again...*/
					DWORD Attr = GetFileAttributes(FileName);

					SetFileAttributes(FileName, Attr | FILE_ATTRIBUTE_READONLY);
				}
			#endif
			if (IsCurrFile) {
				#if defined(WIN32)
					if (SetReadOnly) ReadOnlyFile = TRUE;
					hf = (HFILE)CreateFile(FileName,
										   GENERIC_READ | GENERIC_WRITE,
										   0, NULL, OPEN_EXISTING,
										   FILE_ATTRIBUTE_NORMAL, NULL);
					if (hf != HFILE_ERROR) {
						if (GetFileTime((HANDLE)hf, NULL, NULL, &LastTime))
							SetFileTime((HANDLE)hf, NULL, NULL, &LastTime);
						else memset(&LastTime, 0, sizeof(LastTime));
						_lclose(hf);
					} else memset(&LastTime, 0, sizeof(LastTime));
					WatchFile(FileName);
					if (hf == HFILE_ERROR)
						ErrorBox(MB_ICONEXCLAMATION, 333, "open failed");
				#else
					hf = OpenFile(FileName, &LastOf, OF_READ);
					if (hf != HFILE_ERROR) _lclose(hf);
				#endif
				NotEdited = FALSE;
			}
		}
		DragAcceptFiles(hwndMain, TRUE);
	}
	ShowEditCaret();
	return (Ret);
}
