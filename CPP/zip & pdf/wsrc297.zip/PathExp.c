/********************************************************\
|*                                                      *|
|*   Program:              WinVi                        *|
|*   Author:               Raphael Molle                *|
|*   Compiler:             several                      *|
|*   --------------------- --------------------------   *|
|*   � Copyright 1994-2005 by Raphael Molle, Berlin     *|
|*   � Copyleft by GPL     See file COPYING for more    *|
|*                         info about terms of use      *|
|*                                                      *|
\********************************************************/

/* revision log:
 *      3-Dec-2000	first publication of source code
 *     22-Jul-2002	use of private myassert.h
 *     22-Sep-2002	tabexpand server and share names
 *     22-Sep-2002	new choice for ":set ebcdimode" or shorter ":set em"
 *      3-Oct-2002	corrected handling of :<num><tab> and :<num><letter><tab>
 *      3-Oct-2002	corrected handling of :w>><tab>
 *      6-Oct-2002	corrected handling of :s///<tab>
 *      8-Dec-2002	skipping multiple ":" at start of command line
 *     10-Jan-2003	new variable "shell"
 *     22-Oct-2003	optional tab expansion with forward slash
 *     22-Dec-2004	show at least one more character in shortened menus
 *     01-Jan-2005	bugfix in PatternMatch matching '?' in one pattern of a list
 *     12-Mar-2005	bugfix in PatternMatch when matching a list of patterns
 */

#include <windows.h>
#include <stdio.h> /*for sprintf only*/
#include <string.h>
#include <malloc.h>
#include "myassert.h"
#include "winvi.h"
#include "status.h"
#include "pathexp.h"

HANDLE MyFindFirst(PSTR,   FIND_DATA *);
BOOL   MyFindNext (HANDLE, FIND_DATA *);
BOOL   MyFindClose(HANDLE);
BOOL   IsDirectory(FIND_DATA *);
BOOL   IsHidden   (FIND_DATA *);
LPCSTR FoundName  (FIND_DATA *);

HMENU PathExpMenu;

static char Source[280], Result[280], *pTail, *pMultiLastName;
static UINT Id;
static struct {
	char *Name;
	WORD Flags;
} *pCmd, Commands[] = {
	{"!",			   4},	/*4=expand commands with path*/
	{"=",			   0},	/*0=nothing to expand*/
	{"args",		   0},
	{"cd",			   2},	/*2=expand directories only*/
	{"chdir",		   2},
	{"edit",		   1},	/*1=expand normal files*/
	{"filename",	   1},
	{"next",		   1},
	{"quit",		   0},
	{"read",		   1},
	{"rewind",		   0},
	{"set",			   8},	/*8=expand variable names*/
	{"substitute",	  16},	/*16=expand previous search pattern*/
	{"tag",			   0},
	{"version",		   0},
	{"vi",			   1},
	{"wq",			   1},
	{"write",		   1},
	{"xit",			   1},
	{NULL,			   0}
}, Variables[] = {
	{"ai",			  32},	/*32=suppress menu choice*/
	{"all",			   0},
#if defined(WIN32)
	{"ansicodepage=",128},
	{"ansicp=",		 160},
#endif
	{"am",			  32},
	{"ansimode",	   0},
	{"autoindent",	   0},
	{"autowrite",	   0},
	{"aw",			  32},
	{"columns=",	 128},	/*128=value*/
	{"dm",			  32},
	{"dosmode",		   0},
	{"em",			  32},
	{"ebcdimode",	   0},
	{"hexmode",		   0},
	{"hm",			  32},
	{"ic",			  32},
	{"ignorecase",	   0},
	{"lines=",		 128},
	{"list",		   0},
	{"magic",		   0},
	{"noai",		  96},
	{"noautoindent",  64},	/*64="no" prefix*/
	{"noautowrite",	  64},
	{"noam",		  96},
	{"noansimode",	  96},
	{"noaw",		  96},
	{"nodm",		  96},
	{"nodosmode",	  96},
	{"nohexmode",	  64},
	{"nohm",		  96},
	{"noic",		  96},
	{"noignorecase",  64},
	{"nolist",		  64},
	{"nomagic",		  64},
	{"nonumber",	  64},
	{"noreadonly",	  64},
	{"noro",		  96},
	{"noshowmatch",	  64},
	{"nosm",		  96},
	{"noterse",		  64},
	{"noviewonly",	  64},
	{"novo",		  96},
	{"nowrapscan",	  64},
	{"nows",		  96},
	{"number",		   0},
#if defined(WIN32)
	{"oemcodepage=", 128},
	{"oemcp=",		 160},
#endif
	{"readonly",	   0},
	{"ro",			  32},
	{"scroll=",		 128},
	{"shell=",		 128},
	{"shiftwidth=",  128},
	{"showmatch",	   0},
	{"sm",			  32},
	{"sw=",			 160},
	{"tabstop=",	 128},
	{"tags=",		 128},
	{"terse",		   0},
	{"tmpdirectory=",128},
	{"ts=",			 160},
	{"viewonly",	   0},
	{"vo",			  32},
	{"wrapscan",	   0},
	{"ws",			  32},
	{NULL,			   0}
}, ShellCommands[] = {
	{"break",		  32},	/*not meaningful as a single command*/
	{"call",		   0},
	{"cd",			  32},
	{"chcp",		  32},
	{"chdir",		  32},
	{"cls",			  32},
	{"copy",		   0},
	{"ctty",		   0},
	{"date",		   0},
	{"del",			   0},
	{"dir",			   0},
	{"echo",		   0},
	{"erase",		   0},
	{"exit",		  32},
	{"for",			  32},
	{"goto",		  32},
	{"if",			   0},
	{"lfnfor",		 544},
	{"lh",			   0},
	{"loadhigh",	   0},
	{"lock",		 512},	/*Windows 95 or Windows NT 4.0 only (not Win 3.x)*/
	{"md",			   0},
	{"mkdir",		   0},
	{"path",		  32},
	{"pause",		  32},
	{"prompt",		  32},
	{"rd",			   0},
	{"rem",			   0},
	{"ren",			   0},
	{"rename",		   0},
	{"rmdir",		   0},
	{"set",			  32},
	{"shift",		  32},
	{"time",		   0},
	{"truename",	   0},
	{"type",		   0},
	{"unlock",		 512},
	{"ver",			   0},
	{"verify",		  32},
	{"vol",			   0},
	{NULL,			   0}
};
int nMenuItemHght, nMenuHeight, nMenuItems;
static int Columns, MaxLen;

typedef struct tagPOPUPLIST {
	BYTE   MenuGroup;	/*0=internal/shell internal, 1=directory, 2=file*/
	char   Name[1];
} POPUPLIST, FAR* LPPOPUPLIST, FAR* FAR* LPLPPOPUPLIST;
LPLPPOPUPLIST PopupList = NULL;
int PopupInUse=0, PopupAllocated=0;

extern BOOL TabExpandWithSlash;

static void StartPopupMenu(void)
{
	if (!nMenuItems) {
		nMenuItemHght = GetSystemMetrics(SM_CYMENU);
		nMenuHeight = GetSystemMetrics(SM_CYSCREEN);
		#if defined(WIN32)
			++nMenuItemHght;
		#else
			if (WinVersion >= MAKEWORD(95,3)) {
				nMenuItemHght += 2;
				nMenuHeight -= 10;
			}
		#endif
	}
	while (PopupInUse > 0) _ffree(PopupList[--PopupInUse]);
	if (PopupAllocated) {
		_ffree(PopupList);
		PopupAllocated = 0;
	}
	nMenuItems = MaxLen = 0;
}

static void AppendMenuItem(int MenuGroup, PSTR pString)
{	LPPOPUPLIST NewItem;

	if (PopupInUse+1 /*NULL element at end*/ >= PopupAllocated) {
		LPLPPOPUPLIST np;

		if ((np = _fcalloc(PopupAllocated+100, sizeof(LPPOPUPLIST))) == NULL)
			return;
		if (PopupInUse) {
			_fmemcpy(np, PopupList, PopupInUse*sizeof(LPPOPUPLIST));
			_ffree(PopupList);
		}
		PopupList = np;
		PopupAllocated += 100;
	}
	if ((NewItem = _fcalloc(1, sizeof(POPUPLIST) + lstrlen(pString))) != NULL) {
		int i;

		lstrcpy(NewItem->Name, pString);
		if ((i = lstrlen(pString)) > MaxLen) MaxLen = i;
		NewItem->MenuGroup = (BYTE)MenuGroup;
		/*binary array search...*/
		{	int i, d;

			if (PopupInUse) {
				BOOL Less;

				for (d=PopupInUse-1; d & (d-1); d &= d-1);
				/*d = largest power of 2 less than PopupInUse*/
				i = d;
				if (i) i += i-1;
				for (;;) {
					Less = i < PopupInUse
						   && ( PopupList[i]->MenuGroup <  MenuGroup ||
							   (PopupList[i]->MenuGroup == MenuGroup
								&& lstrcmpi(PopupList[i]->Name, pString) < 0));
					if (Less) i += d;
					else i -= d;
					if (!d) break;
					d >>= 1;
				}
				if (Less) ++i;
			} else i = 0;
			if (i < PopupInUse)
				_fmemmove(PopupList+i+1, PopupList+i,
						  (PopupInUse-i)*sizeof(LPPOPUPLIST));
			assert(i >= 0);
			assert(i < PopupAllocated);
			++PopupInUse;
			PopupList[i] = NewItem;
		}
		++nMenuItems;
	}
}

static BOOL ShowPopupMenu(int x, int y)
{	LPLPPOPUPLIST p;
	int			  MenuGroup, Separator = 0;

	if (PopupList==NULL || *PopupList==NULL) return (FALSE);
	MenuGroup = (*PopupList)->MenuGroup;
	if (PathExpMenu) DestroyMenu(PathExpMenu);
	PathExpMenu = CreatePopupMenu();
	if (!PathExpMenu) {
		MessageBeep(MB_ICONEXCLAMATION);
		return (FALSE);
	}
	if ((LONG)nMenuItems*nMenuItemHght > 3L*nMenuHeight) {
		/*too many files for menu (more than 5 columns), split name...*/
		LPLPPOPUPLIST p2;
		int			  i, MatchLen[21];

		memset(MatchLen, 0, sizeof(MatchLen));
		for (p=PopupList, p2=p+1; *p2!=NULL; ++p, ++p2) {
			LPSTR pN1, pN2;

			if ((*p)->MenuGroup == 0) continue;
			i = 0;
			pN1 = (*p)->Name;
			pN2 = (*p2)->Name;
			while (pN1[i] && AnsiUpper((LPSTR)(INT)(BYTE)pN1[i])==
							 AnsiUpper((LPSTR)(INT)(BYTE)pN2[i])) ++i;
			if (i > 20) i = 20;
			++MatchLen[i];
		}
		for (MaxLen=i=0; MaxLen<=20; ++MaxLen)
			if ((i+=MatchLen[MaxLen]) > 20) break;
		if (i == MatchLen[MaxLen]) ++MaxLen;
		else if (MaxLen>1 && i*nMenuItemHght > 8*nMenuHeight) --MaxLen;
	}
	nMenuItems = 0;
	p = PopupList;
	while (*p != NULL) {
		WORD wFlags = MF_STRING;

		if (((long)++nMenuItems-(Separator>>1))*nMenuItemHght > nMenuHeight) {
			wFlags |= MF_MENUBARBREAK;
			nMenuItems = 1;
			++Columns;
			MenuGroup = (*p)->MenuGroup;
			Separator = 0;
		} else if (MenuGroup != (*p)->MenuGroup) {
			if (((long)++nMenuItems-(Separator>>1))*nMenuItemHght>nMenuHeight) {
				wFlags |= MF_MENUBARBREAK;
				nMenuItems = 1;
				++Columns;
				Separator = 0;
			} else {
				AppendMenu(PathExpMenu, MF_SEPARATOR, 0, NULL);
				if (WinVersion >= MAKEWORD(95,3)) ++Separator;
			}
			MenuGroup = (*p)->MenuGroup;
		}
		if (MenuGroup > 0 && lstrlen((*p)->Name) > MaxLen+(MenuGroup==1)) {
			int			c1, c2, len;
			LPLPPOPUPLIST p2;

			if (*(p2=p+1) != NULL && lstrlen((*p2)->Name) > MaxLen) {
				c1 = (*p)->Name[MaxLen];
				c2 = (*p2)->Name[MaxLen];
				(*p)->Name[MaxLen] = (*p2)->Name[len=MaxLen] = '\0';
				while (lstrcmpi((*p)->Name, (*p2)->Name) == 0
					   && (*p)->MenuGroup == (*p2)->MenuGroup) {
					(*p2)->Name[MaxLen] = c2;
					++p2;
					if (*p2==NULL || (len=lstrlen((*p2)->Name))<MaxLen) break;
					c2 = (*p2)->Name[MaxLen];
					(*p2)->Name[MaxLen] = '\0';
				}
				if (*p2!=NULL && len>=MaxLen)
					(*p2)->Name[MaxLen] = c2;
				if (p2 != p+1) {
					char ps[26];  /*lstrlen((*p)->Name) is not larger than 20*/

					lstrcpy(ps, (*p)->Name);
					if (c1 == '&') {
						/*check for & to double at end of string...*/
						int n = 1, i=MaxLen;

						while ((*p)->Name[++i] == '&') ++n;
						if (n & 1) lstrcat(ps, "&");
					}
					lstrcat(ps, " ...");
					AppendMenu(PathExpMenu, wFlags, Id++, ps);
					(*p)->Name[MaxLen] = c1;
					p = p2;
					continue;
				}
				(*p)->Name[MaxLen] = c1;
			}
		}
		AppendMenu(PathExpMenu, wFlags, Id++, (*p)->Name);
		++p;
	}
	TrackPopupMenu(PathExpMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON,
				   x, y, 0, hwndMain, NULL);
	StartPopupMenu();	/*remove memory only*/
	return (TRUE);
}

static INT InsertHexTab(HWND hwndEdit, INT Position, PSTR *Start, INT nSep)
	/*return values:	0:	insufficient space in buffer,
	 *					1:	tab inserted,
	 *					2:	position out of search/replace fields.
	 */
{	PSTR pTabpos = Source + Position, p;

	if (nSep) {
		/*check Position to be within string separator *Start...*/
		for (p = *Start+1; *p && p < pTabpos; ++p) {
			if (*p == **Start && !--nSep) {
				*Start = p + 1;
				return (2);
			}
			if (*p == '\\' && !*++p) break;
		}
	}
	if (strlen(Source) >= sizeof(Source)-4) return (0);
	memmove(pTabpos+4, pTabpos, lstrlen(pTabpos)+1);
	memcpy(pTabpos, "\\%09", 4);
	SetWindowText(hwndEdit, Source);
	Position += 4;
	#if defined(WIN32)
		SendMessage(hwndEdit, EM_SETSEL, Position, Position);
	#else
		SendMessage(hwndEdit, EM_SETSEL, 0, MAKELPARAM(Position, Position));
	#endif
	return (1);
}

BOOL ExpandPath(HWND hwndEdit, WORD wFlags)
{
	/*wFlags: 1=skip command part (command window in status line)
	 */
	PSTR	pName = Source, pPos;
	LRESULT	CurrSel;
	int		nLen;
	BOOL	ShowInternal = FALSE,	DirectoriesOnly	= FALSE;
	BOOL	Multiple	 = FALSE,	TraversePath	= FALSE;
	PSTR	*SuffixList	 = NULL;
	PSTR	DirSeparator = "\\";
	WORD	SuffixMask	 = 0;

	pMultiLastName = NULL;
	GetWindowText(hwndEdit, Source, sizeof(Source));
	CurrSel = SendMessage(hwndEdit, EM_GETSEL, 0, 0L);
	if (LOWORD(CurrSel) != HIWORD(CurrSel)
			|| (ULONG)(CurrSel &= 0xffff) > strlen(Source)) {
		MessageBeep(MB_ICONEXCLAMATION);
		return (FALSE);
	}
	if (wFlags & 1) {
		BOOL Skip = TRUE;

		if (*pName == '/' || *pName == '?')
			return (InsertHexTab(hwndEdit, (short)CurrSel, &pName, 1));
		if (*pName != ':' && *pName != '!') {
			MessageBeep(MB_ICONEXCLAMATION);
			return (FALSE);
		}
		if (*pName == ':') {
			do; while (*++pName == ':');
			for (;;) {
				switch (*pName) {
					case ' ': case ',': case '%': case '$':
					case '+': case '-': case '.':
					case '0': case '1': case '2': case '3': case '4':
					case '5': case '6': case '7': case '8': case '9':
						++pName;
						continue;
				}
				break;
			}
		}
		switch (LCASE(*pName)) {
			case 'c': DirectoriesOnly = TRUE;
					  break;

			case '!': Skip			  = FALSE;
					  TraversePath	  = TRUE;
					  if (TabExpandWithSlash) DirSeparator = "/";
					  /*FALLTHROUGH*/
			case 'n': Multiple		  = TRUE;
					  break;

			case 's':
				if (LCASE(*++pName) == 'e') {
					if (LCASE(*++pName) == 't') ++pName;
					if (*pName == ' ') {
						for (;;) {
							do; while (*++pName == ' ');
							for (pPos=pName; *pPos && *pPos!=' '; ++pPos)
								if (*pPos == '"')
									do; while (*++pPos && *pPos != '"');
							if (!*pPos) break;
							pName = pPos;
						}
						ShowInternal = TRUE;
						pCmd = Variables;
						Skip = FALSE;
					}
				} else {
					PSTR p = "substitute";

					while (*pName && LCASE(*pName) == *++p) ++pName;
					if (!*pName) break;
					while (*pName == ' ') ++pName;
					if (*pName && (*pName<'A' || *pName>'Z')
							   && (*pName<'a' || *pName>'z')) {
						switch (InsertHexTab(hwndEdit, (short)CurrSel,
											 &pName, 2)) {
							case 0:	return (FALSE);
							case 1:	return (TRUE);
						 /*	case 2: break; */
						}
					}
					{	static PSTR	s[] = {"/", "c", "g"};

						SuffixList = s;
						SuffixMask = pName[-1]!=' ' ? 6 : 7;
						while (*pName) {
							switch (LCASE(*pName++)) {
								case ' ':	continue;

								case 'c':	SuffixMask &= ~3;
											break;

								case 'g':	SuffixMask &= ~5;
											break;

								default:	SuffixMask = 0;
							}
							if (!SuffixMask) break;
						}
						Skip = FALSE;
					}
					if (SuffixMask && !*pName) break;
					MessageBeep(MB_ICONEXCLAMATION);
					return (FALSE);
				}
				break;

			case '.':
				if (pName[1] != '.' && pName[1] != '/' && pName[1] != '\\' &&
						*Source == ':') {
					++pName;
					break;
				}
				/*FALLTHROUGH*/
			case '\\':
			case '?': case '/':
				if (*pName == '\\' || *pName == '.' || *Source != ':') {
					MessageBeep(MB_ICONEXCLAMATION);
					return (FALSE);
				}
				{	INT c = *pName;

					while (*++pName != c) {
						if (*pName == '\\') ++pName;
						else if (pName-Source == CurrSel)
							return (InsertHexTab(hwndEdit, (short)CurrSel,
												 NULL, 0));
						if (!*pName) return(FALSE);
					}
					do; while (*pName && *++pName == ' ');
					if (*pName != ',') break;
					do; while (*++pName == ' ');
					if ((c = *pName) != '/' && c != '?') break;
					while (*++pName != c) {
						if (*pName == '\\') ++pName;
						else if (pName-Source == CurrSel)
							return (InsertHexTab(hwndEdit, (short)CurrSel,
												 NULL, 0));
						if (!*pName) return(FALSE);
					}
					++pName;
				}
		}
		if (Skip) {
			while (*pName >= 'A' && *pName <= 'z') ++pName;
			if (!*pName) {
				ShowInternal = TRUE;
				pCmd = Commands;
				while (pName[-1] > '9' && pName[-1] != ':') --pName;
			}
		}
		while (*pName == ' ' || *pName == '!' || *pName == '>') ++pName;
		if (Multiple) {
			for (;;) {
				if (*pName == '"') {
					++pName;
					pPos = strstr(pName, "\" ");
					if (pPos == NULL) break;
					pName = pPos + 2;
					TraversePath = FALSE;
				} else if ((pPos = strchr(pName, ' ')) != NULL) {
					pName = pPos + 1;
					TraversePath = FALSE;
				} else {
					if (TraversePath)
						if (strchr(pName, '\\') || strchr(pName, '/'))
							TraversePath = FALSE;
					break;
				}
			}
		}
	}
	{	PSTR p;

		for (p=pName; (p=strstr(p, "##")) != NULL; ++p)
			memmove(p, p+1, lstrlen(p));
		for (p=pName; (p=strstr(p, "%%")) != NULL; ++p)
			memmove(p, p+1, lstrlen(p));
	}
	pPos = pName + lstrlen(pName);
	lstrcpy(Result, Source);
	Id = 4000;
	StartPopupMenu();
	if (SuffixMask) {
		pTail = Result + (pName - Source);
		while (SuffixMask) {
			if (SuffixMask & 1) {
				strcpy(pTail, *SuffixList);
				AppendMenuItem(0, pTail);
			}
			SuffixMask >>= 1;
			++SuffixList;
		}
	} else if (ShowInternal) {
		pTail = Result + (pName - Source);
		*pTail = '\0';
		for (; pCmd->Name; ++pCmd) {
			PSTR p1 = pName, p2 = pCmd->Name;

			while (*p1 && LCASE(*p1) == *p2++) ++p1;
			if (*p1 || (*p2 && *p2!='=' && pCmd->Flags & 32)) continue;
			lstrcpy(pTail, pCmd->Name);
			if (/*PopupInUse == 1 &&*/ pCmd->Flags & 27)
				lstrcat(pTail, pCmd->Flags & 16 ? "/" : " ");
			AppendMenuItem(0, pTail);
		}
		if (!*pTail) {
			MessageBeep(MB_ICONEXCLAMATION);
			return (FALSE);
		}
	} else {
		FIND_DATA FindData;
		HANDLE	  hFindHandle;

		for (pTail=Result+(pPos-Source);
			 --pTail>=Result+(pName-Source) && *pTail!='\\' && *pTail!='/';)
			{}
		if ((pPos-pName==2 && pName[1]==':') || !lstrcmp(pTail+1, ".."))
			lstrcat(Result, DirSeparator);
		else {
			LPSTR Path = NULL;
			#if !defined(WIN32)
				BOOL AppendExtension = !strchr(pTail+1, '.');
			#endif

			*++pTail = '\0';
			if (TraversePath && pTail >= Result+(pName-Source)) {
				/*include COMMAND.COM intrinsic commands and path commands...*/
				for (pCmd=ShellCommands; pCmd->Name; ++pCmd) {
					PSTR p1 = pName, p2 = pCmd->Name;
					while (*p1 && LCASE(*p1) == *p2++) ++p1;
					if (*p1 || pCmd->Flags & 32) continue;
					lstrcpy(pTail, pCmd->Name);
					AppendMenuItem(0, pTail);
				}
				#if defined(WIN32)
				{	int Len;
					Len = GetEnvironmentVariable("Path", NULL, 0) + 1;
					Path = _fcalloc(1, Len);
					if (Path) GetEnvironmentVariable("Path", Path, Len);
				}
				#endif
			}
			lstrcpy(pPos, "*");
			#if !defined(WIN32)
				if (AppendExtension) lstrcpy(pPos, "*.*");
				AnsiToOem(pName, pName);
			#endif
			hFindHandle = MyFindFirst(pName, &FindData);
			if (hFindHandle != INVALID_HANDLE_VALUE) {
				do {
					if (*FoundName(&FindData) == '.' &&
								(!lstrcmp(FoundName(&FindData), ".")
							  || !lstrcmp(FoundName(&FindData), "..")))
						/*TODO: make last compare (..) configurable*/
						continue;
					if (IsHidden(&FindData)) continue;
					if (DirectoriesOnly && !IsDirectory(&FindData)) continue;
					TO_ANSI_STRCPY(pTail, FoundName(&FindData));
					LowerCaseFname(pTail);
					{	PSTR p = pTail;

						while ((p = strchr(p, '&')) != NULL) {
							/*double '&' to prevent handling as accelerator...*/
							memmove(p+1, p, lstrlen(p)+1);
							p += 2;
						}
					}
					if (IsDirectory(&FindData)) {
						lstrcat(pTail, DirSeparator);
						AppendMenuItem(1, pTail);
					} else AppendMenuItem(2, pTail);
				} while (MyFindNext(hFindHandle, &FindData));
				MyFindClose(hFindHandle);
			}
			if (!*pTail) {
				MessageBeep(MB_ICONEXCLAMATION);
				return (FALSE);
			}
			if (Multiple) do {	/*no loop, for break only*/
				pMultiLastName = Result + (pName-Source);
				if (pName[-1] != '"') {
					if (PopupInUse != 1 || !strchr(pTail, ' ')) break;
					memmove(pMultiLastName+1, pMultiLastName,
							lstrlen(pMultiLastName)+1);
					*pMultiLastName = '"';
				} else --pMultiLastName;
				if (!strspn(pTail + lstrlen(pTail) - 1, "/\\"))
					lstrcat(pTail, "\"");
			} while (FALSE);
			if (Path) _ffree(Path);
		}
	}
	{	PSTR p, p2;

		*pPos = '\0';
		p = pName;
		while ((p2 = strchr(p, '#')) != NULL) {
			memmove(p2+1, p2, lstrlen(p2)+1);
			p = p2 + 2;
			++pPos;
		}
		p = pName;
		while ((p2 = strchr(p, '%')) != NULL) {
			memmove(p2+1, p2, lstrlen(p2)+1);
			p = p2 + 2;
			++pPos;
		}
		p = Result + (pName-Source);
		while ((p2 = strchr(p, '#')) != NULL) {
			memmove(p2+1, p2, lstrlen(p2)+1);
			p = p2 + 2;
			if (p2 < pTail) ++pTail;
		}
		p = Result + (pName-Source);
		while ((p2 = strchr(p, '%')) != NULL) {
			memmove(p2+1, p2, lstrlen(p2)+1);
			p = p2 + 2;
			if (p2 < pTail) ++pTail;
		}
	}
	if (PopupInUse > 1) {
		RECT Pos;
		HDC  hDC;

		GetWindowRect(hwndEdit, &Pos);
		hDC = GetDC(hwndMain);
		if (hDC) {
			SIZE  Size;
			HFONT hfontOld = SelectObject(hDC, StatusFont);

			Pos.left += StatusFields[0].x;
			if (GetTextExtentPoint(hDC, Source, pPos-Source, &Size)) {
				if (Size.cx >= StatusFields[0].Width)
					 Pos.left += StatusFields[0].Width - 1;
				else Pos.left += Size.cx;
			}
			SelectObject(hDC, hfontOld);
			ReleaseDC(hwndMain, hDC);
		}
		ShowPopupMenu(Pos.left, Pos.top);
	} else {
		while ((pTail = strstr(pTail, "&&")) != NULL) {
			memmove(pTail, pTail+1, lstrlen(pTail));
			++pTail;
		}
		SetWindowText(hwndEdit, Result);
		nLen = lstrlen(Result);
		#if defined(WIN32)
			SendMessage(hwndEdit, EM_SETSEL, nLen, nLen);
		#else
			SendMessage(hwndEdit, EM_SETSEL, 0, MAKELPARAM(nLen, nLen));
		#endif
		pTail = NULL;
	}
	return (TRUE);
}

void PathExpCommand(UINT Command)
{	int nLen;

	if (pTail!=NULL && hwndCmd && PathExpMenu && Command>=4000 && Command<Id) {
		BOOL TabAgain = FALSE;

		GetMenuString(PathExpMenu, Command, pTail,
					  sizeof(Result)-(pTail-Result), MF_BYCOMMAND);
		{	PSTR p, p2;

			for (p=pTail; (p=strstr(p, "&&")) != NULL; ++p)
				/*strip second ampersand (necessary for correct menu display)*/
				memmove(p, p+1, lstrlen(p));
			for (p=pTail; (p2=strchr(p,'#'))  != NULL; p=p2+2)
				/*double these '#' and '%' to avoid filename substitution...*/
				memmove(p2+1, p2, lstrlen(p2)+1);
			for (p=pTail; (p2=strchr(p,'%'))  != NULL; p=p2+2)
				memmove(p2+1, p2, lstrlen(p2)+1);
		}
		if ((nLen=lstrlen(pTail))>4 && lstrcmp(pTail+(nLen-=4), " ...")==0) {
			pTail[nLen] = '\0';
			TabAgain = TRUE;
		}
		if (pMultiLastName) {
			if (*pMultiLastName!='"' && strchr(pTail, ' ')) {
				memmove(pMultiLastName+1, pMultiLastName,
						lstrlen(pMultiLastName)+1);
				*pMultiLastName = '"';
			}
			if (!TabAgain && *pMultiLastName == '"')
				if (!strspn(pTail + lstrlen(pTail) - 1, "/\\"))
					lstrcat(pTail, "\"");
		}
		SetWindowText(hwndCmd, Result);
		nLen = lstrlen(Result);
		#if defined(WIN32)
			SendMessage(hwndCmd, EM_SETSEL, nLen, nLen);
		#else
			SendMessage(hwndCmd, EM_SETSEL, 0, MAKELPARAM(nLen, nLen));
		#endif
		pTail = NULL;
		DestroyMenu(PathExpMenu);
		PathExpMenu = NULL;
		if (TabAgain) ExpandPath(hwndCmd, 1);
	}
}

void PathExpCleanup(void)
{
	if (PathExpMenu) {
		DestroyMenu(PathExpMenu);
		PathExpMenu = NULL;
	}
}

/*-----------------------------------------------------------------
 * now some extensions to FindFirstFile/FindNextFile
 * for handling network enumerations
 */

#if defined(WIN32)

BOOL PatternMatch(PCSTR String, PCSTR Pattern)
{	PCSTR		s = String, p = Pattern;
	static BOOL	Recursive = FALSE;

	for (;;) {
		switch (*p) {
			case '?':
				if (!*s) {
					if (Recursive || (p = strpbrk(p, ",;")) == NULL)
						return (FALSE);
					s = String;
				} else ++s;
				++p;
				break;

			case '*':
				{	BOOL SaveRecursive = Recursive;

					Recursive = TRUE;
					++p;
					do {
						if (PatternMatch(s, p)) {
							Recursive = SaveRecursive;
							return (TRUE);
						}
					} while (*s++);
					Recursive = SaveRecursive;
					if (Recursive || (p = strpbrk(p, ",;")) == NULL)
						return (FALSE);
					s = String;
					++p;
				}
				continue;

			case '\0':
			case ',':
			case ';':
				if (!*s) return (TRUE);
				if (!*p || Recursive) return (FALSE);
				/*FALLTHROUGH*/
			default:
				if (ANSILOWER_CMP(*s, *p)) {
					if (Recursive || (p = strpbrk(p, ",;")) == NULL)
						return (FALSE);
					s = String;
				} else ++s;
				++p;
		}
	}
}

static NETRESOURCE *NetResource[4] = {NULL, NULL, NULL, NULL};
static DWORD       NrSizes[4];
static HANDLE      hEnum[4] =
	   {INVALID_HANDLE_VALUE, INVALID_HANDLE_VALUE,
	    INVALID_HANDLE_VALUE, INVALID_HANDLE_VALUE};
/* The first 3 elements of each of the above arrays are used for the different
 * levels of enumerating network servers (top level, domains, and servers).
 * The 4th element (index 3) is used for enumerating the shares of a server.
 *															25-Sep-2002 Ramo
 */
CHAR TabExpandDomains[256];

static INT EnumNetRes(INT i, INT iMax, NETRESOURCE *nr)
{
	if (hEnum[i] == INVALID_HANDLE_VALUE) {
		if (WNetOpenEnum(RESOURCE_GLOBALNET, RESOURCETYPE_ANY,
   						 0, nr, &hEnum[i]) != NO_ERROR) {
			return (-1);
		}
	}
	for (;;) {
		DWORD count, size;

		if (NetResource[i] == NULL) {
			NetResource[i] = malloc(sizeof(NETRESOURCE));
			if (NetResource[i] == NULL) return (-1);
			NrSizes[i] = sizeof(NETRESOURCE);
		}
		if (i >= iMax || hEnum[i+1] == INVALID_HANDLE_VALUE) {
			DWORD rc;

			count = 1;
			size  = NrSizes[i];
			if (CheckInterrupt()) rc = ERROR_REQUEST_ABORTED;
			else rc = WNetEnumResource(hEnum[i], &count, NetResource[i], &size);
			if (rc == ERROR_MORE_DATA) {
				NETRESOURCE *nr = realloc(NetResource[i], size);

				if (nr == NULL) return (-1);
				NetResource[i] = nr;
				NrSizes[i]     = size;
				count          = 1;
				rc = WNetEnumResource(hEnum[i], &count, NetResource[i], &size);
			}
			if (rc != NO_ERROR) {
				WNetCloseEnum(hEnum[i]);
				hEnum[i] = INVALID_HANDLE_VALUE;
				return (-1);
			}
			if (NetResource[i]->lpRemoteName != NULL &&
					strspn(NetResource[i]->lpRemoteName, "\\/") == 2 &&
					NetResource[i]->dwDisplayType == RESOURCEDISPLAYTYPE_SERVER)
				return (i);
		}
		if (i < iMax && NetResource[i]->dwUsage & RESOURCEUSAGE_CONTAINER) {
			INT Res;

			if (NetResource[i]->dwDisplayType != RESOURCEDISPLAYTYPE_DOMAIN ||
				PatternMatch(NetResource[i]->lpRemoteName, TabExpandDomains)) {
					Res = EnumNetRes(i+1, iMax, NetResource[i]);
					if (Res >= 0) return(Res);
			}
		}
	}
}

static HANDLE EnumServers(LPCSTR Name, FIND_DATA *FindData)
{	INT n;
	static PSTR Compare;

	if (Name != NULL) {
		if (Compare != NULL) free(Compare);
		if ((Compare = malloc(n = strlen(Name) + 1)) == NULL)
			return (INVALID_HANDLE_VALUE);
		strcpy(Compare, Name);
	}
	while ((n = EnumNetRes(0, 2, NULL)) >= 0) {
		if (PatternMatch(NetResource[n]->lpRemoteName, Compare)) {
			strncpy(FindData->cFileName,
			        NetResource[n]->lpRemoteName + 2,
			        sizeof(FindData->cFileName));
			FindData->dwFileAttributes = FILE_ATTRIBUTE_DIRECTORY;
			return((HANDLE)(NetResource+n));
		}
	}
	MyFindClose((HANDLE)NetResource);
	return (INVALID_HANDLE_VALUE);
}

static HANDLE EnumShares(LPSTR Name, LPSTR NameSep, FIND_DATA *FindData)
{	DWORD       rc, count, size;
	static PSTR Compare;

	if (NetResource[3] == NULL) {
		NetResource[3] = malloc(sizeof(NETRESOURCE));
		if (NetResource[3] == NULL) return (INVALID_HANDLE_VALUE);
		NrSizes[3] = sizeof(NETRESOURCE);
	}
	if (hEnum[3] == INVALID_HANDLE_VALUE) {
		static NETRESOURCE Root;
		INT    Separator;

		if (Name == NULL) return (INVALID_HANDLE_VALUE);
		Root.dwScope       = RESOURCE_GLOBALNET;
		Root.dwType        = RESOURCETYPE_ANY;
		Root.dwDisplayType = RESOURCEDISPLAYTYPE_SERVER;
		Root.dwUsage       = RESOURCEUSAGE_CONTAINER;
		Root.lpRemoteName  = Name;
		Separator  = *NameSep;
		*NameSep = '\0';
		if (Compare != NULL) free(Compare);
		if ((Compare = malloc(strlen(NameSep))) == NULL)
			return (INVALID_HANDLE_VALUE);
		strcpy(Compare, NameSep+1);
		if (WNetOpenEnum(RESOURCE_GLOBALNET, RESOURCETYPE_ANY,
   						 0, &Root, &hEnum[3]) != NO_ERROR) {
			*NameSep = Separator;
			return (INVALID_HANDLE_VALUE);
		}
		*NameSep = Separator;
	}
	for (;;) {
		count = 1;
		size  = NrSizes[3];
		rc = WNetEnumResource(hEnum[3], &count, NetResource[3], &size);
		if (rc == ERROR_MORE_DATA) {
			NETRESOURCE *nr;

			nr = realloc(NetResource[3], size);
			if (nr == NULL) {
				WNetCloseEnum(hEnum[3]);
				return (hEnum[3] = INVALID_HANDLE_VALUE);
			}
			NetResource[3] = nr;
			NrSizes[3]     = size;
			count          = 1;
			rc = WNetEnumResource(hEnum[3], &count, NetResource[3], &size);
		}
		if (rc != NO_ERROR) {
			WNetCloseEnum(hEnum[3]);
			return (hEnum[3] = INVALID_HANDLE_VALUE);
		}
		if (NetResource[3]->dwType == RESOURCETYPE_DISK &&
				NetResource[3]->lpRemoteName != NULL &&
				strlen(NetResource[3]->lpRemoteName) > 3) {
			LPCSTR p = strpbrk(NetResource[3]->lpRemoteName+2, "\\/");

			if (p++ != NULL && Compare != NULL && PatternMatch(p, Compare)) {
				strncpy(FindData->cFileName, p, sizeof(FindData->cFileName));
				FindData->dwFileAttributes = FILE_ATTRIBUTE_DIRECTORY;
				return((HANDLE)(NetResource+3));
			}
		}
	}
}

#endif

static HANDLE FindFileHandle = INVALID_HANDLE_VALUE;

HANDLE MyFindFirst(PSTR Name, FIND_DATA *FindData)
{
	#if defined(WIN32)
		if (strspn(Name, "\\/") == 2) do {	/*no loop, for break only*/
			LPSTR p;
			HANDLE Result;

			StartInterruptCheck();
			if ((p = strpbrk(Name+2, "\\/")) == NULL)
				Result = EnumServers(Name, FindData);
			else if (strpbrk(p+1, "\\/") == NULL)
				Result = EnumShares(Name, p, FindData);
			else break;
			if (Result == INVALID_HANDLE_VALUE)
				MyFindClose((HANDLE)(p==NULL ? NetResource : NetResource+3));
			return (Result);
		} while (FALSE);
	#endif
	/*
	 * For enumerating normal filesystem directories, a pointer to the
	 * "real" handle is used instead of the handle returned by the system.
	 * I chose this method to avoid possible but unlikely handle value
	 * conflicts with the server and share enumeration handles.
	 * Currently, there is only one memory location for such handles, so
	 * only one MyFindFirst/MyFindNext/MyFindClose sequence may be in
	 * progress at any time.							25-Sep-2002 Ramo
	 */
	assert(FindFileHandle == INVALID_HANDLE_VALUE);
	FindFileHandle = FIND_FIRST(Name, FindData);
	return (FindFileHandle!=INVALID_HANDLE_VALUE ? &FindFileHandle
												 : INVALID_HANDLE_VALUE);
}

BOOL MyFindNext(HANDLE Handle, FIND_DATA *FindData)
{
	#if defined(WIN32)
		if (	(NETRESOURCE **)Handle >= NetResource &&
			    (NETRESOURCE **)Handle <= NetResource+3) {
			HANDLE Result;

			if ((NETRESOURCE **)Handle < NetResource+3)
				 Result = EnumServers(NULL, FindData);
			else Result = EnumShares (NULL, NULL, FindData);
			return (Result != INVALID_HANDLE_VALUE);
		}
	#endif
	assert(Handle == (HANDLE)&FindFileHandle);
	return (FIND_NEXT(FindFileHandle, FindData));
}

BOOL MyFindClose(HANDLE Handle)
{	BOOL Result;

	#if defined(WIN32)
		if ((NETRESOURCE **)Handle >= NetResource &&
		    (NETRESOURCE **)Handle <= NetResource+3) {
			INT i, i1, i2;

			if ((NETRESOURCE **)Handle < NetResource+3) {
				i1 = 0;
				i2 = 2;
			} else i1 = i2 = 3;
			for (i = i2; i >= i1; --i) {
				if (hEnum[i] != INVALID_HANDLE_VALUE) {
					WNetCloseEnum(hEnum[i]);
					hEnum[i] = INVALID_HANDLE_VALUE;
				}
			}
			Enable();
			SetFocus(hwndCmd);
			return (TRUE);
		}
	#endif
	assert(Handle == (HANDLE)&FindFileHandle);
	Result = FIND_CLOSE(FindFileHandle);
	FindFileHandle = INVALID_HANDLE_VALUE;
	return (Result);
}

BOOL IsDirectory(FIND_DATA *FindData)
{
	return (IS_DIRECTORY(FindData));
}

BOOL IsHidden(FIND_DATA *FindData)
{
	return (IS_HIDDEN(FindData));
}

LPCSTR FoundName(FIND_DATA *FindData)
{
	return (FOUND_NAME(FindData));
}
