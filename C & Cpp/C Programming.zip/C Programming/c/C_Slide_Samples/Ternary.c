/*******************************************************************

SourceName         : Ternary.c

Description        : Ternary operator. 
*******************************************************************/
#include<stdio.h>
int main(void)
{

	int nNum1 = 10, nNum2 = 20;
	printf("Max is %d\n", (nNum1 > nNum2) ? nNum1 : nNum2);
	return(0);
}
