#include <stdio.h>
int main()
{
	char ch;
	int i;

	printf("Enter Character :");
	scanf("%c", &ch);

	printf("Enter Number :");
	scanf("%d", &i);

	printf("Data Entered is : %c %d", ch, i);

	return 0;
}
