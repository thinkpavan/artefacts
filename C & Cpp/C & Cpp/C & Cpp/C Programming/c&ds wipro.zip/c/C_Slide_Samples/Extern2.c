/*******************************************************************

SourceName			: Extern2.c

Dependency			: Extern1.c                                       

Description			: extern keyword 
*******************************************************************/
#include<stdio.h>

int x;	 /* Definition of variable. Memory Allocated here. */
void SetValue()
{
	x = 500;
}