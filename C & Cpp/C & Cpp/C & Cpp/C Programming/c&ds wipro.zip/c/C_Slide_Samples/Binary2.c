/*******************************************************************

SourceName         : Binary2.c                                       

Description        : Using Binary Operator. 
*******************************************************************/
#include <stdio.h>

int main()
{
	printf("%d\n", (5  |  ~3)  &  6);
	return 0;
}
