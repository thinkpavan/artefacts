/*******************************************************************

SourceName         : Addition.c                                       

Description        : Simple Addition Program. 
*******************************************************************/

#include <stdio.h>
int main()
{
	int nNum1 = 10, nNum2 = 20, nNum3 = 0;
	nNum3 = nNum1 + nNum2;
	printf("%d + %d = %d", nNum1, nNum2, nNum3);
	return 0;


}
