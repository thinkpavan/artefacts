#include<stdio.h>

int main()
{
	Display();
}


int Display()
{
	printf("Hello\n");
	return 0;
}