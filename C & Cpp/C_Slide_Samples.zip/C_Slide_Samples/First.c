/*******************************************************************

SourceName         : First.c                                       

Description        : The first C program, prints some messages. 
*******************************************************************/

#include <stdio.h>
int main( )
{
	printf("My first program. \n");
	printf("It is wonderful. \n");
	return 0;
}