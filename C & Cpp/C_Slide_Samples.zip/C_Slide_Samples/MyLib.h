

/* Declare Functions and Global variables*/
int Display();
