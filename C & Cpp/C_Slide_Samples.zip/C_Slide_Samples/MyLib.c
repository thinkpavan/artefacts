/*******************************************************************

SourceName			: MyLib.c

Dependency			: OurMain.c	

Description			: Separate program in more than one file. 
*******************************************************************/
/* Define Func*/
#include<stdio.h>
#include "MyLib.h"

int Display()
{
	printf("From Display Function\n");
	return 0;
}
/* Other function definitions*/ 