/*******************************************************************

SourceName			: OurMain.c

Dependency			: OurLib.c
	
Description			: Separate program in more than one file. 
*******************************************************************/

/* Main Function*/

#include <stdio.h>
#include "MyLib.h"
int main()
{
	Display();
	return 0;
}
