#include<stdio.h>
#define MAX 100
/*
struct nodetype
{
	int info;
	int point;
	int next;
};

struct nodetype node[MAX];

void joinwt(int p , int q , int wt)
{
	int r , r2 ;
	r2 = -1 ;
	r = node[p].point;
	while(r>= 0 && node[p].point!= q){
		r2 = r ;
		r = node[r].next;
	}//end of while

	if(r >= 0)
	{
		node[p].info = wt ;
		return ;
	}
	r = getnode();
	node[r].point = q ;
	node[r].next = -1 ;
	node[r].info = wt ;
	(r2<0)? (node[p].point = r ):(node[p].next=r);
}



int adj[10][10];

void join(int adj[][10] , int node1,int node2)
{
	adj[node2]=1;
}
void remv(int adj[][10],int node1,int node2)
{
	adj[node1][node2] = 0;
}

void adjacent(int adj[][10],int node1,int node2)
{
	return (adj[node1][node2] == 1)?1:0;
}

void main()
{
	
*/
