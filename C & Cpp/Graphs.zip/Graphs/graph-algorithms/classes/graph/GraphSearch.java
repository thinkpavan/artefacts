/*
 * GraphSearch.java
 *
 *    An abstract class for a graph search.
 *
 * Copyright (c) Renaud Waldura, Fri Jun  9 23:31:07 1995
 */

package graph;

import geometry.Rect;



public
interface GraphSearchDisplay
{
    void refresh (Rect r);
}



public
class GraphSearch
    implements GraphSearchDisplay
{

    private
    GraphSearchDisplay display; // where is displayed the search


    public
    void init (GraphSearchDisplay display)
    {
	this.display = display;
    }


    public abstract
    void search (Graph g);


    public
    void refresh (Rect r)
    {
	display.refresh(r);
    }

}




