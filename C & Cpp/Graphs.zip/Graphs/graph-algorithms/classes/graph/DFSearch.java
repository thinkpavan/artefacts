/*
 * DFSearch.java
 *
 *    implements a Depth First Search on a graph.
 *
 * Copyright (c) Renaud Waldura, Sat Jun 10 19:35:14 1995
 */

package graph;

import awt.Color;



public
class DFSearch
    extends GraphSearch
{
    
    protected
    void visit (Graph g, Vertex u)
    {
	g.mark(u, true);             refresh(g.box(u));
	g.paint(u, Color.gray);      refresh(g.box(u));

	int dp = g.degreePlus(u);

	for (int i = 0; i < dp; i++)
	{
	    Vertex v = g.ithSucc(i, u);
	    if (Color.white == g.color(v)) visit(g, v);
	}
	
	g.paint(u, Color.black);     refresh(g.box(u));
	g.mark(u, false);            refresh(g.box(u));
    }

    
    public
    void search (Graph g)
    {
	g.paint(Color.white);   // paint all the graph vertices with white
	g.mark(false);          // unmark the whole graph
	refresh(null);          // and redraw the graph

	visit(g, g.root());
    }


}
