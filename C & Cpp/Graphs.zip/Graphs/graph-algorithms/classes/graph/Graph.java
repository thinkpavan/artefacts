/*
 * Graph.java
 *
 *    A graph package, exports:
 *       - the Vertex class
 *       - the Graph class, implemented with a boolean matrix
 *
 * Copyright (c) Renaud Waldura, Thu Jun 15 03:48:04 1995
 */

package graph;

import awt.Color;
import java.io.*;

import geometry.Rect;



public
class Vertex
{
    int number;
    String name;
    Color color;
    boolean active;
    int x, y;

    Vertex (int number, String name)
    {
	this.number = number;
	this.name = name;
	color = null;
	active = false;
	x = y = 0;
    }

    void position (int _x, int _y)
    {
	x = _x; y = _y;
    }
}



public
class Graph
{

    Vertex vertices[];		// vertices array
    boolean edges[][];		// edges matrix

    int vertex_size;		// constant used for vertex drawing
    boolean directed;		// is the graph directed ?


    /**
     * Graph construction with a number of vertices and a definition file,
     * which format is as follows:
     * <ul>
     *      <li><i>n</i> lines with the #<i>n</i> vertex name, followed by
     *      <li>the edges matrix: <i>n</i> lines of <i>n</i> bits; an edge
     *          between vertices #<i>i</i> and #<i>j</i> when
     *          edges[<i>i</i>][<i>j</i>] == '1'.
     * </ul>
     * Also refer to <a href="http://www.essi.fr/~waldura/graphs.html">the
     * applet web page</a>.
     */
    public
    Graph (int vertices_number, boolean directed, InputStream is)
    {
	this.directed = directed;
        
	vertex_size = 12;       // constants used for drawing the graph

	int border = 20;
	int spacing = 70;

        // parse the graph definition file
        StreamTokenizer st = new StreamTokenizer(is);
        st.commentChar('#');

        // vertices creation
        vertices = new Vertex[vertices_number];
	
        for (int i = 0; i < vertices_number; i++)
        {            
            if (st.nextToken() != StreamTokenizer.TT_WORD)
                throw new DataFormatException(st.toString());
            
            vertices[i] = new Vertex(i, st.sval);
        }
        
        // vertices placement
        int k = 0;
        int z = Math.round(Math.sqrt(vertices_number));

        for (int i = 0; i < z; i++)
            for (int j = 0; j < z; j++)
                if (k < vertices_number) 
                    vertices[k++].position(border + j * spacing, 
                                           border + i * spacing);

        // edges matrix creation
        edges = new boolean[vertices_number][vertices_number];

        // we'll want words made of 0 and 1 characters
        st.resetSyntax();
        st.wordChars('0', '1');
        st.whitespaceChars(0, ' ');
        st.commentChar('#');
        
        for (int i = 0; i < vertices_number; i++)
        {
            if (st.nextToken() != StreamTokenizer.TT_WORD)
                throw new DataFormatException(st.toString());
            
            for (int j = 0; j < vertices_number; j++)
                edges[i][j] = st.sval.charAt(j) == '1';
        }

        // should be at end of the definition file
        if (st.nextToken() != StreamTokenizer.TT_EOF)
            throw new DataFormatException(st.toString());
    }


    /**
     * Returns the graph vertex considered as root.
     */
    public
    Vertex root ()
    {
	return vertices[0];
    }
    

    /**
     * Returns the ith successor of the vertex v in the graph, null if
     * it doesn't exist.
     */
    public
    Vertex ithSucc (int i, Vertex v)
    {
	if (v == null || i < 0) return null;

	int k = 0;

	for (int j = 0; j < vertices.length; j++)
	    if (edges[v.number][j] && k++ == i) return vertices[j];

	return null;				  
    }


    /**
     * Returns the number of edges going out of the vertex v.
     */
    public
    int degreePlus (Vertex v)
    {
	if (v == null) return 0;

	int d = 0;

	for (int j = 0; j < vertices.length; j++)
	    if (edges[v.number][j]) d++;

	return d;
    }

    /**
     * Returns the number of edges going into the vertex v.
     *   **NOT IMPLEMENTED**
     */
    public
    int degreeMinus (Vertex v)
    {
	return -1;
    }


    /**
     * Draws the graph in the graphics g.
     */
    public
    Graph draw (awt.Graphics g)
    {
	for (int i = 0; i < vertices.length; i++)
	    for (int j = 0; j < vertices.length; j++)
		if (edges[i][j]) 
		{
		    int x1 = vertices[i].x + vertex_size / 2,
			y1 = vertices[i].y + vertex_size / 2,
			x2 = vertices[j].x + vertex_size / 2,
			y2 = vertices[j].y + vertex_size / 2;

		    g.drawLine(x1, y1, x2, y2);

		    if (directed) // we try to draw an arrow... :-(
		    {
			g.drawLine(x1 - 1, y1 - 1, x2, y2);
			g.drawLine(x1 - 1, y1 + 1, x2, y2);
			g.drawLine(x1 + 1, y1 - 1, x2, y2);
			g.drawLine(x1 + 1, y1 + 1, x2, y2);
		    }
		}

	for (int i = 0; i < vertices.length; i++) // draw the vertices
	{
	    if (vertices[i].color != null)
	    {
		g.setForeground(vertices[i].color);
		g.fillRect(vertices[i].x, vertices[i].y, vertex_size, vertex_size);
	    }

	    g.setForeground((vertices[i].active) ? Color.red : Color.black);
	    g.drawRect(vertices[i].x, vertices[i].y, vertex_size, vertex_size);

	    g.setForeground(Color.blue);
	    g.drawString(vertices[i].name, vertices[i].x, vertices[i].y - 2);
	}

	return this;
    }


    /**
     * Paints all the graph vertices with color c.
     */
    public
    Graph paint (Color c)
    {
	for (int i = 0; i < vertices.length; i++)
	    paint(vertices[i], c);

	return this;
    }

    /**
     * Paints the graph vertex v with color c; returns its previous color.
     */
    public
    Color paint (Vertex v, Color c)
    {
	if (v == null) return null;

	Color old = v.color;
	v.color = c;
	return old;
    }

    /**
     * Marks/unmarks the whole graph.
     */
    public
    Graph mark (boolean flag)
    {
	for (int i = 0; i < vertices.length; i++)
	    mark(vertices[i], flag);

	return this;
    }

    /**
     * Marks/unmarks the graph vertex v; returns its previous marked state.
     */
    public
    boolean mark (Vertex v, boolean flag)
    {
	if (v == null) return false;

	boolean old = v.active;	
	v.active = flag;
	return old;
    }

    /**
     * Returns a vertex color.
     */
    public
    Color color (Vertex v)
    {
	return (v == null) ? null : v.color;
    }

    /**
     * Returns a bounding box for the vertex v.
     */
    public
    Rect box (Vertex v)
    {
	if (v == null) return null;

	return new Rect(v.x, v.y, vertex_size + 1, vertex_size + 1);
    }

}

