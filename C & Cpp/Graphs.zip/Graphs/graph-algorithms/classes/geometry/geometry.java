/*
 * geometry.java
 *
 *    A package for simple euclidian geometry classes
 *
 * Copyright (c) Renaud Waldura, Fri Jun  9 14:52:44 1995
 */


package geometry;

import awt.Graphics;


/**
 * A point class
 */

public
class Point
{
    public
    int x, y;

    public
    Point ()
    {
	set(0, 0);
    }

    public
    Point (int x, int y)
    {
	set(x, y);
    }

    public
    void set (int x, int y)
    {
	this.x = x; this.y = y;
    }

    public
    void move (Point d)
    {
	move(d.x, d.y);
    }

    public
    void move (int dx, int dy)
    {
	x += dx; y += dy;
    }
}


/**
 * A line class
 */

public
class Line
{
    public
    Point a, b;		// coordinates

    public 
    Line ()
    {
	this(0, 0, 0, 0);
    }

    public
    Line (int x1, int y1, int x2, int y2)
    {
	set(new Point(x1, y1), new Point(x2, y2));
    }

    public
    void set (Point a, Point b)
    {
	this.a = a; this.b = b;
    }

    public
    void move (Point da, Point db)
    {
	a.move(da);
	b.move(db);
    }

    public
    void draw (Graphics g)
    {
	g.drawLine(a.x, a.y, b.x, b.y);
    }
}


/**
 * A rectangle class
 */

public
class Rect
{
    public
    Point origin;

    public
    int width, height;

    public
    Rect (int origin_x, int origin_y, int width, int height)
    {
	origin = new Point(origin_x, origin_y);
	this.width = width; 
	this.height = height;
    }

    public
    boolean contains (Point p)
    {
	return p.x <= origin.x && p.y <= origin.y 
	    && p.x <= origin.x + width && p.y <= origin.y + height;
    }

    public 
    void draw (Graphics g)
    {
	g.drawRect(origin.x, origin.y, width, height);
    }
}
