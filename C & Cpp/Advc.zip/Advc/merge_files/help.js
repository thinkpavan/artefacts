function help(x)
{
     window.open(x, 'test', 'width=700,height=250,menubar=no,location=no,scrollbars=no,dependent=yes')
}


function wind(x, w, h, s)
{
     window.open(x, 'test', 'width='+w+',height='+h+',menubar=no,location=no,scrollbars='+s+',dependent=yes')
}