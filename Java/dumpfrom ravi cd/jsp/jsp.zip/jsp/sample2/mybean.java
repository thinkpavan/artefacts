package mybeans;

public class mybean
{
	private String myname;
	private int mysal;

	public void setMyname(String n)
	{
		myname=n;
	}
	public String getMyname()
	{
		return myname;
	}
	

	public void setMysal(int s)
	{
		mysal=s;
	}
	public int getMysal()
	{
		return mysal;
	}
}