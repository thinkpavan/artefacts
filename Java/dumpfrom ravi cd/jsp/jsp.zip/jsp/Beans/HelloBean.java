public class HelloBean{
	private String name="Trendz";
	private int id=1001;
	public String getName(){
		return name;
		}
	public int getId(){
		return id;
		}
	public void setName(String s){
		name=s;
		}
	public void setId(int i){
		id=i;
		}
	}
