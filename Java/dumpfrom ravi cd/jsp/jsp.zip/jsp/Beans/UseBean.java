package test;
public class UseBean{
String uname;
String passwd;
public void setUname(String uname){
	this.uname=uname;
	}
public String getUname(){
	return uname;
}
}
