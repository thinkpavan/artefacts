package com.oreilly.struts.storefront.framework.database;

public interface Oid {
  public Object getValue();
}