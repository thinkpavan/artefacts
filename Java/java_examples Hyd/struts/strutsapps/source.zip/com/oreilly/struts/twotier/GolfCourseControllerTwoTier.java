package com.oreilly.struts.twotier;
public class GolfCourseControllerTwoTier {
  public GolfCourseControllerTwoTier() {
    
  }
}
