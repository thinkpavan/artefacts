This  app is implement by wiley press book author.

This is implemented for mysql server.

We made the following changes to work with oracle.


1) change in struts config file to connect to oracle server.


2) change in sql script to suite oracle.

3) change in AddEmployeeAction class to suite oracle server.


You can simple copy this folder in webapps and run it.


Assumption : Oracle server will be running on the same machine as that
of tomcat and it's configured with port = 1521 and service name = server.