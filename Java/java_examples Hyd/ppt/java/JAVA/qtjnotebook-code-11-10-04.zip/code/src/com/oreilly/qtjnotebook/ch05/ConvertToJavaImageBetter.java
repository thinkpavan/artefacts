/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch05;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import quicktime.*;
import quicktime.app.view.*;
import quicktime.io.*;
import quicktime.qd.*;
import quicktime.std.*;
import quicktime.std.clocks.*;
import quicktime.std.image.*;
import quicktime.std.movies.*;
import quicktime.std.movies.media.*;

import java.io.*;

public class ConvertToJavaImageBetter extends Frame
    implements ActionListener {

    Movie movie;
    MovieController controller;
    QTComponent qtc;
    GraphicsImporter gi;
    GraphicsImporterDrawer gid;
    static int nextFrameX, nextFrameY;


    public static void main (String[] arrImAPirate) {
        ConvertToJavaImageBetter ctji =
            new ConvertToJavaImageBetter();
        ctji.pack();
        ctji.setVisible(true);
        Rectangle ctjiBounds = ctji.getBounds();
        nextFrameX = ctjiBounds.x + ctjiBounds.width;
        nextFrameY = ctjiBounds.y + ctjiBounds.height;
    }

    public ConvertToJavaImageBetter() {
        super ("QuickTime Movie");
        try {
            // get movie
            QTSessionCheck.check();
            QTFile file =
                QTFile.standardGetFilePreview (QTFile.kStandardQTFileTypes);
            OpenMovieFile omFile = OpenMovieFile.asRead(file);
            movie = Movie.fromFile(omFile);
            controller = new MovieController (movie);
            // build gui
            qtc = QTFactory.makeQTComponent (controller);
            Component c = qtc.asComponent();
            setLayout (new BorderLayout());
            add (c, BorderLayout.CENTER);
            Button imageButton = new Button ("Make Java Image");
            add (imageButton, BorderLayout.SOUTH);
            imageButton.addActionListener (this);
            // set up graphicsimporter
            gi = new GraphicsImporter (StdQTConstants.kQTFileTypePicture);
            gid = new GraphicsImporterDrawer (gi);
            // set up close-to-quit
            addWindowListener (new WindowAdapter() {
                    public void windowClosing (WindowEvent we) {
                        System.exit(0);
                    }
                });
        } catch (QTException qte) {
            qte.printStackTrace();
        }
    }


    public void actionPerformed (ActionEvent e) {
        grabMovieImage();
    }

    public void grabMovieImage() {
        try {
            // stop movie to take picture
            boolean wasPlaying = false;
            if (movie.getRate() > 0) {
                movie.stop();
                wasPlaying = true;
            }

            // take a pict
            Pict pict = movie.getPict (movie.getTime());
            
            // add 512-byte header that pict would have as file
            byte[] newPictBytes =
                new byte [pict.getSize() + 512];
            pict.copyToArray (0,
                              newPictBytes,
                              512,
                              newPictBytes.length - 512);
            pict = new Pict (newPictBytes);
            
            /*
            // debug to disk
            try {
                FileOutputStream out =
                    new FileOutputStream (new File ("newpict.pict"));
                out.write (newPictBytes, 0, newPictBytes.length);
                out.flush();
                out.close();
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
            */

            // export it
            DataRef ref = new DataRef (pict,
                                      StdQTConstants.kDataRefQTFileTypeTag,
                                      "PICT");
            gi.setDataReference (ref);
            QDRect rect = gi.getSourceRect ();
            Dimension dim = new Dimension (rect.getWidth(),
                                           rect.getHeight());
            QTImageProducer ip = new QTImageProducer (gid, dim);
            
            /*
            // sanity check by getting a qtcomponent
            QTComponent giqtc = QTFactory.makeQTComponent (gi);
            Component gic = giqtc.asComponent();
            Frame f = new Frame ("GraphicsImporter");
            f.setLayout (new BorderLayout());
            f.add (gic);
            f.pack();
            f.setVisible(true);
            */

            // convert from MoviePlayer to java.awt.Image
            Image image = Toolkit.getDefaultToolkit().createImage (ip);
            // make a swing icon out of it and show it in a frame
            ImageIcon icon = new ImageIcon (image);
            JLabel label = new JLabel (icon);
            JFrame frame = new JFrame ("Java image");
            frame.getContentPane().add(label);
            frame.pack();
            frame.setLocation (nextFrameX += 10,
                               nextFrameY += 10);
            frame.setVisible(true);
            
            // restart movie
            if (wasPlaying)
                movie.start();
        } catch (QTException qte) {
            qte.printStackTrace();
        }
    } 


}
