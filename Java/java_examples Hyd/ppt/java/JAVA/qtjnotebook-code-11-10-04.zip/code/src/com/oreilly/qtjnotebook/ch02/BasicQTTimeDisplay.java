/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch02;

import quicktime.*;
import quicktime.app.view.*;
import quicktime.std.movies.*;
import quicktime.io.*;

import java.awt.*;
import java.awt.event.*;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class BasicQTTimeDisplay extends Frame
    implements ActionListener {
    Movie theMovie;
    Label timeLabel;

    public BasicQTTimeDisplay (Movie m) throws QTException {
        super ("Basic QT Controller");
        theMovie = m;
        MovieController mc = new MovieController(m);
        QTComponent qc = QTFactory.makeQTComponent (mc);
        Component c = qc.asComponent();
        setLayout (new BorderLayout());
        add (c, BorderLayout.CENTER);
        timeLabel = new Label ("-:--", Label.CENTER);
        add (timeLabel, BorderLayout.SOUTH);
        javax.swing.Timer timer =
            new javax.swing.Timer (250, this);
        timer.start();
        pack();
    }

    public void actionPerformed (ActionEvent e) {
        if (theMovie == null)
                    return;
        try {
            int totalSeconds = theMovie.getTime() /
                               theMovie.getTimeScale();
            int seconds = totalSeconds % 60;
            int minutes = totalSeconds / 60;
            String secString = (seconds > 9) ?
                Integer.toString (seconds) :
                ("0" + Integer.toString (seconds));
            String minString = Integer.toString (minutes);
            timeLabel.setText (minString + ":" + secString);
        } catch (QTException qte) {
            qte.printStackTrace();
        }
    }

    public static void main (String[] args) {
        try {
            QTSessionCheck.check();
            QTFile file =
                QTFile.standardGetFilePreview (QTFile.kStandardQTFileTypes);
            OpenMovieFile omFile = OpenMovieFile.asRead (file);
            Movie m = Movie.fromFile (omFile);
            Frame f = new BasicQTTimeDisplay (m);
            f.pack();
            f.setVisible(true);
            m.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
