/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch08;

import quicktime.*;
import quicktime.std.*;
import quicktime.std.movies.*;
import quicktime.std.movies.media.*;
import quicktime.std.image.*;
import quicktime.io.*;
import quicktime.qd.*;
import quicktime.util.*;
import quicktime.app.view.*;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

import java.awt.*;

public class CompositeVideoTracks extends Frame {

    static Movie foreMovie, backMovie;

    public static void main(String[] args) {
        try {
            QTSessionCheck.check();
            // get background movie
            QTFile file = QTFile.standardGetFilePreview (QTFile.kStandardQTFileTypes);
            OpenMovieFile omf = OpenMovieFile.asRead(file);
            backMovie = Movie.fromFile (omf);
            // get foreground movie
            file = QTFile.standardGetFilePreview (QTFile.kStandardQTFileTypes);
            omf = OpenMovieFile.asRead(file);
            foreMovie = Movie.fromFile (omf);
            // get frame
            Frame frame = new CompositeVideoTracks (backMovie, foreMovie);
            frame.pack();
            frame.setVisible (true);
        } catch (QTException qte) {
            qte.printStackTrace();
        }
    }

    public CompositeVideoTracks (Movie backMovie, Movie foreMovie)
        throws QTException {
        super ("Composite Video Tracks");
        Movie matrixMovie = new Movie();
        // build tracks
        Track foreTrack = addVideoTrack (foreMovie, matrixMovie);
        Track backTrack = addVideoTrack (backMovie, matrixMovie);
        // set graphicsmode composite
        GraphicsMode gm = new GraphicsMode (QDConstants.addMax,
                                            QDColor.green);
        VisualMediaHandler foreHandler = 
            (VisualMediaHandler) foreTrack.getMedia().getHandler();
        foreHandler.setGraphicsMode(gm);
        foreTrack.setLayer(-1);
        // now get component and add to frame
        MovieController controller = new MovieController(matrixMovie);
        Component c = QTFactory.makeQTComponent(controller).asComponent();
        add (c);
    }

    public Track addVideoTrack (Movie sourceMovie, Movie targetMovie)
        throws QTException { 
        Track videoTrack = 
            sourceMovie.getIndTrackType (1,
                                         StdQTConstants.videoMediaType,
                                         StdQTConstants.movieTrackMediaType);
        if (videoTrack == null)
            throw new QTException ("can't find a video track");
        // add videoTrack to targetMovie
        Track newTrack =
            targetMovie.newTrack (videoTrack.getSize().getWidthF(),
                                  videoTrack.getSize().getHeightF(),
                                  1.0f);
        VideoMedia newMedia = 
            new VideoMedia (newTrack,
                            videoTrack.getMedia().getTimeScale(),
                            new DataRef(new QTHandle()));
        videoTrack.insertSegment (newTrack,
                                 0,
                                 videoTrack.getDuration(),
                                 0);
        return newTrack;
    }

}
