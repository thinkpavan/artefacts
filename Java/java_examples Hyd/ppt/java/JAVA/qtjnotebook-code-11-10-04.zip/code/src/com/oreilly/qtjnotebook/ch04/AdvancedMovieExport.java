/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch04;

import quicktime.*;
import quicktime.std.*;
import quicktime.std.movies.*;
import quicktime.io.*;
import quicktime.std.comp.*;
import quicktime.std.qtcomponents.*;

import java.awt.*;
import javax.swing.*;
import java.util.Vector;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class AdvancedMovieExport extends Object {

    public static final void main (String[] args) {
        new AdvancedMovieExport();
    }

    public AdvancedMovieExport() {
        try {
            // query user for a movie to open
            QTSessionCheck.check();
            QTFile file =
                QTFile.standardGetFilePreview (QTFile.kStandardQTFileTypes);
            OpenMovieFile omFile = OpenMovieFile.asRead (file);
            Movie movie = Movie.fromFile (omFile);

            // build up list of suitable components
            Vector choices = new Vector();
            ComponentIdentifier ci = null;
            ComponentDescription cd =
                new ComponentDescription(StdQTConstants.movieExportType);
            while ( (ci = ComponentIdentifier.find(ci, cd)) != null) {
                // check to see that the movie can be exported
                // with this component (this throws some obnoxious
                // exceptions, maybe a bit expensive?)
                try {
                    MovieExporter exporter = new MovieExporter (ci);
                    if (exporter.validate (movie, null)) {
                        ExportChoice choice =
                            new ExportChoice (ci.getInfo().getName(),
                                              ci);
                        choices.addElement(choice);
                    }
                } catch (StdQTException expE) {
                    System.out.println ("** can't validate " +
                                        ci.getInfo().getName() + " **");
                    // expE.printStackTrace();
                } // ow!
            }

            // offer a choice of movie exporters
            JComboBox exportCombo = new JComboBox (choices);
            JOptionPane.showMessageDialog (null,
                                           exportCombo,
                                           "Choose exporter",
                                           JOptionPane.PLAIN_MESSAGE);
            ExportChoice choice = 
                (ExportChoice) exportCombo.getSelectedItem();
            System.out.println ("chose " + choice.name);

            // create an exporter
            MovieExporter exporter = new MovieExporter (choice.identifier);

            QTFile saveFile = new QTFile (new java.io.File("Untitled"));

            // do the export
            /* this works too, assuming you set a file up front
            exporter.toFile (saveFile,
                             movie, 
                             null,
                             0,
                             movie.getDuration());
            */

            movie.setProgressProc();
            movie.convertToFile (null,
                                 saveFile,
                                 StdQTConstants.kQTFileTypeMovie,
                                 StdQTConstants.kMoviePlayer,
                                 IOConstants.smSystemScript,
                                 StdQTConstants.showUserSettingsDialog |
                                 StdQTConstants.movieToFileOnlyExport |
                                 StdQTConstants.movieFileSpecValid, // flags
                                 exporter);


            // need to explicitly quit (since awt is running)
            System.exit(0);
        } catch (QTException qte) {
            qte.printStackTrace();
        }
        
    }

    public class ExportChoice {
        String name;
        ComponentIdentifier identifier;
        public ExportChoice (String n,
                             ComponentIdentifier ci) {
            name = n;
            identifier = ci;
        }
        public String toString() {
            return name;
        }
    }

}
