/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch05;

import quicktime.*;
import quicktime.app.view.*;
import quicktime.std.*;
import quicktime.std.image.*;
import quicktime.io.*;
import quicktime.qd.*;

import java.awt.*;
import java.io.*;
import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class PictTour extends Object {

    static final int[] imagetypes =
         { StdQTConstants.kQTFileTypeQuickTimeImage};

    static int frameX = -1;
    static int frameY = -1;

    public static void main (String[] args) {
        try {
            QTSessionCheck.check();

            // import a graphic
            QTSessionCheck.check();
            QTFile inFile =  QTFile.standardGetFilePreview (imagetypes);
            GraphicsImporter importer =
                new GraphicsImporter (inFile);
            showFrameForImporter (importer,
                                  "Original Import");
            // get a pict object and then save it
            // then load again and show
            Pict pict = importer.getAsPicture();
            String absPictPath = (new File ("pict.pict")).getAbsolutePath();
            File pictFile = new File (absPictPath);
            if (pictFile.exists())
                pictFile.delete();
            try { Thread.sleep (1000); } catch (InterruptedException ie) {}
            pict.writeToFile (pictFile);
            QTFile pictQTFile = new QTFile (pictFile);
            GraphicsImporter pictImporter =
                new GraphicsImporter (pictQTFile);
            showFrameForImporter (pictImporter,
                                  "pict.pict");
            // write to a pict file from importer
            // then load and show it
            String absGIPictPath = (new File ("gipict.pict")).getAbsolutePath();
            QTFile giPictQTFile = new QTFile (absGIPictPath);
            if (giPictQTFile.exists())
                giPictQTFile.delete();
            try { Thread.sleep (1000); } catch (InterruptedException ie) {}
            importer.saveAsPicture (giPictQTFile,
                                    IOConstants.smSystemScript);
            GraphicsImporter giPictImporter =
                new GraphicsImporter (giPictQTFile);
            showFrameForImporter (giPictImporter,
                                  "gipict.pict");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void showFrameForImporter (GraphicsImporter gi,
                                             String frameTitle) 
        throws QTException {
        QTComponent qtc = QTFactory.makeQTComponent (gi);
        Component c = qtc.asComponent();
        Frame f = new Frame (frameTitle);
        f.add (c);
        f.pack();
        if (frameX == -1) {
            frameX = f.getLocation().x;
            frameY = f.getLocation().y;
        } else {
            Point location = new Point (frameX += 20,
                                        frameY += 20);
            f.setLocation (location);
        }

        f.setVisible (true);
    }

}
