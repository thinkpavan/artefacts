/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch06;

import quicktime.*;
import quicktime.io.*;
import quicktime.std.*;
import quicktime.std.sg.*;
import quicktime.std.movies.*;
import quicktime.std.image.*;
import quicktime.qd.*;
import quicktime.sound.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.Timer;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class AudioVideoCaptureToDisk extends Frame 
    implements ActionListener {

    SequenceGrabber grabber;
    SGVideoChannel videoChannel;
    SGSoundChannel soundChannel;
    QDGraphics gw;
    QDRect grabBounds;
    boolean grabbing;
    Button stopButton;
    QTFile grabFile;

    public AudioVideoCaptureToDisk() throws QTException {
        super ("Audio/Video Capture");
        QTSessionCheck.check();
        setLayout (new GridLayout (2, 1));
        add (new Label ("Capturing video..."));
        stopButton = new Button ("Stop");
        stopButton.addActionListener (this);
        add (stopButton);
        setUpVideoGrab();
    }

    public void actionPerformed (ActionEvent e) {
        if (e.getSource() == stopButton) {
            System.out.println ("Stop grabbing");
            try {
                grabbing = false;
                if (grabber != null) {
                    grabber.stop();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            } finally {
                System.exit (0);
            }
        }
    }


    protected void setUpVideoGrab() throws QTException {
        grabber = new SequenceGrabber();
        System.out.println ("got grabber");

        // force an offscreen gworld
        grabBounds = new QDRect (320, 240);
        gw = new QDGraphics (grabBounds);
        grabber.setGWorld (gw, null);

        // get videoChannel and set its bounds
        videoChannel = new SGVideoChannel (grabber);
        soundChannel = new SGSoundChannel (grabber);
        System.out.println ("Got audio, video channels");
        videoChannel.setBounds (grabBounds);

        // get settings
        // yikes! these often crash java 1.4.2 on mac os x!
        // see book for workaround (call these from non-AWT thread and block AWT on it)
        // soundChannel.settingsDialog();
        // videoChannel.settingsDialog();

        // prepare and start previewing
        videoChannel.setUsage (StdQTConstants.seqGrabRecord);
        soundChannel.setUsage (StdQTConstants.seqGrabPreview |
                               StdQTConstants.seqGrabRecord);
        soundChannel.setVolume (0.0f);
        grabber.prepare(false, true);
        grabber.startPreview();

        // create output file
        grabFile = new QTFile (new java.io.File ("audiovideograb.mov"));
        grabber.setDataOutput(grabFile,
                              StdQTConstants.seqGrabToDisk 
                              //seqGrabDontAddMovieResource);
                              );
        grabber.startRecord();

        grabbing = true;

        // set up thread to idle
        ActionListener timerCallback =
            new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (grabbing) {
                        try {
                            System.out.println ("idle");
                            grabber.idle();
                            grabber.update(null);
                        } catch (QTException qte) {
                            qte.printStackTrace();
                        }
                    }
                }
            };
        Timer timer = new Timer (50, timerCallback);
        timer.start();
    }

    public static void main (String[] args) {
        try {
            Frame f = new AudioVideoCaptureToDisk();
            f.pack();
            f.setVisible(true);
        } catch (QTException qte) {
            qte.printStackTrace();
        }
    }

}
