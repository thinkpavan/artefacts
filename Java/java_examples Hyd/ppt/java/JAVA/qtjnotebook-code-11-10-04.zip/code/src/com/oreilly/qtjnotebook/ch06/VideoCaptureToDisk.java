/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch06;

import quicktime.*;
import quicktime.io.*;
import quicktime.std.*;
import quicktime.std.sg.*;
import quicktime.std.movies.*;
import quicktime.std.image.*;
import quicktime.qd.*;
import quicktime.sound.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.Timer;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class VideoCaptureToDisk extends Frame 
    implements ActionListener {

    SequenceGrabber grabber;
    SGVideoChannel videoChannel;
    QDGraphics gw;
    QDRect grabBounds;
    boolean grabbing;
    Button stopButton;
    QTFile grabFile;

    public VideoCaptureToDisk() throws QTException {
        super ("Video Capture");
        QTSessionCheck.check();
        setLayout (new GridLayout (2, 1));
        add (new Label ("Capturing video..."));
        stopButton = new Button ("Stop");
        stopButton.addActionListener (this);
        add (stopButton);
        setUpVideoGrab();
    }

    public void actionPerformed (ActionEvent e) {
        if (e.getSource() == stopButton) {
            System.out.println ("Stop grabbing");
            try {
                grabbing = false;
                if (grabber != null) {
                    grabber.stop();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            } finally {
                System.exit (0);
            }
        }
    }


    protected void setUpVideoGrab() throws QTException {
        grabber = new SequenceGrabber();
        System.out.println ("got grabber");

        // force an offscreen gworld
        grabBounds = new QDRect (320, 240);
        gw = new QDGraphics (grabBounds);
        grabber.setGWorld (gw, null);

        // get videoChannel and set its bounds
        videoChannel = new SGVideoChannel (grabber);
        System.out.println ("Got SGVideoChannel");
        videoChannel.setBounds (grabBounds);

        /*
        // get settings
        // yikes! this crashes java 1.4.2 on mac os x!
        videoChannel.settingsDialog();
        */
        // kludgey - should do a wait()/notify() block instead
        final SGVideoChannel vc = videoChannel;
        Thread t = new Thread() {
                public void run() {
                    try {
                        vc.settingsDialog();
                    } catch (QTException qte) {
                        qte.printStackTrace();
                    }
                }
            };
        t.start();
        while (t.isAlive())
            Thread.yield();

        // prepare and start previewing
        // note - second prepare arg should seemingly be false,
        // but if it is, you get erroneous dskFulErr's
        videoChannel.setUsage (StdQTConstants.seqGrabRecord);
        grabber.prepare(false, true);
        // TODO: do I still want this?
        grabber.startPreview();

        // create output file
        grabFile = new QTFile (new java.io.File ("videograb.mov"));
        grabber.setDataOutput(grabFile,
                              StdQTConstants.seqGrabToDisk 
                              //seqGrabDontAddMovieResource);
                              );
        grabber.startRecord();

        grabbing = true;

        // set up thread to idle
        ActionListener timerCallback =
            new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (grabbing) {
                        try {
                            System.out.println ("idle");
                            grabber.idle();
                            grabber.update(null);
                        } catch (QTException qte) {
                            qte.printStackTrace();
                        }
                    }
                }
            };
        Timer timer = new Timer (50, timerCallback);
        timer.start();
    }

    public static void main (String[] args) {
        try {
            Frame f = new VideoCaptureToDisk();
            f.pack();
            f.setVisible(true);
        } catch (QTException qte) {
            qte.printStackTrace();
        }
    }

}
