/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch02;

import quicktime.*;
import quicktime.app.view.*;
import quicktime.std.movies.*;
import quicktime.io.*;

import java.awt.*;
import java.awt.event.*;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class BasicQTButtons extends Frame
    implements ActionListener {

    Button revButton,
        stopButton,
        startButton,
        fwdButton;

    Movie theMovie;

    public BasicQTButtons (Movie m) throws QTException {
        super ("Basic QT Player");
        theMovie = m;
        QTComponent qc = QTFactory.makeQTComponent (m);
        Component c = qc.asComponent();
        setLayout (new BorderLayout());
        add (c, BorderLayout.CENTER);
        Panel buttons = new Panel();
        revButton = new Button("<");
        revButton.addActionListener (this);
        stopButton = new Button ("0");
        stopButton.addActionListener (this);
        startButton = new Button ("1");
        startButton.addActionListener (this);
        fwdButton = new Button (">");
        fwdButton.addActionListener (this);
        buttons.add (revButton);
        buttons.add (stopButton);
        buttons.add (startButton);
        buttons.add (fwdButton);
        add (buttons, BorderLayout.SOUTH);
        pack();
    }

    public void actionPerformed (ActionEvent e) {
        try {
            if (e.getSource() == revButton)
                theMovie.setRate (theMovie.getRate() - 0.5f);
            else if (e.getSource() == stopButton)
                theMovie.stop();
            else if (e.getSource() == startButton)
                theMovie.start();
            else if (e.getSource() == fwdButton)
                theMovie.setRate (theMovie.getRate() + 0.5f);
        } catch (QTException qte) {
            qte.printStackTrace();
        }
    }

    public static void main (String[] args) {
        try {
            QTSessionCheck.check();
            QTFile file =
                QTFile.standardGetFilePreview (QTFile.kStandardQTFileTypes);
            OpenMovieFile omFile = OpenMovieFile.asRead (file);
            Movie m = Movie.fromFile (omFile);
            Frame f = new BasicQTButtons (m);
            f.pack();
            f.setVisible(true);
            m.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
