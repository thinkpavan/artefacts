/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch05;

import quicktime.*;
import quicktime.std.*;
import quicktime.std.image.*;
import quicktime.qd.*;
import quicktime.io.*;
import quicktime.util.*;
import quicktime.app.view.*;
import java.io.*;
import java.awt.*;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class GraphicImportMatrix extends Object {

    public static void main (String[] args) {
        try {
            QTSessionCheck.check();

            File graphicsDir = new File ("graphics");
            QTFile pngFile1 = new QTFile (new File (graphicsDir, "1.png"));
            QTFile pngFile2 = new QTFile (new File (graphicsDir, "2.png"));
            GraphicsImporter gi1 = new GraphicsImporter (pngFile1);
            GraphicsImporter gi2 = new GraphicsImporter (pngFile2);
            
            // define some matrix transforms on importer 1
            QDRect bounds = gi1.getBoundsRect();
            // combine translation (movement) and scaling into
            // one call to rect
            QDRect newBounds =
                new QDRect (bounds.getWidth()/4,
                            bounds.getHeight()/4,
                            bounds.getWidth()/2,
                            bounds.getHeight()/2);
            Matrix matrix = new Matrix();
            matrix.rect(bounds, newBounds);
            // rotate about its center
            matrix.rotate (30,
                           (bounds.getWidth() - bounds.getX())/2,
                           (bounds.getHeight() - bounds.getY())/2);
            gi1.setMatrix (matrix);

            // draw somewhere
            QDGraphics scratchWorld = new QDGraphics (gi2.getBoundsRect());
            System.out.println ("Scratch world: " + scratchWorld);
            // draw background
            gi2.setGWorld (scratchWorld, null);
            gi2.draw();
            // draw foreground
            gi1.setGWorld (scratchWorld, null);
            gi1.draw();

            int bufSize =
                QTImage.getMaxCompressionSize (scratchWorld, 
                                               scratchWorld.getBounds(),
                                               0,
                                               StdQTConstants.codecNormalQuality,
                                               StdQTConstants4.kPNGCodecType,
                                               CodecComponent.anyCodec);
            byte[] compBytes = new byte[bufSize];
            RawEncodedImage compImg = new RawEncodedImage (compBytes);
            ImageDescription id = QTImage.compress(scratchWorld,
                                                   scratchWorld.getBounds(),
                                                   StdQTConstants.codecNormalQuality,
                                                   StdQTConstants4.kPNGCodecType,
                                                   compImg);
            System.out.println ("rei compressed from gw is " +
                                compImg.getSize());

            /* works, but please kludge less
            try {
                FileOutputStream out = new FileOutputStream ("matrix.png");
                byte compImgBytes[] = compImg.getBytes();
                out.write(compImgBytes, 0, compImgBytes.length);
                out.flush();
                out.close();
            } catch (java.io.IOException ioe) {
                ioe.printStackTrace();
            }
            */

            System.out.println ("exporting");
            GraphicsExporter exporter =
                new GraphicsExporter (StdQTConstants4.kQTFileTypePNG);
            exporter.setInputPtr (compImg, id);
            QTFile outFile = new QTFile (new File ("matrix.png"));
            exporter.setOutputFile (outFile);
            exporter.doExport();
            System.out.println ("did export");

        } catch (QTException qte) {
            qte.printStackTrace();
        }
        System.exit(0);
    }
}
