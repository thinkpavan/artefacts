/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch07;

import quicktime.*;
import quicktime.std.*;
import quicktime.std.movies.*;
import quicktime.std.movies.media.*;
import quicktime.app.view.*;
import quicktime.io.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class LevelMeterPlayer extends Frame { 

    /*
    int[] EQ_LEVELS = {
        32,
        64,
        125,
        250,
        500,
        1000,
        2000,
        4000,
        8000,
        16000
    };
    */

    // bands used by apple sndequalizer example
    // http://developer.apple.com/samplecode/sndequalizer/sndequalizer.html
    int[] EQ_LEVELS = {
        200,
        400,
        800,
        1600,
        3200,
        6400,
        12800,
        21000
    };


    static final Dimension meterMinSize =
        new Dimension (300, 150);
    LevelMeter meter;
    AudioMediaHandler audioMediaHandler;

    public static void main (String[] args) {
        try {
            QTSessionCheck.check();
            Frame f= new LevelMeterPlayer();
            f.pack();
            f.setVisible(true);
        } catch (QTException qte) {
            qte.printStackTrace();
        }
    }

    public LevelMeterPlayer () throws QTException {
        super ("Audio Level Meter");
        // prompt for audio file
        QTFile file = QTFile.standardGetFilePreview(
                          QTFile.kStandardQTFileTypes);
        OpenMovieFile omf = OpenMovieFile.asRead (file);
        Movie movie = Movie.fromFile (omf);
        MovieController controller = new MovieController (movie);
        // get AudioMediaHandler for first audio track
        for (int i=1; i<=movie.getTrackCount(); i++) {
            Track t = movie.getTrack(i);
            Media m = t.getMedia();
            MediaHandler mh = m.getHandler();
            if (mh instanceof AudioMediaHandler) {
                audioMediaHandler = (AudioMediaHandler) mh;
                break;
            }
        }
        if (audioMediaHandler == null) {
            System.out.println ("No audio track");
            System.exit(-1);
        }
        // add controller to GUI
        setLayout (new BorderLayout());
        Component comp =
            QTFactory.makeQTComponent(controller).asComponent();
        add (comp, BorderLayout.NORTH);
        // add level meter to GUI
        meter = new LevelMeter();
        add (meter, BorderLayout.SOUTH);
        // set up repainting timer
        Timer t = new Timer (50, new ActionListener() {
                public void actionPerformed (ActionEvent ae) {
                    meter.repaint();
                }
            });
        t.start();
    }

    class LevelMeter extends Canvas {
        public Dimension getPreferredSize() { return meterMinSize; }
        public Dimension getMinimumSize() { return meterMinSize; }
        public LevelMeter() throws QTException {
            MediaEQSpectrumBands bands =
                new MediaEQSpectrumBands (EQ_LEVELS.length);
            for (int i=0; i<EQ_LEVELS.length; i++) {
                bands.setFrequency (i, EQ_LEVELS[i]);
                audioMediaHandler.setSoundEqualizerBands (bands);
                audioMediaHandler.setSoundLevelMeteringEnabled (true);
            }
        }

        public void paint (Graphics g) {
            int gHeight = this.getHeight();
            int gWidth = this.getWidth();

            // draw baseline
            g.drawLine (0, gHeight, gWidth, gHeight);
            try {
                if (audioMediaHandler != null) {
                    int[] levels =
                        audioMediaHandler.getSoundEqualizerBandLevels(EQ_LEVELS.length);
                    int maxHeight = gHeight - 1;
                    int barWidth = gWidth / levels.length;
                    
                    // boolean foundDud = false;
                    int segInterval = gHeight / 20;
                    // calculate height of each set of boxes,
                    // proportional to level
                    for (int i=0; i<levels.length; i++) {
                        float levPct = ((float)levels[i]) / 255.0f;
                        // math is a little weird here; y axis has 0 at top,
                        // but we have 0 at bottom of this graph
                        int barHeight = (int) (levPct * maxHeight);
                        // draw the bar as set of 0-20 rectangles
                        int barCount = 0;
                        for (int j=maxHeight;
                             j > (maxHeight - barHeight);
                             j-=segInterval) {
                            switch (barCount) {
                            case 20:
                            case 19: 
                            case 18:
                                g.setColor (Color.red);
                                break;
                            case 17:
                            case 16:
                            case 15:
                                g.setColor (Color.yellow);
                                break;
                            default:
                                g.setColor (Color.green);
                            }
                            g.fillRect (i * barWidth,
                                        j - segInterval,
                                        barWidth - 1,
                                        segInterval - 1);
                            barCount++;
                        }
                    }
                }
            } catch (QTException qte) {
                qte.printStackTrace();
            }
            
        }

    }
}
