/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch05;

import quicktime.*;
import quicktime.std.*;
import quicktime.std.image.*;
import quicktime.qd.*;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class GWorldToPict extends Object implements QDDrawer {

    public static void main (String[] args) {
        new GWorldToPict();
    }

    public GWorldToPict() {
        try {
            QTSessionCheck.check();
            QDRect bounds = new QDRect (0, 0, 200, 250);
            ImageDescription imgDesc =
                new ImageDescription(QDConstants.k32RGBAPixelFormat);
            imgDesc.setHeight (bounds.getHeight());
            imgDesc.setWidth (bounds.getWidth());
            QDGraphics gw = new QDGraphics (imgDesc, 0);
            System.out.println ("GWorld created: " + gw);
            
            OpenCPicParams params = new OpenCPicParams(bounds);

            Pict pict = Pict.open (gw, params);
            gw.beginDraw (this);

            pict.close();

            try {
                pict.writeToFile (new java.io.File ("gworld.pict"));
            } catch (java.io.IOException ioe) {
                ioe.printStackTrace();
            }
        } catch (QTException qte) {
            qte.printStackTrace();
        }
        System.exit(0);

    }

    public void draw (QDGraphics gw) throws QTException {
        System.out.println ("draw() called with GWorld " + gw);
        QDRect bounds = gw.getBounds();
        System.out.println ("bounds: " + bounds);
        // clear drawing surface, set up colors
        gw.setBackColor (QDColor.lightGray);
        gw.eraseRect (bounds);
        // draw some shapes
        gw.penSize (2, 2);
        gw.moveTo (20,20);
        gw.setForeColor (QDColor.green);
        gw.line (30, 100);
        gw.moveTo (20,20);
        gw.setForeColor (QDColor.blue);
        gw.lineTo (30, 100);

        // draw some text
        gw.setForeColor (QDColor.red);
        gw.textSize (24);
        gw.moveTo (10, 150);
        gw.drawText ("QDGraphics", 0, 10);

        // draw some shapes
        gw.setForeColor (QDColor.magenta);
        QDRect rect = new QDRect (0, 170, 40, 30);
        gw.paintRoundRect (rect, 0, 0);
        QDRect roundRect = new QDRect (50, 170, 40, 30);
        gw.paintRoundRect (roundRect, 10, 10);
        QDRect ovalRect = new QDRect (100, 170, 40, 30);
        gw.paintOval (ovalRect);
        QDRect arcRect = new QDRect (150, 170, 40, 30);
        gw.paintArc (arcRect, 15, 215);
    }

}
