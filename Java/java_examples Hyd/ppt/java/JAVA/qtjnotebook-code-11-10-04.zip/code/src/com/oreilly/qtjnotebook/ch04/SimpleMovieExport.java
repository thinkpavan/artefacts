/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch04;

import quicktime.*;
import quicktime.std.*;
import quicktime.std.movies.*;
import quicktime.io.*;
import quicktime.std.qtcomponents.*;
import quicktime.util.QTUtils;

import java.awt.*;
import javax.swing.*;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class SimpleMovieExport extends Object {

    public static final void main (String[] args) {
        new SimpleMovieExport();
    }

    public SimpleMovieExport() {
        // build choices
        ExportChoice[] choices = new ExportChoice[3];
        choices[0] =
            new ExportChoice ("QuickTime Movie",
                              StdQTConstants.kQTFileTypeMovie);
        choices[1] =
            new ExportChoice ("AVI file",
                              StdQTConstants.kQTFileTypeAVI);
        choices[2] =
            new ExportChoice ("MPEG-4 file", 
                              // 0x6d706734);
                              QTUtils.toOSType("mpg4"));

        try {
            // query user for a movie to open
            QTSessionCheck.check();
            QTFile file =
                QTFile.standardGetFilePreview (QTFile.kStandardQTFileTypes);
            OpenMovieFile omFile = OpenMovieFile.asRead (file);
            Movie movie = Movie.fromFile (omFile);

            // offer a choice of movie exporters
            JComboBox exportCombo = new JComboBox (choices);
            JOptionPane.showMessageDialog (null,
                                           exportCombo,
                                           "Choose exporter",
                                           JOptionPane.PLAIN_MESSAGE);
            ExportChoice choice = 
                (ExportChoice) exportCombo.getSelectedItem();
            System.out.println ("chose " + choice.name);

            // create an exporter
            MovieExporter exporter =
                new MovieExporter (choice.subtype);

            QTFile saveFile = new QTFile (new java.io.File("Untitled"));

            // do the export
            /* this works too
            exporter.toFile (saveFile,
                             movie, 
                             null,
                             0,
                             movie.getDuration());
            */

            movie.setProgressProc();
            movie.convertToFile (null,
                                 saveFile,
                                 StdQTConstants.kQTFileTypeMovie,
                                 StdQTConstants.kMoviePlayer,
                                 IOConstants.smSystemScript,
                                 StdQTConstants.showUserSettingsDialog |
                                 StdQTConstants.movieToFileOnlyExport |
                                 StdQTConstants.movieFileSpecValid, // flags
                                 exporter);


            // need to explicitly quit (since awt is running)
            System.exit(0);
        } catch (QTException qte) {
            qte.printStackTrace();
        }
        
    }

    public class ExportChoice {
        String name;
        int subtype;
        public ExportChoice (String n, int st) {
            name = n;
            subtype = st;
        }
        public String toString() {
            return name;
        }
    }

}
