/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch07;

import quicktime.*;
import quicktime.std.*;
import quicktime.std.movies.*;
import quicktime.std.movies.media.*;
import quicktime.io.*;
import quicktime.util.*;
import java.util.*;
import java.math.BigInteger;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class AACTagReader extends Object {

    /* these values are straight out of Movies.h
    */
    final static int  kUserDataTextAlbum            = 0xA9616C62; /*'�alb' */
    final static int  kUserDataTextArtist           = 0xA9415254; 
    final static int  kUserDataTextCreationDate     = 0xA9646179; /*'�day' */
    final static int  kUserDataTextFullName         = 0xA96E616D; /*'�nam' */

    /* This array maps all the tag constants to human-readable
       strings (I18N note: could be a localized properties file!)
     */
    private static final Object[][] TAG_NAMES = {
        {new Integer (kUserDataTextAlbum), "Album"},
        {new Integer (kUserDataTextArtist),"Artist" },
        {new Integer (kUserDataTextCreationDate), "Created"},
        {new Integer (kUserDataTextFullName), "Full Name"}
    };

    private static final HashMap TAG_MAP =
        new HashMap(TAG_NAMES.length);
    static {
        for (int i=0; i<TAG_NAMES.length; i++) {
            TAG_MAP.put (TAG_NAMES[i][0],
                         TAG_NAMES[i][1]);
        }
    }

    public static void main (String[] args) {
        new AACTagReader();
        System.exit(0);
    }

    public AACTagReader() {
        try {
            QTSessionCheck.check();
            QTFile f = QTFile.standardGetFilePreview (null);
            OpenMovieFile omf = OpenMovieFile.asRead(f);
            Movie movie = Movie.fromFile (omf);
            // get user data
            UserData userData = movie.getUserData();
            dumpTagsFromUserData(userData);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void dumpTagsFromUserData (UserData userData)
        throws QTException {
        int metaFCC = QTUtils.toOSType("meta");
        QTHandle metaHandle = userData.getData (metaFCC, 1);
        System.out.println ("Found meta");
        byte[] metaBytes = metaHandle.getBytes();

        // locate the "ilst" pseudo-atom, ignoring first 4 bytes
        int ilstFCC = QTUtils.toOSType("ilst");
        // System.out.println ("Looking for ilst, " + FCC_ilst);
        PseudoAtomPointer ilst = findPseudoAtom (metaBytes, 4, ilstFCC);
        // System.out.println ("Found ilst at " + ilst.offset);

        // iterate over the pseudo-atoms inside the "ilst"
        // building lists of tags and values from which we'll
        // create arrays for the DefaultTableModel constructor
        int off = ilst.offset + 8;
        ArrayList foundTags = new ArrayList (TAG_NAMES.length);
        ArrayList foundValues = new ArrayList (TAG_NAMES.length);
        while (off < metaBytes.length) {
            PseudoAtomPointer atom = findPseudoAtom (metaBytes, off, -1);
            /*
            System.out.println ("Found " +
                                QTUtils.fromOSType (atom.type) +
                                " atom at " + atom.offset);
            */
            String tagName = (String) TAG_MAP.get (new Integer(atom.type));
            if (tagName != null) {
                // if we match a type, read everything after byte 24
                // which skips size, type, size, 'data', 8 junk bytes
                byte[] valueBytes = new byte [atom.atomSize - 24];
                System.arraycopy (metaBytes,
                                  atom.offset+24,
                                  valueBytes,
                                  0,
                                  valueBytes.length);
                // note: this approach is stupid about UTF-8'ed data
                String value = new String (valueBytes);
                System.out.println (tagName + ": " + value);
            } // if tagName != null
            off = atom.offset + atom.atomSize;
        }

    }

    /** find the given type in the byte array, starting at
        the start position.  Returns the offset within the
        bye array that begins this pseudo-atom.  a helper method
        to populateFromMetaAtom().
        @param bytes byte array to search
        @param start offset to start at
        @param type type to search for.  if -1, returns first
        atom with a plausible size
     */
    private PseudoAtomPointer findPseudoAtom (byte[] bytes,
                                              int start,
                                              int type) {
        // read size, then type
        // if size is bogus, forget it, increment offset, and try again
        int off = start;
        boolean found = false;
        while ((! found) &&
               (off < bytes.length-8)) {
            // read 32 bits of atom size
            // use BigInteger to convert bytes to long
            // (instead of signed int)
            byte sizeBytes[] = new byte[4];
            System.arraycopy (bytes, off, sizeBytes, 0, 4);
            BigInteger atomSizeBI = new BigInteger (sizeBytes);
            long atomSize = atomSizeBI.longValue();

            // don't bother if the size would take us beyond end of
            // array, or is impossibly small
            if ((atomSize > 7) &&
                (off + atomSize <= bytes.length)) {
                byte[] typeBytes = new byte[4];
                System.arraycopy (bytes, off+4, typeBytes, 0, 4);
                int aType = QTUtils.toOSType (new String (typeBytes));

                if ((type == aType) ||
                    (type == -1))
                    return new PseudoAtomPointer (off, (int) atomSize, aType);
                else
                    off += atomSize;
                                    
            } else {
                System.out.println ("bogus atom size " + atomSize);
                // well, how did this happen?  increment off and try again
                off++;
            }
        } // while
        return null;
    }

    /** Inner class to represent atom-like structures inside
        the meta atom, designed to work with the byte array 
        of the meta atom (ie, just wraps pointers to the 
        beginning of the atom and its computed size and type)
     */
    class PseudoAtomPointer {
        int offset;
        int atomSize;
        int type;
        public PseudoAtomPointer (int o, int s, int t) {
            offset=o;
            atomSize=s;
            type=t;
        }
        
    }



}
