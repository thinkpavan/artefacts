/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch09;

import quicktime.*;
import quicktime.std.*;
import quicktime.std.movies.*;
import quicktime.std.movies.media.*;
import quicktime.io.*;
import quicktime.std.image.*;
import quicktime.util.*;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class EffectOnlyTrackBuilder {

    public static final int EFFECT_TRACK_WIDTH = 320;
    public static final int EFFECT_TRACK_HEIGHT = 240;
    public static final int TIMESCALE = 600;

    public static void main (String[] args) {
        try {
            new EffectOnlyTrackBuilder();
        } catch (QTException qte) {
            qte.printStackTrace();
        }
        System.exit(0);
    }

    public EffectOnlyTrackBuilder() throws QTException {
        QTSessionCheck.check();

        QTFile movFile = new QTFile (new java.io.File("effectonly.mov"));
        Movie movie =
            Movie.createMovieFile(movFile,
                                  StdQTConstants.kMoviePlayer,
                                  StdQTConstants.createMovieFileDeleteCurFile |
                                  StdQTConstants.createMovieFileDontCreateResFile);
        Track effectsTrack = movie.addTrack (EFFECT_TRACK_WIDTH,
                                             EFFECT_TRACK_HEIGHT,
                                             0);
        int TIMESCALE = 600;
		VideoMedia effectsMedia = new VideoMedia(effectsTrack,
                                               TIMESCALE);
        // get list of effects
        // StdQTConstants.elOptionsIncludeNoneInList)
        EffectsList effectsList = new EffectsList (0, 0, 0);
        // show list of effects
        // flags are in StdQTConstants.pdOptions...
        // (http://developer.apple.com/documentation/QuickTime/REF/refEffects.61.htm)
        AtomContainer effect =
            ParameterDialog.showParameterDialog (effectsList, // effectsList
                                                 0, // dialogOptions
                                                 null, // parameters
                                                 "Pick an effect", // title
                                                 null //pictArray
                                                 );
        // find out the effect type by getting the "what" atom,
        // whose data is a FOUR_CHAR_CODE
        Atom what = effect.findChildByIndex_Atom (null, 
                                                   StdQTConstants.kParameterWhatName,
                                                   1);
        int effectType = effect.getAtomData(what).getInt(0);
        effectType = EndianOrder.flipBigEndianToNative32(effectType);
        System.out.println ("User chose " + 
                            QTUtils.fromOSType(effectType) +
                            " effect type");

        // make a sample description for the effect description
        ImageDescription imgDesc = ImageDescription.forEffect (effectType);
        imgDesc.setWidth (EFFECT_TRACK_WIDTH);
        imgDesc.setHeight (EFFECT_TRACK_HEIGHT);

        // add effect to the video media
        effectsMedia.beginEdits();

        effectsMedia.addSample (effect, // QTHandleRef data,
                              0, // int dataOffset,
                              effect.getSize(), // int dataSize,
                              1200, //int durationPerSample,
                              imgDesc, // SampleDescription sampleDesc,
                              1, // int numberOfSamples,
                              0 // int sampleFlags
                              );

        effectsMedia.endEdits();

        // now insert this media into track
        effectsTrack.insertMedia (0, // trackStart
                                0, // mediaTime
                                effectsMedia.getDuration(), // mediaDuration
                                1); // mediaRate
        System.out.println ("inserted media into effects track");

        // save up 
        System.out.println ("Saving...");
        OpenMovieFile omf = OpenMovieFile.asWrite (movFile);
        movie.addResource (omf,
                           StdQTConstants.movieInDataForkResID,
                           movFile.getName());
        System.out.println ("Done");

    }

}
