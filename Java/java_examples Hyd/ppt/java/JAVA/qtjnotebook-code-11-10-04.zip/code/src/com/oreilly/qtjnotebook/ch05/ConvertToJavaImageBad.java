/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch05;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import quicktime.*;
import quicktime.app.view.*;
import quicktime.io.*;
import quicktime.qd.*;
import quicktime.std.*;
import quicktime.std.clocks.*;
import quicktime.std.movies.*;

public class ConvertToJavaImageBad extends Frame
    implements ActionListener {

    Movie movie;
    MoviePlayer player;
    MovieController controller;
    QTComponent qtc;
    static int nextFrameX, nextFrameY;
    QTImageProducer ip;

    public static void main (String[] arrImAPirate) {
        ConvertToJavaImageBad ctji = new ConvertToJavaImageBad();
        ctji.pack();
        ctji.setVisible(true);
        Rectangle ctjiBounds = ctji.getBounds();
        nextFrameX = ctjiBounds.x + ctjiBounds.width;
        nextFrameY = ctjiBounds.y + ctjiBounds.height;
    }

    public ConvertToJavaImageBad() {
        super ("QuickTime Movie");
        try {
            // get movie
            QTSessionCheck.check();
            QTFile file =
                QTFile.standardGetFilePreview (QTFile.kStandardQTFileTypes);
            OpenMovieFile omFile = OpenMovieFile.asRead(file);
            movie = Movie.fromFile(omFile);
            player = new MoviePlayer (movie);
            controller = new MovieController (movie);
            // build gui
            qtc = QTFactory.makeQTComponent (controller);
            Component c = qtc.asComponent();
            setLayout (new BorderLayout());
            add (c, BorderLayout.CENTER);
            Button imageButton = new Button ("Make Java Image");
            add (imageButton, BorderLayout.SOUTH);
            imageButton.addActionListener (this);
            movie.start();
            // set up close-to-quit
            addWindowListener (new WindowAdapter() {
                    public void windowClosing (WindowEvent we) {
                        System.exit(0);
                    }
                });
        } catch (QTException qte) {
            qte.printStackTrace();
        }
    }


    public void actionPerformed (ActionEvent e) {
        grabMovieImage();
    }

    public void grabMovieImage() {
        try {
            // lazy instantiation of ImageProducer
            if (ip == null) {
                QDRect bounds = movie.getBounds();
                Dimension dimBounds =
                    new Dimension (bounds.getWidth(), bounds.getHeight());
                ip = new QTImageProducer (player, dimBounds);
             }

            // stop movie to take picture
            boolean wasPlaying = false;
            if (movie.getRate() > 0) {
                movie.stop();
                wasPlaying = true;
            }

            // convert from MoviePlayer to java.awt.Image
            Image image = Toolkit.getDefaultToolkit().createImage (ip);
            // make a swing icon out of it and show it in a frame
            ImageIcon icon = new ImageIcon (image);
            JLabel label = new JLabel (icon);
            JFrame frame = new JFrame ("Java image");
            frame.getContentPane().add(label);
            frame.pack();
            frame.setLocation (nextFrameX += 10,
                               nextFrameY += 10);
            frame.setVisible(true);
            // restart movie
            if (wasPlaying)
                movie.start();
        } catch (QTException qte) {
            qte.printStackTrace();
        }
    } 

}
