/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch07;

import quicktime.*;
import quicktime.std.*;
import quicktime.std.movies.*;
import quicktime.std.movies.media.*;
import quicktime.app.view.*;
import quicktime.io.*;

import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class BasicAudioControlsPlayer extends Frame 
    implements ChangeListener {

    JSlider balanceSlider, trebleSlider, bassSlider;

    AudioMediaHandler audioMediaHandler;

    public static void main (String[] args) {
        try {
            QTSessionCheck.check();
            Frame f= new BasicAudioControlsPlayer();
            f.pack();
            f.setVisible(true);
        } catch (QTException qte) {
            qte.printStackTrace();
        }
    }

    public BasicAudioControlsPlayer () throws QTException {
        super ("Basic Audio Controls");
        // prompt for audio file
        QTFile file = QTFile.standardGetFilePreview(null);
        OpenMovieFile omf = OpenMovieFile.asRead (file);
        Movie movie = Movie.fromFile (omf);
        MovieController controller = new MovieController (movie);
        // get AudioMediaHandler for first audio track
        for (int i=1; i<=movie.getTrackCount(); i++) {
            Track t = movie.getTrack(i);
            Media m = t.getMedia();
            MediaHandler mh = m.getHandler();
            if (mh instanceof AudioMediaHandler) {
                audioMediaHandler = (AudioMediaHandler) mh;
                break;
            }
        }
        if (audioMediaHandler == null) {
            System.out.println ("No audio track");
            System.exit(-1);
        }
        // add controller to GUI
        setLayout (new BorderLayout());
        Component comp =
            QTFactory.makeQTComponent(controller).asComponent();
        add (comp, BorderLayout.NORTH);
        // build balance, treble, bass controls in a panel
        Panel controls = new Panel(new GridLayout (3,2));
        controls.add (new JLabel ("Balance"));
        balanceSlider = new JSlider (-1000, 1000, 0);
        balanceSlider.addChangeListener (this);
        controls.add (balanceSlider);
        controls.add (new JLabel ("Treble"));
        trebleSlider = new JSlider (-256, 256, 0);
        trebleSlider.addChangeListener (this);
        controls.add (trebleSlider);
        controls.add (new JLabel ("Bass"));
        bassSlider = new JSlider (-256, 256, 0);
        bassSlider.addChangeListener (this);
        controls.add (bassSlider);
        add (controls, BorderLayout.SOUTH);
    }

    public void stateChanged (ChangeEvent ev) {
        Object source = ev.getSource();
        try {
            if (source == balanceSlider) {
                // balance
                float newBal =
                    (float) (balanceSlider.getValue() / 1000f);
                audioMediaHandler.setBalance (newBal);
            } else {
                // bass & treble
                audioMediaHandler.setSoundBassAndTreble (
                                      bassSlider.getValue(),
                                      trebleSlider.getValue());
            }


        } catch (QTException qte) {
            qte.printStackTrace();
        }
    }

}
