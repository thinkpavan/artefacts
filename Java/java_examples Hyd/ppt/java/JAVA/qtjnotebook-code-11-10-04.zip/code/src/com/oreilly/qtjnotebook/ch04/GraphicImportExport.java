/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch04;

import quicktime.*;
import quicktime.io.*;
import quicktime.std.*;
import quicktime.std.comp.*;
import quicktime.std.image.*;
import quicktime.app.view.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Vector;
import java.io.*;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class GraphicImportExport extends Object {

    Button exportButton;
    Frame frame;
    GraphicsImporter importer;

    static final int[] imagetypes =
         { StdQTConstants.kQTFileTypeQuickTimeImage};
    /* other interesting values:
        StdQTConstants.kQTFileTypeGIF,
        StdQTConstants.kQTFileTypeJPEG,
        StdQTConstants4.kQTFileTypePNG,
        StdQTConstants4.kQTFileTypeTIFF
        StdQTConstants.kQTFileTypeMacPaint,
        StdQTConstants.kQTFileTypePhotoShop,
        StdQTConstants.kQTFileTypePICS,
        StdQTConstants.kQTFileTypePicture,
    */

    public static void main (String[] args) {
        new GraphicImportExport();
    }

    public GraphicImportExport() {
        try {
            QTSessionCheck.check();
            QTFile inFile =  QTFile.standardGetFilePreview (imagetypes);
            importer = new GraphicsImporter (inFile);
            // put image onscreen
            QTComponent qtc = QTFactory.makeQTComponent (importer);
            java.awt.Component c = qtc.asComponent();
            frame = new Frame ("Imported image");
            frame.setLayout (new BorderLayout());
            frame.add (c, BorderLayout.CENTER);
            exportButton = new Button ("Export");
            exportButton.addActionListener (new ActionListener() {
                public void actionPerformed (ActionEvent ae) {
                    try {
                        doExport();
                    } catch (QTException qte) {
                        qte.printStackTrace();
                    }
                }
            });
            frame.add (exportButton, BorderLayout.SOUTH);
            frame.pack();
            frame.setVisible(true);
        } catch (QTException qte) {
            qte.printStackTrace();
        }
    }
    
    public void doExport() throws QTException {
        // build list of GraphicExporters
        Vector choices = new Vector();
        ComponentDescription cd =
            new ComponentDescription (
                StdQTConstants.graphicsExporterComponentType);
        ComponentIdentifier ci = null;
        while ( (ci = ComponentIdentifier.find(ci, cd)) != null) {
            choices.add (new ExportChoice (ci.getInfo().getName(),
                                           ci.getInfo().getSubType()));
        }

        // offer a choice of movie exporters
        JComboBox exportCombo = new JComboBox (choices);
        JOptionPane.showMessageDialog (frame,
                                       exportCombo,
                                       "Choose exporter",
                                       JOptionPane.PLAIN_MESSAGE);
        ExportChoice choice = 
            (ExportChoice) exportCombo.getSelectedItem();
        System.out.println ("chose " + choice.name);

        // build a GE, wire up to the GraphicsImporter
        GraphicsExporter exporter =
            new GraphicsExporter (choice.subtype);
        exporter.setInputGraphicsImporter (importer);

        // ask for destination, settings
        FileDialog fd =
            new FileDialog (frame, "Save As", 
                            FileDialog.SAVE);
        fd.setVisible(true);
        String filename = fd.getFile();
        if (filename.indexOf('.') == -1)
            filename = filename + "." +
                exporter.getDefaultFileNameExtension();
        File file = new File (fd.getDirectory(), filename);
        exporter.setOutputFile (new QTFile(file));
        exporter.requestSettings();

        // export
        exporter.doExport();

        // need to explicitly quit (since awt is running)
        System.exit(0);
    }

    public class ExportChoice {
        String name;
        int subtype;
        public ExportChoice (String n, int st) {
            name = n;
            subtype = st;
        }
        public String toString() {
            return name;
        }
    }

}
