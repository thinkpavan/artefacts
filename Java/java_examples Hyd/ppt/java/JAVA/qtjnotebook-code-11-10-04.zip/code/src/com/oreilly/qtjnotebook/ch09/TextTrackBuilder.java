/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch09;

import quicktime.*;
import quicktime.std.*;
import quicktime.std.movies.*;
import quicktime.std.movies.media.*;
import quicktime.io.*;
import quicktime.util.*;
import quicktime.qd.*;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class TextTrackBuilder extends Object {

    public static int TEXT_TRACK_WIDTH = 320;
    public static int TEXT_TRACK_HEIGHT = 24;

    static String[] MESSAGES = {
        "QuickTime for Java",
        "A Developer's Notebook",
        "from O'Reilly Media",
        "Coming Fall 2004"
    };
    static QDRect textBox = new QDRect(0, 0,
                                       TEXT_TRACK_WIDTH,
                                       TEXT_TRACK_HEIGHT);

    public static void main (String[] args) {
        try {
            QTSessionCheck.check();

            QTFile movFile = new QTFile (new java.io.File("buildtext.mov"));
            Movie movie =
                Movie.createMovieFile(movFile,
                           StdQTConstants.kMoviePlayer,
                           StdQTConstants.createMovieFileDeleteCurFile |
                           StdQTConstants.createMovieFileDontCreateResFile);
            
            System.out.println ("Created Movie");
            
            // create an empty text track
            int timeScale = 10; // time measured in 1/10ths of a sec
            Track textTrack = movie.addTrack (TEXT_TRACK_WIDTH,
                                              TEXT_TRACK_HEIGHT, 0);
            System.out.println ("Added empty Track");
            
            // create media for this track
            Media textMedia = new TextMedia (textTrack,
                                             timeScale);
            TextMediaHandler handler =
                (TextMediaHandler) textMedia.getHandler();
            System.out.println ("Created Media");

            textMedia.beginEdits();
            for (int i=0; i<MESSAGES.length; i++) {
                byte[] msgBytes = MESSAGES[i].getBytes();
                QTPointer msgPoint = new QTPointer (msgBytes);
                // add sample
                handler.addTextSample (msgPoint, // text
                                       0, // font number
                                       14, // font size,
                                       QDConstants.bold, // style,
                                       QDColor.yellow, // fg color,
                                       QDColor.black, // bg color,
                                       QDConstants.teCenter,// justification
                                       textBox, // box
                                       0, // displayFlags
                                       0, // scrollDelay
                                       0, // hiliteStart
                                       0, // hiliteEnd
                                       QDColor.white, // rgbHiliteColor
                                       25 // duration
                                       );
            } // for

            // done editing
            textMedia.endEdits();
            
            // now insert this media into track
            textTrack.insertMedia (0, // trackStart
                                   0, // mediaTime
                                   textMedia.getDuration(), // mediaDuration
                                   1); // mediaRate
            

            // save up at this point
            System.out.println ("Saving...");
            OpenMovieFile omf = OpenMovieFile.asWrite (movFile);
            movie.addResource (omf,
                               StdQTConstants.movieInDataForkResID,
                               movFile.getName());
            
            System.out.println ("Done");
            

        } catch (QTException qte) {
            qte.printStackTrace();
        }
        System.exit(0);
    } // main

}
