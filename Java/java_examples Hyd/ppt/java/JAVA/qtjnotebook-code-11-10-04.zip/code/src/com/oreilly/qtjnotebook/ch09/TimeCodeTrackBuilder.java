/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch09;

import quicktime.*;
import quicktime.std.*;
import quicktime.std.image.*;
import quicktime.std.movies.*;
import quicktime.std.movies.media.*;
import quicktime.std.qtcomponents.*;
import quicktime.io.*;
import quicktime.qd.*;
import quicktime.app.view.*;
import quicktime.util.*;
import java.awt.*;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class TimeCodeTrackBuilder {

    public static final int TIMECODE_TRACK_HEIGHT=24;
    public static final int TIMECODE_TRACK_WIDTH=120;
    public static final String SOURCE_NAME="source1234";

    public static void main (String[] args) {
        try {
            QTSessionCheck.check();
            // open a movie
            QTFile file = QTFile.standardGetFilePreview (
                                    QTFile.kStandardQTFileTypes);
            OpenMovieFile omf = OpenMovieFile.asRead(file);
            Movie movie = Movie.fromFile(omf);
            // add a timecode track
            addTimeCodeTrack (movie);

            // create GUI
            Frame f = new Frame ("Movie with TimeCode track");
            MovieController controller = new MovieController(movie);
            Component c = QTFactory.makeQTComponent(controller).asComponent();
            f.add(c);
            f.pack();
            f.setVisible(true);

        } catch (QTException qte) {
            qte.printStackTrace();
        }
    }

    public static Track addTimeCodeTrack (Movie movie)
        throws QTException {
        int timescale = movie.getTimeScale();

        TimeCodeDef tcDef = new TimeCodeDef();
        tcDef.setTimeScale (2997); // ntsc drop-frame
        tcDef.setFrameDuration (100); // 1 frame in 30 fps dropframe
        tcDef.setFramesPerSecond (30);
        tcDef.setFlags (StdQTConstants.tcDropFrame); 
        // other good options: tcNegTimesOK, tc24HoursMax

        // first record at 0 hrs, 0 min, 0 sec, 0 frames
        TimeCodeTime tcTime = new TimeCodeTime (0, 0, 0, 0);

        // create timecode track and media
        Track tcTrack = movie.addTrack (TIMECODE_TRACK_WIDTH,
                                        TIMECODE_TRACK_HEIGHT,
                                        0);
        TimeCodeMedia tcMedia = new TimeCodeMedia (tcTrack, timescale);
        TimeCoder timeCoder = tcMedia.getTimeCodeHandler();

        // turn on timecode display, set colors
        timeCoder.setFlags (timeCoder.getFlags() |
                            StdQTConstants.tcdfShowTimeCode,
                            StdQTConstants.tcdfShowTimeCode);
        TCTextOptions tcTextOptions = timeCoder.getDisplayOptions();
        tcTextOptions.setTXSize (14);
        tcTextOptions.setTXFace (QDConstants.bold);
        tcTextOptions.setForeColor (QDColor.yellow);
        tcTextOptions.setBackColor (QDColor.black);
        timeCoder.setDisplayOptions (tcTextOptions);

        // set up a sample as a 4-byte array in a QTHandle
        int frameNumber = timeCoder.toFrameNumber (tcTime, tcDef);
        int frameNums[] = new int[1];
        frameNums[0] = frameNumber;
        QTHandle frameNumHandle = new QTHandle (4, false);
        frameNumHandle.copyFromArray (0, frameNums, 0, 1);

        // create a timecode description (the sample to be added)
        TimeCodeDescription tcDesc = new TimeCodeDescription();
        tcDesc.setTimeCodeDef (tcDef);

        // add the sample to the TimeCodeMedia
        tcMedia.beginEdits();
        tcMedia.addSample (frameNumHandle,
                           0,
                           frameNumHandle.getSize(),
                           movie.getDuration(),
                           tcDesc,
                           1,
                           0);
        tcMedia.endEdits();

        // now insert this media into track
        tcTrack.insertMedia (0, // trackStart
                               0, // mediaTime
                               tcMedia.getDuration(), // mediaDuration
                               1); // mediaRate

        // move the time code to the bottom of the movie and
        // set a transparent-background GrahpicsMode
        int x = (movie.getBox().getWidth()/2) - (TIMECODE_TRACK_WIDTH / 2);
        int y = movie.getBox().getHeight() - TIMECODE_TRACK_HEIGHT;
        QDRect moveFrom = new QDRect (0, 0,
                                      TIMECODE_TRACK_WIDTH,
                                      TIMECODE_TRACK_HEIGHT);
        QDRect moveTo = new QDRect (x, y,
                                    TIMECODE_TRACK_WIDTH,
                                    TIMECODE_TRACK_HEIGHT);
        Matrix matrix = new Matrix();
        matrix.rect (moveFrom, moveTo);
        tcTrack.setMatrix (matrix);
        timeCoder.setGraphicsMode (new GraphicsMode (QDConstants.transparent,
                                                     QDColor.black));

        return tcTrack;
    }

}
