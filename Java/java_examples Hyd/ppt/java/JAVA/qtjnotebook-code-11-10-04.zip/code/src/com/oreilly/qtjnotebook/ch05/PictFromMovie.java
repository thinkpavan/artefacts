/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch05;

import quicktime.*;
import quicktime.std.*;
import quicktime.std.movies.*;
import quicktime.qd.*;
import quicktime.io.*;
import quicktime.app.view.*;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class PictFromMovie extends Object {

    Movie movie;

    public static void main (String[] args) {
        new PictFromMovie();
    }
    public PictFromMovie () {
        try {
            QTSessionCheck.check();
            QTFile file =
                QTFile.standardGetFilePreview (QTFile.kStandardQTFileTypes);
            OpenMovieFile omFile = OpenMovieFile.asRead (file);
            movie = Movie.fromFile (omFile);
            MovieController controller = new MovieController (movie);
            QTComponent qtc = QTFactory.makeQTComponent (controller);
            Component c = qtc.asComponent();
            Frame frame = new Frame ("Pict From Movie");
            frame.setLayout (new BorderLayout());
            frame.add (c, BorderLayout.CENTER);
            Button pictButton = new Button ("Make movie.pict");
            pictButton.addActionListener (new ActionListener() {
                    public void actionPerformed (ActionEvent e) {
                        dumpToPict();
                    }
                });
            frame.add (pictButton, BorderLayout.SOUTH);
            frame.pack();
            frame.setVisible(true);
        } catch (QTException qte) {
            qte.printStackTrace();
        }
    }

    public void dumpToPict () {
        try {
            float oldRate = movie.getRate();
            movie.stop();
            Pict pict = movie.getPict(movie.getTime());
            String absPictPath = (new File ("movie.pict")).getAbsolutePath();
            pict.writeToFile (new File (absPictPath));
            movie.setRate (oldRate);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
