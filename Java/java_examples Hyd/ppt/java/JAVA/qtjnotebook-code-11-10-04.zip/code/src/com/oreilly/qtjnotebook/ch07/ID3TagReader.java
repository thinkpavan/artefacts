/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch07;

import quicktime.*;
import quicktime.std.*;
import quicktime.std.movies.*;
import quicktime.std.movies.media.*;
import quicktime.io.*;
import java.util.*;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class ID3TagReader extends Object {

    /* these values are straight out of Movies.h
    */
    final static int  kUserDataTextAlbum            = 0xA9616C62; /*'�alb' */
    final static int  kUserDataTextArtist           = 0xA9415254; 
    final static int  kUserDataTextCreationDate     = 0xA9646179; /*'�day' */
    final static int  kUserDataTextFullName         = 0xA96E616D; /*'�nam' */

    /* This array maps all the tag constants to human-readable
       strings (I18N note: could be a localized properties file!)
     */
    private static final Object[][] TAG_NAMES = {
        {new Integer (kUserDataTextAlbum), "Album"},
        {new Integer (kUserDataTextArtist),"Artist" },
        {new Integer (kUserDataTextCreationDate), "Created"},
        {new Integer (kUserDataTextFullName), "Full Name"}
    };

    private static final HashMap TAG_MAP =
        new HashMap(TAG_NAMES.length);
    static {
        for (int i=0; i<TAG_NAMES.length; i++) {
            TAG_MAP.put (TAG_NAMES[i][0],
                         TAG_NAMES[i][1]);
        }
    }

    public static void main (String[] args) {
        new ID3TagReader();
        System.exit(0);
    }

    public ID3TagReader() {
        try {
            QTSessionCheck.check();
            QTFile f = QTFile.standardGetFilePreview (null);
            OpenMovieFile omf = OpenMovieFile.asRead(f);
            Movie movie = Movie.fromFile (omf);
            // get user data
            UserData userData = movie.getUserData();
            dumpTagsFromUserData(userData);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected static void dumpTagsFromUserData (UserData userData) {
        // try for each key in TAG_MAP
        Iterator it = TAG_MAP.keySet().iterator();
        while (it.hasNext()) {
            Integer key = (Integer) it.next();
            int tag = key.intValue();
            String tagName = (String) TAG_MAP.get(key);
            try {
                String value =
                    userData.getTextAsString (tag,
                                              1,
                                              IOConstants.langUnspecified);
                System.out.println (tagName + ": " + value);
            } catch (QTException qte) {} // no such tag
        }
    }

}
