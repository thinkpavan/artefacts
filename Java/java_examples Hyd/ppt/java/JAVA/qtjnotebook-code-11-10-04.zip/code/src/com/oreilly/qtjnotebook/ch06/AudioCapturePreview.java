/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch06;

import quicktime.*;
import quicktime.io.*;
import quicktime.std.*;
import quicktime.std.sg.*;
import quicktime.std.movies.*;
import quicktime.std.image.*;
import quicktime.qd.*;
import quicktime.sound.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.Timer;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class AudioCapturePreview extends Frame 
    implements ItemListener {

    static final Dimension meterDim = new Dimension (200, 25);

    Checkbox previewCheck;
    AudioLevelMeter audioLevelMeter;
    SequenceGrabber grabber;
    SGSoundChannel soundChannel;
    SPBDevice inputDriver;
    boolean grabbing = true;

    public AudioCapturePreview() throws QTException {
        super ("Audio Preview");
        QTSessionCheck.check();
        setLayout (new GridLayout (3, 1));
        add (new Panel()); // reserved for next lab
        previewCheck = new Checkbox ("Preview", false);
        previewCheck.addItemListener (this);
        add (previewCheck);
        audioLevelMeter = new AudioLevelMeter();
        add (audioLevelMeter);
        // 4th row is reserved for later lab
        setUpAudioGrab();
        grabbing = true;
    }

    public void itemStateChanged (ItemEvent e) {
        try {
            if (e.getSource() == previewCheck) {
                if (previewCheck.getState())
                    soundChannel.setVolume (1.0f);
                else
                    soundChannel.setVolume (0.0f);
            }
        } catch (QTException qte) {
            qte.printStackTrace();
        }
    }

    protected void setUpAudioGrab() throws QTException {
        grabber = new SequenceGrabber();
        soundChannel = new SGSoundChannel (grabber);
        System.out.println ("Got SGAudioChannel");
        System.out.println ("SGChannelInfo = " +
                            soundChannel.getSoundInputParameters());
        System.out.println ("SoundDescription = " + 
                            soundChannel.getSoundDescription());

        // prepare and start previewing
        grabber.prepare(true,false);
        soundChannel.setUsage (StdQTConstants.seqGrabPreview);
        soundChannel.setVolume (0.0f);
        grabber.startPreview();

        inputDriver = soundChannel.getInputDriver();
        inputDriver.setLevelMeterOnOff (true);

        int[] levelTest = inputDriver.getActiveLevels();
        System.out.println (levelTest.length + " active levels");

        // set up thread to update level meter
        ActionListener timerCallback =
            new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    // audioLevelMeter.repaint();
                    if (grabbing) {
                        try {
                            grabber.idle();
                            audioLevelMeter.repaint();
                        } catch (QTException qte) {
                            qte.printStackTrace();
                        }
                    }

                }
            };
        Timer timer = new Timer (50, timerCallback);
        timer.start();
    }

    public static void main (String[] args) {
        try {
            Frame f = new AudioCapturePreview();
            f.pack();
            f.setVisible(true);
        } catch (QTException qte) {
            qte.printStackTrace();
        }
    }

    public class AudioLevelMeter extends Canvas {
        public void paint (Graphics g) {
            // get current level if available
            int level = 0;
            if (inputDriver != null) {
                try {
                    int[] levels = inputDriver.getActiveLevels();
                    if (levels.length > 0)
                        level = levels[0];
                } catch (QTException qte) {
                    qte.printStackTrace();
                }
            }
            float levelPercent = level / 256f;
            System.out.println (level + ", " + levelPercent);
            // draw box
            g.setColor (Color.green);
            g.fillRect (0, 0,
                        (int) (levelPercent * getWidth()),
                        getHeight());
        }
        public Dimension getPreferredSize() { return meterDim; }
    }
}
