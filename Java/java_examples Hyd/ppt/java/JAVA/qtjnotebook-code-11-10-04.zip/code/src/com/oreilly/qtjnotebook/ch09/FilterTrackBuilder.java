/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch09;

import quicktime.*;
import quicktime.std.*;
import quicktime.std.movies.*;
import quicktime.std.movies.media.*;
import quicktime.io.*;
import quicktime.std.image.*;
import quicktime.util.*;
import quicktime.qd.*;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class FilterTrackBuilder {

    public static final int EFFECT_TRACK_WIDTH = 320;
    public static final int EFFECT_TRACK_HEIGHT = 240;
    public static final int TIMESCALE = 600;

    public static void main (String[] args) {
        try {
            new FilterTrackBuilder();
        } catch (QTException qte) {
            qte.printStackTrace();
        }
        System.exit(0);
    }

    public FilterTrackBuilder() throws QTException {
        QTSessionCheck.check();

        QTFile movFile = new QTFile (new java.io.File("filter.mov"));
        Movie movie =
            Movie.createMovieFile(movFile,
                                  StdQTConstants.kMoviePlayer,
                                  StdQTConstants.createMovieFileDeleteCurFile |
                                  StdQTConstants.createMovieFileDontCreateResFile);

        Movie sourceMovie = queryUserForMovie();
        Track sourceTrack = addVideoTrack (sourceMovie,
                                           movie,
                                           0,
                                           sourceMovie.getDuration(),
                                           0);

        Track effectsTrack = movie.addTrack (EFFECT_TRACK_WIDTH,
                                             EFFECT_TRACK_HEIGHT,
                                             0);
        effectsTrack.setLayer(-1);

        int TIMESCALE = 600;
		VideoMedia effectsMedia = new VideoMedia(effectsTrack,
                                                 TIMESCALE);
        // set up input map 
        AtomContainer inputMap = new AtomContainer();

        int trackRef =
            effectsTrack.addReference (sourceTrack,
                                       StdQTConstants.kTrackModifierReference);

        // add input reference atom
        Atom inputAtom = 
            inputMap.insertChild (null,
                                  StdQTConstants.kTrackModifierInput, 
                                  trackRef,
                                  0);

        // add name and type
        inputMap.insertChild (inputAtom,
                              StdQTConstants.kTrackModifierType,
                              1,
                              0,
                              EndianOrder.flipNativeToBigEndian32(StdQTConstants.videoMediaType));

        inputMap.insertChild (inputAtom,
                              StdQTConstants.kEffectDataSourceType,
                              1,
                              0,
                              // QTUtils.toOSType ("srcA"));
	                      EndianOrder.flipNativeToBigEndian32(QTUtils.toOSType ("srcA")));
        System.out.println ("set up input map atom");

        // show list of effects
        // flags are in StdQTConstants.pdOptions...
        // (http://developer.apple.com/documentation/QuickTime/REF/refEffects.61.htm)
        Pict[] previewPicts = new Pict[1];
        previewPicts[0] = sourceMovie.getPosterPict();

        // get list of effects
        // StdQTConstants.elOptionsIncludeNoneInList)
        EffectsList effectsList = new EffectsList (1, 1, 0);

        AtomContainer effect =
            ParameterDialog.showParameterDialog (effectsList,
                                                 0, // dialogOptions
                                                 null, // parameters
                                                 "Pick an effect", // title
                                                 previewPicts //pictArray
                                                 );
        // find out the effect type by getting the "what" atom,
        // whose data is a FOUR_CHAR_CODE
        Atom what = effect.findChildByIndex_Atom (null, 
                                                   StdQTConstants.kParameterWhatName,
                                                   1);
        int effectType = effect.getAtomData(what).getInt(0);
        effectType = EndianOrder.flipBigEndianToNative32(effectType);
        System.out.println ("User chose " + 
                            QTUtils.fromOSType(effectType) +
                            " effect type");

        // make a sample description for the effect description
        ImageDescription imgDesc = ImageDescription.forEffect (effectType);
        imgDesc.setWidth (EFFECT_TRACK_WIDTH);
        imgDesc.setHeight (EFFECT_TRACK_HEIGHT);

        // give the effect description a ref to the source
        effect.insertChild (null,
                            StdQTConstants.kEffectSourceName,
                            1,
                            0,
                            // QTUtils.toOSType ("srcA"));
                            EndianOrder.flipNativeToBigEndian32(QTUtils.toOSType ("srcA")));

        // add effect to the video media
        effectsMedia.beginEdits();

        effectsMedia.addSample (effect, // QTHandleRef data,
                              0, // int dataOffset,
                              effect.getSize(), // int dataSize,
                              sourceTrack.getDuration(), //int durationPerSample,
                              imgDesc, // SampleDescription sampleDesc,
                              1, // int numberOfSamples,
                              0 // int sampleFlags
                              );
        effectsMedia.setInputMap (inputMap);

        effectsMedia.endEdits();

        // now insert this media into track
        effectsTrack.insertMedia (0, // trackStart
                                  0, // mediaTime
                                  sourceTrack.getDuration(), // mediaDuration
                                  1); // mediaRate
        System.out.println ("inserted media into effects track");

        // save up 
        System.out.println ("Saving...");
        OpenMovieFile omf = OpenMovieFile.asWrite (movFile);
        movie.addResource (omf,
                           StdQTConstants.movieInDataForkResID,
                           movFile.getName());
        System.out.println ("Done");

    }

    public static Movie queryUserForMovie()
        throws QTException {
        QTFile file =
            QTFile.standardGetFilePreview (QTFile.kStandardQTFileTypes);
        OpenMovieFile omf = OpenMovieFile.asRead (file);
        return Movie.fromFile (omf);
    }

    public static Track addVideoTrack (Movie sourceMovie,
                                       Movie targetMovie,
                                       int srcIn,
                                       int srcDuration,
                                       int targetTime)
        throws QTException { 
        // find first video track
        Track videoTrack = 
            sourceMovie.getIndTrackType (1,
                                         StdQTConstants.videoMediaType,
                                         StdQTConstants.movieTrackMediaType);

        if (videoTrack == null)
            throw new QTException ("can't find a video track");
        // add videoTrack to targetMovie
        Track newTrack =
            targetMovie.newTrack (videoTrack.getSize().getWidthF(),
                                  videoTrack.getSize().getHeightF(),
                                  1.0f);
        VideoMedia newMedia = 
            new VideoMedia (newTrack,
                            videoTrack.getMedia().getTimeScale(),
                            new DataRef(new QTHandle()));
        videoTrack.insertSegment (newTrack,
                                  srcIn, // 0
                                  srcDuration, // videoTrack.getDuration()
                                  targetTime);
        return newTrack;
    }



}
