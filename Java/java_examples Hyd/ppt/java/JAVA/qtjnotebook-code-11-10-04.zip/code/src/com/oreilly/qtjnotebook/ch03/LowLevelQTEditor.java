/*

Copyright (c) 2004, Chris Adamson

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
package com.oreilly.qtjnotebook.ch03;

import quicktime.*;
import quicktime.qd.QDRect;
import quicktime.std.*;
import quicktime.std.movies.*;
import quicktime.app.view.*;
import quicktime.io.*;

import java.awt.*;
import java.awt.event.*;

import com.oreilly.qtjnotebook.ch01.QTSessionCheck;

public class LowLevelQTEditor extends Frame
    implements ActionListener {

    Component comp;

    static Movie copiedMovie;
    Movie movie;
    MovieController controller;
    Menu fileMenu, editMenu;
    MenuItem openItem, closeItem, newItem, quitItem;
    MenuItem copyItem, cutItem, pasteItem;
    static int newFrameX = -1;
    static int newFrameY = -1;
    static int windowCount = 0;
    
    /** no-arg constructor for "new" movie
     */
    public LowLevelQTEditor () throws QTException {
        super ("LowLevelQTEditor");
        setLayout (new BorderLayout());
        QTSessionCheck.check();
        movie = new Movie(StdQTConstants.newMovieActive);
        controller = new MovieController (movie);
        controller.enableEditing(true);
        doMyLayout();
    }

    /** file-based constructor for opening movies
     */
    public LowLevelQTEditor (QTFile file) throws QTException {
        super ("LowLevelQTEditor");
        setLayout (new BorderLayout());
        QTSessionCheck.check();
        OpenMovieFile omf = OpenMovieFile.asRead (file);
        movie = Movie.fromFile (omf);
        controller = new MovieController (movie);
        controller.enableEditing(true);
        doMyLayout();
    }

    /** gets component from controller, makes menus
     */
    private void doMyLayout() throws QTException {
        // add movie component
        QTComponent qtc =
            QTFactory.makeQTComponent (controller);
        comp = qtc.asComponent();
        add (comp, BorderLayout.CENTER);
        // file menu
        fileMenu = new Menu ("File");
        newItem = new MenuItem ("New Movie");
        newItem.addActionListener (this);
        fileMenu.add (newItem);
        openItem = new MenuItem ("Open Movie...");
        openItem.addActionListener (this);
        fileMenu.add (openItem);
        closeItem = new MenuItem ("Close");
        closeItem.addActionListener (this);
        fileMenu.add (closeItem);
        fileMenu.addSeparator();
        quitItem = new MenuItem ("Quit");
        quitItem.addActionListener (this);
        fileMenu.add(quitItem);
        // edit menu
        editMenu = new Menu ("Edit");
        copyItem = new MenuItem ("Copy");
        copyItem.addActionListener(this);
        editMenu.add(copyItem);
        cutItem = new MenuItem ("Cut");
        cutItem.addActionListener(this);
        editMenu.add(cutItem);
        pasteItem = new MenuItem ("Paste");
        pasteItem.addActionListener(this);
        editMenu.add(pasteItem);
        // make menu bar
        MenuBar bar = new MenuBar();
        bar.add (fileMenu);
        bar.add (editMenu);
        setMenuBar (bar);
        // add close-button handling
        addWindowListener (new WindowAdapter() {
                public void windowClosing (WindowEvent e) {
                    doClose();
                }
            });
    }

    /** handles menu actions
     */
    public void actionPerformed (ActionEvent e) {
        Object source = e.getSource();
        try {
            if (source == quitItem) doQuit();
            else if (source == openItem) doOpen();
            else if (source == closeItem) doClose();
            else if (source == newItem) doNew();
            else if (source == copyItem) doCopy();
            else if (source == cutItem) doCut();
            else if (source == pasteItem) doPaste();
        } catch (QTException qte) {
            qte.printStackTrace();
        }
    }

    public void doQuit() {
        System.exit(0);
    }

    public void doNew() throws QTException {
        makeNewAndShow();
    }

    public void doOpen() throws QTException {
        QTFile file =
            QTFile.standardGetFilePreview (QTFile.kStandardQTFileTypes);
        Frame f = new LowLevelQTEditor (file);
        f.pack();
        if (newFrameX >= 0)
            f.setLocation (newFrameX+=16, newFrameY+=16);
        f.setVisible(true);
        windowCount++;
    }

    public void doClose() {
        setVisible(false);
        dispose();
        // quit if no windows now showing
        if (--windowCount == 0)
            doQuit();
    }

    public void doCopy() throws QTException {
        copiedMovie = new Movie();
        TimeInfo selection = movie.getSelection();
        movie.insertSegment (copiedMovie,
                             selection.time,
                             selection.duration,
                             0);
    }

    public void doCut() throws QTException {
        copiedMovie = new Movie();
        TimeInfo selection = movie.getSelection();
        movie.insertSegment (copiedMovie,
                             selection.time,
                             selection.duration,
                             0);
        movie.deleteSegment (selection.time,
                             selection.duration);
        controller.movieChanged();
    }


    public void doPaste() throws QTException {
        if (copiedMovie == null)
            return;
        copiedMovie.insertSegment (movie,
                                   0,
                                   copiedMovie.getDuration(),
                                   movie.getSelection().time);
        controller.movieChanged();
        pack();
    }


    /** Force frame's size to respect movie size
     */
    public Dimension getPreferredSize() {
        if (controller == null)
            return new Dimension (0,0);
        try {
            QDRect contRect = controller.getBounds();
            Dimension compDim = comp.getPreferredSize();
            if (contRect.getHeight() > compDim.height) {
                return new Dimension (contRect.getWidth() +
                                      getInsets().left +
                                      getInsets().right,
                                      contRect.getHeight() +
                                      getInsets().top +
                                      getInsets().bottom);

            } else {
                return new Dimension (compDim.width +
                                      getInsets().left +
                                      getInsets().right,
                                      compDim.height +
                                      getInsets().top +
                                      getInsets().bottom);

            }
        } catch (QTException qte) {
            return new Dimension (0,0);
        }
    }


    /** opens a single new movie window
     */
    public static void main (String[] args) {
        try {
            Frame f = makeNewAndShow();
            // note its x, y for future calls
            newFrameX = f.getLocation().x;
            newFrameY = f.getLocation().y;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /** creates "new" movie frame, packs and shows.
        used by main() and "new"
     */
    private static Frame makeNewAndShow()
        throws QTException {
        Frame f = new LowLevelQTEditor();
        f.pack();
        if (newFrameX >= 0)
            f.setLocation (newFrameX+=16, newFrameY+=16);
        f.setVisible(true);
        windowCount++;
        return f;
    }

}
