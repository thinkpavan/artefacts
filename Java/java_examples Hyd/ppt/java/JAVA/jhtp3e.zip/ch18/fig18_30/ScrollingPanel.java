// Fig. 18.30: ScrollingPanel.java
// Class ScrollingPanel
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ScrollingPanel extends JPanel {
   private JPanel labelPanel, fieldsPanel;
   private String labels[] = 
                 { "ID number:", "First name:", "Last name:",
                   "Address:", "City:", "State/Province:", 
                   "PostalCode:", "Country:", "Email:", 
                   "Home phone:", "Fax Number:" };
   JTextField id, first, last, address,     // package access
              city, state, zip,
              country, email, home, fax;

   public ScrollingPanel()
   {
      // Label panel
      labelPanel = new JPanel();
      labelPanel.setLayout( 
                       new GridLayout( labels.length, 1 ) );

      ImageIcon ii = new ImageIcon( "images/icon.jpg" );

      for ( int i = 0; i < labels.length; i++ )
         labelPanel.add( new JLabel( labels[ i ], ii, 0) );

      // TextField panel
      fieldsPanel = new JPanel();
      fieldsPanel.setLayout( 
                        new GridLayout( labels.length, 1 ) );
      id = new JTextField( 20 );
      id.setEditable( false );
      fieldsPanel.add( id );
      first = new JTextField( 20 );
      fieldsPanel.add( first );
      last = new JTextField( 20 );
      fieldsPanel.add( last );
      address = new JTextField( 20 );
      fieldsPanel.add( address );
      city = new JTextField( 20 );
      fieldsPanel.add( city );
      state = new JTextField( 20 );
      fieldsPanel.add( state  );
      zip = new JTextField( 20 );
      fieldsPanel.add( zip );
      country = new JTextField( 20 );
      fieldsPanel.add( country );
      email = new JTextField( 20 );
      fieldsPanel.add( email );
      home = new JTextField( 20 );
      fieldsPanel.add( home );
      fax = new JTextField( 20 );
      fieldsPanel.add( fax );

      setLayout( new GridLayout( 1, 2 ) );
      add( labelPanel );
      add( fieldsPanel );
   }
}

/**************************************************************************
 * (C) Copyright 1999 by Deitel & Associates, Inc. and Prentice Hall.     *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
