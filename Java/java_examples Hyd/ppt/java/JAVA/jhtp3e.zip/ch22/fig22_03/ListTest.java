// Fig. 22.3: ListTest.java
// Class ListTest
import com.deitel.jhtp3.ch22.List;
import com.deitel.jhtp3.ch22.EmptyListException;

public class ListTest {
   public static void main( String args[] )
   {
      List objList = new List();  // create the List container

      // Create objects to store in the List
      Boolean b = Boolean.TRUE;
      Character c = new Character( '$' );
      Integer i = new Integer( 34567 );
      String s = "hello";

      // Use the List insert methods
      objList.insertAtFront( b );
      objList.print();
      objList.insertAtFront( c );
      objList.print();
      objList.insertAtBack( i );
      objList.print();
      objList.insertAtBack( s );
      objList.print();

      // Use the List remove methods
      Object removedObj;

      try {
         removedObj = objList.removeFromFront();
         System.out.println(
            removedObj.toString() + " removed" );
         objList.print();
         removedObj = objList.removeFromFront();
         System.out.println(
            removedObj.toString() + " removed" );
         objList.print();
         removedObj = objList.removeFromBack();
         System.out.println(
            removedObj.toString() + " removed" );
         objList.print();
         removedObj = objList.removeFromBack();
         System.out.println(
            removedObj.toString() + " removed" );
         objList.print();
      }
      catch ( EmptyListException e ) {
         System.err.println( "\n" + e.toString() );
      }
   }
}


/**************************************************************************
 * (C) Copyright 1999 by Deitel & Associates, Inc. and Prentice Hall.     *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
