			README
			======

		    JavaMail(TM) API 1.1.3 release
		    ------------------------------

Welcome to the JavaMail API 1.1.3 release!  This release includes
versions of the JavaMail API 1.1.3 implementation, IMAP and SMTP service 
providers, some examples, and documentation for the JavaMail 1.1 API.

Please see the FAQ at http://java.sun.com/products/javamail/FAQ.html

JDK Version notes
-----------------

The JavaMail API supports JDK 1.1.x or higher, including the Java 2
platform, Standard Edition (J2SE) v1.2.x.  Note that we have currently
tested this implementation only with JDK 1.1.7 and J2SE 1.2.2.

Note also that JAF is known to have problems with JDK versions before 1.1.6.


Protocols supported
-------------------

This release supports the following mail protocols:

    IMAP - a message Store protocol, for reading messages from a server
    SMTP - a message Transport protocol, for sending messages to a server

See our web page at http://java.sun.com/products/javamail for the
latest information on third party protocol providers.

Note that we do provide a POP3 provider as a separate package. You
can download it from our web page.


Contents
--------

    Included in this release are the following:

    README.txt 		this file
    LICENSE.txt		Software license
    NOTES.txt		Notes, issues and known bugs
    CHANGES.txt		Changes since the 1.0 release
    mail.jar		The JavaMail API classes. DO NOT UNARCHIVE THIS FILE.

    docs/JavaMail-1.1.txt
			Description of the new APIs that have been added in
			JavaMail API 1.1
    docs/JavaMail-1.1.ps	
			Postscript version of the JavaMail API 1.1 specification
    docs/JavaMail-1.1.pdf	
			PDF version of the JavaMail API 1.1 specification
    docs/Providers.ps
			Postscript version of the JavaMail Service Provider
			guide.
    docs/Providers.pdf
			PDF version of the JavaMail Service Provider guide.

    docs/javadocs/	The 1.1 JavaMail API javadocs

    demo/ByteArrayDataSource.java
			demo DataSource that can be used for in-memory data
			of any MIME type
    demo/CRLFOutputStream.java
			demo OutputStream filter to convert all line terminators
			to CRLF
    demo/NewlineOutputStream.java
			demo OutputStream filter to convert all line terminators
			to platform's line terminator
    demo/copier.java	demo program to copy mail between folders
    demo/folderlist.java demo program to list subfolders
    demo/monitor.java	demo program to monitor for new mail
    demo/mover.java	demo program to move mail between folders
    demo/msgmultisendsample.java
			demo program to send a sample multipart message
    demo/msgsend.java	demo program to send a single part text message
			to a specified recipient (ala /bin/mail)
    demo/msgsendsample.java
			demo program to send a sample single part text message
    demo/msgshow.java	demo program to read messages from an IMAP store
    demo/search.java	demo program to search folders
    demo/registry.java	demo program that illustrates the registry
    demo/uidmsgshow.java
			demo program to read messages from an IMAP store
    demo/sendfile.java	demo program to send a file as an attachment
    demo/sendhtml.java  demo program to send html mail
    demo/transport.java	demo program to illustrate use of Transport
    demo/client/	source files for cool demo program that implements 
			a simple mail reader. (Uses Swing)
    demo/client/SimpleClient.README.txt
			README file for running the simple mail-reader demo
    demo/servlet/	source for a simple servlet that allows using a
			web browser to read and send mail
    demo/servlet/JavaMailServlet.README.txt
			README file that describes the JavaMailServlet


Requirements
------------

Note that the JavaMail API requires the JavaBeans(TM) Activation
Framework package to be installed as well.  Download the latest version
of the JavaBeans Activation Framework from

	http://java.sun.com/beans/glasgow/jaf.html

and install it in a suitable location.


Installation
------------

  Solaris
  -------

  1. Unzip the javamail1_1_3.zip archive. (you may have already done this)

  2. Set your CLASSPATH to include the "mail.jar" file obtained from 
     the download, as well as the current directory. 

     Assuming you unzipped javamail1_1_3.zip in /u/me/download/ the
     following would work:

      export CLASSPATH=$CLASSPATH:/u/me/download/javamail1_1_3/mail.jar:.

    Also include the "activation.jar" file that you obtained from
    downloading the Java Activation Framework, in your CLASSPATH.
    i.e,

      export CLASSPATH=$CLASSPATH:/u/me/download/activation/activation.jar

    
  3. Go to the demo directory

  4. Compile any demo using your java compiler. For example:

      javac msgshow.java

  5. Run the demo. The '-' option lists the required and optional
     command-line options to successfully run any demo. For example:

      java msgshow -
    
    lists the available options. And

      java msgshow -T imap -H <mailserver> -U <username> -P <passwd> -f INBOX 5
    
    uses the IMAP protocol to display message number 5 from your INBOX.

  (Additional instructions on how to run the simple mail reader demo 
  and servlet demo are provided in SimpleClient.README.txt and
  JavaMailServlet.README.txt, respectively.)


  Windows NT/95
  -------------

  1. Unzip the javamail1_1_3.zip archive. (you may have already done this)

  2. Set your CLASSPATH to include the "mail.jar" file obtained from 
     the download, as well as the current directory. 

     Assuming you unzipped javamail1_1_3.zip in c:\download the
     following would work:
     
      set CLASSPATH=%CLASSPATH%;c:\download\javamail1_1_3\mail.jar;.

    Also include the "activation.jar" file that you obtained from
    downloading the JavaBeans Activation Framework, in your CLASSPATH.

      set CLASSPATH=%CLASSPATH%;c:\download\activation\activation.jar
    
  3. Go to the demo directory

  4. Compile any demo using your java compiler. For example:

      javac msgshow.java

  5. Run the demo. The '-' option lists the required and optional
     command-line options to successfully run any demo. For example:

      java msgshow -

    lists the available options. And

      java msgshow -T imap -H <mailserver> -U <username> -P <passwd> -f INBOX 5
    
    uses the IMAP protocol to display message number 5 from your INBOX.


  (Additional instructions on how to run the simple mail reader demo 
  and servlet demo are provided in SimpleClient.README.txt and
  JavaMailServlet.README.txt, respectively.)


Problems?
---------

Our web page at http://java.sun.com/products/javamail has a pointer
to the FAQ that includes information on protocols supported,
installation problems, etc.  You'll also find information on how to
subscribe to our discussion-list or announcement-list for announcements 
of future JavaMail API releases.

See the NOTES.txt file for information on how to report bugs.

Enjoy!

The JavaMail API Team
