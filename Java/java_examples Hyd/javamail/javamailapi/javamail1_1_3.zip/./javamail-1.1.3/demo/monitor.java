/*
 * @(#)monitor.java	1.5 99/12/06
 *
 * Copyright 1996-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

import java.util.*;
import java.io.*;
import javax.mail.*;
import javax.mail.event.*;
import javax.activation.*;

/* Monitors given mailbox for new mail */

public class monitor {

    public static void main(String argv[])
    {
	if (argv.length != 5) {
  	   System.out.println("Usage: monitor <host> <user> <password> <mbox> <freq>");
	   System.exit(1);
	}
	System.out.println("\nTesting monitor\n");

        try {
	    Properties props = System.getProperties();

	    // Get a Session object
	    Session session = Session.getDefaultInstance(props, null);
	    // session.setDebug(true);

	    // Get a Store object
	    Store store = session.getStore("imap");

	   // Connect
	    store.connect(argv[0], argv[1], argv[2]);

	   // Open a Folder
	    Folder folder = store.getFolder(argv[3]);
	    if (folder == null || !folder.exists()) {
		System.out.println("Invalid folder");
		System.exit(1);
	    }

	    folder.open(Folder.READ_WRITE);

	    // Add messageCountListener to listen for new messages
	    folder.addMessageCountListener(new MessageCountAdapter() {
		public void messagesAdded(MessageCountEvent ev) {
		    Message[] msgs = ev.getMessages();
		    System.out.println("Got " + msgs.length + " new messages");

		    // Just dump out the new messages
		    for (int i = 0; i < msgs.length; i++) {
			try {
			    DataHandler dh = msgs[i].getDataHandler();
			    InputStream is = dh.getInputStream();
			    int c;
			    while ((c = is.read()) != -1)
			 	System.out.write(c); 
			} catch (IOException ioex) { 
			    ioex.printStackTrace();	
			} catch (MessagingException mex) {
			    mex.printStackTrace();
			}
		    }
		}
	    });
			
	   // Check mail once in "freq" MILLIseconds

	    int freq = Integer.parseInt(argv[4]);

	    for (; ;) {
		Thread.sleep(freq); // sleep for freq milliseconds

		// This is to force the IMAP server to send us
		// EXISTS notifications. 
		folder.getMessageCount();
	    }

	} catch (Exception ex) {
	    ex.printStackTrace();
	}
    }
}
