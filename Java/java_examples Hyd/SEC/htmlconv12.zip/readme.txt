Java(tm) Plug-in HTML Converter  Read Me 

Version:  1.2

*****   BACKUP ALL FILE BEFORE CONVERTING THEM WITH THIS TOOL   *****
*****   ANY FILES CONVERTED WITH EA1 or EA2 WILL NEED TO BE RECONVERTED WITH AN ORGINAL COPY OF THE APPLET  *****
*****	CANCELLING A CONVERSION WILL NOT ROLLBACK THE CHANGES.  *****
*****   COMMENTS WITHIN THE APPLET TAG ARE IGNORED	*****

-----
Contents of this file
-----
1)  New Features (since EA3)
2)  Bug Fixes (since EA 2)
3)  About Java(tm) Plug-in HTML Converter
4)  The conversion process
5)  Choosing files within folders to convert
6)  Choosing one file to convert
7)  Choosing backup folder
8)  Generating a log file
9)  Choosing a conversion template
10)  Converting
11)  More Conversions or Quit
12)  Using the command line interface method of running the converter
13)  Details about templates
14)  Setting up that PureJava Version

-----
1)  New Features since EA3:
-----
	
-----
2)  Bugs Fixed:
-----
	*  Many strange parameter parsing problems fixed.
	*  Error in specifying valued in the advanced options fixed.  The error caused the converter
		to unexpectedly quit.
	*  When running on a Macintosh, paths will not show the %20 excapes for spaces that MRJ puts in.
-----
3)  About Java(tm) Plug-in HTML Converter:
-----
  Java(tm) Plug-in HTML Converter is a utility that allows you to convert any HTML page
  which contains applets to a format that will use the Java(tm) Plug-in.  

-----
4)  The conversion process:
-----
  
  The Java(tm) Plug-in HTML Converter will convert any file(s) containing applets
  to a form that can be used with the Java(tm) Plug-in.  
  
  The process of converting each file is as follows:
  First, HTML that is not part of an applet is transferred from the source file
  to a temporary file.  When an <APPLET tag is reached, the converter will parse
  the applet to the first </APPLET tag (not contained in qoutes), and merge the applet 
  data with the template.
  (see Details about templates, below) If this completes without error,  
  the original html file will be moved to the backup folder and the temporary 
  file will then be renamed to the original file's name.  Thus, your original files 
  will never be removed from disk.
  
  Note that the converter will effectively convert the files in place.  So, once you
  have run the converter, your files will be setup to use the Java(tm) Plug-in.
  
-----
5)  Choosing files within folders to convert:
-----

To convert all files within a folder, choose the radio button next to "All Files
in Folder".  You may then type in the path to the folder, or choose the browse 
button to select a folder from a dialog.  Once you have chosen a path, you may
supply any number to file specifiers in the "Matching File Names".  Each specifier
must be separated by a comma.  You may use * as a wildcard.  Lastly, select the 
checkbox "Include Subfolders", if you would like all files in nested folders to
be converted.

-----
6)  Choosing one file to convert:
-----

To convert one file, choose the radio button next to "One File".  You may then type 
in the path to the file, or choose the browse button to select a file from a dialog.  

-----
7)  Choosing backup folder
-----

The default backup folder path is the source path with an "_BAK" appended to the name.  
i.e.  If the source path is c:/html/applet.html  (converting one file) then the backup
path would be c:/html_BAK.  If the source path is c:/html (converting all file in path)
then the backup path would be c:/html_BAK.  
The backup path may be changed by typing a path in the field next to "Backup files to 
folder:", or by browsing for a folder.


-----
8)  Generating a log file
-----

If you would like a log file to be generated, choose the checkbox "Generate Log File".
Type in a path or browse to choose a folder.  The log file contains basic information 
related to the converting process.

-----
9)  Choosing a conversion template
-----

If a default template will be used if none is chosen.  This template will produce
converted html files that will work with IE and Netscape.  If you would like to
use a different template, you may choose it from the menu on the main screen.  If
you choose other, you will be allowed to choose a file that will be used as the 
template.  If you choose a file, BE SURE THAT IT IS A TEMPLATE.

-----
10)  Converting
-----

Click the "Convert..." button to begin the conversion process.  A process dialog
will show the files being processed, the number for files process, the number of applets
found, and number of errors found.

-----
11)  More Conversions or Quit
-----
 
When the conversion is complete, the button in the process dialog will change from 
"Cancel" to "Done".  You may choose "Done" to close the dialog.  At this point, choose
"Quit" to close the Java(tm) Plug-in HTML Converter, or selected another set of 
files to convert and choose "Convert..." again.


-----
12)  Using the command line interface method of running the converter
-----
COMMAND LINE INTERFACE:

	The converted now supports a command line interface.
>From a command line, you may type

java HTMLConverter [ filespecs ] [-simulate] [-options1 value1 [-option2 value2 [...]]]

If only "java HTMLConverter" is specified (no filespecs or options) the GUI version 
of the converter will be launched.  Otherwise, the GUI will be suppressed.

filespecs:  space delimited list of file specs, * wildcard.  (*.html *.htm)

Options:
	source:  	Path to files.  (c:\htmldocs) Default: <userdir>
				If the path is relative, it is assumed to be relative to the 
				directory that HTMLConverter was launched.
	backup:  	Path to write backup files.  Default: <userdir>/<source>_bak
				If the path is relative, it is assumed to be relative to the 
				directory that HTMLConverter was launched.
	subdirs:  	Should files in subdirectories be processed.  Default:  FALSE
	template:  	Name of template file.  Default:  default.tpl-Standard (IE & Navigator) 
				for Windows & Solaris Only.  USE DEFAULT IF UNSURE.
	log:  		Path and filename to write log.  (Default <userdir>/convert.log)
	progress:  	Display standard out progress while converting.  Default: true
	simulate:  	Display the specifics to the conversion without converting.
				USE THIS OPTION IF UNSURE ABOUT CONVERTING.  YOU WILL BE GIVEN
				A LIST OF DETAILS SPECIFIC TO THE CONVERSION.

-----
13)  Details about templates
-----

The template file is the basis behind converting applets.  It is simply a text file
containing tag the represent parts of the original applet.  By add/removing/moving
the tags in a template file, you can alter the output of the converted file.

Supported Tags:
$OriginalApplet$  This tag is substituted with the complete text of the original
					applet.

$AppletAttributes$  This tag is substituted with all of the applets attributes.
					(code, codebase, width, height, etc.)

$ObjectAttributes$  This tag is substituted with all the attributes required by
					the object tag.

$EmbedAttributes$    This tag is substituted with all the attributes required by
					the embed tag.

$AppletParams$  This tag is substituted with all the applet's <param ...> tags

$ObjectParams$  This tag is substituted with all the <param...> tags required by
				the object tag.

$EmbedParams$  This tag is substituted with all the <param...> tags required by
				the embed tag in the form  NAME=VALUE

$AlternateHTML$   This tag is substituted with the text in the No support for 
				applets area of the original applet
				
$CabFileLocation$	This is the URL of the cab file that should be used in each
					template that targets IE.
					
$NSFileLocation$	This is the URL of the Netscape plugin that be used in each
					template that targets Netscape


/*************************/
default.tpl is the default template for the converter. The converted page can be 
used in IE and Navigator on Windows 95 or Windows NT to invoke Java(TM) Plug-in. 

<!-- CONVERTER VERSION 1.2 -->
<OBJECT classid="clsid:8AD9C840-044E-11D1-B3E9-00805F499D93"
$ObjectAttributes$ codebase="$CabFileLocation$">
$ObjectParams$
<PARAM NAME="type" VALUE="application/x-java-applet;version=1.2">
$AppletParams$<COMMENT>
<EMBED type="application/x-java-applet;version=1.2" $EmbedAttributes$
$EmbedParams$ pluginspage="$NSFileLocation$"><NOEMBED></COMMENT>
		$AlternateHTML$
	</NOEMBED></EMBED>
</OBJECT>

<!--
$ORIGINALAPPLET$
-->
/*************************/


/*************************/
ieonly.tpl -- the converted page can be used to invoke Java(TM) Plug-in in IE on 
Windows 95 or Windows NT only.

<!-- CONVERTER VERSION 1.2 -->
<OBJECT classid="clsid:8AD9C840-044E-11D1-B3E9-00805F499D93"
$ObjectAttributes$ codebase="$CabFileLocation$">
$ObjectParams$
<PARAM NAME="type" VALUE="application/x-java-applet;version=1.2">
$AppletParams$
$AlternateHTML$
</OBJECT>

<!--
$ORIGINALAPPLET$
-->
/*************************/


/*************************/
nsonly.tpl -- the converted page can be used to invoke Java(TM) Plug-in in 
Navigator on Windows 95 or Windows NT only.

<!-- CONVERTER VERSION 1.2 -->
<EMBED type="application/x-java-applet;version=1.2" $EmbedAttributes$
$EmbedParams$ pluginspage="$NSFileLocation$"><NOEMBED>
$AlternateHTML$
</NOEMBED></EMBED>

<!--
$ORIGINALAPPLET$
-->
/*************************/


/*************************/
extend.tpl -- the converted page can be used in any browser and any platform. If 
the browser is IE or Navigator on Windows 95 or Windows NT, Java(TM) Plug-in will 
be invoked. Otherwise, the browser's default JVM is used.


<!-- CONVERTER VERSION 1.2 -->
<SCRIPT LANGUAGE="JavaScript"><!--
    var _info = navigator.userAgent; var _ns = false;
    var _ie = (_info.indexOf("MSIE") > 0 && _info.indexOf("Win") > 0 &&
_info.indexOf("Windows 3.1") < 0);
//--></SCRIPT>
<COMMENT><SCRIPT LANGUAGE="JavaScript1.1"><!--
    var _ns = (navigator.appName.indexOf("Netscape") >= 0 &&
((_info.indexOf("Win") > 0 && _info.indexOf("Win16") < 0 &&
java.lang.System.getProperty("os.version").indexOf("3.5") < 0) ||
_info.indexOf("Sun") > 0));
//--></SCRIPT></COMMENT>

<SCRIPT LANGUAGE="JavaScript"><!--
    if (_ie == true) document.writeln('<OBJECT
classid="clsid:8AD9C840-044E-11D1-B3E9-00805F499D93" $ObjectAttributes$
codebase="$CabFileLocation$"><NOEMBED><XMP>');
    else if (_ns == true) document.writeln('<EMBED
type="application/x-java-applet;version=1.2" $EmbedAttributes$
$EmbedParams$ pluginspage="$NSFileLocation$"><NOEMBED><XMP>');
//--></SCRIPT>
<APPLET $AppletAttributes$></XMP>
$ObjectParams$
<PARAM NAME="type" VALUE="application/x-java-applet;version=1.2">
$AppletParams$
</APPLET>
$AlternateHTML$
</NOEMBED></EMBED></OBJECT>


<!--
$ORIGINALAPPLET$
-->
/*************************/

14)  Setting up the Pure Java version:
  If you want to run the converter on another platform besides Windows, Macintosh, or Solaris, 
you will need to use the Pure Java installer.  Once the installation is done, change directory
to the install folder, and do the following for you specific platform:

Set the classpath to  ./:./HTMLConverter.jar:./templates
(Note:  .'s and /'s are UNIX specific.  Be sure to use your platforms specific file and path
separators.)

Launch the main class:  HTMLConverter

For example, on AIX:

> CLASSPATH=.:HTMLConverter.jar:templates
> export CLASSPATH
> java HTMLConverter
