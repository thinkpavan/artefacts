/*
 * $Header: /cvsroot/mvnforum/myvietnam/docs/README.txt,v 1.13 2003/11/01 05:09:25 minhnn Exp $
 * $Revision: 1.13 $
 * $Date: 2003/11/01 05:09:25 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding MyVietnam and MyVietnam CoreLib
 * MUST remain intact in the scripts and source code.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */



/////////////////////////////////////////////////////////////////////////////
//                 MyVietnam WebApp Framework - Core Lib
//                      Version 1.5.0
//                      $Date: 2003/11/01 05:09:25 $
/////////////////////////////////////////////////////////////////////////////



0. Table of Contents
==================================================================================

0. Table of Contents
1. MyVietnam CoreLib Introduction
2. Installation Instructions



1. MyVietnam CoreLib Introduction
==================================================================================

Thank you for downloading MyVietnam CoreLib from http://www.MyVietnam.net. If you
downloaded this zip-file from an other site, please check http://www.MyVietnam.net
for the latest official release.

MyVietnam CoreLib is a web application framework for any small to medium
Web Applications. It includes many commonly used features that any web apps should
need, including built-in database connection pool, Database Datasource support,
email utilities, System info, AppServer info, Http request utilities,
security/encryption utilities, IP blocking and many, many other features :-).

This version is a stable release and has a lot of exciting new features.

All security bugs should be sent directly to opensource@MyVietnam.net and
the subject should begin with [MyVietnam CoreLib SECURITY]

Developed by Minh Nguyen <minhnn@MyVietnam.net> and Mai Nguyen
<mai.nh@MyVietnam.net>, and the support group is at http://www.mvnForum.com.



2. Installation Instructions
==================================================================================
This software is currently distributed as a core library for the following softwares:
    * mvnForum     - http://www.mvnForum.com
    * NguoiMau     - http://www.nguoimau.net
    * MyVietnam    - http://www.MyVietnam.net
    * VietMot      - http://www.VietMot.com
    * 123Vietnam   - http://www.123Vietnam.com

There is not any installation guide at this time. However, we have plans to
write installation and integration guides for MyVietnam CoreLib in the next releases.


NOTE: This product includes software developed by the
      Apache Software Foundation (http://www.apache.org/).

==================================================================================

Cheers!

minhnn (Minh Nguyen)
http://www.MyVietnam.net
http://www.mvnForum.com
minhnn@MyVietnam.net
