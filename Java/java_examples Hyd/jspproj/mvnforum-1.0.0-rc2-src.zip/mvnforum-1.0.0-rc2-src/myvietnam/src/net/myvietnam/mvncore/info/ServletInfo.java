/*
 * $Header: /cvsroot/mvnforum/myvietnam/src/net/myvietnam/mvncore/info/ServletInfo.java,v 1.5 2003/07/28 08:43:32 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.5 $
 * $Date: 2003/07/28 08:43:32 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding MyVietnam and MyVietnam CoreLib
 * MUST remain intact in the scripts and source code.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvncore.info;

import javax.servlet.ServletContext;

public class ServletInfo {

    private String serverInfo   = null;
    private int majorVersion    = 0;
    private int minorVersion    = 0;
    private String servletVersion = null;

    public ServletInfo(ServletContext context) {
        serverInfo      = context.getServerInfo();
        majorVersion    = context.getMajorVersion();
        minorVersion    = context.getMinorVersion();
        servletVersion  = new StringBuffer().append(majorVersion).append('.').append(minorVersion).toString();
    }

    public int getMajorVersion() {
        return majorVersion;
    }

    public int getMinorVersion() {
        return minorVersion;
    }

    public String getServerInfo() {
        return serverInfo;
    }

    public String getServletVersion() {
        return servletVersion;
    }
}