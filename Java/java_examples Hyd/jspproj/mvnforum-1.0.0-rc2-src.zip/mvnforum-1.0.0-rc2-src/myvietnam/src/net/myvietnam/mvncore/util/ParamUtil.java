/*
 * $Header: /cvsroot/mvnforum/myvietnam/src/net/myvietnam/mvncore/util/ParamUtil.java,v 1.8 2003/10/06 17:16:51 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.8 $
 * $Date: 2003/10/06 17:16:51 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding MyVietnam and MyVietnam CoreLib
 * MUST remain intact in the scripts and source code.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvncore.util;

import javax.servlet.http.*;
import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.filter.DisableHtmlTagFilter;

public final class ParamUtil {

    private ParamUtil() { // prevent instantiation
    }

    private static String contextPath = (new ParamOptions()).contextPath;
    private static String serverPath = (new ParamOptions()).serverPath;//@todo combine 2 line to a static block

    private static java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat ("dd/MM/yyyy");

    public static String getContextPath() {
        return contextPath;
    }

    public static String getServerPath() {
        return serverPath;
    }

    public static String getServer(HttpServletRequest request) {

        StringBuffer server = new StringBuffer(128);
        String scheme = request.getScheme();
        int port = request.getServerPort();
        if (port < 0) {
            port = 80; // Work around java.net.URL bug
        }
        server.append(scheme);
        server.append ("://");
        server.append(request.getServerName());
        if ( (scheme.equals("http") && (port != 80))
            || (scheme.equals("https") && (port != 443)) ) {
            server.append(':');
            server.append(port);
        }
        return server.toString();
    }

    public static String getServer2(HttpServletRequest request) {
        StringBuffer server = new StringBuffer(128);
        server.append(request.getScheme());
        server.append ("://");
        server.append(request.getHeader("host"));
        return server.toString();
    }

    public static String getParameter(HttpServletRequest request, String param) {
        String ret = request.getParameter(param);
        if (ret == null) ret = "";
        return ret.trim();
    }

    public static String getParameter(HttpServletRequest request, String param, boolean checkEmpty)
        throws BadInputException {
        String ret = request.getParameter(param);
        if (ret == null) ret = "";
        ret = ret.trim();
        if ( checkEmpty && (ret.length() == 0) )
            throw new BadInputException("The parameter '" + DisableHtmlTagFilter.filter(param) + "' is not allowed to be empty! Please try again.");
        return ret;
    }

    /** @todo review this method */
    public static String getParameterSafe(HttpServletRequest request, String param, boolean checkEmpty) throws BadInputException {
        String ret = getParameter(request, param, checkEmpty);
        if ( (ret.indexOf('<') != -1) ||
             (ret.indexOf('>') != -1)) {
            throw new BadInputException("The parameter '" + DisableHtmlTagFilter.filter(param) + "' is not allowed to contain '<' or '>'! Please try again.");
        }
        return ret;
    }

    public static int getParameterInt(HttpServletRequest request, String param) throws BadInputException {
        String inputStr = getParameter(request, param, true);
        int ret;
        try {
            ret = Integer.parseInt(inputStr);
        } catch (NumberFormatException e) {
            throw new BadInputException("Cannot parse the parameter \"" + DisableHtmlTagFilter.filter(param) + "\" to an integer value!. Please try again.");
        }
        return ret;
    }

    public static int getParameterInt(HttpServletRequest request, String param, int defaultValue)
        throws BadInputException {
        String inputStr = getParameter(request, param, false);
        if (inputStr.length() == 0) {
            return defaultValue;
        }
        int ret;
        try {
            ret = Integer.parseInt(inputStr);
        } catch (NumberFormatException e) {
            throw new BadInputException("Cannot parse the parameter \"" + DisableHtmlTagFilter.filter(param) + "\" to an integer value!. Please try again.");
        }
        return ret;
    }

    public static long getParameterLong(HttpServletRequest request, String param) throws BadInputException {
        String inputStr = getParameter(request, param, true);
        long ret;
        try {
            ret = Long.parseLong(inputStr);
        } catch (NumberFormatException e) {
            throw new BadInputException("Cannot parse the parameter \"" + DisableHtmlTagFilter.filter(param) + "\" to an long value!. Please try again.");
        }
        return ret;
    }

    public static long getParameterLong(HttpServletRequest request, String param, long defaultValue)
        throws BadInputException {
        String inputStr = getParameter(request, param, false);
        if (inputStr.length() == 0) {
            return defaultValue;
        }

        long ret;
        try {
            ret = Long.parseLong(inputStr);
        } catch (NumberFormatException e) {
            throw new BadInputException("Cannot parse the parameter \"" + DisableHtmlTagFilter.filter(param) + "\" to an long value!. Please try again.");
        }
        return ret;
    }

    /**
     * @param  : param is the name of variable
     * @return : true if the value of param is not empty
     */
    public static boolean getParameterBoolean(HttpServletRequest request, String param) {
        String inputStr = getParameter(request, param);
        if (inputStr.length() == 0) return false;
        return true;
    }

    public static byte getParameterByte(HttpServletRequest request, String param) throws BadInputException {
        String inputStr = getParameter(request, param, true);
        byte ret;
        try {
            ret = Byte.parseByte(inputStr);
        } catch (NumberFormatException e) {
            throw new BadInputException("Cannot parse the parameter \"" + DisableHtmlTagFilter.filter(param) + "\" to an Byte value!. Please try again.");
        }
        return ret;
    }

    public static double getParameterDouble(HttpServletRequest request, String param) throws BadInputException {
        String inputStr = getParameter(request, param, true);
        double ret;
        try {
            ret = Double.parseDouble(inputStr);
        } catch (NumberFormatException e) {
            throw new BadInputException("Cannot parse the parameter \"" + DisableHtmlTagFilter.filter(param) + "\" to an double value!. Please try again.");
        }
        return ret;
    }

    public static String getParameterUrl(HttpServletRequest request, String param)
        throws BadInputException {
        String ret = getParameter(request, param);
        if ( ret.length() > 0 ) {
            if ( !ret.startsWith("http://") &&
                 !ret.startsWith("https://") &&
                 !ret.startsWith("ftp://") ) {
                throw new BadInputException("The parameter '" + DisableHtmlTagFilter.filter(param) + "' must begin with http:// or https:// or ftp:// ! Please try again.");
            }
        }
        return ret;
    }

    public static String getParameterPassword(HttpServletRequest request, String param, int minLength, int option)
        throws BadInputException {

        if (minLength < 1) minLength = 1;

        String ret = request.getParameter(param);
        if (ret == null) ret = "";
        ret = ret.trim();

        if ( ret.length() < minLength ) {
            throw new BadInputException("Your password is not allowed to be lesser than " + minLength + " characters! Please try again.");
        }

        /** @todo implement this feature */
        if (option == 1) {//char and number

        } else if (option == 2) {// lower char, upper char and number

        }
        return ret;
    }

    public static String getParameterEmail(HttpServletRequest request, String param) throws BadInputException {
        String email = getParameterSafe(request, param, true);
        MailUtil.checkGoodEmail(email);
        return email;
    }

    /**
     *
     */
    public static java.sql.Date getParameterDate(HttpServletRequest request, String param) throws BadInputException {
        String inputStr = getParameter(request, param, true);
        java.util.Date ret;
        try {
            ret = dateFormat.parse(inputStr);
        } catch (java.text.ParseException e) {
            throw new BadInputException("Cannot parse the parameter '" + DisableHtmlTagFilter.filter(param) + "' to an Date value!. Please try again.");
        }
        return new java.sql.Date(ret.getTime());
    }

    /**
     *
     */
    public static java.sql.Date getParameterDate(HttpServletRequest request, String paramDay, String paramMonth, String paramYear)
        throws BadInputException {
        int day = getParameterInt(request, paramDay);
        int month = getParameterInt(request, paramMonth);
        int year = getParameterInt(request, paramYear);
        StringBuffer buffer = new StringBuffer();
        buffer.append(day).append("/").append(month).append("/").append(year);
        String inputStr = buffer.toString();

        java.util.Date ret;
        try {
            ret = dateFormat.parse(inputStr);
        } catch (java.text.ParseException e) {
            throw new BadInputException("Cannot parse the parameter '" + DisableHtmlTagFilter.filter(inputStr) + "' to an Date value!. Please try again.");
        }
        return new java.sql.Date(ret.getTime());
    }

    public static int getParameterTimeZone(HttpServletRequest request, String param)
        throws BadInputException {
        int timeZone = getParameterInt(request, param, 0);
        if (timeZone < -12 || timeZone > 13) {
            timeZone = 0;
        }
        return timeZone;
    }

    public static String getAttribute(HttpSession session, String name) {
        String ret = (String)session.getAttribute(name);
        if (ret == null) ret = "";
        return ret.trim();
    }

    public static String getAttribute(HttpServletRequest request, String name) {
        String ret = (String)request.getAttribute(name);
        if (ret == null) ret = "";
        return ret.trim();
    }

}