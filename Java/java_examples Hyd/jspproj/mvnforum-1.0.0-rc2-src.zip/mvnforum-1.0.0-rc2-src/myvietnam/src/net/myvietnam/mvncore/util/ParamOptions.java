/*
 * $Header: /cvsroot/mvnforum/myvietnam/src/net/myvietnam/mvncore/util/ParamOptions.java,v 1.7 2003/06/01 19:07:40 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.7 $
 * $Date: 2003/06/01 19:07:40 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding MyVietnam and MyVietnam CoreLib
 * MUST remain intact in the scripts and source code.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvncore.util;

import java.util.ResourceBundle;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

final class ParamOptions {

    private static Log log = LogFactory.getLog(ParamOptions.class);

    private static final String OPTION_FILE_NAME = "mvncore_util_ParamOptions";

    //default values
    String contextPath = "";
    String serverPath = "";

    ParamOptions() {
        try {
            ResourceBundle res = ResourceBundle.getBundle(OPTION_FILE_NAME);
            contextPath = res.getString("CONTEXT_PATH").trim();
            serverPath = res.getString("SERVER_PATH").trim();
            if (serverPath.endsWith("/")) {
                serverPath = serverPath.substring(0, serverPath.length()-1);
            }
        } catch (Exception e) {
            String message = "net.myvietnam.mvncore.util.ParamOptions: Can't read the properties file: '" + OPTION_FILE_NAME + ".properties'. Make sure the file is in your CLASSPATH";
            log.error(message, e);
        }
    }//constructor
}