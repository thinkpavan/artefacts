/*
 * $Header: /cvsroot/mvnforum/myvietnam/src/net/myvietnam/mvncore/info/DatabaseInfo.java,v 1.6 2003/08/02 15:10:00 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.6 $
 * $Date: 2003/08/02 15:10:00 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding MyVietnam and MyVietnam CoreLib
 * MUST remain intact in the scripts and source code.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvncore.info;

import java.sql.Connection;
import java.sql.DatabaseMetaData;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.db.DBUtils;

public class DatabaseInfo {

    private static Log log = LogFactory.getLog(DatabaseInfo.class);

    private String databaseProductName;
    private String databaseProductVersion;
    private String databaseUrl;
    private String databaseUsername;
    private String driverName;
    private String driverVersion;

    private String errorMessage;

    public DatabaseInfo() {
        Connection connection = null;
        try {
            connection = DBUtils.getConnection();
            DatabaseMetaData dbmd   = connection.getMetaData();
            databaseUrl             = dbmd.getURL();
            databaseUsername        = dbmd.getUserName();
            databaseProductName     = dbmd.getDatabaseProductName();
            databaseProductVersion  = dbmd.getDatabaseProductVersion();
            driverName              = dbmd.getDriverName();
            driverVersion           = dbmd.getDriverVersion();
        } catch (Exception ex) {
            log.error("Error when access database info", ex);
            errorMessage = ex.getMessage();
        } finally {
            DBUtils.closeConnection(connection);
        }
    }

    public String getDatabaseProductName() {
        return databaseProductName;
    }

    public String getDatabaseProductVersion() {
        return databaseProductVersion;
    }

    public String getDatabaseUrl() {
        return databaseUrl;
    }

    public String getDatabaseUsername() {
        return databaseUsername;
    }

    public String getDriverName() {
        return driverName;
    }

    public String getDriverVersion() {
        return driverVersion;
    }

    public String getErrorMessage() {
        return errorMessage;
    }
}