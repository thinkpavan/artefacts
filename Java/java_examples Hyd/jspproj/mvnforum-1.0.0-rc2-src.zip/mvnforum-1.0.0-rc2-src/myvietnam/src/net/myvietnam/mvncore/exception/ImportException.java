/*
 * $Header: /cvsroot/mvnforum/myvietnam/src/net/myvietnam/mvncore/exception/ImportException.java,v 1.7 2003/09/27 15:05:17 imanic Exp $
 * $Author: imanic $
 * $Revision: 1.7 $
 * $Date: 2003/09/27 15:05:17 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding MyVietnam and MyVietnam CoreLib
 * MUST remain intact in the scripts and source code.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Igor Manic  imanic@users.sourceforge.net
 */
package net.myvietnam.mvncore.exception;

/**
 * @author <a href="mailto:imanic@users.sourceforge.net">Igor Manic</a>
 * @version $Revision: 1.7 $, $Date: 2003/09/27 15:05:17 $
 * <br/>
 * <code>ImportException</code> represents the error that could be raised during
 * the database import process. This class encapsulates detailed message that
 * describes the error in user-friendly language, and the root exception that
 * caused the import to stop.
 */
public class ImportException extends Exception {

    private Exception exception;

    public ImportException() {
        super();
        this.exception = null;
    }

    public ImportException(String message) {
        super(message);
        this.exception = null;
    }

    public ImportException(Exception e) {
        super();
        this.exception = e;
    }

    public ImportException(String message, Exception e) {
        super(message);
        this.exception = e;
    }

    public String getMessage() {
        String message = super.getMessage();

        if (exception != null) {
            return message + " Detail: " + exception.getMessage();
        } else {
            return message;
        }
    }

    public Exception getException() {
        return exception;
    }

    public String toString() {
        if (exception != null) {
            return exception.toString();
        } else {
            return super.toString();
        }
    }

}