/*
 * $Header: /cvsroot/mvnforum/myvietnam/src/net/myvietnam/mvncore/db/DBOptions.java,v 1.9 2003/08/20 17:15:11 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.9 $
 * $Date: 2003/08/20 17:15:11 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding MyVietnam and MyVietnam CoreLib
 * MUST remain intact in the scripts and source code.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvncore.db;

import java.util.ResourceBundle;
import java.util.MissingResourceException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

class DBOptions {

    private static Log log = LogFactory.getLog(DBOptions.class);

    private static final String OPTION_FILE_NAME = "mvncore_db_DBOptions";

    //default values
    boolean useDatasource   = false;
    // MUST NOT refer to DBUtils, not we will get an infinite recurse
    int databaseType        = 0; //DATABASE_UNKNOWN

    // if useDatasource = true
    String datasourceName   = "";

    // if useDatasource = false
    String driverClassName  = "org.gjt.mm.mysql.Driver";
    String databaseURL      = "jdbc:mysql://localhost/test";
    String databaseUser     = "user";
    String databasePassword = "password";
    int maxConnection       = 20;
    int maxTimeToWait       = 2000;// 2 seconds
    int minutesBetweenRefresh = 30;// 30 minutes

    DBOptions() {
        try {
            ResourceBundle res = ResourceBundle.getBundle(OPTION_FILE_NAME);

            String strUseDatasource = "false";
            try {
                strUseDatasource = res.getString("USE_DATASOURCE").trim();
            } catch (MissingResourceException ex) {
                // ignore exception
            }
            try {
                databaseType   = Integer.parseInt(res.getString("DATABASE_TYPE").trim());
            } catch (Exception ex) {
                log.error("Fail to read DATABASE_TYPE, use default value = " + databaseType);
            }

            if (strUseDatasource.equals("true")) {
                useDatasource       = true;
                datasourceName      = res.getString("DATASOURCE_NAME").trim();
            } else {
                useDatasource       = false;
                driverClassName     = res.getString("DRIVER_CLASS_NAME").trim();
                databaseURL         = res.getString("DATABASE_URL").trim();
                databaseUser        = res.getString("DATABASE_USER").trim();
                databasePassword    = res.getString("DATABASE_PASSWORD").trim();
                try {
                    maxConnection   = Integer.parseInt(res.getString("DATABASE_MAXCONNECTION").trim());
                } catch (Exception ex) {
                    log.error("Fail to read DATABASE_MAXCONNECTION, use default value = " + maxConnection, ex);
                }
                try {
                    maxTimeToWait   = Integer.parseInt(res.getString("MAX_TIME_TO_WAIT").trim());
                } catch (Exception ex) {
                    log.error("Fail to read MAX_TIME_TO_WAIT, use default value = " + maxTimeToWait, ex);
                }
                try {
                    minutesBetweenRefresh = Integer.parseInt(res.getString("MINUTES_BETWEEN_REFRESH").trim());
                    if (minutesBetweenRefresh < 1) minutesBetweenRefresh = 1;//min is 1 minute
                } catch (Exception ex) {
                    log.error("Fail to read MINUTES_BETWEEN_REFRESH, use default value = " + minutesBetweenRefresh, ex);
                }
            }
        } catch (Exception e) {
            String message = "net.myvietnam.mvncore.db.DBOptions: Can't read the properties file: '" + OPTION_FILE_NAME + ".properties'. Make sure the file is in your CLASSPATH";
            log.error(message, e);
        }
    }//constructor
}