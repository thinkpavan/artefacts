/*
 * $Header: /cvsroot/mvnforum/myvietnam/src/net/myvietnam/mvncore/util/StringUtil.java,v 1.12 2003/10/06 17:16:51 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.12 $
 * $Date: 2003/10/06 17:16:51 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding MyVietnam and MyVietnam CoreLib
 * MUST remain intact in the scripts and source code.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvncore.util;

import net.myvietnam.mvncore.exception.BadInputException;
import java.util.*;
import net.myvietnam.mvncore.filter.DisableHtmlTagFilter;
/**
 * @todo:  add option for SHORT_STRING_LENGTH
 */
public final class StringUtil {

    private StringUtil() {//prevent instantiation
    }

    private static final int SHORT_STRING_LENGTH = 100;

    /**
     * This method trim the input variable, so if it contains only spaces,
     * then it will be empty string, then we have 0 token :-)
     * The returned value is never null. If the input String is null, an
     * empty String array will be returned
     * All tokens are trimed before returning
     */
    public static String[] getStringArray(String inputValue, String delim) {
        if (inputValue == null) inputValue = "";
        inputValue = inputValue.trim();// very important
        java.util.StringTokenizer t = new java.util.StringTokenizer(inputValue, delim);
        String[] ret = new String[t.countTokens()];
        int index = 0;
        while(t.hasMoreTokens()) {
            String token = t.nextToken().trim();
            // check for valid value here if needed
            ret[index] = token;
            index++;
        }
        return ret;
    }

    public static String getEmptyStringIfNull(String str) {
        if (str == null) return "";
        return str;
    }

    /**
     * @todo: use StringBuffer
     * accept name with char, number or '_' or '.'
     */
    public static void checkGoodName(String str) throws BadInputException {
        byte[] s = str.getBytes();
        int length = s.length;
        byte b = 0;

        for (int i = 0; i < length; i++) {
            b = s[i];
            if ((b >= 'a') && (b <= 'z')) {
                // lower char
            } else if ((b >= 'A') && (b <= 'Z')) {
                // upper char
            } else if ((b >= '0') && (b <= '9') && (i != 0)) {
                // numeric char
            } else if (( (b=='_') || (b=='.') ) && (i != 0)) {
                // _ char
            } else {
                // not good char, throw an BadInputException
                throw new BadInputException("The string '" + DisableHtmlTagFilter.filter(str) + "' is not a good name. Reason: character '" + (char)(b) + "' is not allowed.");
            }
        }// for
    }

    public static String getShorterString(String str, int maxLength) throws BadInputException {
        if (maxLength < 0) throw new BadInputException("The maxLength < 0 is not allowed.");
        if (str == null) return "";
        if (str.length() <= maxLength) return str;
        return str.substring(0, maxLength) + "...";
    }

    public static String getShorterString(String str) throws BadInputException {
        return getShorterString(str, SHORT_STRING_LENGTH);
    }

    public static String replace(String input, char from, String to) {
        if (input == null) {
            return null;
        }

        char[] s = input.toCharArray();
        int length = s.length;
        StringBuffer ret = new StringBuffer(length * 2);

        for (int i = 0; i < length; i++) {
            if (s[i] == from) {
                ret.append(to);
            } else {
                ret.append(s[i]);
            }
        }// for
        return ret.toString();
    }

    /*
    public static String replace(String input, String from, String to) {
        if (input == null) {
            return null;
        }
        return null;
    }
    */

    /**
     * This method can be replaced by getStringArray
     */
    public static Collection getSeparateString(String strContent, String pattern) {
        int beginIndex = 0;
        Collection coResult = new ArrayList();
        String result;
        int position = strContent.indexOf(pattern, beginIndex); // Get the first position
        while (position != -1) {
            result = strContent.substring(beginIndex, position);
            if (!result.trim().equals("")) {
                coResult.add(result);
            }
            beginIndex = position + pattern.length(); //Cong 1 la chieu dai cua ky tu ;
            position = strContent.indexOf(pattern, beginIndex);
        }

        return coResult;
    }

    /* for test only
    public static void main(String[] args) {
        //String[] s = getStringArray("  fasg;,   zdgsag, ,,", ",");
        String[] s = getStringArray("  fasg  ", ",");
        System.out.println("length = " + s.length);
        for (int i = 0; i < s.length; i++) {
            System.out.println("" + i + " : " + s[i]);
        }
    }
    */
}