/*
 * $Header: /cvsroot/mvnforum/myvietnam/src/net/myvietnam/mvncore/security/Encoder.java,v 1.9 2003/07/21 16:20:48 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.9 $
 * $Date: 2003/07/21 16:20:48 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding MyVietnam and MyVietnam CoreLib
 * MUST remain intact in the scripts and source code.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvncore.security;

import java.net.URLEncoder;
import java.security.MessageDigest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.misc.Base64;
import net.myvietnam.mvncore.util.MailUtil;

public class Encoder {

    private static Log log = LogFactory.getLog(Encoder.class);

    // Please note that 2 below methods are used in #getMD5_Base64 only
    // use them in other methods will make it not thread-safe
    private static MessageDigest digest = null;
    private static boolean isInited = false;

    private Encoder() {
    }

    public static synchronized String getMD5_Base64(String input) {
        // please note that we dont use digest, because if we
        // cannot get digest, then the second time we have to call it
        // again, which will fail again
        if (isInited == false) {
            isInited = true;
            try {
                digest = MessageDigest.getInstance("MD5");
            } catch (Exception ex) {
                log.error("Cannot get MessageDigest. Application may fail to run correctly.", ex);
            }
        }
        if (digest == null) return input;

        // now everything is ok, go ahead
        try {
            digest.update(input.getBytes("UTF-8"));
        } catch (java.io.UnsupportedEncodingException ex) {
            log.error("Assertion: This should never occur.");
        }
        byte[] rawData = digest.digest();
        byte[] encoded = Base64.encode(rawData);
        String retValue = new String(encoded);
        return retValue;
    }

    public static String encodeURL(String input) {
        return URLEncoder.encode(input);
    }

    public static String filterUrl(String url) {
        String lowerUrl = url.toLowerCase();
        if ( (lowerUrl.indexOf("javascript:") >= 0) ||
             lowerUrl.indexOf("file:") >= 0) {
            return "";
        }

        String protocol = "http://";//default protocol
        String name = null;
        if (url.startsWith("http://")) {
            protocol = "http://";
            name = url.substring(protocol.length());// must duplicate it because of the default protocol
        } else if (url.startsWith("https://")) {
            protocol = "https://";
            name = url.substring(protocol.length());// must duplicate it because of the default protocol
        } else if (url.startsWith("ftp://")) {
            protocol = "ftp://";
            name = url.substring(protocol.length());// must duplicate it because of the default protocol
        } else if (url.startsWith("mailto:")) {
            protocol = "mailto:";
            name = url.substring(protocol.length());// must duplicate it because of the default protocol
        } else {
            name = url;
        }
        String ret;
        if (protocol.equals("mailto:")) {
            try {
                MailUtil.checkGoodEmail(name);
                ret = protocol + name;
            } catch (Exception ex) {
                ret = "";
            }
        } else {
            ret = protocol + encodePath(name);
        }
        return ret;
    }

    /**
     *
     * @param path the path, something like this localhost:8080/image/index.html
     * @return the path after being encoded
     */
    private static String encodePath(String path) {
        return path;
        /*
        String ret = "";
        int indexFirstSlash = path.indexOf('/');
        if ( indexFirstSlash != -1 ) {
            String hostport = path.substring(0, indexFirstSlash);
            int indexFirstColon = hostport.indexOf(':');
            if (indexFirstColon != -1) {
                String host = hostport.substring(0, indexFirstColon);
                String port = hostport.substring(indexFirstColon + 1);
                hostport = Encoder.encodeURL(host) + ":" + Encoder.encodeURL(port);
            } else {
                hostport = Encoder.encodeURL(hostport);
            }
            String filename = path.substring(indexFirstSlash + 1);
            filename = Encoder.encodeURL(filename);
            ret = hostport + "/" + filename;
        } else {
            ret = Encoder.encodeURL(path);
        }
        return ret;
        */
    }

    /*
    public static void main(String[] args) {
        //test data should be
        //a1            iou3zTQ6oq2Zt9diAwhXog==
        //Hello World   sQqNsWTgdUEFt6mb5y4/5Q==

        String testString = "a1";
        String encrypted = getMD5_Base64(testString);
        System.out.println("encrypted = " + encrypted);
        System.out.println("length = " + encrypted.length());
    }
    */
}