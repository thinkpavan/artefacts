/*
 * $Header: /cvsroot/mvnforum/myvietnam/src/net/myvietnam/mvncore/util/MailOptions.java,v 1.7 2003/06/01 19:07:40 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.7 $
 * $Date: 2003/06/01 19:07:40 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding MyVietnam and MyVietnam CoreLib
 * MUST remain intact in the scripts and source code.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvncore.util;

import java.util.ResourceBundle;
import java.util.MissingResourceException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

final class MailOptions {

    private static Log log = LogFactory.getLog(MailOptions.class);

    private static final String OPTION_FILE_NAME = "mvncore_util_MailOptions";

    //default values
    String mailServer       = "mail.host";
    String defaultMailFrom  = "user@host";
    String username         = "";
    String password         = "";
    int    port             = 25;

    MailOptions() {
        try {
            ResourceBundle res = ResourceBundle.getBundle(OPTION_FILE_NAME);

            mailServer      = res.getString("MAIL_SERVER").trim();
            defaultMailFrom = res.getString("DEFAULT_MAIL_FROM").trim();
            username        = res.getString("USERNAME").trim();
            password        = res.getString("PASSWORD").trim();
            try {
                String temp = res.getString("PORT").trim();
                port = Integer.parseInt(temp);
            } catch (MissingResourceException ex) {
                // do nothing, just use default
            } catch (NumberFormatException ex) {
                // do nothing, just use default
            }
        } catch (Exception e) {
            String message = "net.myvietnam.mvncore.util.MailOptions: Can't read the properties file: '" + OPTION_FILE_NAME + ".properties'. Make sure the file is in your CLASSPATH";
            log.error(message, e);
        }
    }//constructor
}