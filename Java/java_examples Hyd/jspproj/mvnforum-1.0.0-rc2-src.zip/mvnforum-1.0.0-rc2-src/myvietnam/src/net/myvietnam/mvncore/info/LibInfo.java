/*
 * $Header: /cvsroot/mvnforum/myvietnam/src/net/myvietnam/mvncore/info/LibInfo.java,v 1.5 2003/06/01 19:07:40 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.5 $
 * $Date: 2003/06/01 19:07:40 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding MyVietnam and MyVietnam CoreLib
 * MUST remain intact in the scripts and source code.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvncore.info;

import java.awt.image.BufferedImage;
import java.awt.Graphics2D;

public class LibInfo {

    boolean supportJNDI             = false;
    boolean supportJavaxSql         = false;
    boolean supportJAF              = false;
    boolean supportMail             = false;

    boolean supportBeanUtils        = false;
    boolean supportCommonLogging    = false;
    boolean supportJakartaRegExp    = false;
    boolean supportLucene           = false;

    boolean supportMmMysqlDriver    = false;
    boolean supportComMysqlDriver   = false;

    boolean supportImageProcessing  = false;

    public LibInfo() {
        try {
            Class.forName("javax.naming.Name");
            supportJNDI = true;
        } catch (ClassNotFoundException ex) {}

        try {
            Class.forName("javax.sql.DataSource");
            supportJavaxSql = true;
        } catch (ClassNotFoundException ex) {}

        try {
            Class.forName("javax.activation.DataSource");
            supportJAF = true;
        } catch (ClassNotFoundException ex) {}

        try {
            Class.forName("javax.mail.Message");
            supportMail = true;
        } catch (ClassNotFoundException ex) {}

        try {
            Class.forName("org.apache.commons.beanutils.MethodUtils");
            supportBeanUtils = true;
        } catch (ClassNotFoundException ex) {}

        try {
            Class.forName("org.apache.commons.logging.LogFactory");
            supportCommonLogging = true;
        } catch (ClassNotFoundException ex) {}

        try {
            Class.forName("org.apache.regexp.RE");
            supportJakartaRegExp = true;
        } catch (ClassNotFoundException ex) {}

        try {
            Class.forName("org.apache.lucene.index.IndexWriter");
            supportLucene = true;
        } catch (ClassNotFoundException ex) {}

        try {
            Class.forName("org.gjt.mm.mysql.Driver");
            supportMmMysqlDriver = true;
        } catch (ClassNotFoundException ex) {}

        try {
            Class.forName("com.mysql.jdbc.Driver");
            supportComMysqlDriver = true;
        } catch (ClassNotFoundException ex) {}

        try {
            BufferedImage bufferedImage = new BufferedImage(10, 10, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = bufferedImage.createGraphics();
            g.drawLine(0, 0, 10, 10);
            g.dispose();// free resource

            supportImageProcessing = true;
        } catch (Throwable ex) {}

    }

    public boolean isSupportJAF() {
        return supportJAF;
    }

    public boolean isSupportJavaxSql() {
        return supportJavaxSql;
    }

    public boolean isSupportJNDI() {
        return supportJNDI;
    }

    public boolean isSupportMail() {
        return supportMail;
    }

    public boolean isSupportBeanUtils() {
        return supportBeanUtils;
    }

    public boolean isSupportCommonLogging() {
        return supportCommonLogging;
    }

    public boolean isSupportJakartaRegExp() {
        return supportJakartaRegExp;
    }

    public boolean isSupportLucene() {
        return supportLucene;
    }

    public boolean isSupportMmMysqlDriver() {
        return supportMmMysqlDriver;
    }

    public boolean isSupportComMysqlDriver() {
        return supportComMysqlDriver;
    }

    public boolean isSupportImageProcessing() {
        return supportImageProcessing;
    }

}