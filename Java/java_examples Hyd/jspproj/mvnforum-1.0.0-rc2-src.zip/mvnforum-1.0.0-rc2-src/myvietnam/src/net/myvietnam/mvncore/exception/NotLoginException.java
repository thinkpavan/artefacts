/*
 * $Header: /cvsroot/mvnforum/myvietnam/src/net/myvietnam/mvncore/exception/NotLoginException.java,v 1.5 2003/06/01 19:07:39 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.5 $
 * $Date: 2003/06/01 19:07:39 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding MyVietnam and MyVietnam CoreLib
 * MUST remain intact in the scripts and source code.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvncore.exception;

public class NotLoginException extends Exception {

    public static final int NOT_LOGIN           = 0;
    public static final int ILLEGAL_STATE       = 1;
    public static final int WRONG_NAME          = 2;
    public static final int WRONG_PASSWORD      = 3;
    public static final int ACCOUNT_DISABLED    = 4;
    public static final int NOT_ENOUGH_RIGHTS   = 5;
    public static final int NOT_ACTIVATED       = 6;

    private int exceptionReason = NOT_LOGIN;

    public NotLoginException(String msg) {
        super(msg);
    }

    public NotLoginException(int reason) {
        exceptionReason = reason;
    }

    public NotLoginException(String msg, int reason) {
        super(msg);
        exceptionReason = reason;
    }

    public int getReason() {
        return exceptionReason;
    }

    public String getReasonString() {
        if (exceptionReason == ILLEGAL_STATE) {
            return "reason: ILLEGAL_STATE";
        } else if (exceptionReason == WRONG_NAME) {
            return "reason: WRONG_NAME";
        } else if (exceptionReason == WRONG_PASSWORD) {
            return "reason: WRONG_PASSWORD";
        } else if (exceptionReason == ACCOUNT_DISABLED) {
            return "reason: ACCOUNT_DISABLED";
        } else if (exceptionReason == NOT_ENOUGH_RIGHTS) {
            return "reason: NOT_ENOUGH_RIGHTS";
        } else if (exceptionReason == NOT_ACTIVATED) {
            return "reason: NOT_ACTIVATED";
        }
        return "reason: NOTLOGIN";
    }

    public String getReasonExplanation() {
        if (exceptionReason == ILLEGAL_STATE) {
            return "Your session has been timed out. Please login again.";
        } else if (exceptionReason == WRONG_NAME) {
            return "Cannot find the name you'd like to login. Please login with other name.";
        } else if (exceptionReason == WRONG_PASSWORD) {
            return "You have typed wrong password! Please try again.";
        } else if (exceptionReason == ACCOUNT_DISABLED) {
            return "Your account is currently disabled. Please contact Web site Administrator for the reason.";
        } else if (exceptionReason == NOT_ENOUGH_RIGHTS) {
            return "Sorry, you do not have enough permissions.";
        } else if (exceptionReason == NOT_ACTIVATED) {
            return "Your account is not activated. Please activate your account first before continuing.";
        }
        return "Please login to have access to the system.";
    }
}
