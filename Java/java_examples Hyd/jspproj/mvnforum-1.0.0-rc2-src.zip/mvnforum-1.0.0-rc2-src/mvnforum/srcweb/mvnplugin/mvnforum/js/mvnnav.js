// *******************************************************
// moved javascript from listrecentthreads.jsp, listthreads.jsp, viewthread.jsp
function gotoPage(s) {
    if (s != '') location.href = s;
    return 1;
}