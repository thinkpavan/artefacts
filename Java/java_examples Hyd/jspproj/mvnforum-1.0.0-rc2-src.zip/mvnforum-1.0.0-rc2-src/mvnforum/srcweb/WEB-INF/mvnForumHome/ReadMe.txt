This is the home directory of all the files that mvnForum will use/create during it's work.

It contains:
- temporary files directory (temp)
- log directory (log)
- backup repository (backup)
- attachments repository (attachment)
