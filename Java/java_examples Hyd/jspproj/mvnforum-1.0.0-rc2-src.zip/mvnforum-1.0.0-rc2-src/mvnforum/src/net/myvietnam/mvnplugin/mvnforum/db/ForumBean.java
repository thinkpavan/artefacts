/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/ForumBean.java,v 1.6 2003/09/14 14:15:39 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.6 $
 * $Date: 2003/09/14 14:15:39 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Iterator;

import net.myvietnam.mvncore.util.StringUtil;

/*
 * Included columns: ForumID, CategoryID, LastPostMemberName, ForumName, ForumDesc,
 *                   ForumCreationDate, ForumModifiedDate, ForumLastPostDate, ForumOrder, ForumType,
 *                   ForumFormatOption, ForumOption, ForumStatus, ForumModerationMode, ForumPassword,
 *                   ForumThreadCount, ForumPostCount
 * Excluded columns:
 */
public class ForumBean {
    private int forumID;
    private int categoryID;
    private String lastPostMemberName;
    private String forumName;
    private String forumDesc;
    private Timestamp forumCreationDate;
    private Timestamp forumModifiedDate;
    private Timestamp forumLastPostDate;
    private int forumOrder;
    private int forumType;
    private int forumFormatOption;
    private int forumOption;
    private int forumStatus;
    private int forumModerationMode;
    private String forumPassword;
    private int forumThreadCount;
    private int forumPostCount;

    public int getForumID() {
        return forumID;
    }
    public void setForumID(int forumID) {
        this.forumID = forumID;
    }

    public int getCategoryID() {
        return categoryID;
    }
    public void setCategoryID(int categoryID) {
        this.categoryID = categoryID;
    }

    public String getLastPostMemberName() {
        return lastPostMemberName;
    }
    public void setLastPostMemberName(String lastPostMemberName) {
        this.lastPostMemberName = StringUtil.getEmptyStringIfNull(lastPostMemberName);
    }

    public String getForumName() {
        return forumName;
    }
    public void setForumName(String forumName) {
        this.forumName = forumName;
    }

    public String getForumDesc() {
        return forumDesc;
    }
    public void setForumDesc(String forumDesc) {
        this.forumDesc = StringUtil.getEmptyStringIfNull(forumDesc);
    }

    public Timestamp getForumCreationDate() {
        return forumCreationDate;
    }
    public void setForumCreationDate(Timestamp forumCreationDate) {
        this.forumCreationDate = forumCreationDate;
    }

    public Timestamp getForumModifiedDate() {
        return forumModifiedDate;
    }
    public void setForumModifiedDate(Timestamp forumModifiedDate) {
        this.forumModifiedDate = forumModifiedDate;
    }

    public Timestamp getForumLastPostDate() {
        return forumLastPostDate;
    }
    public void setForumLastPostDate(Timestamp forumLastPostDate) {
        this.forumLastPostDate = forumLastPostDate;
    }

    public int getForumOrder() {
        return forumOrder;
    }
    public void setForumOrder(int forumOrder) {
        this.forumOrder = forumOrder;
    }

    public int getForumType() {
        return forumType;
    }
    public void setForumType(int forumType) {
        this.forumType = forumType;
    }

    public int getForumFormatOption() {
        return forumFormatOption;
    }
    public void setForumFormatOption(int forumFormatOption) {
        this.forumFormatOption = forumFormatOption;
    }

    public int getForumOption() {
        return forumOption;
    }
    public void setForumOption(int forumOption) {
        this.forumOption = forumOption;
    }

    public int getForumStatus() {
        return forumStatus;
    }
    public void setForumStatus(int forumStatus) {
        this.forumStatus = forumStatus;
    }

    public int getForumModerationMode() {
        return forumModerationMode;
    }
    public void setForumModerationMode(int forumModerationMode) {
        this.forumModerationMode = forumModerationMode;
    }

    public String getForumPassword() {
        return forumPassword;
    }
    public void setForumPassword(String forumPassword) {
        this.forumPassword = StringUtil.getEmptyStringIfNull(forumPassword);
    }

    public int getForumThreadCount() {
        return forumThreadCount;
    }
    public void setForumThreadCount(int forumThreadCount) {
        this.forumThreadCount = forumThreadCount;
    }

    public int getForumPostCount() {
        return forumPostCount;
    }
    public void setForumPostCount(int forumPostCount) {
        this.forumPostCount = forumPostCount;
    }

    public String getXML() {
        StringBuffer xml = new StringBuffer(1024);
        xml.append("<ForumSection>\n");
        xml.append("  <Rows>\n");
        xml.append("    <Row>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>CategoryID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(categoryID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>LastPostMemberName</Name>\n");
        xml.append("        <Value>").append(String.valueOf(lastPostMemberName)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumName</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumName)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumDesc</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumDesc)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumCreationDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumCreationDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumModifiedDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumModifiedDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumLastPostDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumLastPostDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumOrder</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumOrder)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumType</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumType)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumFormatOption</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumFormatOption)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumOption</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumOption)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumStatus</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumStatus)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumModerationMode</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumModerationMode)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumPassword</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumPassword)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumThreadCount</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumThreadCount)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumPostCount</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumPostCount)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("    </Row>\n");
        xml.append("  </Rows>\n");
        xml.append("</ForumSection>\n");
        return xml.toString();
    }

    public static String getXML(Collection objForumBeans) {
        StringBuffer xml = new StringBuffer(1024);
        Iterator iterator = objForumBeans.iterator();
        xml.append("<ForumSection>\n");
        xml.append("  <Rows>\n");
        while (iterator.hasNext()) {
            ForumBean objForumBean = (ForumBean)iterator.next();
            xml.append("    <Row>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objForumBean.forumID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>CategoryID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objForumBean.categoryID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>LastPostMemberName</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objForumBean.lastPostMemberName)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumName</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objForumBean.forumName)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumDesc</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objForumBean.forumDesc)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumCreationDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objForumBean.forumCreationDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumModifiedDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objForumBean.forumModifiedDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumLastPostDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objForumBean.forumLastPostDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumOrder</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objForumBean.forumOrder)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumType</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objForumBean.forumType)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumFormatOption</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objForumBean.forumFormatOption)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumOption</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objForumBean.forumOption)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumStatus</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objForumBean.forumStatus)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumModerationMode</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objForumBean.forumModerationMode)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumPassword</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objForumBean.forumPassword)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumThreadCount</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objForumBean.forumThreadCount)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumPostCount</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objForumBean.forumPostCount)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("    </Row>\n");
        }//while
        xml.append("  </Rows>\n");
        xml.append("</ForumSection>\n");
        return xml.toString();
    }
} //end of class ForumBean
