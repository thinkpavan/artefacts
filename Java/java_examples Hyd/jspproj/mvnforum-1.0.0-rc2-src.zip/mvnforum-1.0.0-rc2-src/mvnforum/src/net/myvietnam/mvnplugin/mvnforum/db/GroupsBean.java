/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/GroupsBean.java,v 1.8 2003/10/29 18:57:41 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.8 $
 * $Date: 2003/10/29 18:57:41 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Iterator;

import net.myvietnam.mvncore.util.StringUtil;
import net.myvietnam.mvncore.exception.ObjectNotFoundException;

/*
 * Included columns: GroupID, GroupOwnerID, GroupOwnerName, GroupName, GroupDesc,
 *                   GroupOption, GroupCreationDate, GroupModifiedDate
 * Excluded columns:
 */
public class GroupsBean {
    private int groupID;
    private int groupOwnerID;
    private String groupOwnerName;
    private String groupName;
    private String groupDesc;
    private int groupOption;
    private Timestamp groupCreationDate;
    private Timestamp groupModifiedDate;

    public int getGroupID() {
        return groupID;
    }
    public void setGroupID(int groupID) {
        this.groupID = groupID;
    }

    public int getGroupOwnerID() {
        return groupOwnerID;
    }
    public void setGroupOwnerID(int groupOwnerID) {
        this.groupOwnerID = groupOwnerID;
    }

    public String getGroupOwnerName() {
        return groupOwnerName;
    }
    public void setGroupOwnerName(String groupOwnerName) {
        this.groupOwnerName = StringUtil.getEmptyStringIfNull(groupOwnerName);
    }

    public String getGroupName() {
        return groupName;
    }
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupDesc() {
        return groupDesc;
    }
    public void setGroupDesc(String groupDesc) {
        this.groupDesc = StringUtil.getEmptyStringIfNull(groupDesc);
    }

    public int getGroupOption() {
        return groupOption;
    }
    public void setGroupOption(int groupOption) {
        this.groupOption = groupOption;
    }

    public Timestamp getGroupCreationDate() {
        return groupCreationDate;
    }
    public void setGroupCreationDate(Timestamp groupCreationDate) {
        this.groupCreationDate = groupCreationDate;
    }

    public Timestamp getGroupModifiedDate() {
        return groupModifiedDate;
    }
    public void setGroupModifiedDate(Timestamp groupModifiedDate) {
        this.groupModifiedDate = groupModifiedDate;
    }

    public String getXML() {
        StringBuffer xml = new StringBuffer(1024);
        xml.append("<GroupsSection>\n");
        xml.append("  <Rows>\n");
        xml.append("    <Row>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>GroupID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(groupID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>GroupOwnerID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(groupOwnerID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>GroupOwnerName</Name>\n");
        xml.append("        <Value>").append(String.valueOf(groupOwnerName)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>GroupName</Name>\n");
        xml.append("        <Value>").append(String.valueOf(groupName)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>GroupDesc</Name>\n");
        xml.append("        <Value>").append(String.valueOf(groupDesc)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>GroupOption</Name>\n");
        xml.append("        <Value>").append(String.valueOf(groupOption)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>GroupCreationDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(groupCreationDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>GroupModifiedDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(groupModifiedDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("    </Row>\n");
        xml.append("  </Rows>\n");
        xml.append("</GroupsSection>\n");
        return xml.toString();
    }

    public static String getXML(Collection objGroupsBeans) {
        StringBuffer xml = new StringBuffer(1024);
        Iterator iterator = objGroupsBeans.iterator();
        xml.append("<GroupsSection>\n");
        xml.append("  <Rows>\n");
        while (iterator.hasNext()) {
            GroupsBean objGroupsBean = (GroupsBean)iterator.next();
            xml.append("    <Row>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>GroupID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objGroupsBean.groupID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>GroupOwnerID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objGroupsBean.groupOwnerID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>GroupOwnerName</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objGroupsBean.groupOwnerName)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>GroupName</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objGroupsBean.groupName)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>GroupDesc</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objGroupsBean.groupDesc)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>GroupOption</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objGroupsBean.groupOption)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>GroupCreationDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objGroupsBean.groupCreationDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>GroupModifiedDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objGroupsBean.groupModifiedDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("    </Row>\n");
        }//while
        xml.append("  </Rows>\n");
        xml.append("</GroupsSection>\n");
        return xml.toString();
    }

    /************************************************
     * Customized methods come below
     ************************************************/
    private int groupMemberCount;

    public int getGroupMemberCount() {
        return groupMemberCount;
    }
    public void setGroupMemberCount(int groupMemberCount) {
        this.groupMemberCount = groupMemberCount;
    }

    public static GroupsBean getGroupsBean(Collection objGroupsBeans, int groupID)
        throws ObjectNotFoundException {
        Iterator iterator = objGroupsBeans.iterator();
        while (iterator.hasNext()) {
            GroupsBean objGroupsBean = (GroupsBean)iterator.next();
            if (objGroupsBean.getGroupID() == groupID) {
                return objGroupsBean;
            }
        }//while
        throw new ObjectNotFoundException("Cannot find GroupsBean with GroupID = " + groupID);
    }

} //end of class GroupsBean
