/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/user/ThreadWebHandler.java,v 1.33 2003/10/31 20:19:04 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.33 $
 * $Date: 2003/10/31 20:19:04 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.user;

import java.sql.Timestamp;
import java.util.*;

import javax.servlet.http.HttpServletRequest;

import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.util.ParamUtil;
import net.myvietnam.mvnplugin.mvnforum.*;
import net.myvietnam.mvnplugin.mvnforum.auth.*;
import net.myvietnam.mvnplugin.mvnforum.db.*;
import net.myvietnam.mvnplugin.mvnforum.search.DeletePostIndexTask;
import net.myvietnam.mvnplugin.mvnforum.search.PostIndexer;

class ThreadWebHandler {

    private OnlineUserManager onlineUserManager = OnlineUserManager.getInstance();

    ThreadWebHandler() {
    }

    private void updateForumStatistics(int forumID)
        throws ObjectNotFoundException, DatabaseException, AssertionException {

        int forumThreadCount = ThreadWebHelper.getNumberOfThreads_inForum(forumID);
        int forumPostCount = PostWebHelper.getNumberOfPosts_inForum(forumID);
        ForumWebHelper.updateForumStatistics(forumID, forumThreadCount, forumPostCount);

        Collection lastPostInForum = PostWebHelper.getLastBeans_inForum_limit(forumID, 1);
        Iterator iteratorInForum = lastPostInForum.iterator();
        if (iteratorInForum.hasNext()) {
            PostBean lastPostBeanInForum = (PostBean)iteratorInForum.next();
            String lastPostMemberName = lastPostBeanInForum.getMemberName();
            Timestamp forumLastPostDate = lastPostBeanInForum.getPostCreationDate();
            try {
                ForumWebHelper.updateForumLastPostMemberName(forumID, lastPostMemberName);
            } catch (ForeignKeyNotFoundException ex) {
                throw new AssertionException("Assertion: cannot update LastPostMemberName in ThreadWebHandler.updateForumStatistics");
            }
            ForumWebHelper.updateForumLastPostDate(forumID, forumLastPostDate);
        }
    }

    void prepareDelete(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException,
        AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // primary key column(s)
        int threadID = ParamUtil.getParameterInt(request, "thread");

        ThreadBean threadBean = ThreadWebHelper.getThread(threadID);

        // now, check the permission
        permission.ensureCanDeletePost(threadBean.getForumID());

        int numberOfPosts = PostWebHelper.getNumberOfPosts_inThread(threadID);

        request.setAttribute("ThreadBean", threadBean);
        request.setAttribute("NumberOfPosts", new Integer(numberOfPosts));
    }

    void processDelete(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException,
        AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // user must have been authenticated before he can delete
        permission.ensureIsAuthenticated();

        // primary key column(s)
        int threadID = ParamUtil.getParameterInt(request, "thread");

        // now, check the permission
        ThreadBean threadBean = ThreadWebHelper.getThread(threadID);
        int forumID = threadBean.getForumID();
        permission.ensureCanDeletePost(forumID);

        // now check the password
        try {
            String memberPassword  = ParamUtil.getParameterPassword(request, "MemberMatkhau", 3, 0);
            ManagerFactory.getOnlineUserFactory().validatePassword(onlineUser.getMemberName(), memberPassword, false);
        } catch (AuthenticationException e) {
            throw new BadInputException("You have typed the wrong password. Cannot proceed.");
        }

        // Delete all attachments in this thread,
        // we must call this before any attempt to delete the thread
        // That is, the order when delete is VERY IMPORTANT
        AttachmentWebHandler.deleteAttachments_inThread(threadID);

        FavoriteThreadWebHelper.deleteFavoriteThread_inThread(threadID);

        WatchWebHelper.deleteWatch_inThread(threadID);

        PostWebHelper.deletePost_inThread(threadID);

        // now delete the thread, note that we delete it after delete all child objects
        ThreadWebHelper.deleteThread(threadID);

        // now update the search index
        // @todo : what if the above methods throw exception, then no thread is deleted from index ???
        PostIndexer.scheduleDeletePostTask(threadID, DeletePostIndexTask.OBJECT_TYPE_THREAD);

        //now, update the statistics in the forum
        updateForumStatistics(forumID);

        request.setAttribute("ForumID", String.valueOf(forumID));
    }

    void prepareMoveThread(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException,
        AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // primary key column(s)
        int threadID = ParamUtil.getParameterInt(request, "thread");

        ThreadBean threadBean = ThreadWebHelper.getThread(threadID);

        // now, check the permission
        // @todo: is it the correct permission ???
        permission.ensureCanDeletePost(threadBean.getForumID());

        //Get All Destination Forums except forum of thread
        Collection forumBeans = ForumCache.getInstance().getBeans();
        int numberOfPosts = PostWebHelper.getNumberOfPosts_inThread(threadID);

        request.setAttribute("ThreadBean", threadBean);
        request.setAttribute("ForumBeans", forumBeans);
        request.setAttribute("NumberOfPosts", new Integer(numberOfPosts));
    }

    void processMoveThread(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException,
        ForeignKeyNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // user must have been authenticated before he can delete
        permission.ensureIsAuthenticated();

        // primary key column(s)
        int threadID = ParamUtil.getParameterInt(request, "thread");

        // now, check the permission
        ThreadBean threadBean = ThreadWebHelper.getThread(threadID);
        int forumID = threadBean.getForumID();
        permission.ensureCanDeletePost(forumID);

        // now check the password
        try {
            String memberPassword  = ParamUtil.getParameterPassword(request, "MemberMatkhau", 3, 0);
            ManagerFactory.getOnlineUserFactory().validatePassword(onlineUser.getMemberName(),
                                                                   memberPassword, false);
        } catch (AuthenticationException e) {
            throw new BadInputException("You have typed the wrong password. Cannot proceed.");
        }

        int destForumID = ParamUtil.getParameterInt(request, "destforum");

        // make sure that we dont move to the same forum (meaningless)
        if (destForumID == forumID) {
            throw new AssertionException("Cannot move thread to the same forum.");
        }

        // now make sure that the dest forum is existed
        ForumCache.getInstance().getBean(destForumID);

        ThreadWebHelper.updateThread_ForumID(threadID, destForumID);
        PostWebHelper.updatePost_ForumID_inThread(threadID, destForumID);
        FavoriteThreadWebHelper.updateFavoriteThread_ForumID_inThread(threadID, destForumID);

        //now, update the statistics in the source forum and dest forum
        updateForumStatistics(forumID);
        updateForumStatistics(destForumID);

        // now update the search index
        // @todo : what if the above methods throw exception, then no thread is deleted from index ???
        PostIndexer.scheduleUpdateThreadTask(threadID);

        request.setAttribute("ForumID", String.valueOf(forumID));
    }

    void prepareList_limit(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException,
        AssertionException, AuthenticationException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        int forumID = ParamUtil.getParameterInt(request, "forum");

        // make sure there is the forum
        // will throw an BadInputException if there is not this forum
        ForumCache.getInstance().getBean(forumID);

        // make sure user can read post in this forum
        permission.ensureCanReadPost(forumID);

        // for sort and order stuff
        String sort  = ParamUtil.getParameter(request, "sort");
        String order = ParamUtil.getParameter(request, "order");
        if (sort.length() == 0) sort = "ThreadLastPostDate";
        if (order.length()== 0) order = "DESC";

        int postsPerPage = onlineUser.getPostsPerPage();
        int offset = 0;
        try {
            offset = ParamUtil.getParameterInt(request, "pager.offset");
        } catch (BadInputException e) {
            // do nothing
        }

        int totalThreads = ThreadWebHelper.getNumberOfThreads_inForum(forumID);
        if (offset > totalThreads) {
            throw new BadInputException("The offset is not allowed to be greater than total rows.");
        }

        Collection beans = ThreadWebHelper.getThreads_inForum_withSortSupport_limit(forumID, offset, postsPerPage, sort, order);
        int totalPosts = PostWebHelper.getNumberOfPosts_inForum(forumID);

        request.setAttribute("ThreadBeans", beans);
        request.setAttribute("TotalThreads", new Integer(totalThreads));
        request.setAttribute("TotalPosts", new Integer(totalPosts));
    }

    void prepareListRecentThreads_limit(HttpServletRequest request)
        throws DatabaseException, AssertionException, BadInputException, AuthenticationException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // for sort and order stuff
        String sort  = ParamUtil.getParameter(request, "sort");
        String order = ParamUtil.getParameter(request, "order");
        if (sort.length() == 0) sort = "ThreadLastPostDate";
        if (order.length()== 0) order = "DESC";

        int postsPerPage = onlineUser.getPostsPerPage();
        int offset = 0;
        try {
            offset = ParamUtil.getParameterInt(request, "pager.offset");
        } catch (BadInputException e) {
            // do nothing
        }

        int totalThreads = ThreadWebHelper.getNumberOfThreads();
        if (offset > totalThreads) {
            throw new BadInputException("The offset is not allowed to be greater than total rows.");
        }

        Collection threadBeans = ThreadWebHelper.getThreads_withSortSupport_limit(offset, postsPerPage, sort, order);

        // now remove thread that current user does not have permission
        for (Iterator iterator = threadBeans.iterator(); iterator.hasNext(); ) {
            ThreadBean threadBean = (ThreadBean)iterator.next();
            if (permission.canReadPost(threadBean.getForumID()) == false) {
                iterator.remove();
            }
        }

        request.setAttribute("ThreadBeans", threadBeans);
        request.setAttribute("TotalThreads", new Integer(totalThreads));
    }

    void prepareList_inFavorite(HttpServletRequest request)
        throws DatabaseException, AssertionException, BadInputException, AuthenticationException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();
        // @todo Check permission here
        //permission.ensureCanReadPost(forumID);

        int memberID = onlineUser.getMemberID();

        Collection threadBeans = ThreadWebHelper.getThreads_inFavorite_inMember(memberID);

        request.setAttribute("ThreadBeans", threadBeans);
    }

    void prepareListRSS(HttpServletRequest request)
        throws DatabaseException, AssertionException, BadInputException, AuthenticationException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // for sort and order stuff
        String sort  = ParamUtil.getParameter(request, "sort");
        String order = ParamUtil.getParameter(request, "order");
        if (sort.length() == 0) sort = "ThreadLastPostDate";
        if (order.length()== 0) order = "DESC";

        int offset = 0;
        try {
            offset = ParamUtil.getParameterInt(request, "offset");
        } catch (BadInputException e) {
            // do nothing
        }

        // now find that user want global/category/forum RSS
        int forumID = -1;
        int categoryID = -1;
        try {
            forumID = ParamUtil.getParameterInt(request, "forum");
        } catch (Exception ex) {
            try {
                //categoryID = ParamUtil.getParameterInt(request, "category");
            } catch (Exception ex1) { }
        }

        Collection threadBeans = null;
        if (forumID > 0) {
            int totalThreads = ThreadWebHelper.getNumberOfThreads_inForum(forumID);
            if (offset > totalThreads) {
                throw new BadInputException("The offset is not allowed to be greater than total rows.");
            }
            if (permission.canReadPost(forumID)) {
                threadBeans = ThreadWebHelper.getThreads_inForum_withSortSupport_limit(forumID, offset, MVNForumConfig.ROWS_IN_RSS, sort, order);
            } else {
                // dont have permission on this forum, just create empty Collection
                threadBeans = new ArrayList();
            }
        } else if (categoryID > 0) {
            //@todo implement later
        } else {
            int totalThreads = ThreadWebHelper.getNumberOfThreads();
            if (offset > totalThreads) {
                throw new BadInputException("The offset is not allowed to be greater than total rows.");
            }
            threadBeans = ThreadWebHelper.getThreads_withSortSupport_limit(offset, MVNForumConfig.ROWS_IN_RSS, sort, order);

            //remove threads that current user dont have permission
            for (Iterator iter = threadBeans.iterator(); iter.hasNext(); ) {
                ThreadBean threadBean = (ThreadBean)iter.next();
                int currentForumID = threadBean.getForumID();
                if (permission.canReadPost(forumID) == false) {
                    iter.remove();
                }
            }
        }

        request.setAttribute("ThreadBeans", threadBeans);
        request.setAttribute("ForumID", new Integer(forumID));
        request.setAttribute("CategoryID", new Integer(categoryID));
    }

}
