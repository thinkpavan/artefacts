/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/MemberWebHandler.java,v 1.28 2003/10/30 19:18:57 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.28 $
 * $Date: 2003/10/30 19:18:57 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 * @author: Igor Manic   imanic@users.sourceforge.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;

import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.security.Encoder;
import net.myvietnam.mvncore.util.*;
import net.myvietnam.mvnplugin.mvnforum.*;
import net.myvietnam.mvnplugin.mvnforum.auth.*;
import net.myvietnam.mvnplugin.mvnforum.db.MemberBean;

class MemberWebHandler {

    private OnlineUserManager onlineUserManager = OnlineUserManager.getInstance();

    MemberWebHandler() {
    }

    void processAdd(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, CreateException, DatabaseException, DuplicateKeyException,
        ForeignKeyNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        Timestamp now = DateUtil.getCurrentGMTTimestamp();

        String memberName           = ParamUtil.getParameterSafe(request, "MemberName", true);// check good name
        /** @todo move to a name filter */
        if ( memberName.equalsIgnoreCase(MVNForumConfig.getDefaultGuestName()) ||
             memberName.equalsIgnoreCase("Guest") ||
             memberName.equalsIgnoreCase("Administrator") ||
             memberName.equalsIgnoreCase("Moderator") ) {
            throw new BadInputException("Cannot register member with a reserved name : " + memberName);
        }
        StringUtil.checkGoodName(memberName);

        String memberPassword1      = ParamUtil.getParameterPassword(request, "MemberMatkhau", 3, 0);
        String memberPassword2      = ParamUtil.getParameterPassword(request, "MemberMatkhauConfirm", 3, 0);
        if (!memberPassword1.equals(memberPassword2)) {
            throw new BadInputException("Password and confirmed password are not the same, please try again.");
        }
        String memberPassword       = Encoder.getMD5_Base64(memberPassword1);

        String memberEmail          = ParamUtil.getParameterEmail(request, "MemberEmail");
        String memberEmailConfirm   = ParamUtil.getParameterEmail(request, "MemberEmailConfirm");
        if (!memberEmail.equals(memberEmailConfirm)) {
            throw new BadInputException("Email and confirmed email are not the same, please try again.");
        }
        String memberFirstEmail     = memberEmail;

        int memberEmailVisible      = 0;
        int memberNameVisible       = 1;
        String memberFirstIP        = request.getRemoteAddr();
        String memberLastIP         = memberFirstIP;
        int memberOption            = 0;//@todo review and support it later
        int memberStatus            = 0;// @todo review and support it later, ex: should it be active or not?
        String memberActivateCode   = "";// @todo review and support it later
        int memberMessageOption     = 0;// @todo review and support it later
        int memberPostsPerPage      = 10; //default for all preregistered users
        Date memberBirthday         = new java.sql.Date(now.getTime());

        ManagerFactory.getMemberDAO().create(memberName, memberPassword, memberFirstEmail,
                                   memberEmail, memberEmailVisible, memberNameVisible,
                                   memberFirstIP, memberLastIP, 0/*memberViewCount*/,
                                   0/*memberPostCount*/, now/*memberCreationDate*/, now/*memberModifiedDate*/,
                                   now/*memberLastLogon*/, memberOption, memberStatus,
                                   memberActivateCode, ""/*memberTempPassword*/, 0/*memberMessageCount*/,
                                   memberMessageOption, memberPostsPerPage, 0/*memberWarnCount*/,
                                   0/*memberVoteCount*/, 0/*memberVoteTotalStars*/, 0/*memberRewardPoints*/,
                                   ""/*memberTitle*/, 0/*memberTimeZone*/, ""/*memberSignature*/,
                                   ""/*memberAvatar*/, ""/*memberSkin*/, ""/*memberLanguage*/,
                                   " "/*memberFirstname*/, " "/*memberLastname*/, 1/*memberGender*/,
                                   memberBirthday, ""/*memberAddress*/, ""/*memberCity*/,
                                   ""/*memberState*/, ""/*memberCountry*/, ""/*memberPhone*/,
                                   ""/*memberMobile*/, ""/*memberFax*/, ""/*memberCareer*/,
                                   ""/*memberHomepage*/, ""/*memberYahoo*/, ""/*memberAol*/,
                                   ""/*memberIcq*/, ""/*memberMsn*/, ""/*memberCoolLink1*/,
                                   ""/*memberCoolLink2*/);

        // Now, create 2 default folders for each member
        int memberID = ManagerFactory.getMemberDAO().getMemberIDFromMemberName(memberName);
        MessageFolderWebHelper.createMessageFolder(MVNForumConstant.MESSAGE_FOLDER_INBOX, memberID, 0, now, now);
        MessageFolderWebHelper.createMessageFolder(MVNForumConstant.MESSAGE_FOLDER_SENT, memberID, 0, now, now);

        /**@todo: check it*/
        //request.setAttribute("MemberID", memberID);
    }

    void processUpdateMemberStatus(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException {

        // primary key column(s)
        int memberID    = ParamUtil.getParameterInt(request, "memberid");

        // column(s) to update
        int memberStatus= ParamUtil.getParameterInt(request, "status");

        // now check if status is in the valid range
        if ( memberStatus != MemberBean.MEMBER_STATUS_ENABLE
          && memberStatus != MemberBean.MEMBER_STATUS_DISABLE) {
            throw new BadInputException("Cannot update member's status to an unknown status = " + memberStatus);
        }

        // This code make sure Admin always has Enable status
        if (memberID == MVNForumConstant.MEMBER_ID_OF_ADMIN) {
            memberStatus = MemberBean.MEMBER_STATUS_ENABLE;
        }
        //IMPORTANT: Guest (id=MEMBER_ID_OF_GUEST) can be disabled by administrator.

        ManagerFactory.getMemberDAO().updateStatus(memberID, // primary key
                               memberStatus);
    }

    void prepareView(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException,
        AssertionException, AuthenticationException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        String strMemberID = ParamUtil.getParameter(request, "memberid", false);
        String strMemberName = ParamUtil.getParameter(request, "member", false);
        String strMemberEmail = ParamUtil.getParameter(request, "memberemail", false);

        int memberID;

        if (strMemberID.length() > 0) {
            memberID = ParamUtil.getParameterInt(request, "memberid");
        } else if (strMemberName.length() > 0){
            /**@todo: improve this for better performance(dont use this method,
             * and write 2 new methods)*/
            StringUtil.checkGoodName(strMemberName);// check for better security
            memberID = ManagerFactory.getMemberDAO().getMemberIDFromMemberName(strMemberName);
        } else if (strMemberEmail.length() > 0){
            String memberEmail = ParamUtil.getParameterEmail(request, "memberemail");// check for better security
            memberID = ManagerFactory.getMemberDAO().getMemberIDFromMemberEmail(memberEmail);
        } else {
            throw new BadInputException("Cannot get the information to view member.");
        }

        MemberBean bean = ManagerFactory.getMemberDAO().getBean_forPublic(memberID);

        request.setAttribute("MemberBean", bean);
    }

    void processUpdateMemberTitle(HttpServletRequest request)
        throws BadInputException, DatabaseException, ObjectNotFoundException,
        AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        // primary key column(s)
        int memberID        = ParamUtil.getParameterInt(request, "MemberID");

        // column(s) to update
        String memberTitle  = ParamUtil.getParameterSafe(request, "MemberTitle", false);

        ManagerFactory.getMemberDAO().updateTitle(memberID, // primary key
                               memberTitle);
    }

    void processResetMemberSignature(HttpServletRequest request)
        throws BadInputException, DatabaseException, ObjectNotFoundException,
        AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        int memberID = ParamUtil.getParameterInt(request, "memberid");
        ManagerFactory.getMemberDAO().updateSignature(memberID, "");

        request.setAttribute("MemberID", new Integer(memberID));
    }

    void processResetMemberAvatar(HttpServletRequest request)
        throws BadInputException, DatabaseException, ObjectNotFoundException,
        AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        int memberID = ParamUtil.getParameterInt(request, "memberid");
        ManagerFactory.getMemberDAO().updateAvatar(memberID, "");

        request.setAttribute("MemberID", new Integer(memberID));
    }

    void processResetMemberActivation(HttpServletRequest request)
        throws BadInputException, DatabaseException, ObjectNotFoundException,
        AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        int memberID = ParamUtil.getParameterInt(request, "memberid");
        ManagerFactory.getMemberDAO().updateActivateCode(memberID, "");

        request.setAttribute("MemberID", new Integer(memberID));
    }

    void processDeleteMember(HttpServletRequest request)
        throws BadInputException, DatabaseException, ObjectNotFoundException,
        AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        int memberID = ParamUtil.getParameterInt(request, "memberid");
        if ((memberID==MVNForumConstant.MEMBER_ID_OF_ADMIN) ||
            (memberID==0) ||
            (memberID==MVNForumConstant.MEMBER_ID_OF_GUEST)) {
            throw new BadInputException("Cannot delete default Admin and Guest users.");
        }
        MemberBean memberBean = ManagerFactory.getMemberDAO().getBean_forPublic(memberID);
        if (memberBean.getMemberPostCount() > 0) {
            throw new BadInputException("Cannot delete member that has posted at least one post.");
        }

        /*@todo: also delete corresponding entries (for this memberid) in tables:
         * membergroup:
         *    add deleteMemberGroup_inMember(memberID) -> calls MemberWebHelper.deleteMemberGroup_inMember(memberID)
         * memberpermission, memberforum
         * messagefolder, watch, favoritethread
         */
        ManagerFactory.getMemberDAO().deleteByPrimaryKey(memberID);
    }

    /**
     * This method supports sorting base on many criteria
     */
    void prepareListMembers_forPublic(HttpServletRequest request)
        throws DatabaseException, AssertionException, BadInputException, AuthenticationException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        // for sort and order stuff
        String sort  = net.myvietnam.mvncore.util.ParamUtil.getParameter(request, "sort");
        String order = net.myvietnam.mvncore.util.ParamUtil.getParameter(request, "order");
        if (sort.length() == 0) sort = "MemberCreationDate";
        if (order.length()== 0) order = "DESC";

        // we continue
        int offset = 0;
        try {
            offset = ParamUtil.getParameterInt(request, "offset");
        } catch (BadInputException e) {
            // do nothing
        }

        int totalMembers = ManagerFactory.getMemberDAO().getNumberOfBeans();
        if (offset > totalMembers) {
            throw new BadInputException("The offset is not allowed to be greater than total members.");
        }

        Collection memberRows = MemberWebHelper.getMembers_withSortSupport_limit(offset, MVNForumConfig.MEMBERS_PER_PAGE, sort, order);
        MyUtil.prepareNavigate(request, offset, memberRows.size(), totalMembers, MVNForumConfig.MEMBERS_PER_PAGE);

        request.setAttribute("MemberBeans", memberRows);
        request.setAttribute("TotalMembers", new Integer(totalMembers));
        request.setAttribute("offset", new Integer(offset));
    }

}
