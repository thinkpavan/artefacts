/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/ForumWebHandler.java,v 1.23 2003/09/14 14:15:38 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.23 $
 * $Date: 2003/09/14 14:15:38 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;

import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.security.Encoder;
import net.myvietnam.mvncore.util.DateUtil;
import net.myvietnam.mvncore.util.ParamUtil;
import net.myvietnam.mvnplugin.mvnforum.ManagerFactory;
import net.myvietnam.mvnplugin.mvnforum.auth.*;
import net.myvietnam.mvnplugin.mvnforum.db.ForumBean;
import net.myvietnam.mvnplugin.mvnforum.search.DeletePostIndexTask;
import net.myvietnam.mvnplugin.mvnforum.search.PostIndexer;

class ForumWebHandler {

    private OnlineUserManager onlineUserManager = OnlineUserManager.getInstance();

    ForumWebHandler() {
    }

    void processAdd(HttpServletRequest request)
        throws BadInputException, CreateException, DatabaseException, DuplicateKeyException,
        ForeignKeyNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAddForum();

        Timestamp now = DateUtil.getCurrentGMTTimestamp();

        int categoryID              = ParamUtil.getParameterInt(request, "CategoryID");
        String forumName            = ParamUtil.getParameterSafe(request, "ForumName", true);
        String forumDesc            = ParamUtil.getParameterSafe(request, "ForumDesc", false);
        int forumType               = 0;//@todo review and support it later
        int forumFormatOption       = 0;//@todo review and support it later
        int forumOption             = 0;//@todo review and support it later
        int forumStatus             = 0;//@todo review and support it later
        int forumModerationMode     = 0;//@todo review and support it later
        String forumPassword        = "";//@todo review and support it later

        ForumWebHelper.createForum(categoryID, ""/*lastPostMemberName*/, forumName,
                                  forumDesc, now/*forumCreationDate*/, now/*forumModifiedDate*/,
                                  now/*forumLastPostDate*/, 0/*forumOrder*/, forumType,
                                  forumFormatOption, forumOption, forumStatus,
                                  forumModerationMode, forumPassword, 0/*forumThreadCount*/,
                                  0/*forumPostCount*/);

        request.setAttribute("ForumName", forumName);
    }

    void prepareDelete(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // primary key column(s)
        int forumID = ParamUtil.getParameterInt(request, "forum");

        permission.ensureCanDeleteForum(forumID);

        ForumBean forumBean = ForumWebHelper.getForum(forumID);
        int numberOfThreads = ThreadWebHelper.getNumberOfThreads_inForum(forumID);
        int numberOfPosts = PostWebHelper.getNumberOfPosts_inForum(forumID);

        request.setAttribute("ForumBean", forumBean);
        request.setAttribute("NumberOfThreads", new Integer(numberOfThreads));
        request.setAttribute("NumberOfPosts", new Integer(numberOfPosts));
    }

    void processDelete(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // primary key column(s)
        int forumID = ParamUtil.getParameterInt(request, "forum");

        // user must have been authenticated before he can delete
        permission.ensureIsAuthenticated();

        permission.ensureCanDeleteForum(forumID);

        // now check the password
        String memberPassword  = ParamUtil.getParameterPassword(request, "MemberMatkhau", 3, 0);
        String encodedPassword = Encoder.getMD5_Base64(memberPassword);
        int memberID = onlineUser.getMemberID();
        if (!encodedPassword.equals(ManagerFactory.getMemberDAO().getPassword(memberID))) {
            throw new BadInputException("You have typed the wrong password. Cannot proceed.");
        }

        // Delete all attachments in this forum,
        // we must call this before any attempt to delete the post/thread/forum
        // That is, the order when delete is VERY IMPORTANT
        AttachmentWebHandler.deleteAttachments_inForum(forumID);

        GroupForumWebHelper.deleteGroupForum_inForum(forumID);
        MemberForumWebHelper.deleteMemberForum_inForum(forumID);

        FavoriteThreadWebHelper.deleteFavoriteThread_inForum(forumID);

        WatchWebHelper.deleteWatch_inForum(forumID);

        PostWebHelper.deletePost_inForum(forumID);
        ThreadWebHelper.deleteThread_inForum(forumID);

        // now delete the forum, note that we delete it after delete all child objects
        ForumWebHelper.deleteForum(forumID);

        // now update the search index
        PostIndexer.scheduleDeletePostTask(forumID, DeletePostIndexTask.OBJECT_TYPE_FORUM);
    }

    void prepareEdit(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // primary key column(s)
        int forumID = ParamUtil.getParameterInt(request, "forum");

        permission.ensureCanEditForum(forumID);

        ForumBean bean = ForumWebHelper.getForum(forumID);

        request.setAttribute("ForumBean", bean);
    }

    void processUpdate(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException, DuplicateKeyException,
        ForeignKeyNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // primary key column(s)
        int forumID                 = ParamUtil.getParameterInt(request, "ForumID");

        permission.ensureCanEditForum(forumID);

        Timestamp now = DateUtil.getCurrentGMTTimestamp();


        // column(s) to update
        int categoryID              = ParamUtil.getParameterInt(request, "CategoryID");
        String forumName            = ParamUtil.getParameterSafe(request, "ForumName", true);
        String forumDesc            = ParamUtil.getParameterSafe(request, "ForumDesc", false);
        Timestamp forumModifiedDate = now;
        int forumOrder              = ParamUtil.getParameterInt(request, "ForumOrder");
        if (forumOrder < 0) {
            throw new BadInputException("ForumOrder cannot be negative");
        }
        int forumType               = 0;//ParamUtil.getParameterInt(request, "ForumType");
        int forumFormatOption       = 0;//ParamUtil.getParameterInt(request, "ForumFormatOption");
        int forumOption             = 0;//ParamUtil.getParameterInt(request, "ForumOption");
        int forumStatus             = 0;//ParamUtil.getParameterInt(request, "ForumStatus");
        int forumModerationMode     = 0;//ParamUtil.getParameterInt(request, "ForumModerationMode");

        ForumWebHelper.updateForum(forumID, // primary key
                                  categoryID, forumName, forumDesc,
                                  forumModifiedDate, forumOrder, forumType,
                                  forumFormatOption, forumOption, forumStatus,
                                  forumModerationMode);
    }

    /**
     * @todo: check permission
     */
    void processUpdateForumOrder(HttpServletRequest request)
        throws BadInputException, DatabaseException, DuplicateKeyException,
        ObjectNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // primary key column(s)
        int forumID                  = ParamUtil.getParameterInt(request, "forum");

        permission.ensureCanEditForum(forumID);

        Timestamp now = DateUtil.getCurrentGMTTimestamp();

        String action                   = ParamUtil.getParameterSafe(request, "action", true);
        if (action.equals("up")) {
            ForumWebHelper.decreaseForumOrder(forumID, now);
        } else if (action.equals("down")) {
            ForumWebHelper.increaseForumOrder(forumID, now);
        } else {
            throw new BadInputException("Cannot update ForumOrder: unknown action: " + action);
        }
    }
}
