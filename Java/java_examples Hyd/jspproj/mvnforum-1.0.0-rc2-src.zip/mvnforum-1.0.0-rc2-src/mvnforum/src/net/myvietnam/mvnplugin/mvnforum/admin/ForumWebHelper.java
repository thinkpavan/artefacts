/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/ForumWebHelper.java,v 1.10 2003/09/17 14:59:09 imanic Exp $
 * $Author: imanic $
 * $Revision: 1.10 $
 * $Date: 2003/09/17 14:59:09 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import java.sql.*;
import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.db.DBUtils;
import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvnplugin.mvnforum.db.ForumBean;

class ForumWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper {

    private static Log log = LogFactory.getLog(ForumWebHelper.class);

    // prevent instantiation and inheritance
    private ForumWebHelper() {
    }

    public static void createForum(int categoryID, String lastPostMemberName, String forumName,
                        String forumDesc, Timestamp forumCreationDate, Timestamp forumModifiedDate,
                        Timestamp forumLastPostDate, int forumOrder, int forumType,
                        int forumFormatOption, int forumOption, int forumStatus,
                        int forumModerationMode, String forumPassword, int forumThreadCount,
                        int forumPostCount)
                        throws CreateException, DatabaseException, DuplicateKeyException, ForeignKeyNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper.create(categoryID, lastPostMemberName, forumName, forumDesc, forumCreationDate, forumModifiedDate, forumLastPostDate, forumOrder, forumType, forumFormatOption, forumOption, forumStatus, forumModerationMode, forumPassword, forumThreadCount, forumPostCount);
    }

    public static void deleteForum(int forumID)
        throws DatabaseException, ObjectNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper.delete(forumID);
    }

    public static void updateForum(int forumID, // primary key
                        int categoryID, String forumName, String forumDesc,
                        Timestamp forumModifiedDate, int forumOrder, int forumType,
                        int forumFormatOption, int forumOption, int forumStatus,
                        int forumModerationMode)
                        throws ObjectNotFoundException, DatabaseException, DuplicateKeyException, ForeignKeyNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper.update(forumID, // primary key
                        categoryID, forumName, forumDesc,
                        forumModifiedDate, forumOrder, forumType,
                        forumFormatOption, forumOption, forumStatus,
                        forumModerationMode);
    }

    public static void updateForumLastPostMemberName(int forumID, // primary key
                        String lastPostMemberName)
                        throws ObjectNotFoundException, DatabaseException, ForeignKeyNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper.updateLastPostMemberName(forumID, // primary key
                        lastPostMemberName);
    }

    public static void updateForumLastPostDate(int forumID, // primary key
                        Timestamp forumLastPostDate)
                        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper.updateLastPostDate(forumID, // primary key
                        forumLastPostDate);
    }

    public static void increaseForumThreadCount(int forumID) // primary key
        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper.increaseThreadCount(forumID); // primary key
    }

    public static void increaseForumPostCount(int forumID) // primary key
        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper.increasePostCount(forumID); // primary key
    }

    public static ForumBean getForum(int forumID)
        throws ObjectNotFoundException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper.getBean(forumID);
    }

    public static Collection getForums()
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper.getBeans();
    }

    public static Collection getForums_inCategory(int categoryID)
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper.getBeans_inCategory(categoryID);
    }

/************************************************
 * Customized methods come below
 ************************************************/


    /**
     * This method should be call only when we can make sure that memberID is in database
     */
    public static void decreaseForumOrder(int forumID, Timestamp forumModifiedDate)
        throws DatabaseException, ObjectNotFoundException {

        Connection connection = null;
        PreparedStatement statement = null;
        String sql = "UPDATE " + TABLE_NAME + " SET ForumOrder = ForumOrder - 1, ForumModifiedDate = ? WHERE ForumID = ?";
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql);
            statement.setTimestamp(1, forumModifiedDate);
            statement.setInt(2, forumID);
            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update the ForumOrder in table Forum. Please contact Web site Administrator.");
            }
            //@todo: coi lai cho nay
            // ATTENTION !!!
            setDirty(true);
        } catch (SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error occured when update table Forum: column name = ForumOrder.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /**
     * This method should be call only when we can make sure that memberID is in database
     */
    public static void increaseForumOrder(int forumID, Timestamp forumModifiedDate)
        throws DatabaseException, ObjectNotFoundException {

        Connection connection = null;
        PreparedStatement statement = null;
        String sql = "UPDATE " + TABLE_NAME + " SET ForumOrder = ForumOrder + 1, ForumModifiedDate = ? WHERE ForumID = ?";
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql);
            statement.setTimestamp(1, forumModifiedDate);
            statement.setInt(2, forumID);
            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update the ForumOrder in table Forum. Please contact Web site Administrator.");
            }
            //@todo: coi lai cho nay
            // ATTENTION !!!
            setDirty(true);
        } catch (SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error occured when update table Forum: column name = ForumOrder.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

}
