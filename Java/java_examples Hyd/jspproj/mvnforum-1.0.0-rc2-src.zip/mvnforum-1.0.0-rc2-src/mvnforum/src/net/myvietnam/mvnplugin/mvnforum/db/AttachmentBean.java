/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/AttachmentBean.java,v 1.5 2003/09/14 14:15:39 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.5 $
 * $Date: 2003/09/14 14:15:39 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Iterator;

import net.myvietnam.mvncore.util.StringUtil;

/*
 * Included columns: AttachID, PostID, MemberID, AttachFilename, AttachFileSize,
 *                   AttachMimeType, AttachDesc, AttachCreationIP, AttachCreationDate, AttachModifiedDate,
 *                   AttachDownloadCount, AttachOption, AttachStatus
 * Excluded columns:
 */
public class AttachmentBean {
    private int attachID;
    private int postID;
    private int memberID;
    private String attachFilename;
    private int attachFileSize;
    private String attachMimeType;
    private String attachDesc;
    private String attachCreationIP;
    private Timestamp attachCreationDate;
    private Timestamp attachModifiedDate;
    private int attachDownloadCount;
    private int attachOption;
    private int attachStatus;

    public int getAttachID() {
        return attachID;
    }
    public void setAttachID(int attachID) {
        this.attachID = attachID;
    }

    public int getPostID() {
        return postID;
    }
    public void setPostID(int postID) {
        this.postID = postID;
    }

    public int getMemberID() {
        return memberID;
    }
    public void setMemberID(int memberID) {
        this.memberID = memberID;
    }

    public String getAttachFilename() {
        return attachFilename;
    }
    public void setAttachFilename(String attachFilename) {
        this.attachFilename = StringUtil.getEmptyStringIfNull(attachFilename);
    }

    public int getAttachFileSize() {
        return attachFileSize;
    }
    public void setAttachFileSize(int attachFileSize) {
        this.attachFileSize = attachFileSize;
    }

    public String getAttachMimeType() {
        return attachMimeType;
    }
    public void setAttachMimeType(String attachMimeType) {
        this.attachMimeType = StringUtil.getEmptyStringIfNull(attachMimeType);
    }

    public String getAttachDesc() {
        return attachDesc;
    }
    public void setAttachDesc(String attachDesc) {
        this.attachDesc = StringUtil.getEmptyStringIfNull(attachDesc);
    }

    public String getAttachCreationIP() {
        return attachCreationIP;
    }
    public void setAttachCreationIP(String attachCreationIP) {
        this.attachCreationIP = StringUtil.getEmptyStringIfNull(attachCreationIP);
    }

    public Timestamp getAttachCreationDate() {
        return attachCreationDate;
    }
    public void setAttachCreationDate(Timestamp attachCreationDate) {
        this.attachCreationDate = attachCreationDate;
    }

    public Timestamp getAttachModifiedDate() {
        return attachModifiedDate;
    }
    public void setAttachModifiedDate(Timestamp attachModifiedDate) {
        this.attachModifiedDate = attachModifiedDate;
    }

    public int getAttachDownloadCount() {
        return attachDownloadCount;
    }
    public void setAttachDownloadCount(int attachDownloadCount) {
        this.attachDownloadCount = attachDownloadCount;
    }

    public int getAttachOption() {
        return attachOption;
    }
    public void setAttachOption(int attachOption) {
        this.attachOption = attachOption;
    }

    public int getAttachStatus() {
        return attachStatus;
    }
    public void setAttachStatus(int attachStatus) {
        this.attachStatus = attachStatus;
    }

    public String getXML() {
        StringBuffer xml = new StringBuffer(1024);
        xml.append("<AttachmentSection>\n");
        xml.append("  <Rows>\n");
        xml.append("    <Row>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>AttachID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(attachID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>PostID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(postID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>AttachFilename</Name>\n");
        xml.append("        <Value>").append(String.valueOf(attachFilename)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>AttachFileSize</Name>\n");
        xml.append("        <Value>").append(String.valueOf(attachFileSize)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>AttachMimeType</Name>\n");
        xml.append("        <Value>").append(String.valueOf(attachMimeType)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>AttachDesc</Name>\n");
        xml.append("        <Value>").append(String.valueOf(attachDesc)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>AttachCreationIP</Name>\n");
        xml.append("        <Value>").append(String.valueOf(attachCreationIP)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>AttachCreationDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(attachCreationDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>AttachModifiedDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(attachModifiedDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>AttachDownloadCount</Name>\n");
        xml.append("        <Value>").append(String.valueOf(attachDownloadCount)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>AttachOption</Name>\n");
        xml.append("        <Value>").append(String.valueOf(attachOption)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>AttachStatus</Name>\n");
        xml.append("        <Value>").append(String.valueOf(attachStatus)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("    </Row>\n");
        xml.append("  </Rows>\n");
        xml.append("</AttachmentSection>\n");
        return xml.toString();
    }

    public static String getXML(Collection objAttachmentBeans) {
        StringBuffer xml = new StringBuffer(1024);
        Iterator iterator = objAttachmentBeans.iterator();
        xml.append("<AttachmentSection>\n");
        xml.append("  <Rows>\n");
        while (iterator.hasNext()) {
            AttachmentBean objAttachmentBean = (AttachmentBean)iterator.next();
            xml.append("    <Row>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>AttachID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objAttachmentBean.attachID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>PostID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objAttachmentBean.postID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objAttachmentBean.memberID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>AttachFilename</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objAttachmentBean.attachFilename)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>AttachFileSize</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objAttachmentBean.attachFileSize)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>AttachMimeType</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objAttachmentBean.attachMimeType)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>AttachDesc</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objAttachmentBean.attachDesc)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>AttachCreationIP</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objAttachmentBean.attachCreationIP)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>AttachCreationDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objAttachmentBean.attachCreationDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>AttachModifiedDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objAttachmentBean.attachModifiedDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>AttachDownloadCount</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objAttachmentBean.attachDownloadCount)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>AttachOption</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objAttachmentBean.attachOption)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>AttachStatus</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objAttachmentBean.attachStatus)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("    </Row>\n");
        }//while
        xml.append("  </Rows>\n");
        xml.append("</AttachmentSection>\n");
        return xml.toString();
    }
} //end of class AttachmentBean
