/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/user/WatchWebHelper.java,v 1.7 2003/09/21 17:06:57 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.7 $
 * $Date: 2003/09/21 17:06:57 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.user;

import java.sql.Timestamp;
import java.util.Collection;

import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvnplugin.mvnforum.db.WatchBean;

class WatchWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper {

    // Prevent instantiation and inheritence
    private WatchWebHelper() {
    }

    public static void createWatch(int memberID, int categoryID, int forumID,
                        int threadID, int watchType, int watchOption,
                        int watchStatus, Timestamp watchCreationDate, Timestamp watchLastSentDate,
                        Timestamp watchEndDate)
                        throws IllegalArgumentException, CreateException, DatabaseException,
                        DuplicateKeyException, ForeignKeyNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.create(memberID, categoryID, forumID, threadID, watchType, watchOption, watchStatus, watchCreationDate, watchLastSentDate, watchEndDate);
    }

    public static void updateWatchLastSentDate_forMember(int memberID, Timestamp watchLastSentDate)
                        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.updateLastSentDate_forMember(memberID, watchLastSentDate);
    }

    public static void deleteWatch(int watchID)
        throws DatabaseException, ObjectNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.delete(watchID);
    }

    public static void deleteWatch_inThread(int threadID)
        throws DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.delete_inThread(threadID);
    }

    public static WatchBean getWatch(int watchID)
        throws ObjectNotFoundException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.getBean(watchID);
    }

    public static Collection getMemberWatchs()
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.getMemberBeans();
    }

    public static Collection getWatchs_forMember(int memberID)
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.getBeans_forMember(memberID);
    }

}
