/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/GroupsWebHelper.java,v 1.7 2003/09/14 14:15:38 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.7 $
 * $Date: 2003/09/14 14:15:38 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import java.sql.Timestamp;
import java.util.Collection;

import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvnplugin.mvnforum.db.GroupsBean;

class GroupsWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.GroupsWebHelper {
    // prevent instantiation and inheritance
    private GroupsWebHelper() {
    }

    public static void createGroups(String groupOwnerName, String groupName,
                        String groupDesc, int groupOption, Timestamp groupCreationDate,
                        Timestamp groupModifiedDate)
                        throws CreateException, DatabaseException, DuplicateKeyException, ForeignKeyNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.GroupsWebHelper.create(groupOwnerName, groupName, groupDesc, groupOption, groupCreationDate, groupModifiedDate);
    }

    public static void deleteGroups(int groupID)
        throws DatabaseException, ObjectNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.GroupsWebHelper.delete(groupID);
    }

    public static void updateGroups(int groupID, // primary key
                        String groupName, String groupDesc, Timestamp groupModifiedDate)
                        throws ObjectNotFoundException, DatabaseException, DuplicateKeyException {
        net.myvietnam.mvnplugin.mvnforum.db.GroupsWebHelper.update(groupID, // primary key
                        groupName, groupDesc, groupModifiedDate);
    }

    public static void updateGroupOwner(int groupID, // primary key
                        String groupOwnerName, Timestamp groupModifiedDate)
                        throws ObjectNotFoundException, DatabaseException, ForeignKeyNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.GroupsWebHelper.updateOwner(groupID, // primary key
                        groupOwnerName, groupModifiedDate);
    }

    public static GroupsBean getGroup(int groupID)
        throws ObjectNotFoundException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.GroupsWebHelper.getBean(groupID);
    }

    public static Collection getGroups()
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.GroupsWebHelper.getBeans();
    }

    public static int getNumberOfGroups()
        throws AssertionException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.GroupsWebHelper.getNumberOfBeans();
    }


}
