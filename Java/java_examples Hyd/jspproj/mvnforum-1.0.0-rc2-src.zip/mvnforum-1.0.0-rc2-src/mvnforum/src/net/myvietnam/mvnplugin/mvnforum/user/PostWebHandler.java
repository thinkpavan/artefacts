/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/user/PostWebHandler.java,v 1.57 2003/10/31 20:19:04 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.57 $
 * $Date: 2003/10/31 20:19:04 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.user;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.filter.DisableHtmlTagFilter;
import net.myvietnam.mvncore.security.Encoder;
import net.myvietnam.mvncore.util.*;
import net.myvietnam.mvnplugin.mvnforum.*;
import net.myvietnam.mvnplugin.mvnforum.auth.*;
import net.myvietnam.mvnplugin.mvnforum.db.*;
import net.myvietnam.mvnplugin.mvnforum.search.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

class PostWebHandler {

    private static Log log = LogFactory.getLog(PostWebHandler.class);

    private OnlineUserManager onlineUserManager = OnlineUserManager.getInstance();

    PostWebHandler() {
    }

    /**
     * This method is for addpost page
     */
    void prepareAdd(HttpServletRequest request)
        throws ObjectNotFoundException, DatabaseException, BadInputException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        if (MVNForumConfig.isGuestUserInDatabase() == false) {
            permission.ensureIsAuthenticated();
        }
        /* was: permission.ensureIsAuthenticated();
         * We don't need previous line, since we want to allow Guests adding
         * posts. Of course, they'll actually be able to post only if admin
         * allows them to, and later in this method we are checking:
         *     permission.ensureCanAddThread(forumID)
         * or
         *     permission.ensureCanAddPost(forumID)
         */

        // we set this action attribute first because the return below can make method return prematurely
        request.setAttribute("action", "addnew");

        int parentPostID    = 0;
        try {
            // neu co parent thi` khong co forum !!!
            parentPostID = ParamUtil.getParameterInt(request, "parent");
        } catch (Exception ex) {
            // do nothing
            // NOTE: we cannot return here since user can have a parameter parent = 0
        }

        if (parentPostID == 0) {// new thread
            int forumID = ParamUtil.getParameterInt(request, "forum");

            permission.ensureCanAddThread(forumID);
        } else {// reply to a post
            // this is a parent post
            PostBean postBean = PostWebHelper.getPost(parentPostID);// can throw DatabaseException

            // check permission
            int forumID  = postBean.getForumID();

            permission.ensureCanAddPost(forumID);

            // now we prepare to list lastest post in the thread
            int threadID = postBean.getThreadID();
            Collection postBeans = PostWebHelper.getLastBeans_inThread_limit(threadID, MVNForumConfig.ROWS_IN_LAST_REPLIES);

            request.setAttribute("ParentPostBean", postBean);
            request.setAttribute("PostBeans", postBeans);
        }

        boolean isPreviewing = ParamUtil.getParameterBoolean(request, "preview");
        if (isPreviewing) {
            // Check if user enter some text or not
            ParamUtil.getParameter(request, "PostTopic", true);
            ParamUtil.getParameter(request, "message", true);// use message instead of MessageBody

            MemberBean memberBean = ManagerFactory.getMemberDAO().getBean_forPublic(onlineUser.getMemberID());
            request.setAttribute("MemberBean", memberBean);
        }
    }

    void processAdd(HttpServletRequest request)
        throws ObjectNotFoundException, AssertionException, DatabaseException,
               CreateException, BadInputException, ForeignKeyNotFoundException, AuthenticationException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        /* was: permission.ensureIsAuthenticated();
         * We don't need previous line, since we want to allow Guests adding
         * posts. Of course, they'll actually be able to post only if admin
         * allows them to, and later in this method we are checking:
         *     permission.ensureCanAddThread(forumID)
         * or
         *     permission.ensureCanAddPost(forumID)
         */

        int memberID        = onlineUser.getMemberID();
        String memberName   = onlineUser.getMemberName();

        Timestamp now       = DateUtil.getCurrentGMTTimestamp();

        int parentPostID    = ParamUtil.getParameterInt(request, "parent");
        boolean attachMore  = ParamUtil.getParameterBoolean(request, "AttachMore");
        boolean addFavoriteThread = ParamUtil.getParameterBoolean(request, "AddFavoriteParentThread");
        boolean addWatchThread    = ParamUtil.getParameterBoolean(request, "AddWatchParentThread");

        String postTopic = ParamUtil.getParameter(request, "PostTopic", true);
        postTopic = DisableHtmlTagFilter.filter(postTopic);// always disable HTML

        String postBody  = ParamUtil.getParameter(request, "message", true);// use message instead of MessageBody
        postBody = DisableHtmlTagFilter.filter(postBody);// always disable HTML

        String postIcon = ParamUtil.getParameter(request, "PostIcon");
        postIcon = DisableHtmlTagFilter.filter(postIcon);// always disable HTML

        int forumID = 0;
        int threadID= 0;
        if (parentPostID == 0) {// new thread
            forumID         = ParamUtil.getParameterInt(request, "forum");

            // check permission
            permission.ensureCanAddThread(forumID);

            String lastPostMemberName   = memberName;
            int threadType              = 0;//@todo review and support it later
            int threadOption            = 0;//@todo review and support it later
            int threadStatus            = 0;//@todo review and support it later
            int threadHasPoll           = 0;//@todo review and support it later
            int threadDuration          = 0;//@todo review and support it later
            threadID = ThreadWebHelper.createThread(forumID, memberName, lastPostMemberName,
                                   postTopic, postBody, 0/*threadVoteCount*/,
                                   0/*threadVoteTotalStars*/, now/*threadCreationDate*/, now/*threadLastPostDate*/,
                                   threadType, threadOption, threadStatus,
                                   threadHasPoll, 0/*threadViewCount*/, 0/*threadReplyCount*/,
                                   postIcon, threadDuration);
        } else {// reply to a post
            PostBean parentPostBean = PostWebHelper.getPost(parentPostID);
            forumID = parentPostBean.getForumID();
            threadID = parentPostBean.getThreadID();

            // check permission
            permission.ensureCanAddPost(forumID);
        }

        //Timestamp postLastEditDate = now;
        String postCreationIP       = request.getRemoteAddr();
        String postLastEditIP       = "";// should we init it to postCreationIP ???
        int postFormatOption        = 0;
        int postOption              = 0;
        int postStatus              = 0;
        int postAttachCount         = 0;

        int postID = PostWebHelper.createPost(parentPostID, forumID, threadID,
                             memberID, memberName, ""/*lastEditMemberName*/,
                             postTopic, postBody, now/*postCreationDate*/,
                             now/*postLastEditDate*/, postCreationIP, postLastEditIP,
                             0/*postEditCount*/, postFormatOption, postOption,
                             postStatus, postIcon, postAttachCount);

        ManagerFactory.getMemberDAO().increasePostCount(memberID);
        ForumWebHelper.increaseForumPostCount(forumID);
        if (parentPostID == 0) {//new thread, so we increase the ForumThreadCount
            ForumWebHelper.increaseForumThreadCount(forumID);
        }
        if (parentPostID != 0) {//reply to a post in thread, so we increase the ThreadReplyCount
            ThreadWebHelper.increaseThreadReplyCount(threadID);
        }
        ThreadWebHelper.updateThreadLastPostMemberName(threadID, memberName);
        ThreadWebHelper.updateThreadLastPostDate(threadID, now);
        ForumWebHelper.updateForumLastPostMemberName(forumID, memberName);
        ForumWebHelper.updateForumLastPostDate(forumID, now);
        /** @todo Update PostEditLog table here */

        //add favorite thread if user checked it
        if (addFavoriteThread) {
            permission.ensureIsAuthenticated();
            //@todo: add checking of MVNForumConfig.getEnableFavoriteThread()
            // check to make sure that this user doesnt exceed his favorite max
            int currentFavoriteCount = FavoriteThreadWebHelper.getNumberOfFavoriteThreads_inMember(memberID);
            int maxFavorites = MVNForumConfig.getMaxFavoriteThread();
            if (currentFavoriteCount > maxFavorites) {
                //@todo: choose a better exception class
                throw new BadInputException("You have already use all your favorite quota (" + maxFavorites + ").");
            }

            Timestamp favoriteCreationDate  = now;
            int favoriteType                = 0;//@todo implement it later
            int favoriteOption              = 0;//@todo implement it later
            int favoriteStatus              = 0;//@todo implement it later

            // now check permission the this user have the readPost permission
            permission.ensureCanReadPost(forumID);

            // has the permission now, then insert to database
            try {
                FavoriteThreadWebHelper.createFavoriteThread(memberID, threadID, forumID,
                                                   favoriteCreationDate, favoriteType, favoriteOption,
                                                   favoriteStatus);
            } catch (DuplicateKeyException ex) {
                // already add favorite thread, just ignore
            }
        }

        //add watch if user checked it
        if (addWatchThread) {
            permission.ensureIsAuthenticated();
            permission.ensureIsActivated();
            if (MVNForumConfig.getEnableWatch() == false) {
                throw new AssertionException("Cannot add Watch because Watch feature is disabled.");
            }

            int watchType               = 0;//ParamUtil.getParameterInt(request, "WatchType");
            int watchOption             = 0;//ParamUtil.getParameterInt(request, "WatchOption");
            int watchStatus             = 0;//ParamUtil.getParameterInt(request, "WatchStatus");
            Timestamp watchCreationDate = now;
            Timestamp watchLastSentDate = now;
            Timestamp watchEndDate      = now;// @todo: check it !!!

            try {
                WatchWebHelper.createWatch(memberID, 0/*watchCategoryID*/, 0/*watchForumID*/,
                                           threadID, watchType, watchOption,
                                           watchStatus, watchCreationDate, watchLastSentDate,
                                           watchEndDate);
            } catch (DuplicateKeyException ex) {
                // User try to create a duplicate watch, just ignore
            }
        }

        // now, update the Search Index
        //@todo check the performance here
        PostBean justAddedPostBean = PostWebHelper.getPost(postID);
        PostIndexer.scheduleAddPostTask(justAddedPostBean);

        request.setAttribute("ForumID", String.valueOf(forumID));
        request.setAttribute("ThreadID", String.valueOf(threadID));
        request.setAttribute("PostID", String.valueOf(postID));
        request.setAttribute("AttachMore", new Boolean(attachMore));
        request.setAttribute("AddFavoriteParentThread", new Boolean(addFavoriteThread));
        request.setAttribute("AddWatchParentThread", new Boolean(addWatchThread));
        /**@todo: review, this variable is still reserved*/
        //request.setAttribute("ParentPostID", String.valueOf(parentPostID));
    }

    void preparePrintPost(HttpServletRequest request)
        throws ObjectNotFoundException, DatabaseException, BadInputException,
        AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        int postID = ParamUtil.getParameterInt(request, "post");

        PostBean postBean = PostWebHelper.getPost(postID);
        int threadID = postBean.getThreadID();
        int forumID = postBean.getForumID();

        permission.ensureCanReadPost(forumID);

        // to show the thread topic
        ThreadBean threadBean = ThreadWebHelper.getThread(threadID);

        MemberBean memberBean = null;
        if (postBean.getMemberID()>0) {
            memberBean = ManagerFactory.getMemberDAO().getBean_forPublic(postBean.getMemberID());
        }
        postBean.setMemberBean(memberBean);

        int postAttachCount = postBean.getPostAttachCount();
        if ( (postAttachCount > 0) && MVNForumConfig.getEnableAttachment()) {
            Collection attachBeans = AttachmentWebHelper.getAttachments_inPost(postID);
            int actualAttachCount = attachBeans.size();

            // now check if the attachCount in talbe Post equals to the actual attachCount in table Attachment
            if (postAttachCount != actualAttachCount) {
                if (actualAttachCount != AttachmentWebHelper.getNumberOfAttachments_inPost(postID)) {
                    throw new AssertionException("AssertionException: Serious error: cannot process Attachment Count in table Attachment");
                }
                log.warn("The attachment count in table Post and Attachment are not synchronized. In table Post = " + postAttachCount + " and in table Attachment = " + actualAttachCount + ". Synchronize to " + actualAttachCount);
                PostWebHelper.updatePostAttachCount(postID, actualAttachCount);
            }
            if (actualAttachCount > 0) {
                postBean.setAttachmentBeans(attachBeans);
            }
        }

        request.setAttribute("PostBean", postBean);
        request.setAttribute("ThreadBean", threadBean);
    }

    /**
     * then, it will be forward to addpost.jsp
     * NOTE: This method MUST NOT use parameter MessageParent (need some process to figure out)
     */
    void prepareEdit(HttpServletRequest request)
        throws ObjectNotFoundException, DatabaseException, BadInputException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // a guest CANNOT edit a post, because it need Authenticated Permission
        permission.ensureIsAuthenticated();

        int postID = ParamUtil.getParameterInt(request, "post");
        PostBean postBean = PostWebHelper.getPost(postID);
        int forumID = postBean.getForumID();

        int logonMemberID   = onlineUser.getMemberID();
        int authorID        = postBean.getMemberID();

        // check constraint
        if (permission.canEditPost(forumID)) {
            // have permission, just do nothing, that is dont check the max day contraint
        } else if (logonMemberID == authorID) {// same author
            // check date here, usually must not older than 7 days
            Timestamp now = DateUtil.getCurrentGMTTimestamp();
            Timestamp postDate = postBean.getPostCreationDate();
            int maxDays = MVNForumConfig.MAX_EDIT_DAYS;
            if ( (now.getTime() - postDate.getTime()) > (DateUtil.DAY * maxDays) ) {
                /** @todo choose a better Exception here */
                throw new BadInputException("You cannot edit a post which is older than " + maxDays + " days.");
            }
            /** @todo check status of this post */
            /*
            if (postBean.getPostStatus() == ?) {
                throw new BadInputException("Cannot edit message which is disable.");
            }*/
        } else {//not an author, so this user must have Edit Permission
            permission.ensureCanEditPost(forumID);// this method ALWAYS throws AuthenticationException
        }

        request.setAttribute("PostToEdit", postBean);
        request.setAttribute("action", "update");

        boolean isPreviewing = ParamUtil.getParameterBoolean(request, "preview");
        if (isPreviewing) {
            // Check if user enter some text or not
            ParamUtil.getParameter(request, "PostTopic", true);
            ParamUtil.getParameter(request, "message", true);// use message instead of MessageBody

            MemberBean memberBean = ManagerFactory.getMemberDAO().getBean_forPublic(onlineUser.getMemberID());
            request.setAttribute("MemberBean", memberBean);
        }
    }

    /**
     * @todo: log the modification
     * @todo: check the comment below, it's obsolete now :(
     * @todo: check coi messageTopic co the la optional khi reply
     * NOTE: This method MUST NOT get parameter MessageParent (need some process to figure out)
     *      so it needs to call setAttribute with messageParent for page updatepostsuccess.jsp
     */
    void processUpdate(HttpServletRequest request)
        throws ObjectNotFoundException, BadInputException, DatabaseException,
               ForeignKeyNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // a guest CANNOT edit a post, because it need Authenticated Permission
        permission.ensureIsAuthenticated();

        Timestamp now   = DateUtil.getCurrentGMTTimestamp();

        int postID      = ParamUtil.getParameterInt(request, "post");// dont change

        // check constraint
        PostBean postBean = PostWebHelper.getPost(postID);
        int forumID = postBean.getForumID();

        String postTopic  = ParamUtil.getParameter(request, "PostTopic", true);
        postTopic = DisableHtmlTagFilter.filter(postTopic);// always disable HTML

        String postBody   = ParamUtil.getParameter(request, "message", true);// use message instead of PostBody
        postBody = DisableHtmlTagFilter.filter(postBody);// always disable HTML

        int    logonMemberID    = onlineUser.getMemberID();
        String logonMemberName  = onlineUser.getMemberName();
        int    authorID         = postBean.getMemberID();

        // check constraint
        if (permission.canEditPost(forumID)) {
            // have permission, just do nothing, that is dont check the max day contraint
        } else if (logonMemberID == authorID) {// same author
            // check date here, usually must not older than 7 days
            Timestamp postDate = postBean.getPostCreationDate();
            /** @todo config maxDays */
            int maxDays = 7;
            if ( (now.getTime() - postDate.getTime()) > (DateUtil.DAY * maxDays) ) {
                /** @todo choose a better Exception here */
                throw new BadInputException("You cannot edit a post which is older than " + maxDays + " days.");
            }
            /** @todo check status of this post */
            /*
            if (postBean.getPostStatus() == ?) {
                throw new BadInputException("Cannot edit a post which is disable.");
            }*/
        } else {//not an author, so this user must have Edit Permission
            permission.ensureCanEditPost(forumID);// this method ALWAYS throws AuthenticationException
        }

        String postLastEditIP       = request.getRemoteAddr();
        int postFormatOption        = 0;//@todo review and support it later
        int postOption              = 0;//@todo review and support it later
        int postStatus              = 0;//@todo review and support it later
        String postIcon = ParamUtil.getParameter(request, "PostIcon");
        postIcon = DisableHtmlTagFilter.filter(postIcon);// always disable HTML

        /*
         * Note that although the 2 methods below can be combined,
         * I dont do that for clearness
         */
        /** @todo log the modification here */
        PostWebHelper.updatePost(postID, // primary key
                             logonMemberName, postTopic, postBody,
                             now/*postLastEditDate*/, postLastEditIP, postFormatOption,
                             postOption, postStatus, postIcon);
        PostWebHelper.increaseEditCount(postID);

        int threadID = postBean.getThreadID();
        if (postBean.getParentPostID() == 0) {//edit a top post ( thread )
            ThreadWebHelper.updateThreadTopic_Body(threadID, postTopic, postBody);
        }

        request.setAttribute("ForumID", String.valueOf(forumID));
        request.setAttribute("ThreadID", String.valueOf(threadID));

        // now update the search index
        //@todo : modify for better performance here
        PostIndexer.scheduleUpdatePostTask(PostWebHelper.getPost(postID));
    }

    void prepareOwnDelete(HttpServletRequest request)
        throws ObjectNotFoundException, BadInputException, DatabaseException, AuthenticationException, AssertionException {

        //We will check authentication here. if User has Admin's right or he is an author of post
        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        //onlineUser.getMemberName();
        MVNForumPermission permission = onlineUser.getPermission();

        // a guest CANNOT edit a post, because it need Authenticated Permission
        permission.ensureIsAuthenticated();

        // primary key column(s)
        int postID = ParamUtil.getParameterInt(request, "post");

        PostBean postBean = PostWebHelper.getPost(postID);
        if (postBean.getParentPostID() == 0) {
            throw new BadInputException("Cannot delete a root post. Use delete thread instead.");
        }

        // now, check the permission
        //permission.ensureCanDeletePost(postBean.getForumID());

        request.setAttribute("PostBean", postBean);
    }

    void processOwnDelete(HttpServletRequest request)
        throws BadInputException, DatabaseException, AuthenticationException, AssertionException, ObjectNotFoundException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // user must have been authenticated before he can delete
        permission.ensureIsAuthenticated();

        // primary key column(s)
        int postID = ParamUtil.getParameterInt(request, "post");

        PostBean postBean = PostWebHelper.getPost(postID);
        int parentPostID = postBean.getParentPostID();
        if (parentPostID == 0) {
            throw new BadInputException("Cannot delete a root post. Use delete thread instead.");
        }
        // Check to make sure that this post belong to login user
        if ( !onlineUser.getMemberName().equals(postBean.getMemberName())) {
            throw new BadInputException("Cannot delete a post. You are not an author of it");
        }

        // now check the password.
        try {
        String memberPassword  = ParamUtil.getParameterPassword(request, "MemberMatkhau", 3, 0);
            ManagerFactory.getOnlineUserFactory().validatePassword(onlineUser.getMemberName(), //Co van de cho na`y
                                                                   memberPassword, false);
        } catch (AuthenticationException e) {
            throw new BadInputException("You have typed the wrong password. Cannot proceed.");
        }

        int threadID = postBean.getThreadID();
        Collection postBeans = PostWebHelper.getAllPosts(threadID);

        //Check to make sure that "no reply" for this post
        boolean bloFind = false;
        for (java.util.Iterator ite = postBeans.iterator(); ite.hasNext(); ) {
            PostBean tPostBean = (PostBean) ite.next();
            if (tPostBean.getParentPostID() == postBean.getPostID()) {
                bloFind = true;
            }
        }
        if (bloFind) {
            throw new BadInputException("Cannot delete a post has reply");
        }

        // now, check the permission
        //permission.ensureCanDeletePost(postBean.getForumID());

        // Delete all attachments in this post,
        // we must call this before any attempt to delete the post
        AttachmentWebHandler.deleteAttachments_inPost(postID);

        // now delete the post, note that we delete it after delete all child objects (attachment)
        PostWebHelper.deletePost(postID);

        try {
            PostWebHelper.updateParentPostID(postID, parentPostID);
        } catch (ObjectNotFoundException ex) {}

        // now update the search index
        PostIndexer.scheduleDeletePostTask(postID, DeletePostIndexTask.OBJECT_TYPE_POST);

        int forumID  = postBean.getForumID();
        //int threadID = postBean.getThreadID();

        //now, update the statistics in the forum
        int forumThreadCount = ThreadWebHelper.getNumberOfThreads_inForum(forumID);
        int forumPostCount = PostWebHelper.getNumberOfPosts_inForum(forumID);
        ForumWebHelper.updateForumStatistics(forumID, forumThreadCount, forumPostCount);

        Collection lastPostInForum = PostWebHelper.getLastBeans_inForum_limit(forumID, 1);
        Iterator iteratorInForum = lastPostInForum.iterator();
        if (iteratorInForum.hasNext()) {
            PostBean lastPostBeanInForum = (PostBean)iteratorInForum.next();
            String lastPostMemberName = lastPostBeanInForum.getMemberName();
            Timestamp forumLastPostDate = lastPostBeanInForum.getPostCreationDate();
            try {
                ForumWebHelper.updateForumLastPostMemberName(forumID, lastPostMemberName);
            } catch (ForeignKeyNotFoundException ex) {
                throw new AssertionException("Assertion: cannot update LastPostMemberName of forum in ThreadWebHandler.processDelete");
            }
            ForumWebHelper.updateForumLastPostDate(forumID, forumLastPostDate);
        }

        //now, update the statistics in the thread
        int threadReplyCount = PostWebHelper.getNumberOfPosts_inThread(threadID) - 1;
        ThreadWebHelper.updateThreadReplyCount(threadID, threadReplyCount);

        Collection lastPostInThread = PostWebHelper.getLastBeans_inThread_limit(threadID, 1);
        Iterator iteratorInThread = lastPostInThread.iterator();
        if (iteratorInThread.hasNext()) {
            PostBean lastPostBeanInThread = (PostBean)iteratorInThread.next();
            String lastPostMemberName = lastPostBeanInThread.getMemberName();
            Timestamp threadLastPostDate = lastPostBeanInThread.getPostCreationDate();
            try {
                ThreadWebHelper.updateThreadLastPostMemberName(threadID, lastPostMemberName);
            } catch (ForeignKeyNotFoundException ex) {
                throw new AssertionException("Assertion: cannot update LastPostMemberName of thread in ThreadWebHandler.processDelete");
            }
            ThreadWebHelper.updateThreadLastPostDate(threadID, threadLastPostDate);
        }

        request.setAttribute("ForumID", String.valueOf(forumID));
        request.setAttribute("ThreadID", String.valueOf(threadID));
    }

    void prepareDelete(HttpServletRequest request)
        throws ObjectNotFoundException, BadInputException, DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // primary key column(s)
        int postID = ParamUtil.getParameterInt(request, "post");

        PostBean postBean = PostWebHelper.getPost(postID);
        if (postBean.getParentPostID() == 0) {
            throw new BadInputException("Cannot delete a root post. Use delete thread instead.");
        }

        // now, check the permission
        permission.ensureCanDeletePost(postBean.getForumID());

        request.setAttribute("PostBean", postBean);
    }

    void processDelete(HttpServletRequest request)
        throws BadInputException, DatabaseException, AuthenticationException, AssertionException, ObjectNotFoundException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // user must have been authenticated before he can delete
        permission.ensureIsAuthenticated();

        // primary key column(s)
        int postID = ParamUtil.getParameterInt(request, "post");

        PostBean postBean = PostWebHelper.getPost(postID);
        int parentPostID = postBean.getParentPostID();
        if (parentPostID == 0) {
            throw new BadInputException("Cannot delete a root post. Use delete thread instead.");
        }

        // now, check the permission
        permission.ensureCanDeletePost(postBean.getForumID());

        // now check the password
        try {
            String memberPassword = ParamUtil.getParameterPassword(request, "MemberMatkhau", 3, 0);
            ManagerFactory.getOnlineUserFactory().validatePassword(onlineUser.getMemberName(),
                                                                   memberPassword, false);
        } catch (AuthenticationException e) {
            throw new BadInputException("You have typed the wrong password. Cannot proceed.");
        }

        // Delete all attachments in this post,
        // we must call this before any attempt to delete the post
        AttachmentWebHandler.deleteAttachments_inPost(postID);

        // now delete the post, note that we delete it after delete all child objects (attachment)
        PostWebHelper.deletePost(postID);

        try {
            PostWebHelper.updateParentPostID(postID, parentPostID);
        } catch (ObjectNotFoundException ex) {}

        // now update the search index
        PostIndexer.scheduleDeletePostTask(postID, DeletePostIndexTask.OBJECT_TYPE_POST);

        int forumID  = postBean.getForumID();
        int threadID = postBean.getThreadID();

        //now, update the statistics in the forum
        int forumThreadCount = ThreadWebHelper.getNumberOfThreads_inForum(forumID);
        int forumPostCount = PostWebHelper.getNumberOfPosts_inForum(forumID);
        ForumWebHelper.updateForumStatistics(forumID, forumThreadCount, forumPostCount);

        Collection lastPostInForum = PostWebHelper.getLastBeans_inForum_limit(forumID, 1);
        Iterator iteratorInForum = lastPostInForum.iterator();
        if (iteratorInForum.hasNext()) {
            PostBean lastPostBeanInForum = (PostBean)iteratorInForum.next();
            String lastPostMemberName = lastPostBeanInForum.getMemberName();
            Timestamp forumLastPostDate = lastPostBeanInForum.getPostCreationDate();
            try {
                ForumWebHelper.updateForumLastPostMemberName(forumID, lastPostMemberName);
            } catch (ForeignKeyNotFoundException ex) {
                throw new AssertionException("Assertion: cannot update LastPostMemberName of forum in ThreadWebHandler.processDelete");
            }
            ForumWebHelper.updateForumLastPostDate(forumID, forumLastPostDate);
        }

        //now, update the statistics in the thread
        int threadReplyCount = PostWebHelper.getNumberOfPosts_inThread(threadID) - 1;
        ThreadWebHelper.updateThreadReplyCount(threadID, threadReplyCount);

        Collection lastPostInThread = PostWebHelper.getLastBeans_inThread_limit(threadID, 1);
        Iterator iteratorInThread = lastPostInThread.iterator();
        if (iteratorInThread.hasNext()) {
            PostBean lastPostBeanInThread = (PostBean)iteratorInThread.next();
            String lastPostMemberName = lastPostBeanInThread.getMemberName();
            Timestamp threadLastPostDate = lastPostBeanInThread.getPostCreationDate();
            try {
                ThreadWebHelper.updateThreadLastPostMemberName(threadID, lastPostMemberName);
            } catch (ForeignKeyNotFoundException ex) {
                throw new AssertionException("Assertion: cannot update LastPostMemberName of thread in ThreadWebHandler.processDelete");
            }
            ThreadWebHelper.updateThreadLastPostDate(threadID, threadLastPostDate);
        }

        request.setAttribute("ForumID", String.valueOf(forumID));
        request.setAttribute("ThreadID", String.valueOf(threadID));
    }

    /**
     * This method is for viewthread page
     */
    /**@todo: change this method's name*/
    void listPosts_inThread(HttpServletRequest request)
        throws DatabaseException, ObjectNotFoundException, BadInputException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        int threadID = ParamUtil.getParameterInt(request, "thread");
        boolean printAll = ParamUtil.getParameterBoolean(request, "printall");
        ThreadBean threadBean = ThreadWebHelper.getThread(threadID);
        int forumID = threadBean.getForumID();
        int numberOfPosts = PostWebHelper.getNumberOfPosts_inThread(threadID);

        permission.ensureCanReadPost(forumID);

        int postsPerPage = onlineUser.getPostsPerPage();
        int offset = 0;
        boolean lastPage = ParamUtil.getParameterBoolean(request, "lastpage");
        if (lastPage) {
            // note that in the worst case, numberOfPosts could equals 0 (bad database)
            int pageCount = numberOfPosts / postsPerPage;
            int odd = numberOfPosts % postsPerPage;
            if (odd > 0) {
                pageCount++;
            }
            if (pageCount < 1) {
                pageCount = 1;// at least, there is one page
            }
            offset = (pageCount-1) * postsPerPage;
        } else {
            try {
                offset = ParamUtil.getParameterInt(request, "pager.offset");
            } catch (BadInputException e) {
                // do nothing
            }
        }
        if (printAll) {
            postsPerPage = 10000; //We assume that big number
            offset = 0;
        }

        Collection postBeans = PostWebHelper.getPosts_inThread_limit(threadID, offset, postsPerPage);

        Iterator iterator = postBeans.iterator();
        while(iterator.hasNext()) {
            PostBean postBean = (PostBean)iterator.next();
            // very slow here
            /** @todo find a better solution */
            MemberBean memberBean = null;
            if (postBean.getMemberID()>0) {
                memberBean = ManagerFactory.getMemberDAO().getBean_forPublic(postBean.getMemberID());
            }
            postBean.setMemberBean(memberBean);

            int postAttachCount = postBean.getPostAttachCount();
            if ( (postAttachCount > 0) && MVNForumConfig.getEnableAttachment()) {
                int postID = postBean.getPostID();
                Collection attachBeans = AttachmentWebHelper.getAttachments_inPost(postID);
                int actualAttachCount = attachBeans.size();

                // now check if the attachCount in talbe Post equals to the actual attachCount in table Attachment
                if (postAttachCount != actualAttachCount) {
                    if (actualAttachCount != AttachmentWebHelper.getNumberOfAttachments_inPost(postID)) {
                        throw new AssertionException("AssertionException: Serious error: cannot process Attachment Count in table Attachment");
                    }
                    log.warn("The attachment count in table Post and Attachment are not synchronized. In table Post = " + postAttachCount + " and in table Attachment = " + actualAttachCount + ". Synchronize to " + actualAttachCount);
                    PostWebHelper.updatePostAttachCount(postID, actualAttachCount);
                }
                if (actualAttachCount > 0) {
                    postBean.setAttachmentBeans(attachBeans);
                }
            }
        }

        int previousTopic = ThreadWebHelper.getPreviousThread(forumID, threadID);// can throw AssertionException
        int nextTopic     = ThreadWebHelper.getNextThread(forumID, threadID);// can throw AssertionException

        ThreadWebHelper.increaseViewCount(threadID);

        request.setAttribute("ThreadBean", threadBean);
        request.setAttribute("PostBeans", postBeans);
        request.setAttribute("NumberOfPosts", new Integer(numberOfPosts));
        request.setAttribute("PreviousTopic", new Integer(previousTopic));
        request.setAttribute("NextTopic", new Integer(nextTopic));
    }

    void processSearch(HttpServletRequest request)
        throws BadInputException, IOException, DatabaseException, ObjectNotFoundException,
        AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        String memberName = ParamUtil.getParameter(request, "member");
        StringUtil.checkGoodName(memberName);

        // if user does not enter MemberName, then user must enter "key"
        boolean requireKey = memberName.length() == 0;
        String key = ParamUtil.getParameter(request, "key", requireKey);

        int forumID       = ParamUtil.getParameterInt(request, "forum", 0);
        int rowsToReturn  = ParamUtil.getParameterInt(request, "rowsToReturn", 20);
        int offset        = ParamUtil.getParameterInt(request, "offset", 0);

        // offset should be even when divide with rowsToReturn
        offset = (offset/rowsToReturn)*rowsToReturn;
        if (offset < 0) {
            throw new BadInputException("Cannot search with offset < 0");
        }

        SearchQuery query = new SearchQuery();

        if (key.length() > 0) {
            query.setSearchString(key);
        }
        if (memberName.length() > 0) {
            int memberID = ManagerFactory.getMemberDAO().getMemberIDFromMemberName(memberName);
            query.setMemberId(memberID);
        }
        if (forumID > 0) {
            query.setForumId(forumID);
        } else if (forumID < 0) {
            // choose to search in a category
            query.setForumId(forumID);
        } else {
            // forumID equals to 0, it mean global searching
            // just do nothing, lucene will search all forums (globally)
        }

        query.searchDocuments(offset, rowsToReturn);
        int hitCount = query.getHitCount();
        Collection result = query.getPostResult();

        //remove postd that current user dont have permission
        for (Iterator iter = result.iterator(); iter.hasNext(); ) {
            PostBean postBean = (PostBean)iter.next();
            int currentForumID = postBean.getForumID();
            if (permission.canReadPost(forumID) == false) {
                iter.remove();
            }
        }

        if (offset > hitCount) {
            throw new BadInputException("Cannot search with offset > total posts");
        }

        request.setAttribute("key", Encoder.encodeURL(key));
        request.setAttribute("member", memberName);
        request.setAttribute("forum", new Integer(forumID));
        request.setAttribute("offset", new Integer(offset));
        request.setAttribute("rows", new Integer(rowsToReturn));
        request.setAttribute("TotalPosts", new Integer(hitCount));
        request.setAttribute("PostBeans", result);
    }
}
