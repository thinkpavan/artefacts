/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/AdminModuleProcessor.java,v 1.40 2003/10/30 12:48:12 imanic Exp $
 * $Author: imanic $
 * $Revision: 1.40 $
 * $Date: 2003/10/30 12:48:12 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.util.ParamUtil;
import net.myvietnam.mvncore.util.StringUtil;
import net.myvietnam.mvnplugin.mvnforum.URLMap;
import net.myvietnam.mvnplugin.mvnforum.auth.*;

class AdminModuleProcessor {

    private static Log log = LogFactory.getLog(AdminModuleProcessor.class);

    private final String ORIGINAL_REQUEST = "mvnforum.admin.OriginalRequest";

    private HttpServlet     adminServlet    = null;
    //private ServletContext  servletContext  = null;

    private AdminModuleURLMapHandler    urlMapHandler               = new AdminModuleURLMapHandler();
    private ForumWebHandler             forumWebHandler             = new ForumWebHandler();
    private CategoryWebHandler          categoryWebHandler          = new CategoryWebHandler();
    private MemberWebHandler            memberWebHandler            = new MemberWebHandler();
    private WatchWebHandler             watchWebHandler             = new WatchWebHandler();
    private GroupsWebHandler            groupsWebHandler            = new GroupsWebHandler();
    private MemberGroupWebHandler       memberGroupWebHandler       = new MemberGroupWebHandler();
    private GroupPermissionWebHandler   groupPermissionWebHandler   = new GroupPermissionWebHandler();
    private GroupForumWebHandler        groupForumWebHandler        = new GroupForumWebHandler();
    private RankWebHandler              rankWebHandler              = new RankWebHandler();
    private MemberPermissionWebHandler  memberPermissionWebHandler  = new MemberPermissionWebHandler();
    private MemberForumWebHandler       memberForumWebHandler       = new MemberForumWebHandler();
    private GeneralAdminTasksWebHandler generalAdminTasksWebHandler = new GeneralAdminTasksWebHandler();
    private OnlineUserManager           onlineUserManager           = OnlineUserManager.getInstance();

    public AdminModuleProcessor(HttpServlet servlet) {
        adminServlet    = servlet;
        //servletContext  = servlet.getServletContext();
    }

    /**
     * This method handles the <code>requestURI</code>, and invokes the needed
     * procedure (if the current user has the permission to perform that task).
     * <br/>
     * For example, URI <code>"/addforumprocess"</code> invokes the call to
     * <code>forumWebHandler.processAdd(request);</code>.<br/>
     * After the task is performed, we use the <code>AdminModuleURLMapHandler</code>
     * to get the <code>responseURI</code>. That <code>responseURI</code> is
     * returned back to the calling method, so it can decide and act on it
     * (to redirect to that URI).<br/>
     *
     * @param request The <code>HttpServletRequest</code> object of this HTTP request.
     * @param response The <code>HttpServletResponse</code> object of this HTTP request.
     * @return responseURI to be redirected to. <b>It could be null</b>, which
     *         means we are not supposed to do any redirection, since the output was
     *         already commited (for example, if we sent (downloaded) a file to the user.
     */
    public String process(HttpServletRequest request, HttpServletResponse response)
        throws IOException, ServletException {

        long start = 0;
        String requestURI = StringUtil.getEmptyStringIfNull(request.getPathInfo());
        String responseURI = null;
        if (log.isDebugEnabled()) {
            start = System.currentTimeMillis();
            log.debug("AdminModuleProcessor : requestURI  = " + requestURI);
        }

        // step 1: some command need to be processed before we do the URI mapping (of the MODAL)
        try {
            // always check for Authenticated User
            OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
            MVNForumPermission permission = onlineUser.getPermission();
            if ( !requestURI.equals("") &&
                 !requestURI.equals("/") &&
                 !requestURI.equals("/login") &&
                 !requestURI.equals("/loginprocess") &&
                 !requestURI.equals("/logout")) {
                permission.ensureIsAuthenticated();
            }

            if (requestURI.equals("/forummanagement")) {
                permission.ensureCanEditAnyForum();// is this the correct permission
            } else if (requestURI.equals("/editgroupforumpermission")) {
                groupForumWebHandler.prepareList(request);
            } else if (requestURI.equals("/updategroupforumpermission")) {
                groupForumWebHandler.processUpdate(request);

            } else if (requestURI.equals("/addforum")) {
                permission.ensureCanAddForum();
            } else if (requestURI.equals("/addforumprocess")) {
                forumWebHandler.processAdd(request);
            } else if (requestURI.equals("/deleteforum")) {
                forumWebHandler.prepareDelete(request);
            } else if (requestURI.equals("/deleteforumprocess")) {
                forumWebHandler.processDelete(request);
            } else if (requestURI.equals("/editforum")) {
                forumWebHandler.prepareEdit(request);
            } else if (requestURI.equals("/updateforum")) {
                forumWebHandler.processUpdate(request);
            } else if (requestURI.equals("/updateforumorder")) {
                forumWebHandler.processUpdateForumOrder(request);

            } else if (requestURI.equals("/addcategory")) {
                permission.ensureCanAddCategory();
            } else if (requestURI.equals("/addcategoryprocess")) {
                categoryWebHandler.processAdd(request);
            } else if (requestURI.equals("/deletecategory")) {
                categoryWebHandler.prepareDelete(request);
            } else if (requestURI.equals("/deletecategoryprocess")) {
                categoryWebHandler.processDelete(request);
            } else if (requestURI.equals("/editcategory")) {
                categoryWebHandler.prepareEdit(request);
            } else if (requestURI.equals("/updatecategory")) {
                categoryWebHandler.processUpdate(request);
            } else if (requestURI.equals("/updatecategoryorder")) {
                categoryWebHandler.processUpdateCategoryOrder(request);

            } else if (requestURI.equals("/rankmanagement")) {
                rankWebHandler.prepareList(request);
            } else if (requestURI.equals("/editrank")) {
                rankWebHandler.prepareEdit(request);
            } else if (requestURI.equals("/editrankprocess")) {
                rankWebHandler.processUpdate(request);
            } else if (requestURI.equals("/addrankprocess")) {
                rankWebHandler.processAdd(request);
            } else if (requestURI.equals("/deleterankprocess")) {
                rankWebHandler.processDelete(request);

            } else if (requestURI.equals("/usermanagement")) {
                memberWebHandler.prepareListMembers_forPublic(request);
            } else if (requestURI.equals("/addmemberprocess")) {
                memberWebHandler.processAdd(request);
            } else if (requestURI.equals("/changememberstatusprocess")) {
                memberWebHandler.processUpdateMemberStatus(request);
            } else if (requestURI.equals("/viewmember")) {
                memberWebHandler.prepareView(request);
            } else if (requestURI.equals("/editmembertitle")) {
                memberWebHandler.prepareView(request);
            } else if (requestURI.equals("/editmembertitleprocess")) {
                memberWebHandler.processUpdateMemberTitle(request);
            } else if (requestURI.equals("/resetsignatureprocess")) {
                memberWebHandler.processResetMemberSignature(request);
            } else if (requestURI.equals("/resetavatarprocess")) {
                memberWebHandler.processResetMemberAvatar(request);
            } else if (requestURI.equals("/resetactivationprocess")) {
                memberWebHandler.processResetMemberActivation(request);

            } else if (requestURI.equals("/deletewatch")) {
                watchWebHandler.processDelete_forMember(request);

            } else if (requestURI.equals("/addgroupprocess")) {
                groupsWebHandler.processAdd(request);
            } else if (requestURI.equals("/deletegroup")) {
                groupsWebHandler.prepareDelete(request);
            } else if (requestURI.equals("/deletegroupprocess")) {
                groupsWebHandler.processDelete(request);
            } else if (requestURI.equals("/groupmanagement")) {
                groupsWebHandler.prepareList(request);
            } else if (requestURI.equals("/viewgroup")) {
                groupsWebHandler.prepareView(request);
            } else if (requestURI.equals("/editgroupinfo")) {
                groupsWebHandler.prepareView(request);
            } else if (requestURI.equals("/updategroupinfo")) {
                groupsWebHandler.processUpdate(request);
            } else if (requestURI.equals("/editgroupowner")) {
                groupsWebHandler.prepareView(request);
            } else if (requestURI.equals("/updategroupowner")) {
                groupsWebHandler.processUpdateGroupOwner(request);
            } else if (requestURI.equals("/listmembergroup")) {
                memberGroupWebHandler.prepareList_inGroup_limit(request);
            } else if (requestURI.equals("/addmembergroup")) {
                groupsWebHandler.prepareView(request);
            } else if (requestURI.equals("/addmembergroupprocess")) {
                memberGroupWebHandler.processAdd(request);
            } else if (requestURI.equals("/deletemembergroupprocess")) {
                memberGroupWebHandler.processDelete(request);
            } else if (requestURI.equals("/editgrouppermission")) {
                groupPermissionWebHandler.prepareList(request);
            } else if (requestURI.equals("/updategrouppermission")) {
                groupPermissionWebHandler.processUpdate(request);
            } else if (requestURI.equals("/assignforumtogroup")) {
                groupForumWebHandler.prepareAssignForumToGroup(request);
            } else if (requestURI.equals("/assigngrouptoforum")) {
                groupForumWebHandler.prepareAssignGroupToForum(request);
            } else if (requestURI.equals("/assignforumtomember")) {
                memberForumWebHandler.prepareAssignForumToMember(request);
            } else if (requestURI.equals("/assignmembertoforum")) {
                memberForumWebHandler.prepareAssignMemberToForum(request);
            } else if (requestURI.equals("/editmemberforumpermission")) {
                memberForumWebHandler.prepareList(request);
            } else if (requestURI.equals("/updatememberforumpermission")) {
                memberForumWebHandler.processUpdate(request);
            } else if (requestURI.equals("/editmemberpermission")) {
                memberPermissionWebHandler.prepareListPermission(request);
            } else if (requestURI.equals("/updatememberpermission")) {
                memberPermissionWebHandler.processUpdate(request);
            } else if (requestURI.equals("/deletememberprocess")) {
                memberWebHandler.processDeleteMember(request);
            }

            else if (requestURI.equals("/index")) {
                generalAdminTasksWebHandler.prepareShowIndex(request);
            } else if (requestURI.equals("/testsystem")) {
                generalAdminTasksWebHandler.prepareTestSystem(request);
            } else if (requestURI.equals("/importexport")) {
                generalAdminTasksWebHandler.prepareImportExport(request);
            } else if (requestURI.equals("/importprocess")) {
                generalAdminTasksWebHandler.importXmlZip(request, response);
                return null;//already commited some messages, no further process is needed
            } else if (requestURI.equals("/exportprocess")) {
                generalAdminTasksWebHandler.exportXmlZip(request);
            } else if (requestURI.equals("/getexportprocess")) {
                generalAdminTasksWebHandler.getExportXmlZip(request, response);
                return null;//already commited file or raised exception, no further process is needed
            } else if (requestURI.equals("/deleteexportprocess")) {
                generalAdminTasksWebHandler.deleteExportXmlZip(request);
            } else if (requestURI.equals("/rebuildindex")) {
                generalAdminTasksWebHandler.rebuildIndex(request);
            } else if (requestURI.equals("/sendmail")) {
                generalAdminTasksWebHandler.prepareSendMail(request);
            } else if (requestURI.equals("/sendmailprocess")) {
                generalAdminTasksWebHandler.sendMail(request);
            } else if (requestURI.equals("/loginprocess")) {
                onlineUserManager.processLogin(request, response);
                String originalRequest = ParamUtil.getAttribute(request.getSession(), ORIGINAL_REQUEST);
                if (originalRequest.length() > 0) {
                    request.getSession().setAttribute(ORIGINAL_REQUEST, "");
                    responseURI = originalRequest;
                }
            } else if (requestURI.equals("/logout")) {
                onlineUserManager.logout(request, response);
                request.setAttribute("Reason", "Logout successfully.");
            }
        } catch (AuthenticationException e) {
            // make sure not from login page, we cannot set original request in this situation
            // and also make sure the request's method must be GET to set the OriginalRequest
            boolean shouldSaveOriginalRequest = (e.getReason()==NotLoginException.NOT_LOGIN) || (e.getReason()==NotLoginException.NOT_ENOUGH_RIGHTS);
            if (shouldSaveOriginalRequest && (request.getMethod().equals("GET"))) {
                String url = AdminModuleConfig.URL_PATTERN + requestURI + "?" + StringUtil.getEmptyStringIfNull(request.getQueryString());
                request.getSession().setAttribute(ORIGINAL_REQUEST, url);
            }

            requestURI = "/login";
            request.setAttribute("Reason", e.getReasonExplanation());
        } catch (Exception e) {
            if (e instanceof BadInputException) {
                // we log in WARN level if this is the exception from user input
                log.warn("Exception in AdminModuleProcessor e = " + e.getMessage(), e);
            } else {
                log.error("Exception in AdminModuleProcessor e = " + e.getMessage(), e);
            }
            requestURI = "/error";
            request.getSession().setAttribute("ErrorMessage", StringUtil.getEmptyStringIfNull(e.getMessage()));
        }

        // step 2: map the URI (of the CONTROLLER)
        try {
            // See note in the ActionInUserModule
            Action action = new ActionInAdminModule(request, requestURI);// may throw MissingURLMapEntryException
            onlineUserManager.updateOnlineUserAction(request, action);

            if (responseURI == null) {
                URLMap map = urlMapHandler.getMap(requestURI, request);
                responseURI = map.getResponse();
            }
        } catch (MissingURLMapEntryException e) {
            log.error("Exception: missing urlmap entry in admin module: requestURI = " + requestURI);
            responseURI = "/mvnplugin/mvnforum/admin/error.jsp";
            request.getSession().setAttribute("ErrorMessage", e.getMessage());
        } catch (Exception e) {
            // This will catch AuthenticationException, AssertionException, DatabaseException
            // in the method onlineUserManager.updateOnlineUserAction(request, action)
            responseURI = "/mvnplugin/mvnforum/admin/error.jsp";
            request.getSession().setAttribute("ErrorMessage", e.getMessage());
        }

        // step 3: return URI to be forwarded to or dispatched to the VIEW
        if (log.isDebugEnabled()) {
            long duration = System.currentTimeMillis() - start;
            log.debug("AdminModuleProcessor : responseURI = " + responseURI + ". (" + duration + " ms)\n");
        }

        return responseURI;
        /* Redirection is moved into ForumAdminServlet.process() method.
        if (responseURI.endsWith(".jsp")) {
            servletContext.getRequestDispatcher(responseURI).forward(request, response);
        } else {
            response.sendRedirect(ParamUtil.getContextPath() + responseURI);
        }
         */
    }// process method
}
