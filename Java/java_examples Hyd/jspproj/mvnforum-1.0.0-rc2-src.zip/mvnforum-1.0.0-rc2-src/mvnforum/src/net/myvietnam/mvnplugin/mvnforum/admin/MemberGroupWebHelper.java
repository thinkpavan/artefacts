/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/MemberGroupWebHelper.java,v 1.12 2003/10/30 19:18:57 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.12 $
 * $Date: 2003/10/30 19:18:57 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import java.sql.Timestamp;
import java.util.Collection;

import net.myvietnam.mvncore.exception.*;

class MemberGroupWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.MemberGroupWebHelper {
    // prevent instantiation and inheritance
    private MemberGroupWebHelper() {
    }

    public static void createMemberGroup(int groupID, String memberName,
                        int privilege, Timestamp creationDate, Timestamp modifiedDate)
        throws CreateException, DatabaseException, DuplicateKeyException, ForeignKeyNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.MemberGroupWebHelper.create(groupID, memberName, privilege, creationDate, modifiedDate);
    }

    public static void deleteMemberGroup(int groupID, int memberID)
        throws DatabaseException, ObjectNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.MemberGroupWebHelper.delete(groupID, memberID);
    }

    public static void deleteMemberGroup_inGroup(int groupID)
        throws DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.MemberGroupWebHelper.delete_inGroup(groupID);
    }

    public static void deleteMemberGroup_inMember(int memberID)
        throws DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.MemberGroupWebHelper.delete_inMember(memberID);
    }

    public static Collection getMemberGroups_inGroup(int groupID)
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.MemberGroupWebHelper.getBeans_inGroup(groupID);
    }

    public static int getNumberOfMemberGroups_inGroup(int groupID)
        throws AssertionException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.MemberGroupWebHelper.getNumberOfBeans_inGroup(groupID);
    }
}
