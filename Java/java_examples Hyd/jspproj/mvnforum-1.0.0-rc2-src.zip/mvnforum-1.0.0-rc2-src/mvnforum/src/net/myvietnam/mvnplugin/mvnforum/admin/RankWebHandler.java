/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/RankWebHandler.java,v 1.2 2003/09/05 17:23:49 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.2 $
 * $Date: 2003/09/05 17:23:49 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import javax.servlet.http.*;
import java.sql.*;
import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.util.ParamUtil;
import net.myvietnam.mvnplugin.mvnforum.db.RankBean;
import net.myvietnam.mvnplugin.mvnforum.auth.*;

class RankWebHandler {

    private OnlineUserManager onlineUserManager = OnlineUserManager.getInstance();

    RankWebHandler() {
    }

    void processAdd(HttpServletRequest request)
        throws BadInputException, CreateException, DatabaseException,
        DuplicateKeyException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        int rankMinPosts= ParamUtil.getParameterInt(request, "RankMinPosts");
        String rankTitle= ParamUtil.getParameterSafe(request, "RankTitle", true);

        // reserved for future
        int rankLevel   = 0;
        String rankImage= "";
        int rankType    = 0;
        int rankOption  = 0;

        RankWebHelper.createRank(rankMinPosts, rankLevel, rankTitle,
                             rankImage, rankType, rankOption);
    }

    public void prepareEdit(HttpServletRequest request)
        throws BadInputException, DatabaseException, ObjectNotFoundException,
        AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        // primary key column(s)
        int rankID  = ParamUtil.getParameterInt(request, "rank");

        RankBean bean = RankWebHelper.getRank(rankID);

        request.setAttribute("RankBean", bean);
    }

    public void prepareList(HttpServletRequest request)
        throws DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();
    }

    public void processUpdate(HttpServletRequest request)
        throws BadInputException, DatabaseException, DuplicateKeyException,
        ObjectNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        // primary key column(s)
        int rankID      = ParamUtil.getParameterInt(request, "RankID");

        // column(s) to update
        int rankMinPosts= ParamUtil.getParameterInt(request, "RankMinPosts");
        String rankTitle= ParamUtil.getParameterSafe(request, "RankTitle", true);

        //reserved for future
        int rankLevel   = 0;
        String rankImage= "";
        int rankType    = 0;
        int rankOption  = 0;

        RankWebHelper.updateRank(rankID, // primary key
                             rankMinPosts, rankLevel, rankTitle,
                             rankImage, rankType, rankOption);
    }

    public void processDelete(HttpServletRequest request)
        throws BadInputException, DatabaseException, ObjectNotFoundException,
        AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        // primary key column(s)
        int rankID  = ParamUtil.getParameterInt(request, "rank");

        RankWebHelper.deleteRank(rankID);
    }

}
