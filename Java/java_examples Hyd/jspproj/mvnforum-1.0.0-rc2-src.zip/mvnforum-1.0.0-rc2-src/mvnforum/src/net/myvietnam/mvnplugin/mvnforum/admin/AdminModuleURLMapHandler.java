/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/AdminModuleURLMapHandler.java,v 1.18 2003/10/27 20:41:55 imanic Exp $
 * $Author: imanic $
 * $Revision: 1.18 $
 * $Date: 2003/10/27 20:41:55 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import javax.servlet.http.HttpServletRequest;

import net.myvietnam.mvncore.exception.MissingURLMapEntryException;
import net.myvietnam.mvncore.util.ParamUtil;
import net.myvietnam.mvnplugin.mvnforum.URLMap;

class AdminModuleURLMapHandler {

    public AdminModuleURLMapHandler() {
    }

    /**
     * We must pass the requestURI to this method, instead of from request,
     * because requestURI may be changed from Processor before call this method
     * NOTE: Currently we dont use the param request
     */
    public URLMap getMap(String requestURI, HttpServletRequest request)
        throws MissingURLMapEntryException {
        URLMap map = new URLMap();

        // ADMIN module
        if (requestURI.equals("") || requestURI.equals("/")) {
            map.setResponse(AdminModuleConfig.URL_PATTERN + "/index");
        } else if (requestURI.equals("/index")) {
            map.setResponse("/mvnplugin/mvnforum/admin/index.jsp");
        } else if (requestURI.equals("/error")) {
            map.setResponse("/mvnplugin/mvnforum/admin/error.jsp");

        } else if (requestURI.equals("/login")) {
            map.setResponse("/mvnplugin/mvnforum/admin/login.jsp");
        } else if (requestURI.equals("/loginprocess")) {
            map.setResponse(AdminModuleConfig.URL_PATTERN + "/index");
        } else if (requestURI.equals("/logout")) {
            map.setResponse("/mvnplugin/mvnforum/admin/login.jsp");

        } else if (requestURI.equals("/testsystem")) {
            map.setResponse("/mvnplugin/mvnforum/admin/testsystem.jsp");
        } else if (requestURI.equals("/misctasks")) {
            map.setResponse("/mvnplugin/mvnforum/admin/misctasks.jsp");
        } else if (requestURI.equals("/importexport")) {
            map.setResponse("/mvnplugin/mvnforum/admin/importexport.jsp");
        } else if (requestURI.equals("/exportprocess")) {
            map.setResponse("/mvnplugin/mvnforum/admin/exportsuccess.jsp");
        } else if (requestURI.equals("/deleteexportprocess")) {
            map.setResponse("/mvnplugin/mvnforum/admin/importexport.jsp"); //go back to importexport
        /* "/importprocess" and "/getexportprocess" are handled without
         * using this url map handler, since they directly commit output, and
         * there should be no redirection/forward to JSPs
         */
        } else if (requestURI.equals("/rebuildindex")) {
            map.setResponse("/mvnplugin/mvnforum/admin/rebuildindexsuccess.jsp");

        } else if (requestURI.equals("/rankmanagement")) {
            map.setResponse("/mvnplugin/mvnforum/admin/rankmanagement.jsp");
        } else if (requestURI.equals("/addrankprocess")) {
            map.setResponse("/mvnplugin/mvnforum/admin/addranksuccess.jsp");
        } else if (requestURI.equals("/deleterankprocess")) {
            map.setResponse("/mvnplugin/mvnforum/admin/deleteranksuccess.jsp");
        } else if (requestURI.equals("/editrank")) {
            map.setResponse("/mvnplugin/mvnforum/admin/editrank.jsp");
        } else if (requestURI.equals("/editrankprocess")) {
            map.setResponse("/mvnplugin/mvnforum/admin/editranksuccess.jsp");

        } else if (requestURI.equals("/usermanagement")) {
            map.setResponse("/mvnplugin/mvnforum/admin/usermanagement.jsp");
        } else if (requestURI.equals("/addmember")) {
            map.setResponse("/mvnplugin/mvnforum/admin/addmember.jsp");
        } else if (requestURI.equals("/addmemberprocess")) {
            map.setResponse(AdminModuleConfig.URL_PATTERN + "/usermanagement");
        } else if (requestURI.equals("/changememberstatusprocess")) {
            map.setResponse("/mvnplugin/mvnforum/admin/changememberstatussuccess.jsp");
        } else if (requestURI.equals("/viewmember")) {
            map.setResponse("/mvnplugin/mvnforum/admin/viewmember.jsp");
        } else if (requestURI.equals("/editmembertitle")) {
            map.setResponse("/mvnplugin/mvnforum/admin/editmembertitle.jsp");
        } else if (requestURI.equals("/editmembertitleprocess")) {
            map.setResponse("/mvnplugin/mvnforum/admin/editmembertitlesuccess.jsp");
        } else if (requestURI.equals("/resetsignatureprocess")) {
            map.setResponse("/mvnplugin/mvnforum/admin/resetsignaturesuccess.jsp");
        } else if (requestURI.equals("/resetavatarprocess")) {
            map.setResponse("/mvnplugin/mvnforum/admin/resetavatarsuccess.jsp");
        } else if (requestURI.equals("/resetactivationprocess")) {
            map.setResponse("/mvnplugin/mvnforum/admin/resetactivationsuccess.jsp");
        } else if (requestURI.equals("/deletewatch")) {
            map.setResponse(AdminModuleConfig.URL_PATTERN + "/viewmember?memberid=" + ParamUtil.getParameter(request, "memberid"));

        } else if (requestURI.equals("/groupmanagement")) {
            map.setResponse("/mvnplugin/mvnforum/admin/groupmanagement.jsp");
        } else if (requestURI.equals("/addgroup")) {
            map.setResponse("/mvnplugin/mvnforum/admin/addgroup.jsp");
        } else if (requestURI.equals("/addgroupprocess")) {
            map.setResponse(AdminModuleConfig.URL_PATTERN + "/groupmanagement");
        } else if (requestURI.equals("/deletegroup")) {
            map.setResponse("/mvnplugin/mvnforum/admin/deletegroup.jsp");
        } else if (requestURI.equals("/deletegroupprocess")) {
            map.setResponse(AdminModuleConfig.URL_PATTERN + "/groupmanagement");
        } else if (requestURI.equals("/viewgroup")) {
            map.setResponse("/mvnplugin/mvnforum/admin/viewgroup.jsp");
        } else if (requestURI.equals("/assignforumtogroup")) {
            map.setResponse("/mvnplugin/mvnforum/admin/assignforumtogroup.jsp");
        } else if (requestURI.equals("/assigngrouptoforum")) {
            map.setResponse("/mvnplugin/mvnforum/admin/assigngrouptoforum.jsp");
        } else if (requestURI.equals("/editgroupinfo")) {
            map.setResponse("/mvnplugin/mvnforum/admin/editgroupinfo.jsp");
        } else if (requestURI.equals("/updategroupinfo")) {
            map.setResponse("/mvnplugin/mvnforum/admin/updategroupinfosuccess.jsp");
        } else if (requestURI.equals("/editgroupowner")) {
            map.setResponse("/mvnplugin/mvnforum/admin/editgroupowner.jsp");
        } else if (requestURI.equals("/updategroupowner")) {
            map.setResponse("/mvnplugin/mvnforum/admin/updategroupinfosuccess.jsp");
        } else if (requestURI.equals("/listmembergroup")) {
            map.setResponse("/mvnplugin/mvnforum/admin/listmembergroup.jsp");
        } else if (requestURI.equals("/addmembergroup")) {
            map.setResponse("/mvnplugin/mvnforum/admin/addmembergroup.jsp");
        } else if (requestURI.equals("/addmembergroupprocess")) {
            map.setResponse(AdminModuleConfig.URL_PATTERN + "/listmembergroup?group=" + ParamUtil.getParameter(request, "group"));
        } else if (requestURI.equals("/deletemembergroupprocess")) {
            map.setResponse(AdminModuleConfig.URL_PATTERN + "/listmembergroup?group=" + ParamUtil.getParameter(request, "group"));
        } else if (requestURI.equals("/editgrouppermission")) {
            map.setResponse("/mvnplugin/mvnforum/admin/editgrouppermission.jsp");
        } else if (requestURI.equals("/updategrouppermission")) {
            map.setResponse(AdminModuleConfig.URL_PATTERN + "/editgrouppermission?group=" + ParamUtil.getParameter(request, "group"));

        } else if (requestURI.equals("/forummanagement")) {
            map.setResponse("/mvnplugin/mvnforum/admin/forummanagement.jsp");
        } else if (requestURI.equals("/updatecategoryorder")) {
            map.setResponse(AdminModuleConfig.URL_PATTERN + "/forummanagement");
        } else if (requestURI.equals("/updateforumorder")) {
            map.setResponse(AdminModuleConfig.URL_PATTERN + "/forummanagement");
        } else if (requestURI.equals("/editgroupforumpermission")) {
            map.setResponse("/mvnplugin/mvnforum/admin/editgroupforumpermission.jsp");
        } else if (requestURI.equals("/editmemberforumpermission")) {
            map.setResponse("/mvnplugin/mvnforum/admin/editmemberforumpermission.jsp");
        } else if (requestURI.equals("/editmemberpermission")) {
            map.setResponse("/mvnplugin/mvnforum/admin/editmemberpermission.jsp");
        } else if (requestURI.equals("/deletememberprocess")) {
            map.setResponse("/mvnplugin/mvnforum/admin/deletemembersuccess.jsp");
        } else if (requestURI.equals("/updategroupforumpermission")) {
            map.setResponse(AdminModuleConfig.URL_PATTERN +
                            "/editgroupforumpermission?group=" + ParamUtil.getParameter(request, "group") +
                            "&forum=" + ParamUtil.getParameter(request, "forum")
                            );
        } else if (requestURI.equals("/updatememberforumpermission")) {
            map.setResponse(AdminModuleConfig.URL_PATTERN +
                            "/editmemberforumpermission?memberid=" +
                            ParamUtil.getParameter(request, "memberid") +
                            "&forum=" + ParamUtil.getParameter(request, "forum")
                            );
        } else if (requestURI.equals("/updatememberpermission")) {
            map.setResponse(AdminModuleConfig.URL_PATTERN +
                            "/editmemberpermission?memberid=" +
                            ParamUtil.getParameter(request, "memberid"));

        } else if (requestURI.equals("/addforum")) {
            map.setResponse("/mvnplugin/mvnforum/admin/addforum.jsp");
        } else if (requestURI.equals("/addforumprocess")) {
            map.setResponse("/mvnplugin/mvnforum/admin/addforumsuccess.jsp");
        } else if (requestURI.equals("/deleteforum")) {
            map.setResponse("/mvnplugin/mvnforum/admin/deleteforum.jsp");
        } else if (requestURI.equals("/deleteforumprocess")) {
            map.setResponse("/mvnplugin/mvnforum/admin/deleteforumsuccess.jsp");
        } else if (requestURI.equals("/editforum")) {
            map.setResponse("/mvnplugin/mvnforum/admin/editforum.jsp");
        } else if (requestURI.equals("/updateforum")) {
            map.setResponse("/mvnplugin/mvnforum/admin/updateforumsuccess.jsp");

        } else if (requestURI.equals("/addcategory")) {
            map.setResponse("/mvnplugin/mvnforum/admin/addcategory.jsp");
        } else if (requestURI.equals("/addcategoryprocess")) {
            map.setResponse("/mvnplugin/mvnforum/admin/addcategorysuccess.jsp");
        } else if (requestURI.equals("/deletecategory")) {
            map.setResponse("/mvnplugin/mvnforum/admin/deletecategory.jsp");
        } else if (requestURI.equals("/deletecategoryprocess")) {
            map.setResponse("/mvnplugin/mvnforum/admin/deletecategorysuccess.jsp");
        } else if (requestURI.equals("/editcategory")) {
            map.setResponse("/mvnplugin/mvnforum/admin/editcategory.jsp");
        } else if (requestURI.equals("/updatecategory")) {
            map.setResponse("/mvnplugin/mvnforum/admin/updatecategorysuccess.jsp");
        } else if (requestURI.equals("/listcategories")) {
            map.setResponse("/mvnplugin/mvnforum/admin/listcategories.jsp");

        } else if (requestURI.equals("/sendmail")) {
            map.setResponse("/mvnplugin/mvnforum/admin/sendmail.jsp");
        } else if (requestURI.equals("/sendmailprocess")) {
            map.setResponse("/mvnplugin/mvnforum/admin/sendmailsuccess.jsp");

        } else if (requestURI.equals("/assignforumtomember")) {
            map.setResponse("/mvnplugin/mvnforum/admin/assignforumtomember.jsp");
        } else if (requestURI.equals("/assignmembertoforum")) {
            map.setResponse("/mvnplugin/mvnforum/admin/assignmembertoforum.jsp");
        }

        // unknown module, we throw an exception
        if (map.getResponse() == null) {
            String errorMessage = "Cannot find matching entry in URLMap for '" + requestURI + "'. Please contact the administrator.";
            throw new MissingURLMapEntryException(errorMessage);
        }
        return map;
    }
}
