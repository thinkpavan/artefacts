/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/GroupsWebHandler.java,v 1.18 2003/10/05 09:51:44 imanic Exp $
 * $Author: imanic $
 * $Revision: 1.18 $
 * $Date: 2003/10/05 09:51:44 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.security.Encoder;
import net.myvietnam.mvncore.util.DateUtil;
import net.myvietnam.mvncore.util.ParamUtil;
import net.myvietnam.mvnplugin.mvnforum.MVNForumConstant;
import net.myvietnam.mvnplugin.mvnforum.ManagerFactory;
import net.myvietnam.mvnplugin.mvnforum.auth.*;
import net.myvietnam.mvnplugin.mvnforum.db.GroupsBean;

class GroupsWebHandler {

    private OnlineUserManager onlineUserManager = OnlineUserManager.getInstance();

    GroupsWebHandler() {
    }

    void processAdd(HttpServletRequest request)
        throws ObjectNotFoundException, BadInputException, CreateException, DatabaseException, DuplicateKeyException,
        ForeignKeyNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        Timestamp now = DateUtil.getCurrentGMTTimestamp();

        String groupName        = ParamUtil.getParameterSafe(request, "GroupName", true);
        String groupDesc        = ParamUtil.getParameterSafe(request, "GroupDesc", false);
        int groupOption         = 0;//ParamUtil.getParameterInt(request, "GroupOption");

        GroupsWebHelper.createGroups(""/*groupOwnerName*/, groupName, groupDesc,
                               groupOption, now/*groupCreationDate*/, now/*groupModifiedDate*/);

        //now add owner to group if there is owner for this group
        String groupOwnerName   = ParamUtil.getParameterSafe(request, "GroupOwnerName", false);
        if (groupOwnerName.length() > 0) {
            int groupID     = GroupsWebHelper.getGroupIDFromGroupName(groupName);
            int privilege   = 0;//@todo review and support it later, should be GroupAdmin
            try {
                GroupsWebHelper.updateGroupOwner(groupID, // primary key
                                       groupOwnerName, now/*groupModifiedDate*/);
                MemberGroupWebHelper.createMemberGroup(groupID, groupOwnerName, privilege, now, now);
            } catch (ForeignKeyNotFoundException ex) {
                // what should do when member not found ???
                // now, I just do nothing
            } catch (DuplicateKeyException ex) {
                // do nothing, it is not an error (member already in this group)
            }
        }
    }

    void prepareDelete(HttpServletRequest request)
        throws ObjectNotFoundException, BadInputException, DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        // primary key column(s)
        int groupID = ParamUtil.getParameterInt(request, "group");

        //make sure reserved groups are never deleted (like "Registered Members" group)
        if (groupID <= MVNForumConstant.LAST_RESERVED_GROUP_ID) {
            throw new BadInputException("Cannot delete group with id <= "+
                      Integer.toString(MVNForumConstant.LAST_RESERVED_GROUP_ID));
        }

        GroupsBean bean = GroupsWebHelper.getGroup(groupID);

        request.setAttribute("GroupsBean", bean);
    }

    void processDelete(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        // primary key column(s)
        int groupID = ParamUtil.getParameterInt(request, "group");

        //make sure reserved groups are never deleted (like "Registered Members" group)
        if (groupID <= MVNForumConstant.LAST_RESERVED_GROUP_ID) {
            throw new BadInputException("Cannot delete group with id <= "+
                      Integer.toString(MVNForumConstant.LAST_RESERVED_GROUP_ID));
        }

        // now check the password
        String memberPassword  = ParamUtil.getParameterPassword(request, "MemberMatkhau", 3, 0);
        String encodedPassword = Encoder.getMD5_Base64(memberPassword);
        int memberID = onlineUser.getMemberID();
        if (!encodedPassword.equals(ManagerFactory.getMemberDAO().getPassword(memberID))) {
            throw new BadInputException("You have typed the wrong password. Cannot proceed.");
        }

        GroupForumWebHelper.deleteGroupForum_inGroup(groupID);

        GroupPermissionWebHelper.deleteGroupPermission_inGroup(groupID);

        MemberGroupWebHelper.deleteMemberGroup_inGroup(groupID);

        GroupsWebHelper.deleteGroups(groupID);
    }

    void processUpdate(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException, DuplicateKeyException,
        AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        Timestamp now = DateUtil.getCurrentGMTTimestamp();

        // primary key column(s)
        int groupID                 = ParamUtil.getParameterInt(request, "group");

        // column(s) to update
        String groupName            = ParamUtil.getParameterSafe(request, "GroupName", true);
        String groupDesc            = ParamUtil.getParameterSafe(request, "GroupDesc", true);

        GroupsWebHelper.updateGroups(groupID, // primary key
                               groupName, groupDesc, now/*groupModifiedDate*/);
    }

    void processUpdateGroupOwner(HttpServletRequest request)
        throws ObjectNotFoundException, BadInputException, DatabaseException, ForeignKeyNotFoundException,
        CreateException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        Timestamp now = DateUtil.getCurrentGMTTimestamp();

        // primary key column(s)
        int groupID             = ParamUtil.getParameterInt(request, "group");

        //make sure group owners for reserved groups can't be changed
        if (groupID <= MVNForumConstant.LAST_RESERVED_GROUP_ID) {
            throw new AssertionException("Cannot update group owner for reserved (virtual) groups.");
        }
        //@todo: Igor: Why don't we allow changing of GroupOwner for reserved groups? I think we have no reason to disallow that.

        // column(s) to update
        String groupOwnerName   = ParamUtil.getParameterSafe(request, "GroupOwnerName", false);

        GroupsWebHelper.updateGroupOwner(groupID, // primary key
                               groupOwnerName, now/*groupModifiedDate*/);

        /*
         * now add owner to group if there is owner for this group
         * if member already in the group, we dont throw Exception (DuplicateKeyException)
         */
        if (groupOwnerName.length() > 0) {
            int privilege = 0;//@todo review and support it later
            try {
                MemberGroupWebHelper.createMemberGroup(groupID, groupOwnerName, privilege, now, now);
            } catch (DuplicateKeyException ex) {
                // do nothing, it is not an error (member already in this group)
            }
        }
    }

    void prepareView(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        // primary key column(s)
        int groupID = ParamUtil.getParameterInt(request, "group");

        GroupsBean bean = GroupsWebHelper.getGroup(groupID);

        request.setAttribute("GroupsBean", bean);
    }

    void prepareList(HttpServletRequest request)
        throws DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        Collection beans = GroupsWebHelper.getGroups();

        // now count the number of members in each group
        Iterator iterator = beans.iterator();
        while(iterator.hasNext()) {
            GroupsBean row = (GroupsBean)iterator.next();
            int groupID = row.getGroupID();
            if (groupID == MVNForumConstant.GROUP_ID_OF_REGISTERED_MEMBERS) {
                //"Registered Members" group. Exclude virtual guest from count.
                row.setGroupMemberCount(ManagerFactory.getMemberDAO().getNumberOfBeans()-1);
            } else if (groupID <= MVNForumConstant.LAST_RESERVED_GROUP_ID) {
                //other reserved groups
                row.setGroupMemberCount(0);
            } else {
                row.setGroupMemberCount(MemberGroupWebHelper.getNumberOfMemberGroups_inGroup(groupID));
            }
        }

        request.setAttribute("GroupsBeans", beans);
    }

}
