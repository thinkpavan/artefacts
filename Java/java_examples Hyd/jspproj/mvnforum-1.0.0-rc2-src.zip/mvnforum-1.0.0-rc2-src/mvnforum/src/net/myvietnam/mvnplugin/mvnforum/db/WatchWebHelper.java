/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/WatchWebHelper.java,v 1.11 2003/09/27 15:05:17 imanic Exp $
 * $Author: imanic $
 * $Revision: 1.11 $
 * $Date: 2003/09/27 15:05:17 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.db.DBUtils;
import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvnplugin.mvnforum.MVNForumConstant;
import net.myvietnam.mvnplugin.mvnforum.ManagerFactory;

/*
// @todo: copy this skeleton for derived class
package package_of_derived_class;

//import java.sql.*;// @todo: uncomment as needed
//import java.util.Collection; // @todo: uncomment as needed
//import net.myvietnam.mvncore.db.DBUtils;// @todo: uncomment as needed
import net.myvietnam.mvncore.exception.*;
//import net.myvietnam.mvnplugin.mvnforum.db.WatchBean;// @todo: uncomment as needed

class WatchWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper {
    // prevent instantiation and inheritance
    private WatchWebHelper() {
    }

    // @todo: add methods here
}
*/
public class WatchWebHelper {

    private static Log log = LogFactory.getLog(WatchWebHelper.class);

    public static final String TABLE_NAME = DatabaseConfig.TABLE_PREFIX + "Watch";

    // this variable will support caching if cache for this class is needed
    private static boolean m_dirty = true;

    // Prevent instantiation from classes other than derived classes
    protected WatchWebHelper() {
    }

    protected static boolean isDirty() {
        return m_dirty;
    }

    protected static void setDirty(boolean dirty) {
        m_dirty = dirty;
    }

    // @todo: add methods here
    protected static void findByPrimaryKey(int watchID)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT WatchID");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE WatchID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, watchID);
            resultSet = statement.executeQuery();
            if (!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the primary key (" + watchID + ") in table 'Watch'.");
            }
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in WatchWebHelper.findByPrimaryKey.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    protected static void findByAlternateKey_MemberID_CategoryID_ForumID_ThreadID(int memberID, int categoryID, int forumID, int threadID)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberID, CategoryID, ForumID, ThreadID");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE MemberID = ? AND CategoryID = ? AND ForumID = ? AND ThreadID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            statement.setInt(2, categoryID);
            statement.setInt(3, forumID);
            statement.setInt(4, threadID);
            resultSet = statement.executeQuery();
            if (!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the alternate key <MemberID, CategoryID, ForumID, ThreadID> (" + memberID + ", " + categoryID + ", " + forumID + ", " + threadID + ") in table 'Watch'.");
            }
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in WatchWebHelper.findByAlternateKey_MemberID_CategoryID_ForumID_ThreadID.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static void createWatch(int memberID, int categoryID, int forumID,
                            int threadID, int watchType, int watchOption,
                            int watchStatus, Timestamp watchCreationDate, Timestamp watchLastSentDate,
                            Timestamp watchEndDate)
                            throws CreateException, DatabaseException, DuplicateKeyException, ForeignKeyNotFoundException {
            net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.create(memberID, categoryID, forumID, threadID, watchType, watchOption, watchStatus, watchCreationDate, watchLastSentDate, watchEndDate);
        }
    */
    /*
     * Included columns: MemberID, CategoryID, ForumID, ThreadID, WatchType,
     *                   WatchOption, WatchStatus, WatchCreationDate, WatchLastSentDate, WatchEndDate
     * Excluded columns: WatchID
     */
    protected static void create(int memberID, int categoryID, int forumID,
                        int threadID, int watchType, int watchOption,
                        int watchStatus, Timestamp watchCreationDate, Timestamp watchLastSentDate,
                        Timestamp watchEndDate)
                        throws IllegalArgumentException, CreateException, DatabaseException, DuplicateKeyException, ForeignKeyNotFoundException {

        if ( (memberID==0) || (memberID==MVNForumConstant.MEMBER_ID_OF_GUEST) ) {
            throw new IllegalArgumentException("Cannot add a new watch for Guest (id = 0)");
        }
        int notZeroCount = 0;
        if (categoryID != 0) {
            notZeroCount++;
        }
        if (forumID != 0) {
            notZeroCount++;
        }
        if (threadID != 0) {
            notZeroCount++;
        }
        if (notZeroCount > 1) {
            throw new IllegalArgumentException("Cannot add watch with more than 1 element.");
        }

        // @todo: Comment this try-catch block if the needed columns dont have attribute 'include'
        // If this is the case, then it is highly recommended that you regenerate this method with the attribute 'include' turned on
        try {
            //Check if alternate key already exists
            findByAlternateKey_MemberID_CategoryID_ForumID_ThreadID(memberID, categoryID, forumID, threadID);
            //If so, then we have to throw an exception
            throw new DuplicateKeyException("Alternate key already exists. Cannot create new Watch with the same <MemberID, CategoryID, ForumID, ThreadID> (" + memberID + ", " + categoryID + ", " + forumID + ", " + threadID + ").");
        } catch(ObjectNotFoundException e) {
            //Otherwise we can go ahead
        }

        try {
            // @todo: modify the parameter list as needed
            // You may have to regenerate this method if the needed columns dont have attribute 'include'
            ManagerFactory.getMemberDAO().findByPrimaryKey(memberID);
        } catch(ObjectNotFoundException e) {
            throw new ForeignKeyNotFoundException("Foreign key refers to table 'Member' does not exist. Cannot create new Watch.");
        }

        try {
            // @todo: modify the parameter list as needed
            // You may have to regenerate this method if the needed columns dont have attribute 'include'
            if (categoryID != 0) {
                CategoryWebHelper.findByPrimaryKey(categoryID);
            }
        } catch(ObjectNotFoundException e) {
            throw new ForeignKeyNotFoundException("Foreign key refers to table 'Category' does not exist. Cannot create new Watch.");
        }

        try {
            // @todo: modify the parameter list as needed
            // You may have to regenerate this method if the needed columns dont have attribute 'include'
            if (forumID != 0) {
                ForumWebHelper.findByPrimaryKey(forumID);
            }
        } catch(ObjectNotFoundException e) {
            throw new ForeignKeyNotFoundException("Foreign key refers to table 'Forum' does not exist. Cannot create new Watch.");
        }

        try {
            // @todo: modify the parameter list as needed
            // You may have to regenerate this method if the needed columns dont have attribute 'include'
            if (threadID != 0) {
                ThreadWebHelper.findByPrimaryKey(threadID);
            }
        } catch(ObjectNotFoundException e) {
            throw new ForeignKeyNotFoundException("Foreign key refers to table 'Thread' does not exist. Cannot create new Watch.");
        }

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("INSERT INTO " + TABLE_NAME + " (MemberID, CategoryID, ForumID, ThreadID, WatchType, WatchOption, WatchStatus, WatchCreationDate, WatchLastSentDate, WatchEndDate)");
        sql.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            statement.setInt(1, memberID);
            statement.setInt(2, categoryID);
            statement.setInt(3, forumID);
            statement.setInt(4, threadID);
            statement.setInt(5, watchType);
            statement.setInt(6, watchOption);
            statement.setInt(7, watchStatus);
            statement.setTimestamp(8, watchCreationDate);
            statement.setTimestamp(9, watchLastSentDate);
            statement.setTimestamp(10, watchEndDate);

            if (statement.executeUpdate() != 1) {
                throw new CreateException("Error adding a row into table 'Watch'.");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in WatchWebHelper.create.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static void deleteWatch(int watchID)
            throws DatabaseException, ObjectNotFoundException {
            net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.delete(watchID);
        }
    */
    protected static void delete(int watchID)
        throws DatabaseException, ObjectNotFoundException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("DELETE FROM " + TABLE_NAME);
        sql.append(" WHERE WatchID = ?");

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, watchID);
            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot delete a row in table Watch where primary key = (" + watchID + ").");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in WatchWebHelper.delete.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static void deleteWatch_inMember(int memberID)
            throws DatabaseException {
            net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.delete_inMember(memberID);
        }
    */
    protected static void delete_inMember(int memberID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("DELETE FROM " + TABLE_NAME);
        sql.append(" WHERE MemberID = ?");

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            statement.executeUpdate();
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in WatchWebHelper.delete_inMember.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static void deleteWatch_inCategory(int categoryID)
            throws DatabaseException {
            net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.delete_inCategory(categoryID);
        }
    */
    protected static void delete_inCategory(int categoryID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("DELETE FROM " + TABLE_NAME);
        sql.append(" WHERE CategoryID = ?");

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, categoryID);
            statement.executeUpdate();
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in WatchWebHelper.delete_inCategory.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static void deleteWatch_inForum(int forumID)
            throws DatabaseException {
            net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.delete_inForum(forumID);
        }
    */
    protected static void delete_inForum(int forumID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("DELETE FROM " + TABLE_NAME);
        sql.append(" WHERE ForumID = ?");

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, forumID);
            statement.executeUpdate();
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in WatchWebHelper.delete_inForum.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static void deleteWatch_inThread(int threadID)
            throws DatabaseException {
            net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.delete_inThread(threadID);
        }
    */
    protected static void delete_inThread(int threadID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("DELETE FROM " + TABLE_NAME);
        sql.append(" WHERE ThreadID = ?");

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, threadID);
            statement.executeUpdate();
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in WatchWebHelper.delete_inThread.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static void updateWatchLastSentDate(int watchID, // primary key
                            Timestamp watchLastSentDate)
                            throws ObjectNotFoundException, DatabaseException {
            net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.updateLastSentDate(watchID, // primary key
                            watchLastSentDate);
        }
    */
    /*
     * Included columns: WatchLastSentDate
     * Excluded columns: WatchID, MemberID, CategoryID, ForumID, ThreadID,
     *                   WatchType, WatchOption, WatchStatus, WatchCreationDate, WatchEndDate
     */
    protected static void updateLastSentDate(int watchID, // primary key
                        Timestamp watchLastSentDate)
                        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("UPDATE " + TABLE_NAME + " SET WatchLastSentDate = ?");
        sql.append(" WHERE WatchID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            // // column(s) to update
            statement.setTimestamp(1, watchLastSentDate);

            // primary key column(s)
            statement.setInt(2, watchID);

            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update table Watch where primary key = (" + watchID + ").");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in WatchWebHelper.updateLastSentDate.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static WatchBean getWatch(int watchID)
            throws ObjectNotFoundException, DatabaseException {
            return net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.getBean(watchID);
        }
    */
    /*
     * Included columns: MemberID, CategoryID, ForumID, ThreadID, WatchType,
     *                   WatchOption, WatchStatus, WatchCreationDate, WatchLastSentDate, WatchEndDate
     * Excluded columns: WatchID
     */
    protected static WatchBean getBean(int watchID)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberID, CategoryID, ForumID, ThreadID, WatchType, WatchOption, WatchStatus, WatchCreationDate, WatchLastSentDate, WatchEndDate");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE WatchID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, watchID);
            resultSet = statement.executeQuery();
            if(!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the row in table Watch where primary key = (" + watchID + ").");
            }

            WatchBean bean = new WatchBean();
            // @todo: uncomment the following line(s) as needed
            bean.setWatchID(watchID);
            bean.setMemberID(resultSet.getInt("MemberID"));
            bean.setCategoryID(resultSet.getInt("CategoryID"));
            bean.setForumID(resultSet.getInt("ForumID"));
            bean.setThreadID(resultSet.getInt("ThreadID"));
            bean.setWatchType(resultSet.getInt("WatchType"));
            bean.setWatchOption(resultSet.getInt("WatchOption"));
            bean.setWatchStatus(resultSet.getInt("WatchStatus"));
            bean.setWatchCreationDate(resultSet.getTimestamp("WatchCreationDate"));
            bean.setWatchLastSentDate(resultSet.getTimestamp("WatchLastSentDate"));
            bean.setWatchEndDate(resultSet.getTimestamp("WatchEndDate"));
            return bean;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in WatchWebHelper.getBean(pk).");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static WatchBean getWatch_byAlternateKey_MemberID_CategoryID_ForumID_ThreadID(int memberID, int categoryID, int forumID, int threadID)
            throws ObjectNotFoundException, DatabaseException {
            return net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.getBean_byAlternateKey_MemberID_CategoryID_ForumID_ThreadID(memberID, categoryID, forumID, threadID);
        }
    */
    /*
     * Included columns: WatchID, WatchType, WatchOption, WatchStatus, WatchCreationDate,
     *                   WatchLastSentDate, WatchEndDate
     * Excluded columns: MemberID, CategoryID, ForumID, ThreadID
     */
    protected static WatchBean getBean_byAlternateKey_MemberID_CategoryID_ForumID_ThreadID(int memberID, int categoryID, int forumID, int threadID)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT WatchID, WatchType, WatchOption, WatchStatus, WatchCreationDate, WatchLastSentDate, WatchEndDate");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE MemberID = ? AND CategoryID = ? AND ForumID = ? AND ThreadID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            statement.setInt(2, categoryID);
            statement.setInt(3, forumID);
            statement.setInt(4, threadID);
            resultSet = statement.executeQuery();
            if(!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the row in table Watch where alternate key <MemberID, CategoryID, ForumID, ThreadID> = (" + memberID + ", " + categoryID + ", " + forumID + ", " + threadID + ").");
            }

            WatchBean bean = new WatchBean();
            // @todo: uncomment the following line(s) as needed
            bean.setMemberID(memberID);
            bean.setCategoryID(categoryID);
            bean.setForumID(forumID);
            bean.setThreadID(threadID);
            bean.setWatchID(resultSet.getInt("WatchID"));
            bean.setWatchType(resultSet.getInt("WatchType"));
            bean.setWatchOption(resultSet.getInt("WatchOption"));
            bean.setWatchStatus(resultSet.getInt("WatchStatus"));
            bean.setWatchCreationDate(resultSet.getTimestamp("WatchCreationDate"));
            bean.setWatchLastSentDate(resultSet.getTimestamp("WatchLastSentDate"));
            bean.setWatchEndDate(resultSet.getTimestamp("WatchEndDate"));
            return bean;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in WatchWebHelper.getBean_byAlternateKey_MemberID_CategoryID_ForumID_ThreadID(ak).");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static Collection getWatchs()
            throws DatabaseException {
            return net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.getBeans();
        }
    */
    /*
     * Included columns: WatchID, MemberID, CategoryID, ForumID, ThreadID,
     *                   WatchType, WatchOption, WatchStatus, WatchCreationDate, WatchLastSentDate,
     *                   WatchEndDate
     * Excluded columns:
     */
    protected static Collection getBeans()
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Collection retValue = new ArrayList();
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT WatchID, MemberID, CategoryID, ForumID, ThreadID, WatchType, WatchOption, WatchStatus, WatchCreationDate, WatchLastSentDate, WatchEndDate");
        sql.append(" FROM " + TABLE_NAME);
        //sql.append(" WHERE "); // @todo: uncomment as needed
        //sql.append(" ORDER BY ColumnName ASC|DESC "); // @todo: uncomment as needed
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                WatchBean bean = new WatchBean();
                bean.setWatchID(resultSet.getInt("WatchID"));
                bean.setMemberID(resultSet.getInt("MemberID"));
                bean.setCategoryID(resultSet.getInt("CategoryID"));
                bean.setForumID(resultSet.getInt("ForumID"));
                bean.setThreadID(resultSet.getInt("ThreadID"));
                bean.setWatchType(resultSet.getInt("WatchType"));
                bean.setWatchOption(resultSet.getInt("WatchOption"));
                bean.setWatchStatus(resultSet.getInt("WatchStatus"));
                bean.setWatchCreationDate(resultSet.getTimestamp("WatchCreationDate"));
                bean.setWatchLastSentDate(resultSet.getTimestamp("WatchLastSentDate"));
                bean.setWatchEndDate(resultSet.getTimestamp("WatchEndDate"));
                retValue.add(bean);
            }
            return retValue;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in WatchWebHelper.getBeans.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static int getNumberOfWatchs()
            throws AssertionException, DatabaseException {
            return net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.getNumberOfBeans();
        }
    */
    protected static int getNumberOfBeans()
        throws AssertionException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT Count(*)");
        sql.append(" FROM " + TABLE_NAME);
        //sql.append(" WHERE "); // @todo: uncomment as needed
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            resultSet = statement.executeQuery();
            if (!resultSet.next()) {
                throw new AssertionException("Assertion in WatchWebHelper.getNumberOfBeans.");
            }
            return resultSet.getInt(1);
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in WatchWebHelper.getNumberOfBeans.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/***************************************************************************
 * Customized methods come below
 ***************************************************************************/

    /*
// @todo: copy this method for derived class
        public static Collection getMemberWatchs()
            throws DatabaseException {
            return net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.getMemberBeans();
        }
    */
    /*
     * Included columns: MemberID, WatchLastSentDate
     * Excluded columns: WatchID, CategoryID, ForumID, ThreadID, WatchType,
     *                   WatchOption, WatchStatus, WatchCreationDate, WatchEndDate
     */
    protected static Collection getMemberBeans()
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Collection retValue = new ArrayList();
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT DISTINCT MemberID, MIN(WatchLastSentDate) AS lastsent");// postgreSQL need AS
        sql.append(" FROM " + TABLE_NAME);
        //sql.append(" WHERE "); // @todo: uncomment as needed
        //sql.append(" ORDER BY ColumnName ASC|DESC "); // @todo: uncomment as needed
        sql.append(" GROUP BY MemberID ");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                WatchBean bean = new WatchBean();
                bean.setMemberID(resultSet.getInt("MemberID"));
                bean.setWatchLastSentDate(resultSet.getTimestamp("lastsent"));
                retValue.add(bean);
            }
            return retValue;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in WatchWebHelper.getMemberBeans.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static Collection getWatchs_forMember(int memberID)
            throws DatabaseException {
            return net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.getBeans_forMember(memberID);
        }
    */
    /*
     * Included columns: WatchID, MemberID, CategoryID, ForumID, ThreadID,
     *                   WatchType, WatchOption, WatchStatus, WatchCreationDate, WatchLastSentDate,
     *                   WatchEndDate
     * Excluded columns:
     */
    protected static Collection getBeans_forMember(int memberID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Collection retValue = new ArrayList();
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT WatchID, MemberID, CategoryID, ForumID, ThreadID, WatchType, WatchOption, WatchStatus, WatchCreationDate, WatchLastSentDate, WatchEndDate");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE MemberID = ? ");
        //sql.append(" ORDER BY ColumnName ASC|DESC "); // @todo: uncomment as needed
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                WatchBean bean = new WatchBean();
                bean.setWatchID(resultSet.getInt("WatchID"));
                bean.setMemberID(resultSet.getInt("MemberID"));
                bean.setCategoryID(resultSet.getInt("CategoryID"));
                bean.setForumID(resultSet.getInt("ForumID"));
                bean.setThreadID(resultSet.getInt("ThreadID"));
                bean.setWatchType(resultSet.getInt("WatchType"));
                bean.setWatchOption(resultSet.getInt("WatchOption"));
                bean.setWatchStatus(resultSet.getInt("WatchStatus"));
                bean.setWatchCreationDate(resultSet.getTimestamp("WatchCreationDate"));
                bean.setWatchLastSentDate(resultSet.getTimestamp("WatchLastSentDate"));
                bean.setWatchEndDate(resultSet.getTimestamp("WatchEndDate"));
                retValue.add(bean);
            }
            return retValue;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in WatchWebHelper.getBeans_forMember.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static void updateWatchLastSentDate_forMember(int memberID, // primary key
                            Timestamp watchLastSentDate)
                            throws ObjectNotFoundException, DatabaseException {
            net.myvietnam.mvnplugin.mvnforum.db.WatchWebHelper.updateLastSentDate_forMember(memberID, // primary key
                            watchLastSentDate);
        }
    */
    /*
     * Included columns: WatchLastSentDate
     * Excluded columns: WatchID, MemberID, CategoryID, ForumID, ThreadID,
     *                   WatchType, WatchOption, WatchStatus, WatchCreationDate, WatchEndDate
     */
    protected static void updateLastSentDate_forMember(int memberID,
                        Timestamp watchLastSentDate)
                        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("UPDATE " + TABLE_NAME + " SET WatchLastSentDate = ?");
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            // // column(s) to update
            statement.setTimestamp(1, watchLastSentDate);

            // primary key column(s)
            statement.setInt(2, memberID);

            if (statement.executeUpdate() < 1) {
                throw new ObjectNotFoundException("Cannot update table Watch where primary key = (" + memberID + ").");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in WatchWebHelper.updateLastSentDate.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }


}// end of class WatchWebHelper

