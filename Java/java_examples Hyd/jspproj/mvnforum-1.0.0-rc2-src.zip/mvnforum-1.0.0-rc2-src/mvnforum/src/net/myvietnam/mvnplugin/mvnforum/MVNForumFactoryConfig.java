/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/MVNForumFactoryConfig.java,v 1.3 2003/07/28 08:49:18 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.3 $
 * $Date: 2003/07/28 08:49:18 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Luis Miguel Hernanz <luish@germinus.com>
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum; // Generated package name

import java.util.ResourceBundle;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * Class that loads and makes accesible the factory configuration.
 *
 * @author <a href="luish@germinus.com">Luis Miguel Hernanz</a>
 * @version $Revision: 1.3 $
 */
public class MVNForumFactoryConfig {

    private static Log log = LogFactory.getLog(MVNForumFactoryConfig.class);

    private static final String OPTION_FILE_NAME = "mvnplugin_mvnforum_MVNForumFactoryConfig";

    private static String authenticatorClassName = null;
    private static String memberManagerClassName = "net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper";
    private static String onlineUserFactoryClassName = "net.myvietnam.mvnplugin.mvnforum.auth.OnlineUserFactoryImpl";
    private static String requestProcessorClassName = "net.myvietnam.mvnplugin.mvnforum.RequestProcessorDefault";

    public static String getMemberManagerClassName() {
        return memberManagerClassName;
    }

    public static String getOnlineUserFactoryClassName() {
        return onlineUserFactoryClassName;
    }

    public static String getAuthenticatorClassName() {
        return authenticatorClassName;
    }

    public static String getRequestProcessorClassName() {
        return requestProcessorClassName;
    }

    static {
        try {
            ResourceBundle properties = null;
            try {
                properties = ResourceBundle.getBundle(OPTION_FILE_NAME);
            } catch (Exception ex) {
                // ignore exception
            }
            if (properties != null) {
                memberManagerClassName = properties.getString("member.implementation").trim();
                onlineUserFactoryClassName = properties.getString("onlineUser.implementation").trim();
                authenticatorClassName = properties.getString("authenticator.implementation").trim();
                requestProcessorClassName = properties.getString("requestProcessor.implementation").trim();
            }
        } catch (Exception e) {
            log.error("Error loading the factory properties", e);
        }
    }
}
