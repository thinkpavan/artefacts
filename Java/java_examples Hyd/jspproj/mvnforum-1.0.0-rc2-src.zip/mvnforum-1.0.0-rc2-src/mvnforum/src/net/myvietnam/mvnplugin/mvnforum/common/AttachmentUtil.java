/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/common/AttachmentUtil.java,v 1.1 2003/06/01 19:23:12 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.1 $
 * $Date: 2003/06/01 19:23:12 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.common;

import java.io.File;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.util.FileUtil;
import net.myvietnam.mvnplugin.mvnforum.MVNForumConfig;
import net.myvietnam.mvnplugin.mvnforum.auth.OnlineUserManager;

public class AttachmentUtil {

    private static Log log = LogFactory.getLog(AttachmentUtil.class);

    private OnlineUserManager userManager = OnlineUserManager.getInstance();

    private AttachmentUtil() {
    }

    public static String getAttachFilenameOnDisk(int attachID) {
        String filename = MVNForumConfig.getAttachmentDir() + File.separatorChar + attachID + ".mvn";
        return filename;
    }

    public static void deleteAttachFilenameOnDisk(int attachID) {
        String filename = getAttachFilenameOnDisk(attachID);
        try {
            log.info("About to delete attachment = " + filename);
            FileUtil.deleteFile(filename);
        } catch (Exception ex) {
            log.warn("Cannot delete attachment file " + filename, ex);
            //@todo schedule to delete it later
        }
    }
}
