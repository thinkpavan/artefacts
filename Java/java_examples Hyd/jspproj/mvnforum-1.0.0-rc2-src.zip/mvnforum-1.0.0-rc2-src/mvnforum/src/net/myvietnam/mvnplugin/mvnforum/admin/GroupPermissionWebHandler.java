/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/GroupPermissionWebHandler.java,v 1.10 2003/09/14 14:15:38 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.10 $
 * $Date: 2003/09/14 14:15:38 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.util.ParamUtil;
import net.myvietnam.mvnplugin.mvnforum.auth.*;
import net.myvietnam.mvnplugin.mvnforum.db.GroupPermissionBean;
import net.myvietnam.mvnplugin.mvnforum.db.GroupsBean;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

class GroupPermissionWebHandler {

    private static Log log = LogFactory.getLog(GroupPermissionWebHandler.class);

    private OnlineUserManager onlineUserManager = OnlineUserManager.getInstance();

    GroupPermissionWebHandler() {
    }

    void prepareList(HttpServletRequest request)
        throws DatabaseException, BadInputException, ObjectNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        int groupID = ParamUtil.getParameterInt(request, "group");

        GroupsBean groupsBean = GroupsWebHelper.getGroup(groupID);

        ArrayList beans = (ArrayList)GroupPermissionWebHelper.getGroupPermissions_inGroup(groupID);
        int currentSize = beans.size();
        int[] currentPermissions = new int[currentSize];
        for (int i = 0; i < currentSize; i++) {
            GroupPermissionBean bean = (GroupPermissionBean)beans.get(i);
            currentPermissions[i] = bean.getPermission();
        }

        request.setAttribute("GroupsBean", groupsBean);
        request.setAttribute("CurrentPermissions", currentPermissions);
    }

    void processUpdate(HttpServletRequest request)
        throws CreateException, ObjectNotFoundException, BadInputException, DatabaseException, DuplicateKeyException,
        ForeignKeyNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        String btnAdd = request.getParameter("btnAdd");
        String btnRemove = request.getParameter("btnRemove");

        boolean addAction = false;
        if ((btnAdd != null) && btnAdd.equals("Add")) {
            addAction = true;
        } else if ((btnRemove != null) && btnRemove.equals("Remove")) {
            addAction = false;
        } else {
            throw new BadInputException("No Add or Remove has been specified. Cannot process!");
        }

        int groupID     = ParamUtil.getParameterInt(request, "group");

        if (addAction) {
            log.debug("Add List:" + btnAdd);
            String[] addList = request.getParameterValues("add");
            for (int i = 0; (addList != null) && (i < addList.length); i++) {
                int perm = Integer.parseInt(addList[i]);
                log.debug("perm = " + perm);
                GroupPermissionWebHelper.createGroupPermission(groupID, perm);
            }
        } else {
            log.debug("Remove List:" + btnRemove);
            String[] removeList = request.getParameterValues("remove");
            for (int i = 0; (removeList != null) && (i < removeList.length); i++) {
                int perm = Integer.parseInt(removeList[i]);
                log.debug("perm = " + removeList[i]);
                GroupPermissionWebHelper.deleteGroupPermission(groupID, perm);
            }
        }//else
    }

}
