/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/user/FavoriteThreadWebHandler.java,v 1.6 2003/09/30 16:31:12 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.6 $
 * $Date: 2003/09/30 16:31:12 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.user;

import javax.servlet.http.*;
import java.sql.*;
//import java.util.Collection;
import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.util.ParamUtil;
import net.myvietnam.mvncore.util.DateUtil;
//import net.myvietnam.mvnplugin.mvnforum.db.FavoriteThreadBean;
import net.myvietnam.mvnplugin.mvnforum.db.ThreadBean;
import net.myvietnam.mvnplugin.mvnforum.auth.*;
import net.myvietnam.mvnplugin.mvnforum.MVNForumConfig;

class FavoriteThreadWebHandler {

    private OnlineUserManager userManager = OnlineUserManager.getInstance();

    FavoriteThreadWebHandler() {
    }

    void processAdd(HttpServletRequest request)
        throws BadInputException, CreateException, DatabaseException, DuplicateKeyException, ForeignKeyNotFoundException,
        ObjectNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = userManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();

        int memberID = onlineUser.getMemberID();

        // check to make sure that this user doesnt exceed his favorite max
        int currentFavoriteCount = FavoriteThreadWebHelper.getNumberOfFavoriteThreads_inMember(memberID);
        int maxFavorites = MVNForumConfig.getMaxFavoriteThread();
        if (currentFavoriteCount > maxFavorites) {
            //@todo: choose a better exception class
            throw new BadInputException("You have already use all your favorite quota (" + maxFavorites + ").");
        }

        Timestamp now = DateUtil.getCurrentGMTTimestamp();
        int threadID                    = ParamUtil.getParameterInt(request, "thread");
        Timestamp favoriteCreationDate  = now;
        int favoriteType                = 0;//@todo implement it later
        int favoriteOption              = 0;//@todo implement it later
        int favoriteStatus              = 0;//@todo implement it later

        ThreadBean threadBean = ThreadWebHelper.getThread(threadID);
        int forumID = threadBean.getForumID();

        // now check permission the this user have the readPost permission
        permission.ensureCanReadPost(forumID);

        // has the permission now, then insert to database
        try {
            FavoriteThreadWebHelper.createFavoriteThread(memberID, threadID, forumID,
                                               favoriteCreationDate, favoriteType, favoriteOption,
                                               favoriteStatus);
        } catch (DuplicateKeyException ex) {
            // already add favorite thread, just ignore
        }
    }

    public void processDelete(HttpServletRequest request)
        throws BadInputException, DatabaseException, ObjectNotFoundException,
        AuthenticationException, AssertionException {

        OnlineUser onlineUser = userManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();

        // primary key column(s)
        int memberID = onlineUser.getMemberID();
        int threadID = ParamUtil.getParameterInt(request, "thread");

        FavoriteThreadWebHelper.deleteFavoriteThread(memberID, threadID);
    }
}
