/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/MessageFolderBean.java,v 1.6 2003/09/14 14:15:39 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.6 $
 * $Date: 2003/09/14 14:15:39 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Iterator;

public class MessageFolderBean {
    private String folderName;
    private int memberID;
    private int folderOrder;
    private Timestamp folderCreationDate;
    private Timestamp folderModifiedDate;

    public String getFolderName() {
        return folderName;
    }
    public void setFolderName(String folderName) {
        this.folderName = folderName;
    }

    public int getMemberID() {
        return memberID;
    }
    public void setMemberID(int memberID) {
        this.memberID = memberID;
    }

    public int getFolderOrder() {
        return folderOrder;
    }
    public void setFolderOrder(int folderOrder) {
        this.folderOrder = folderOrder;
    }

    public Timestamp getFolderCreationDate() {
        return folderCreationDate;
    }
    public void setFolderCreationDate(Timestamp folderCreationDate) {
        this.folderCreationDate = folderCreationDate;
    }

    public Timestamp getFolderModifiedDate() {
        return folderModifiedDate;
    }
    public void setFolderModifiedDate(Timestamp folderModifiedDate) {
        this.folderModifiedDate = folderModifiedDate;
    }

    public String getXML() {
        StringBuffer xml = new StringBuffer(1024);
        xml.append("<MessageFolderSection>\n");
        xml.append("  <Rows>\n");
        xml.append("    <Row>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>FolderName</Name>\n");
        xml.append("        <Value>").append(String.valueOf(folderName)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>FolderOrder</Name>\n");
        xml.append("        <Value>").append(String.valueOf(folderOrder)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>FolderCreationDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(folderCreationDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>FolderModifiedDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(folderModifiedDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("    </Row>\n");
        xml.append("  </Rows>\n");
        xml.append("</MessageFolderSection>\n");
        return xml.toString();
    }

    public static String getXML(Collection objMessageFolderBeans) {
        StringBuffer xml = new StringBuffer(1024);
        Iterator iterator = objMessageFolderBeans.iterator();
        xml.append("<MessageFolderSection>\n");
        xml.append("  <Rows>\n");
        while (iterator.hasNext()) {
            MessageFolderBean objMessageFolderBean = (MessageFolderBean)iterator.next();
            xml.append("    <Row>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>FolderName</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMessageFolderBean.folderName)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMessageFolderBean.memberID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>FolderOrder</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMessageFolderBean.folderOrder)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>FolderCreationDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMessageFolderBean.folderCreationDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>FolderModifiedDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMessageFolderBean.folderModifiedDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("    </Row>\n");
        }//while
        xml.append("  </Rows>\n");
        xml.append("</MessageFolderSection>\n");
        return xml.toString();
    }
} //end of class MessageFolderBean
