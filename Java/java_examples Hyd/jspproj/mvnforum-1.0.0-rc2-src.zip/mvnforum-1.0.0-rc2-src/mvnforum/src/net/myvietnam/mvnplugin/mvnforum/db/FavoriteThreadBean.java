/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/FavoriteThreadBean.java,v 1.2 2003/09/09 17:08:20 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.2 $
 * $Date: 2003/09/09 17:08:20 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.sql.*;
import java.util.Collection;//for xml support
import java.util.Iterator;//for xml support

/*
 * Included columns: MemberID, ThreadID, ForumID, FavoriteCreationDate, FavoriteType,
 *                   FavoriteOption, FavoriteStatus
 * Excluded columns:
 */
public class FavoriteThreadBean {
    private int memberID;
    private int threadID;
    private int forumID;
    private Timestamp favoriteCreationDate;
    private int favoriteType;
    private int favoriteOption;
    private int favoriteStatus;

    public int getMemberID() {
        return memberID;
    }
    public void setMemberID(int memberID) {
        this.memberID = memberID;
    }

    public int getThreadID() {
        return threadID;
    }
    public void setThreadID(int threadID) {
        this.threadID = threadID;
    }

    public int getForumID() {
        return forumID;
    }
    public void setForumID(int forumID) {
        this.forumID = forumID;
    }

    public Timestamp getFavoriteCreationDate() {
        return favoriteCreationDate;
    }
    public void setFavoriteCreationDate(Timestamp favoriteCreationDate) {
        this.favoriteCreationDate = favoriteCreationDate;
    }

    public int getFavoriteType() {
        return favoriteType;
    }
    public void setFavoriteType(int favoriteType) {
        this.favoriteType = favoriteType;
    }

    public int getFavoriteOption() {
        return favoriteOption;
    }
    public void setFavoriteOption(int favoriteOption) {
        this.favoriteOption = favoriteOption;
    }

    public int getFavoriteStatus() {
        return favoriteStatus;
    }
    public void setFavoriteStatus(int favoriteStatus) {
        this.favoriteStatus = favoriteStatus;
    }

    public String getXML() {
        StringBuffer xml = new StringBuffer(1024);
        xml.append("<FavoriteThreadSection>\n");
        xml.append("  <Rows>\n");
        xml.append("    <Row>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>FavoriteCreationDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(favoriteCreationDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>FavoriteType</Name>\n");
        xml.append("        <Value>").append(String.valueOf(favoriteType)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>FavoriteOption</Name>\n");
        xml.append("        <Value>").append(String.valueOf(favoriteOption)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>FavoriteStatus</Name>\n");
        xml.append("        <Value>").append(String.valueOf(favoriteStatus)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("    </Row>\n");
        xml.append("  </Rows>\n");
        xml.append("</FavoriteThreadSection>\n");
        return xml.toString();
    }

    public static String getXML(Collection objFavoriteThreadBeans) {
        StringBuffer xml = new StringBuffer(1024);
        Iterator iterator = objFavoriteThreadBeans.iterator();
        xml.append("<FavoriteThreadSection>\n");
        xml.append("  <Rows>\n");
        while (iterator.hasNext()) {
            FavoriteThreadBean objFavoriteThreadBean = (FavoriteThreadBean)iterator.next();
            xml.append("    <Row>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objFavoriteThreadBean.memberID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objFavoriteThreadBean.threadID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objFavoriteThreadBean.forumID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>FavoriteCreationDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objFavoriteThreadBean.favoriteCreationDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>FavoriteType</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objFavoriteThreadBean.favoriteType)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>FavoriteOption</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objFavoriteThreadBean.favoriteOption)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>FavoriteStatus</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objFavoriteThreadBean.favoriteStatus)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("    </Row>\n");
        }//while
        xml.append("  </Rows>\n");
        xml.append("</FavoriteThreadSection>\n");
        return xml.toString();
    }
} //end of class FavoriteThreadBean
