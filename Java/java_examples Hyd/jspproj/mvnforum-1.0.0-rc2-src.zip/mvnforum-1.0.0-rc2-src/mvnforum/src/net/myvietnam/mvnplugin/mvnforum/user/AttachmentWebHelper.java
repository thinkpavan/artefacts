/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/user/AttachmentWebHelper.java,v 1.11 2003/09/16 16:58:25 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.11 $
 * $Date: 2003/09/16 16:58:25 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.user;

import java.sql.*;
import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.db.DBUtils;
import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvnplugin.mvnforum.db.AttachmentBean;

class AttachmentWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.AttachmentWebHelper {

    private static Log log = LogFactory.getLog(AttachmentWebHelper.class);

    // prevent instantiation and inheritance
    private AttachmentWebHelper() {
    }

    public static int createAttachment(int postID, int memberID, String attachFilename,
                        int attachFileSize, String attachMimeType, String attachDesc,
                        String attachCreationIP, Timestamp attachCreationDate, Timestamp attachModifiedDate,
                        int attachDownloadCount, int attachOption, int attachStatus)
                        throws CreateException, DatabaseException, ForeignKeyNotFoundException, ObjectNotFoundException {

        net.myvietnam.mvnplugin.mvnforum.db.AttachmentWebHelper.create(postID, memberID, attachFilename, attachFileSize, attachMimeType, attachDesc, attachCreationIP, attachCreationDate, attachModifiedDate, attachDownloadCount, attachOption, attachStatus);

        int attachID = 0;
        try {
            attachID = findAttachID(postID, memberID, attachCreationDate);
        } catch (ObjectNotFoundException ex) {
            // Hack the Oracle 9i problem
            Timestamp roundTimestamp = new Timestamp((attachCreationDate.getTime()/1000)*1000);
            attachID = findAttachID(postID, memberID, roundTimestamp);
        }
        return attachID;
    }

    public static void deleteAttachment(int attachID)
        throws DatabaseException, ObjectNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.AttachmentWebHelper.delete(attachID);
    }

    public static void deleteAttachments_inPost(int postID)
        throws DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.AttachmentWebHelper.delete_inPost(postID);
    }

    public static AttachmentBean getAttachment(int attachID)
        throws ObjectNotFoundException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.AttachmentWebHelper.getBean(attachID);
    }

    public static Collection getAttachments_inPost(int postID)
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.AttachmentWebHelper.getBeans_inPost(postID);
    }

    public static Collection getAttachments_inThread(int threadID)
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.AttachmentWebHelper.getBeans_inThread(threadID);
    }

    public static int getNumberOfAttachments_inPost(int postID)
        throws AssertionException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.AttachmentWebHelper.getNumberOfBeans_inPost(postID);
    }
    /************************************************
     * Customized methods come below
     ************************************************/

    /**
     * This method should be call only when we can make sure that postID is in database
     */
    public static void increaseDownloadCount(int attachID)
        throws DatabaseException, ObjectNotFoundException {

        Connection connection = null;
        PreparedStatement statement = null;
        String sql = "UPDATE " + TABLE_NAME + " SET AttachDownloadCount = AttachDownloadCount + 1 WHERE AttachID = ?";
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql);
            statement.setInt(1, attachID);
            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update the AttachDownloadCount in table Attachment. Please contact Web site Administrator.");
            }
            //@todo: coi lai cho nay
            // ATTENTION !!!
            setDirty(true);
        } catch (SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error occured when update Attachment: column name = AttachDownloadCount.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

}
