/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/MemberGroupWebHandler.java,v 1.13 2003/10/03 17:49:34 imanic Exp $
 * $Author: imanic $
 * $Revision: 1.13 $
 * $Date: 2003/10/03 17:49:34 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import java.io.*;
import java.sql.Timestamp;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;

import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.util.DateUtil;
import net.myvietnam.mvncore.util.ParamUtil;
import net.myvietnam.mvnplugin.mvnforum.MVNForumConstant;
import net.myvietnam.mvnplugin.mvnforum.auth.*;
import net.myvietnam.mvnplugin.mvnforum.db.GroupsBean;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

class MemberGroupWebHandler {

    private static Log log = LogFactory.getLog(MemberGroupWebHandler.class);

    private OnlineUserManager onlineUserManager = OnlineUserManager.getInstance();

    MemberGroupWebHandler() {
    }

    void processAdd(HttpServletRequest request)
        throws IOException, BadInputException, CreateException, DatabaseException,
        AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        Timestamp now = DateUtil.getCurrentGMTTimestamp();

        int groupID         = ParamUtil.getParameterInt(request, "group");

        // check if the group is one of the reserved groups
        if (groupID == MVNForumConstant.GROUP_ID_OF_REGISTERED_MEMBERS) {
            // actually it could be ok to list member in this group
            throw new AssertionException("Cannot add member to virtual group Registered Members.");
        } else if (groupID <= MVNForumConstant.LAST_RESERVED_GROUP_ID) {
            throw new AssertionException("Cannot add member to a reserved (virtual) group.");
        }

        String memberNames  = ParamUtil.getParameterSafe(request, "MemberNames", true);
        int privilege       = 0;//ParamUtil.getParameterInt(request, "Privilege");

        //log.debug("member names = " + memberNames);
        StringReader stringReader = new StringReader(memberNames);
        BufferedReader reader = new BufferedReader(stringReader);

        String memberName = null;
        while ((memberName = reader.readLine()) != null) {
            //log.debug("name = " + memberName + " length = " + memberName.length());
            memberName = memberName.trim();
            if (memberName.length() > 0) {
                try {
                    MemberGroupWebHelper.createMemberGroup(groupID, memberName, privilege,
                                                now/*creationDate*/, now/*modifiedDate*/);
                } catch (DuplicateKeyException ex) {
                    // already existed, just ignore
                } catch (ForeignKeyNotFoundException ex) {
                    // member not found, just ignore
                }
            }// if memberName is not empty
        }//while
    }

    /*
     * @todo: check if we should reset the GroupOwnerID from Groups table ???
     */
    void processDelete(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        // primary key column(s)
        int groupID = ParamUtil.getParameterInt(request, "group");
        int memberID= ParamUtil.getParameterInt(request, "memberid");

        MemberGroupWebHelper.deleteMemberGroup(groupID, memberID);
    }

    void prepareList_inGroup_limit(HttpServletRequest request)
        throws DatabaseException, BadInputException, ObjectNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        int groupID = ParamUtil.getParameterInt(request, "group");

        // check if the group is one of the reserved groups
        if (groupID == MVNForumConstant.GROUP_ID_OF_REGISTERED_MEMBERS) {
            // actually it could be ok to list member in this group
            throw new AssertionException("Cannot list member in virtual group Registered Members.");
        } else if (groupID <= MVNForumConstant.LAST_RESERVED_GROUP_ID) {
            throw new AssertionException("Cannot list member in a reserved (virtual) group.");
        }

        GroupsBean bean = GroupsWebHelper.getGroup(groupID);
        Collection beans = MemberGroupWebHelper.getMemberGroups_inGroup(groupID);

        request.setAttribute("MemberGroupBeans", beans);
        request.setAttribute("GroupsBean", bean);
    }
}
