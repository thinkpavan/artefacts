/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/PostBean.java,v 1.9 2003/07/28 08:49:18 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.9 $
 * $Date: 2003/07/28 08:49:18 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Iterator;

import net.myvietnam.mvncore.util.StringUtil;

/*
 * Included columns: PostID, ParentPostID, ForumID, ThreadID, MemberID,
 *                   MemberName, LastEditMemberName, PostTopic, PostBody, PostCreationDate,
 *                   PostLastEditDate, PostCreationIP, PostLastEditIP, PostEditCount, PostFormatOption,
 *                   PostOption, PostStatus, PostIcon, PostAttachCount
 * Excluded columns:
 */
public class PostBean {
    private int postID;
    private int parentPostID;
    private int forumID;
    private int threadID;
    private int memberID;
    private String memberName;
    private String lastEditMemberName;
    private String postTopic;
    private String postBody;
    private Timestamp postCreationDate;
    private Timestamp postLastEditDate;
    private String postCreationIP;
    private String postLastEditIP;
    private int postEditCount;
    private int postFormatOption;
    private int postOption;
    private int postStatus;
    private String postIcon;
    private int postAttachCount;

    public int getPostID() {
        return postID;
    }
    public void setPostID(int postID) {
        this.postID = postID;
    }

    public int getParentPostID() {
        return parentPostID;
    }
    public void setParentPostID(int parentPostID) {
        this.parentPostID = parentPostID;
    }

    public int getForumID() {
        return forumID;
    }
    public void setForumID(int forumID) {
        this.forumID = forumID;
    }

    public int getThreadID() {
        return threadID;
    }
    public void setThreadID(int threadID) {
        this.threadID = threadID;
    }

    public int getMemberID() {
        return memberID;
    }
    public void setMemberID(int memberID) {
        this.memberID = memberID;
    }

    public String getMemberName() {
        return memberName;
    }
    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getLastEditMemberName() {
        return lastEditMemberName;
    }
    public void setLastEditMemberName(String lastEditMemberName) {
        this.lastEditMemberName = StringUtil.getEmptyStringIfNull(lastEditMemberName);
    }

    public String getPostTopic() {
        return postTopic;
    }
    public void setPostTopic(String postTopic) {
        this.postTopic = postTopic;
    }

    public String getPostBody() {
        return postBody;
    }
    public void setPostBody(String postBody) {
        this.postBody = postBody;
    }

    public Timestamp getPostCreationDate() {
        return postCreationDate;
    }
    public void setPostCreationDate(Timestamp postCreationDate) {
        this.postCreationDate = postCreationDate;
    }

    public Timestamp getPostLastEditDate() {
        return postLastEditDate;
    }
    public void setPostLastEditDate(Timestamp postLastEditDate) {
        this.postLastEditDate = postLastEditDate;
    }

    public String getPostCreationIP() {
        return postCreationIP;
    }
    public void setPostCreationIP(String postCreationIP) {
        this.postCreationIP = postCreationIP;
    }

    public String getPostLastEditIP() {
        return postLastEditIP;
    }
    public void setPostLastEditIP(String postLastEditIP) {
        this.postLastEditIP = StringUtil.getEmptyStringIfNull(postLastEditIP);
    }

    public int getPostEditCount() {
        return postEditCount;
    }
    public void setPostEditCount(int postEditCount) {
        this.postEditCount = postEditCount;
    }

    public int getPostFormatOption() {
        return postFormatOption;
    }
    public void setPostFormatOption(int postFormatOption) {
        this.postFormatOption = postFormatOption;
    }

    public int getPostOption() {
        return postOption;
    }
    public void setPostOption(int postOption) {
        this.postOption = postOption;
    }

    public int getPostStatus() {
        return postStatus;
    }
    public void setPostStatus(int postStatus) {
        this.postStatus = postStatus;
    }

    public String getPostIcon() {
        return postIcon;
    }
    public void setPostIcon(String postIcon) {
        this.postIcon = StringUtil.getEmptyStringIfNull(postIcon);
    }

    public int getPostAttachCount() {
        return postAttachCount;
    }
    public void setPostAttachCount(int postAttachCount) {
        this.postAttachCount = postAttachCount;
    }

    public String getXML() {
        StringBuffer xml = new StringBuffer(1024);
        xml.append("<PostSection>\n");
        xml.append("  <Rows>\n");
        xml.append("    <Row>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>PostID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(postID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ParentPostID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(parentPostID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberName</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberName)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>LastEditMemberName</Name>\n");
        xml.append("        <Value>").append(String.valueOf(lastEditMemberName)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>PostTopic</Name>\n");
        xml.append("        <Value>").append(String.valueOf(postTopic)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>PostBody</Name>\n");
        xml.append("        <Value>").append(String.valueOf(postBody)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>PostCreationDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(postCreationDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>PostLastEditDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(postLastEditDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>PostCreationIP</Name>\n");
        xml.append("        <Value>").append(String.valueOf(postCreationIP)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>PostLastEditIP</Name>\n");
        xml.append("        <Value>").append(String.valueOf(postLastEditIP)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>PostEditCount</Name>\n");
        xml.append("        <Value>").append(String.valueOf(postEditCount)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>PostFormatOption</Name>\n");
        xml.append("        <Value>").append(String.valueOf(postFormatOption)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>PostOption</Name>\n");
        xml.append("        <Value>").append(String.valueOf(postOption)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>PostStatus</Name>\n");
        xml.append("        <Value>").append(String.valueOf(postStatus)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>PostIcon</Name>\n");
        xml.append("        <Value>").append(String.valueOf(postIcon)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>PostAttachCount</Name>\n");
        xml.append("        <Value>").append(String.valueOf(postAttachCount)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("    </Row>\n");
        xml.append("  </Rows>\n");
        xml.append("</PostSection>\n");
        return xml.toString();
    }

    public static String getXML(Collection objPostBeans) {
        StringBuffer xml = new StringBuffer(1024);
        Iterator iterator = objPostBeans.iterator();
        xml.append("<PostSection>\n");
        xml.append("  <Rows>\n");
        while (iterator.hasNext()) {
            PostBean objPostBean = (PostBean)iterator.next();
            xml.append("    <Row>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>PostID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.postID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ParentPostID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.parentPostID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.forumID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.threadID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.memberID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberName</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.memberName)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>LastEditMemberName</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.lastEditMemberName)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>PostTopic</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.postTopic)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>PostBody</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.postBody)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>PostCreationDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.postCreationDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>PostLastEditDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.postLastEditDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>PostCreationIP</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.postCreationIP)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>PostLastEditIP</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.postLastEditIP)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>PostEditCount</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.postEditCount)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>PostFormatOption</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.postFormatOption)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>PostOption</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.postOption)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>PostStatus</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.postStatus)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>PostIcon</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.postIcon)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>PostAttachCount</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objPostBean.postAttachCount)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("    </Row>\n");
        }//while
        xml.append("  </Rows>\n");
        xml.append("</PostSection>\n");
        return xml.toString();
    }
    /************************************************
     * Customized methods come below
     ************************************************/
    private MemberBean memberBean = null;
    private Collection attachmentBeans = null;

    public MemberBean getMemberBean() {
        return memberBean;
    }
    public void setMemberBean(MemberBean memberBean) {
        this.memberBean = memberBean;
    }

    public Collection getAttachmentBeans() {
        return attachmentBeans;
    }
    public void setAttachmentBeans(Collection attachmentBeans) {
        this.attachmentBeans = attachmentBeans;
    }

} //end of class PostBean
