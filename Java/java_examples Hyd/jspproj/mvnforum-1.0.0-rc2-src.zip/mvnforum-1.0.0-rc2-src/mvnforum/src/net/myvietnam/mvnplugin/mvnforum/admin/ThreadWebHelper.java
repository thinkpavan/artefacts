/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/ThreadWebHelper.java,v 1.8 2003/09/17 15:01:21 imanic Exp $
 * $Author: imanic $
 * $Revision: 1.8 $
 * $Date: 2003/09/17 15:01:21 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 * @author: Igor Manic   imanic@users.sourceforge.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;


import java.sql.*;
//import java.util.Collection; // @todo: uncomment as needed

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//import net.myvietnam.mvncore.db.DBUtils; // @todo: uncomment as needed
import net.myvietnam.mvncore.exception.*;
//import net.myvietnam.mvnplugin.mvnforum.db.ThreadBean;// @todo: uncomment as needed

class ThreadWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.ThreadWebHelper {
   
   // static variable
   private static Log log = LogFactory.getLog(ThreadWebHelper.class);

   // prevent instantiation and inheritance
   private ThreadWebHelper() {
   }

   public static int createThread(int forumID, String memberName, String lastPostMemberName,
                       String threadTopic, String threadBody, int threadVoteCount,
                       int threadVoteTotalStars, Timestamp threadCreationDate, Timestamp threadLastPostDate,
                       int threadType, int threadOption, int threadStatus,
                       int threadHasPoll, int threadViewCount, int threadReplyCount,
                       String threadIcon, int threadDuration)
                       throws ObjectNotFoundException, CreateException, DatabaseException, ForeignKeyNotFoundException {
       net.myvietnam.mvnplugin.mvnforum.db.ThreadWebHelper.create(forumID, memberName, lastPostMemberName, threadTopic, threadBody, threadVoteCount, threadVoteTotalStars, threadCreationDate, threadLastPostDate, threadType, threadOption, threadStatus, threadHasPoll, threadViewCount, threadReplyCount, threadIcon, threadDuration);
       int threadID = 0;
       try {
           threadID = findThreadID(forumID, memberName, threadCreationDate);
       } catch (ObjectNotFoundException ex) {
           // Hack the Oracle 9i problem
           Timestamp roundTimestamp = new Timestamp((threadCreationDate.getTime()/1000)*1000);
           threadID = findThreadID(forumID, memberName, roundTimestamp);
       }
       return threadID;
   }

   public static void deleteThread_inForum(int forumID)
       throws DatabaseException {
       net.myvietnam.mvnplugin.mvnforum.db.ThreadWebHelper.delete_inForum(forumID);
   }

   public static void increaseThreadReplyCount(int threadID) // primary key
       throws ObjectNotFoundException, DatabaseException, ForeignKeyNotFoundException {
       net.myvietnam.mvnplugin.mvnforum.db.ThreadWebHelper.increaseReplyCount(threadID); // primary key
   }

   public static void updateThreadLastPostMemberName(int threadID, // primary key
                       String lastPostMemberName)
                       throws ObjectNotFoundException, DatabaseException, ForeignKeyNotFoundException {
       net.myvietnam.mvnplugin.mvnforum.db.ThreadWebHelper.updateLastPostMemberName(threadID, // primary key
                       lastPostMemberName);
   }

   public static void updateThreadLastPostDate(int threadID, // primary key
                       Timestamp threadLastPostDate)
                       throws ObjectNotFoundException, DatabaseException {
       net.myvietnam.mvnplugin.mvnforum.db.ThreadWebHelper.updateLastPostDate(threadID, // primary key
                       threadLastPostDate);
   }

   public static int getNumberOfThreads_inForum(int forumID)
       throws AssertionException, DatabaseException {
       return net.myvietnam.mvnplugin.mvnforum.db.ThreadWebHelper.getNumberOfBeans_inForum(forumID);
   }
   
   
}
