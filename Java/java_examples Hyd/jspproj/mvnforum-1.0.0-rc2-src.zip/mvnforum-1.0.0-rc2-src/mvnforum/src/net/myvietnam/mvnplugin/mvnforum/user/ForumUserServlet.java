/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/user/ForumUserServlet.java,v 1.18 2003/10/02 17:00:39 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.18 $
 * $Date: 2003/10/02 17:00:39 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.user;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import net.myvietnam.mvncore.db.DBUtils;
import net.myvietnam.mvncore.filter.IPFilter;
import net.myvietnam.mvncore.util.DateUtil;
import net.myvietnam.mvncore.util.TimerUtil;
import net.myvietnam.mvnplugin.mvnforum.*;
import net.myvietnam.mvnplugin.mvnforum.auth.OnlineUser;
import net.myvietnam.mvnplugin.mvnforum.auth.OnlineUserManager;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ForumUserServlet extends HttpServlet {

    private static Log log = LogFactory.getLog(ForumUserServlet.class);

    private UserModuleProcessor userModuleProcessor  = null;
    private static int count = 0;

    /**Initialize global variables*/
    public void init() throws ServletException {
        /*
        if (MVNForumConfig.isShouldRun() == false) {
            throw new ServletException("Cannot init system. Reason = " + MVNForumConfig.getReason());
        }*/

        userModuleProcessor  = new UserModuleProcessor(this);

        // schedule the WatchTask
        if (MVNForumConfig.getEnableWatch()) {
            if (MVNForumConfig.isShouldRun()) {
                log.info("Schedule the WatchTask.");
                WatchTask.getInstance().schedule(DateUtil.MINUTE, DateUtil.HOUR);
            }
        } else {
            log.info("Watch is disabled. Do not schedule the WatchTask.");
        }

        log.info("<<---- ForumUserServlet has been inited.  Detailed info: " + MVNForumInfo.getProductVersion() + " (Build: " + MVNForumInfo.getProductReleaseDate() + ") ---->>");
    }

    /**Process the HTTP Get request*/
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    /**Process the HTTP Post request*/
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    public void process(HttpServletRequest request, HttpServletResponse response)
        throws IOException, ServletException {

        if (MVNForumConfig.isShouldRun() == false) {
            String error = "Cannot init system. Reason : " + MVNForumConfig.getReason();
            request.setAttribute("fatal_error_message", error);
            getServletContext().getRequestDispatcher("/mvnplugin/mvnforum/fatalerror.jsp").forward(request, response);
            return;
        }

        long startTime = 0;
        if (log.isDebugEnabled()) {
            startTime = System.currentTimeMillis();
        }
        count++;
        try {
            if (IPFilter.filter(request) == false) {
                getServletContext().getRequestDispatcher("/mvnplugin/mvnforum/404.jsp").forward(request, response);
                return;
            }

            //request.setCharacterEncoding("utf-8");

            String responseURI = null;
            responseURI = ManagerFactory.getRequestProcessor().preLogin(request, response);

            // This will make sure that the user information is put in
            // the request.
            OnlineUserManager onlineUserManager = OnlineUserManager.getInstance();
            OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);

            if (null == responseURI) {
                responseURI = ManagerFactory.getRequestProcessor().preProcess(request, response);
            }

            if (null == responseURI) {
                // this method should not throw Exception (it must catch all Exceptions)
                responseURI = userModuleProcessor.process(request, response);
            }

            responseURI = ManagerFactory.getRequestProcessor().postProcess(request, response, responseURI);

            if (null != responseURI && !response.isCommitted()) {
                if (responseURI.endsWith(".jsp")) {
                    request.getRequestDispatcher(responseURI).forward(request, response);
                } else {
                    response.sendRedirect(request.getContextPath() + responseURI);
                }
            }
        } catch (Exception e) {
            // so it should never go here
            log.error("Error assertion", e);
        } finally {
            if (log.isDebugEnabled()) {
                long processTime = System.currentTimeMillis() - startTime;
                log.debug("ForumUserServlet processed " + count + " times. Took " + processTime + " miliseconds.\n");
            }
        }
    }// process

    /**
     * Clean up resources
     */
    public void destroy() {
        // This code will release all connections currently pooled.
        // The next call to #getConnection will recreate the pool.
        DBUtils.closeAllConnections();

        //finally, cancel the TimerUtil
        TimerUtil.getInstance().cancel();
        log.info("<<---- ForumUserServlet has been destroyed. ---->>");
    }
}
