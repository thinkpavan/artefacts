/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/MemberBean.java,v 1.11 2003/09/14 14:15:39 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.11 $
 * $Date: 2003/09/14 14:15:39 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Iterator;

import net.myvietnam.mvncore.security.Encoder;
import net.myvietnam.mvncore.util.*;

/*
 * Included columns: MemberID, MemberName, MemberFirstEmail, MemberEmail, MemberEmailVisible,
 *                   MemberNameVisible, MemberFirstIP, MemberLastIP, MemberViewCount, MemberPostCount,
 *                   MemberCreationDate, MemberModifiedDate, MemberLastLogon, MemberOption, MemberStatus,
 *                   MemberActivateCode, MemberMessageCount, MemberMessageOption, MemberPostsPerPage, MemberWarnCount,
 *                   MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle, MemberTimeZone,
 *                   MemberSignature, MemberAvatar, MemberSkin, MemberLanguage, MemberFirstname,
 *                   MemberLastname, MemberGender, MemberBirthday, MemberAddress, MemberCity,
 *                   MemberState, MemberCountry, MemberPhone, MemberMobile, MemberFax,
 *                   MemberCareer, MemberHomepage, MemberYahoo, MemberAol, MemberIcq,
 *                   MemberMsn, MemberCoolLink1, MemberCoolLink2
 * Excluded columns: MemberPassword, MemberTempPassword
 */
public class MemberBean {
    public static final int MEMBER_STATUS_ENABLE  = 0;
    public static final int MEMBER_STATUS_DISABLE = 1;

    public static final String MEMBER_ACTIVATECODE_ACTIVATED = "activated";

    private int memberID;
    private String memberName;
    private String memberFirstEmail;
    private String memberEmail;
    private int memberEmailVisible;
    private int memberNameVisible;
    private String memberFirstIP;
    private String memberLastIP;
    private int memberViewCount;
    private int memberPostCount;
    private Timestamp memberCreationDate;
    private Timestamp memberModifiedDate;
    private Timestamp memberLastLogon;
    private int memberOption;
    private int memberStatus;
    private String memberActivateCode;
    private int memberMessageCount;
    private int memberMessageOption;
    private int memberPostsPerPage;
    private int memberWarnCount;
    private int memberVoteCount;
    private int memberVoteTotalStars;
    private int memberRewardPoints;
    private String memberTitle;
    private int memberTimeZone;
    private String memberSignature;
    private String memberAvatar;
    private String memberSkin;
    private String memberLanguage;
    private String memberFirstname;
    private String memberLastname;
    private int memberGender;
    private Date memberBirthday;
    private String memberAddress;
    private String memberCity;
    private String memberState;
    private String memberCountry;
    private String memberPhone;
    private String memberMobile;
    private String memberFax;
    private String memberCareer;
    private String memberHomepage;
    private String memberYahoo;
    private String memberAol;
    private String memberIcq;
    private String memberMsn;
    private String memberCoolLink1;
    private String memberCoolLink2;

    public int getMemberID() {
        return memberID;
    }
    public void setMemberID(int memberID) {
        this.memberID = memberID;
    }

    public String getMemberName() {
        return memberName;
    }
    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberFirstEmail() {
        return memberFirstEmail;
    }
    public void setMemberFirstEmail(String memberFirstEmail) {
        this.memberFirstEmail = memberFirstEmail;
    }

    public String getMemberEmail() {
        return memberEmail;
    }
    public void setMemberEmail(String memberEmail) {
        this.memberEmail = memberEmail;
    }

    public int getMemberEmailVisible() {
        return memberEmailVisible;
    }
    public void setMemberEmailVisible(int memberEmailVisible) {
        this.memberEmailVisible = memberEmailVisible;
    }

    public int getMemberNameVisible() {
        return memberNameVisible;
    }
    public void setMemberNameVisible(int memberNameVisible) {
        this.memberNameVisible = memberNameVisible;
    }

    public String getMemberFirstIP() {
        return memberFirstIP;
    }
    public void setMemberFirstIP(String memberFirstIP) {
        this.memberFirstIP = memberFirstIP;
    }

    public String getMemberLastIP() {
        return memberLastIP;
    }
    public void setMemberLastIP(String memberLastIP) {
        this.memberLastIP = memberLastIP;
    }

    public int getMemberViewCount() {
        return memberViewCount;
    }
    public void setMemberViewCount(int memberViewCount) {
        this.memberViewCount = memberViewCount;
    }

    public int getMemberPostCount() {
        return memberPostCount;
    }
    public void setMemberPostCount(int memberPostCount) {
        this.memberPostCount = memberPostCount;
    }

    public Timestamp getMemberCreationDate() {
        return memberCreationDate;
    }
    public void setMemberCreationDate(Timestamp memberCreationDate) {
        this.memberCreationDate = memberCreationDate;
    }

    public Timestamp getMemberModifiedDate() {
        return memberModifiedDate;
    }
    public void setMemberModifiedDate(Timestamp memberModifiedDate) {
        this.memberModifiedDate = memberModifiedDate;
    }

    public Timestamp getMemberLastLogon() {
        return memberLastLogon;
    }
    public void setMemberLastLogon(Timestamp memberLastLogon) {
        this.memberLastLogon = memberLastLogon;
    }

    public int getMemberOption() {
        return memberOption;
    }
    public void setMemberOption(int memberOption) {
        this.memberOption = memberOption;
    }

    public int getMemberStatus() {
        return memberStatus;
    }
    public void setMemberStatus(int memberStatus) {
        this.memberStatus = memberStatus;
    }

    public String getMemberActivateCode() {
        return memberActivateCode;
    }
    public void setMemberActivateCode(String memberActivateCode) {
        this.memberActivateCode = StringUtil.getEmptyStringIfNull(memberActivateCode);
    }

    public int getMemberMessageCount() {
        return memberMessageCount;
    }
    public void setMemberMessageCount(int memberMessageCount) {
        this.memberMessageCount = memberMessageCount;
    }

    public int getMemberMessageOption() {
        return memberMessageOption;
    }
    public void setMemberMessageOption(int memberMessageOption) {
        this.memberMessageOption = memberMessageOption;
    }

    public int getMemberPostsPerPage() {
        return memberPostsPerPage;
    }
    public void setMemberPostsPerPage(int memberPostsPerPage) {
        this.memberPostsPerPage = memberPostsPerPage;
    }

    public int getMemberWarnCount() {
        return memberWarnCount;
    }
    public void setMemberWarnCount(int memberWarnCount) {
        this.memberWarnCount = memberWarnCount;
    }

    public int getMemberVoteCount() {
        return memberVoteCount;
    }
    public void setMemberVoteCount(int memberVoteCount) {
        this.memberVoteCount = memberVoteCount;
    }

    public int getMemberVoteTotalStars() {
        return memberVoteTotalStars;
    }
    public void setMemberVoteTotalStars(int memberVoteTotalStars) {
        this.memberVoteTotalStars = memberVoteTotalStars;
    }

    public int getMemberRewardPoints() {
        return memberRewardPoints;
    }
    public void setMemberRewardPoints(int memberRewardPoints) {
        this.memberRewardPoints = memberRewardPoints;
    }

    public String getMemberTitle() {
        return memberTitle;
    }
    public void setMemberTitle(String memberTitle) {
        this.memberTitle = StringUtil.getEmptyStringIfNull(memberTitle);
    }

    public int getMemberTimeZone() {
        return memberTimeZone;
    }
    public void setMemberTimeZone(int memberTimeZone) {
        this.memberTimeZone = memberTimeZone;
    }

    public String getMemberSignature() {
        return memberSignature;
    }
    public void setMemberSignature(String memberSignature) {
        this.memberSignature = StringUtil.getEmptyStringIfNull(memberSignature);
    }

    public String getMemberAvatar() {
        if (memberAvatar.length() > 0) {
            if (memberAvatar.startsWith("/mvnplugin")) {
                // no context prefix, so we prepend the contextPath
                return ParamUtil.getContextPath() + memberAvatar;
            }
        }
        return memberAvatar;
    }
    public void setMemberAvatar(String memberAvatar) {
        this.memberAvatar = StringUtil.getEmptyStringIfNull(memberAvatar);
    }

    public String getMemberSkin() {
        return memberSkin;
    }
    public void setMemberSkin(String memberSkin) {
        this.memberSkin = StringUtil.getEmptyStringIfNull(memberSkin);
    }

    public String getMemberLanguage() {
        return memberLanguage;
    }
    public void setMemberLanguage(String memberLanguage) {
        this.memberLanguage = StringUtil.getEmptyStringIfNull(memberLanguage);
    }

    public String getMemberFirstname() {
        return memberFirstname;
    }
    public void setMemberFirstname(String memberFirstname) {
        this.memberFirstname = memberFirstname;
    }

    public String getMemberLastname() {
        return memberLastname;
    }
    public void setMemberLastname(String memberLastname) {
        this.memberLastname = memberLastname;
    }

    public int getMemberGender() {
        return memberGender;
    }
    public void setMemberGender(int memberGender) {
        this.memberGender = memberGender;
    }

    public Date getMemberBirthday() {
        return memberBirthday;
    }
    public void setMemberBirthday(Date memberBirthday) {
        this.memberBirthday = memberBirthday;
    }

    public String getMemberAddress() {
        return memberAddress;
    }
    public void setMemberAddress(String memberAddress) {
        this.memberAddress = StringUtil.getEmptyStringIfNull(memberAddress);
    }

    public String getMemberCity() {
        return memberCity;
    }
    public void setMemberCity(String memberCity) {
        this.memberCity = StringUtil.getEmptyStringIfNull(memberCity);
    }

    public String getMemberState() {
        return memberState;
    }
    public void setMemberState(String memberState) {
        this.memberState = StringUtil.getEmptyStringIfNull(memberState);
    }

    public String getMemberCountry() {
        return memberCountry;
    }
    public void setMemberCountry(String memberCountry) {
        this.memberCountry = StringUtil.getEmptyStringIfNull(memberCountry);
    }

    public String getMemberPhone() {
        return memberPhone;
    }
    public void setMemberPhone(String memberPhone) {
        this.memberPhone = StringUtil.getEmptyStringIfNull(memberPhone);
    }

    public String getMemberMobile() {
        return memberMobile;
    }
    public void setMemberMobile(String memberMobile) {
        this.memberMobile = StringUtil.getEmptyStringIfNull(memberMobile);
    }

    public String getMemberFax() {
        return memberFax;
    }
    public void setMemberFax(String memberFax) {
        this.memberFax = StringUtil.getEmptyStringIfNull(memberFax);
    }

    public String getMemberCareer() {
        return memberCareer;
    }
    public void setMemberCareer(String memberCareer) {
        this.memberCareer = StringUtil.getEmptyStringIfNull(memberCareer);
    }

    public String getMemberHomepage() {
        return memberHomepage;
    }
    public void setMemberHomepage(String memberHomepage) {
        this.memberHomepage = StringUtil.getEmptyStringIfNull(memberHomepage);
    }

    public String getMemberYahoo() {
        return memberYahoo;
    }
    public void setMemberYahoo(String memberYahoo) {
        this.memberYahoo = StringUtil.getEmptyStringIfNull(memberYahoo);
    }

    public String getMemberAol() {
        return memberAol;
    }
    public void setMemberAol(String memberAol) {
        this.memberAol = StringUtil.getEmptyStringIfNull(memberAol);
    }

    public String getMemberIcq() {
        return memberIcq;
    }
    public void setMemberIcq(String memberIcq) {
        this.memberIcq = StringUtil.getEmptyStringIfNull(memberIcq);
    }

    public String getMemberMsn() {
        return memberMsn;
    }
    public void setMemberMsn(String memberMsn) {
        this.memberMsn = StringUtil.getEmptyStringIfNull(memberMsn);
    }

    public String getMemberCoolLink1() {
        return memberCoolLink1;
    }
    public void setMemberCoolLink1(String memberCoolLink1) {
        this.memberCoolLink1 = StringUtil.getEmptyStringIfNull(memberCoolLink1);
    }

    public String getMemberCoolLink2() {
        return memberCoolLink2;
    }
    public void setMemberCoolLink2(String memberCoolLink2) {
        this.memberCoolLink2 = StringUtil.getEmptyStringIfNull(memberCoolLink2);
    }

    public String getXML() {
        StringBuffer xml = new StringBuffer(1024);
        xml.append("<MemberSection>\n");
        xml.append("  <Rows>\n");
        xml.append("    <Row>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberName</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberName)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberFirstEmail</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberFirstEmail)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberEmail</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberEmail)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberEmailVisible</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberEmailVisible)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberNameVisible</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberNameVisible)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberFirstIP</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberFirstIP)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberLastIP</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberLastIP)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberViewCount</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberViewCount)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberPostCount</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberPostCount)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberCreationDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberCreationDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberModifiedDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberModifiedDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberLastLogon</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberLastLogon)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberOption</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberOption)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberStatus</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberStatus)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberActivateCode</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberActivateCode)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberMessageCount</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberMessageCount)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberMessageOption</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberMessageOption)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberPostsPerPage</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberPostsPerPage)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberWarnCount</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberWarnCount)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberVoteCount</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberVoteCount)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberVoteTotalStars</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberVoteTotalStars)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberRewardPoints</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberRewardPoints)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberTitle</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberTitle)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberTimeZone</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberTimeZone)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberSignature</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberSignature)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberAvatar</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberAvatar)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberSkin</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberSkin)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberLanguage</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberLanguage)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberFirstname</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberFirstname)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberLastname</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberLastname)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberGender</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberGender)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberBirthday</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberBirthday)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberAddress</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberAddress)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberCity</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberCity)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberState</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberState)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberCountry</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberCountry)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberPhone</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberPhone)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberMobile</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberMobile)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberFax</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberFax)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberCareer</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberCareer)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberHomepage</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberHomepage)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberYahoo</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberYahoo)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberAol</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberAol)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberIcq</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberIcq)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberMsn</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberMsn)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberCoolLink1</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberCoolLink1)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberCoolLink2</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberCoolLink2)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("    </Row>\n");
        xml.append("  </Rows>\n");
        xml.append("</MemberSection>\n");
        return xml.toString();
    }

    public static String getXML(Collection objMemberBeans) {
        StringBuffer xml = new StringBuffer(1024);
        Iterator iterator = objMemberBeans.iterator();
        xml.append("<MemberSection>\n");
        xml.append("  <Rows>\n");
        while (iterator.hasNext()) {
            MemberBean objMemberBean = (MemberBean)iterator.next();
            xml.append("    <Row>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberName</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberName)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberFirstEmail</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberFirstEmail)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberEmail</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberEmail)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberEmailVisible</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberEmailVisible)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberNameVisible</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberNameVisible)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberFirstIP</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberFirstIP)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberLastIP</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberLastIP)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberViewCount</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberViewCount)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberPostCount</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberPostCount)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberCreationDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberCreationDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberModifiedDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberModifiedDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberLastLogon</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberLastLogon)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberOption</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberOption)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberStatus</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberStatus)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberActivateCode</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberActivateCode)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberMessageCount</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberMessageCount)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberMessageOption</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberMessageOption)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberPostsPerPage</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberPostsPerPage)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberWarnCount</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberWarnCount)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberVoteCount</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberVoteCount)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberVoteTotalStars</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberVoteTotalStars)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberRewardPoints</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberRewardPoints)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberTitle</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberTitle)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberTimeZone</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberTimeZone)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberSignature</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberSignature)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberAvatar</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberAvatar)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberSkin</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberSkin)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberLanguage</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberLanguage)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberFirstname</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberFirstname)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberLastname</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberLastname)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberGender</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberGender)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberBirthday</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberBirthday)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberAddress</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberAddress)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberCity</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberCity)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberState</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberState)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberCountry</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberCountry)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberPhone</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberPhone)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberMobile</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberMobile)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberFax</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberFax)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberCareer</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberCareer)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberHomepage</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberHomepage)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberYahoo</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberYahoo)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberAol</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberAol)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberIcq</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberIcq)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberMsn</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberMsn)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberCoolLink1</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberCoolLink1)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberCoolLink2</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objMemberBean.memberCoolLink2)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("    </Row>\n");
        }//while
        xml.append("  </Rows>\n");
        xml.append("</MemberSection>\n");
        return xml.toString();
    }

    /////////////////////////////////////////////////////////////////
    // utility methods
    /*
     * @todo : review these methods
     */
    public String getMemberGenderString() {
        if (memberGender == 1) return "Male";
        return "Female";
    }

    public String getMemberHomepage_http() {
        if (memberHomepage == null) memberHomepage = "";
        return Encoder.filterUrl(memberHomepage);
        /*
        String ret = memberHomepage.toLowerCase();
        if ( (ret.length() > 0) && (!ret.startsWith("http://")) ) {
            ret = "http://" + ret;
        }
        return ret;
        */
    }

    public String getMemberCoolLink1_http() {
        if (memberCoolLink1 == null) memberCoolLink1 = "";
        return Encoder.filterUrl(memberCoolLink1);
        /*
        String ret = memberCoolLink1.toLowerCase();
        if ( (ret.length() > 0) && (!ret.startsWith("http://")) ) {
            ret = "http://" + ret;
        }
        return ret;
        */
    }

    public String getMemberCoolLink2_http() {
        if (memberCoolLink2 == null) memberCoolLink2 = "";
        return Encoder.filterUrl(memberCoolLink2);
        /*
        String ret = memberCoolLink2.toLowerCase();
        if ( (ret.length() > 0) && (!ret.startsWith("http://")) ) {
            ret = "http://" + ret;
        }
        return ret;
        */
    }

    public String getMemberCreationDate_short() {
        return DateUtil.getDateDDMMYYYY(memberCreationDate);
    }

} //end of class MemberBean


