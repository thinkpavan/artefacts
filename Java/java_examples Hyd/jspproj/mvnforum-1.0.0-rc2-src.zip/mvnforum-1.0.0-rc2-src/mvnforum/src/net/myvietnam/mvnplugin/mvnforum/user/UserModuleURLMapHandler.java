/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/user/UserModuleURLMapHandler.java,v 1.9 2003/10/15 18:27:20 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.9 $
 * $Date: 2003/10/15 18:27:20 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.user;

import javax.servlet.http.HttpServletRequest;
import net.myvietnam.mvncore.exception.MissingURLMapEntryException;
import net.myvietnam.mvnplugin.mvnforum.URLMap;
import net.myvietnam.mvnplugin.mvnforum.MyUtil;

class UserModuleURLMapHandler {

    UserModuleURLMapHandler() {
    }

    /**
     * We must pass the requestURI to this method, instead of from request,
     * because requestURI may be changed from Processor before call this method
     * NOTE: Currently we dont use the param request
     */
    public URLMap getMap(String requestURI, HttpServletRequest request, String localeName)
        throws MissingURLMapEntryException {

        localeName = MyUtil.getLocaleNameAndSlash(localeName);

        URLMap map = new URLMap();

        if (requestURI.equals("/error")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/error.jsp");
        } else if (requestURI.equals("") || requestURI.equals("/")) {
            map.setResponse(UserModuleConfig.URL_PATTERN + "/index");
        } else if (requestURI.equals("/index")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/listforums.jsp");//index.jsp
        } else if (requestURI.equals("/listonlineusers")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/listonlineusers.jsp");

        } else if (requestURI.equals("/listforums")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/listforums.jsp");
        } else if (requestURI.equals("/listthreads")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/listthreads.jsp");
        } else if (requestURI.equals("/listrecentthreads")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/listrecentthreads.jsp");

        } else if (requestURI.equals("/addpost")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/addpost.jsp");
        } else if (requestURI.equals("/addpostprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/addpostsuccess.jsp");
        } else if (requestURI.equals("/editpost")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/addpost.jsp");//editpost.jsp
        } else if (requestURI.equals("/updatepost")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/updatepostsuccess.jsp");
        } else if (requestURI.equals("/printpost")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/printpost.jsp");
        } else if (requestURI.equals("/deletepost")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/deletepost.jsp");
        } else if (requestURI.equals("/deletepostprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/deletepostsuccess.jsp");
        } else if (requestURI.equals("/deleteownpost")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/deleteownpost.jsp");
        } else if (requestURI.equals("/deleteownpostprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/deleteownpostsuccess.jsp");

        } else if (requestURI.equals("/addattachment")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/addattachment.jsp");
        } else if (requestURI.equals("/addattachmentprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/addattachmentsuccess.jsp");
        } else if (requestURI.equals("/deleteattachment")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/deleteattachment.jsp");
        } else if (requestURI.equals("/deleteattachmentprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/deleteattachmentsuccess.jsp");

        } else if (requestURI.equals("/viewthread")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/viewthread.jsp");
        } else if (requestURI.equals("/printthread")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/printthread.jsp");

        } else if (requestURI.equals("/deletethread")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/deletethread.jsp");

        } else if (requestURI.equals("/movethread")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/movethread.jsp");
        } else if (requestURI.equals("/movethreadprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/movethreadsuccess.jsp");

        } else if (requestURI.equals("/deletethreadprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/deletethreadsuccess.jsp");
        } else if (requestURI.equals("/viewmember")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/viewmember.jsp");
        } else if (requestURI.equals("/listmembers")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/listmembers.jsp");
        } else if (requestURI.equals("/editmember")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/editmember.jsp");
        } else if (requestURI.equals("/updatemember")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/updatemembersuccess.jsp");

        } else if (requestURI.equals("/login")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/login.jsp");
        } else if (requestURI.equals("/loginprocess")) {
            //map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/loginsuccess.jsp");
            map.setResponse(UserModuleConfig.URL_PATTERN + "/index");
        } else if (requestURI.equals("/logout")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/login.jsp");
        } else if (requestURI.equals("/deletecookieprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/deletecookiesuccess.jsp");

        } else if (requestURI.equals("/rss")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/rss.jsp");
        } else if (requestURI.equals("/help")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/help.jsp");
        } else if (requestURI.equals("/docs")) {
            map.setResponse("/mvnplugin/mvnforum/docs/mvnforum.html");
        } else if (requestURI.equals("/faq")) {
            map.setResponse("/mvnplugin/mvnforum/docs/mvnFaq.html");
        } else if (requestURI.equals("/search")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/search.jsp");
        } else if (requestURI.equals("/searchprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/searchresult.jsp");
        } else if (requestURI.equals("/registermember")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/addmember.jsp");
        } else if (requestURI.equals("/registermemberprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/addmembersuccess.jsp");

        } else if (requestURI.equals("/myprofile")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/myprofile.jsp");
        } else if (requestURI.equals("/changepassword")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/changepassword.jsp");
        } else if (requestURI.equals("/changepasswordprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/changepasswordsuccess.jsp");
        } else if (requestURI.equals("/changeemail")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/changeemail.jsp");
        } else if (requestURI.equals("/changeemailprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/changeemailsuccess.jsp");
        } else if (requestURI.equals("/changesignature")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/changesignature.jsp");
        } else if (requestURI.equals("/changesignatureprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/changesignaturesuccess.jsp");

        } else if (requestURI.equals("/changeavatar")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/changeavatar.jsp");
        } else if (requestURI.equals("/uploadavatar")) {
            map.setResponse(UserModuleConfig.URL_PATTERN + "/myprofile");
        } else if (requestURI.equals("/updateavatar")) {
            map.setResponse(UserModuleConfig.URL_PATTERN + "/myprofile");
        } else if (requestURI.equals("/mywatch")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/mywatch.jsp");
        } else if (requestURI.equals("/addwatch")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/addwatch.jsp");
        } else if (requestURI.equals("/addwatchprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/addwatchsuccess.jsp");
        } else if (requestURI.equals("/deletewatchprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/deletewatchsuccess.jsp");

        } else if (requestURI.equals("/myfavoritethread")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/myfavoritethread.jsp");
        } else if (requestURI.equals("/addfavoritethreadprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/addfavoritethreadsuccess.jsp");
        } else if (requestURI.equals("/deletefavoritethreadprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/deletefavoritethreadsuccess.jsp");

        } else if (requestURI.equals("/iforgotpasswords")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/forgotpassword.jsp");
        } else if (requestURI.equals("/forgotpasswordprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/forgotpasswordsuccess.jsp");
        } else if (requestURI.equals("/resetpassword")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/resetpassword.jsp");
        } else if (requestURI.equals("/resetpasswordprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/resetpasswordsuccess.jsp");

        } else if (requestURI.equals("/sendactivationcode")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/sendactivationcode.jsp");
        } else if (requestURI.equals("/sendactivationcodeprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/sendactivationcodesuccess.jsp");
        } else if (requestURI.equals("/activatemember")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/activatemember.jsp");
        } else if (requestURI.equals("/activatememberprocess")) {
            map.setResponse("/mvnplugin/mvnforum/user" + localeName + "/activatemembersuccess.jsp");
        }

        // unknown module, we throw an exception
        if (map.getResponse() == null) {
            String errorMessage = "Cannot find matching entry in URLMap for '" + requestURI + "'. Please contact the administrator.";
            throw new MissingURLMapEntryException(errorMessage);
        }
        return map;
    }
}
