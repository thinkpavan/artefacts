/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/MemberDAO.java,v 1.7 2003/10/04 02:25:31 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.7 $
 * $Date: 2003/10/04 02:25:31 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Luis Miguel Hernanz <luish@germinus.com>
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;

import net.myvietnam.mvncore.exception.AssertionException;
import net.myvietnam.mvncore.exception.CreateException;
import net.myvietnam.mvncore.exception.DatabaseException;
import net.myvietnam.mvncore.exception.DuplicateKeyException;
import net.myvietnam.mvncore.exception.ObjectNotFoundException;

/**
 * Interface to access to the user data.
 *
 * @author <a href="luish@germinus.com">Luis Miguel Hernanz</a>
 * @version $Revision: 1.7 $
 */
public interface MemberDAO {

    public void findByPrimaryKey(int memberID)
        throws ObjectNotFoundException, DatabaseException;

    public void findByAlternateKey_MemberName(String memberName)
        throws ObjectNotFoundException, DatabaseException;

    public void findByAlternateKey_MemberEmail(String memberEmail)
        throws ObjectNotFoundException, DatabaseException;

    public void deleteByPrimaryKey(int memberID)
        throws DatabaseException;

    public void create(String memberName,
                       String memberPassword,
                       String memberFirstEmail,
                       String memberEmail,
                       int memberEmailVisible,
                       int memberNameVisible,
                       String memberFirstIP,
                       String memberLastIP,
                       int memberViewCount,
                       int memberPostCount,
                       Timestamp memberCreationDate,
                       Timestamp memberModifiedDate,
                       Timestamp memberLastLogon,
                       int memberOption,
                       int memberStatus,
                       String memberActivateCode,
                       String memberTempPassword,
                       int memberMessageCount,
                       int memberMessageOption,
                       int memberPostsPerPage,
                       int memberWarnCount,
                       int memberVoteCount,
                       int memberVoteTotalStars,
                       int memberRewardPoints,
                       String memberTitle,
                       int memberTimeZone,
                       String memberSignature,
                       String memberAvatar,
                       String memberSkin,
                       String memberLanguage,
                       String memberFirstname,
                       String memberLastname,
                       int memberGender,
                       Date memberBirthday,
                       String memberAddress,
                       String memberCity,
                       String memberState,
                       String memberCountry,
                       String memberPhone,
                       String memberMobile,
                       String memberFax,
                       String memberCareer,
                       String memberHomepage,
                       String memberYahoo,
                       String memberAol,
                       String memberIcq,
                       String memberMsn,
                       String memberCoolLink1,
                       String memberCoolLink2)
        throws CreateException, DatabaseException, DuplicateKeyException;


    public void update(int memberID, // primary key
                       int memberEmailVisible,
                       int memberNameVisible,
                       Timestamp memberModifiedDate,
                       int memberOption,
                       int memberStatus,
                       int memberMessageOption,
                       int memberPostsPerPage,
                       int memberTimeZone,
                       String memberSkin,
                       String memberLanguage,
                       String memberFirstname,
                       String memberLastname,
                       int memberGender,
                       Date memberBirthday,
                       String memberAddress,
                       String memberCity,
                       String memberState,
                       String memberCountry,
                       String memberPhone,
                       String memberMobile,
                       String memberFax,
                       String memberCareer,
                       String memberHomepage,
                       String memberYahoo,
                       String memberAol,
                       String memberIcq,
                       String memberMsn,
                       String memberCoolLink1,
                       String memberCoolLink2)
        throws ObjectNotFoundException, DatabaseException;

    public void updateEmail(int memberID, // primary key
                            String memberEmail)
        throws ObjectNotFoundException, DatabaseException, DuplicateKeyException;

    public void updatePassword(int memberID, // primary key
                               String memberPassword)
        throws ObjectNotFoundException, DatabaseException;

    public void updateTempPassword(int memberID, // primary key
                                   String memberTempPassword)
        throws ObjectNotFoundException, DatabaseException;

    public void updateActivateCode(int memberID, // primary key
                                   String memberActivateCode)
        throws ObjectNotFoundException, DatabaseException;

    public void updateAvatar(int memberID, // primary key
                             String memberAvatar)
        throws ObjectNotFoundException, DatabaseException;

    public void updateSignature(int memberID, // primary key
                                String memberSignature)
        throws ObjectNotFoundException, DatabaseException;

    public void updateTitle(int memberID, // primary key
                            String memberTitle)
        throws ObjectNotFoundException, DatabaseException;

    public void updateLastLogon(int memberID, // primary key
                                Timestamp memberLastLogon)
        throws ObjectNotFoundException, DatabaseException;

    public String getPassword(int memberID)
        throws ObjectNotFoundException, DatabaseException;

    public String getTempPassword(int memberID)
        throws ObjectNotFoundException, DatabaseException;

    public String getActivateCode(int memberID)
        throws ObjectNotFoundException, DatabaseException;

    public MemberBean getBean_forViewCurrentMember(int memberID)
        throws ObjectNotFoundException, DatabaseException;

    public MemberBean getBean_forEditCurrentMember(int memberID)
        throws ObjectNotFoundException, DatabaseException;

    public MemberBean getBean_forPublic(int memberID)
        throws ObjectNotFoundException, DatabaseException;

    public Collection getBeans_forPublic() throws DatabaseException;

    public int getNumberOfBeans()
        throws AssertionException, DatabaseException;

    /************************************************
     * Customized methods come below
     ************************************************/
    public int getMemberIDFromMemberName(String memberName)
        throws ObjectNotFoundException, DatabaseException;

    /* @todo check if this method work with other DBMS other than MySql (check case-sensitive) */
    public int getMemberIDFromMemberEmail(String memberEmail)
        throws ObjectNotFoundException, DatabaseException;

    public Collection getBeans_withSortSupport_limit_mysql(int offset,
                                                           int rowsToReturn,
                                                           String sort,
                                                           String order)
        throws IllegalArgumentException, DatabaseException;

    public Collection getBeans_withSortSupport_limit_noscroll(int offset,
                                                              int rowsToReturn,
                                                              String sort,
                                                              String order)
        throws IllegalArgumentException, DatabaseException;

    public Collection getBeans_withSortSupport_limit_general(int offset,
                                                             int rowsToReturn,
                                                             String sort,
                                                             String order)
        throws IllegalArgumentException, DatabaseException;

    public void updateStatus(int memberID, // primary key
                             int memberStatus)
        throws ObjectNotFoundException, DatabaseException;

    /**
     * This method should be call only when we can make sure that memberID is in database
     */
    public void increaseViewCount(int memberID)
        throws DatabaseException, ObjectNotFoundException;

    /**
     * This method should be call only when we can make sure that memberID is in database
     */
    public void increasePostCount(int memberID)
        throws DatabaseException, ObjectNotFoundException;

}
