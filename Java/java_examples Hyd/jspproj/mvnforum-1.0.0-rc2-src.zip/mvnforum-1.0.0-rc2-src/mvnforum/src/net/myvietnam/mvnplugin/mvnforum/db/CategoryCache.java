/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/CategoryCache.java,v 1.6 2003/06/14 05:49:17 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.6 $
 * $Date: 2003/06/14 05:49:17 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.util.ArrayList;
import net.myvietnam.mvncore.exception.DatabaseException;
import net.myvietnam.mvncore.exception.ObjectNotFoundException;

public final class CategoryCache {

    // static singleton variable
    static private CategoryCache instance = new CategoryCache();

    // instance variable
    private ArrayList beanArray = null;

    /**
     * A private constructor since this is a Singleton
     */
    private CategoryCache() {
    }

    /**
     * Returns the single instance
     * @return CategoryCache : the singleton instance.
     *
     * NOTE: if use normal singleton pattern, this method should be synchronized
     */
    static public CategoryCache getInstance() {
        return instance;
    }

    /**
     * This is a private method, and a util method
     * If a method call ensureNewData(), then it MUST be synchronized
     */
    private void ensureNewData() throws DatabaseException {
        if ( CategoryWebHelper.isDirty() || (beanArray == null) ) {
            CategoryWebHelper.setDirty(false);
            beanArray = (ArrayList)CategoryWebHelper.getBeans();
        }
    }

    /**
     * IMPORTANT NOTE: The caller must not alter the returned collection
     * Note: since the return value can be accessed in many threads,
     *       we must be sure that this collection is intact. Now we can only
     *       be sure that each object in the collection is intact (default set methods) ,
     *       but we can not prevent the collection from being changed
     * #@todo Find a way to make the collection immutable
     */
    public synchronized ArrayList getBeans() throws DatabaseException {
        ensureNewData();
        return beanArray;
    }

    public synchronized CategoryBean getBean(int categoryID)
        throws DatabaseException, ObjectNotFoundException {

        ensureNewData();
        int size = beanArray.size();
        for (int i = 0; i < size; i++) {
            CategoryBean bean = (CategoryBean)beanArray.get(i);
            if (bean.getCategoryID() == categoryID) {
                return bean;
            }
        }
        throw new ObjectNotFoundException("Cannot find the row in table Category where primary key = (" + categoryID + ").");
    }

    /**
     * Reload to get the lastest info
     * Normally, this class will detect all the modifications in the table.
     * However, call this method to force a reload
     * Auto call reload after some time (say 1 hour) is also a good idea
     */
    public synchronized void reload() throws DatabaseException {
        CategoryWebHelper.setDirty(false);
        beanArray = (ArrayList)CategoryWebHelper.getBeans();
    }
}
