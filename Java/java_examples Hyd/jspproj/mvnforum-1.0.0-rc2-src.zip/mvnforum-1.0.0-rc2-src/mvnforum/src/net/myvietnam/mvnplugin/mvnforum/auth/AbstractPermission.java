/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/auth/AbstractPermission.java,v 1.10 2003/09/12 17:37:26 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.10 $
 * $Date: 2003/09/12 17:37:26 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.auth;

import net.myvietnam.mvncore.exception.BadInputException;
import net.myvietnam.mvncore.exception.NotLoginException;

public abstract class AbstractPermission implements MVNForumPermission {

    public static final int[] globalCombinedPermissionArray =
        {
            PERMISSION_SYSTEM_ADMIN,

            // below are forum-appliable permissions
            PERMISSION_FORUM_ADMIN,
            PERMISSION_FORUM_MODERATOR,
            PERMISSION_LIMITED_USER,
            PERMISSION_NORMAL_USER,
            PERMISSION_POWER_USER
        };

    public static final int[] forumCombinedPermissionArray =
        {
            PERMISSION_FORUM_ADMIN,
            PERMISSION_FORUM_MODERATOR,
            PERMISSION_LIMITED_USER,
            PERMISSION_NORMAL_USER,
            PERMISSION_POWER_USER
        };

    public static final int[] globalIndividualPermissionArray =
        {
            PERMISSION_LOGIN,
            //PERMISSION_ADMIN_SYSTEM,
            PERMISSION_ADD_CATEGORY,
            PERMISSION_EDIT_CATEGORY,
            PERMISSION_DELETE_CATEGORY,
            PERMISSION_ADD_FORUM,

            // these 2 permission should be in forum-appliable permissions,
            // However, I put it here for the more natural order that user
            // can see in interface
            PERMISSION_EDIT_FORUM,
            PERMISSION_DELETE_FORUM,

            PERMISSION_SEND_MAIL,
            PERMISSION_USE_MESSAGE,
            PERMISSION_USE_AVATAR,

            // below are forum-appliable permissions
            PERMISSION_READ_POST,
            PERMISSION_ADD_THREAD,
            PERMISSION_ADD_POST,
            PERMISSION_EDIT_POST,
            PERMISSION_DELETE_POST,
            PERMISSION_ADD_POLL,
            PERMISSION_EDIT_POLL,
            PERMISSION_DELETE_POLL,
            PERMISSION_ADD_ATTACHMENT,
            PERMISSION_GET_ATTACHMENT
        };

    public static final int[] forumIndividualPermissionArray =
        {
            PERMISSION_EDIT_FORUM,
            PERMISSION_DELETE_FORUM,
            PERMISSION_READ_POST,
            PERMISSION_ADD_THREAD,
            PERMISSION_ADD_POST,
            PERMISSION_EDIT_POST,
            PERMISSION_DELETE_POST,
            PERMISSION_ADD_POLL,
            PERMISSION_EDIT_POLL,
            PERMISSION_DELETE_POLL,
            PERMISSION_ADD_ATTACHMENT,
            PERMISSION_GET_ATTACHMENT
        };

/**************************************************************************
 * global permissions variables
 **************************************************************************/
    protected boolean authenticated = false;

    protected boolean activated     = false;

    protected boolean login         = false;

    protected boolean adminSystem   = false;

    protected boolean addForum      = false;

    protected boolean addCategory   = false;

    protected boolean editCategory  = false;

    protected boolean deleteCategory= false;

    protected boolean sendMail      = false;

    protected boolean useAvatar     = false;

    protected boolean useMessage    = false;

/**************************************************************************
 * individual forum permissions variables
 **************************************************************************/
    protected ForumListPermission editForum     = new ForumListPermission();

    protected ForumListPermission deleteForum   = new ForumListPermission();

    protected ForumListPermission readPost      = new ForumListPermission();

    protected ForumListPermission addThread     = new ForumListPermission();

    protected ForumListPermission addPost       = new ForumListPermission();

    protected ForumListPermission editPost      = new ForumListPermission();

    protected ForumListPermission deletePost    = new ForumListPermission();

    protected ForumListPermission addPoll       = new ForumListPermission();

    protected ForumListPermission editPoll      = new ForumListPermission();

    protected ForumListPermission deletePoll    = new ForumListPermission();

    protected ForumListPermission addAttachment = new ForumListPermission();

    protected ForumListPermission getAttachment = new ForumListPermission();

    /**
     * constructor
     */
    protected AbstractPermission() {
    }

/**************************************************************************
 * The below methods are static methods
 **************************************************************************/

    public static String getDescription(int permission) throws BadInputException {
        String desc = "";

        switch (permission) {
            /**************************************************************************
             * Combined permissions
             **************************************************************************/
            case PERMISSION_SYSTEM_ADMIN:
                desc = "System Admin (Combined Permission)";
                break;

            case PERMISSION_FORUM_ADMIN:
                desc = "Forum Admin (Combined Permission)";
                break;

            case PERMISSION_FORUM_MODERATOR:
                desc = "Forum Moderator (Combined Permission)";
                break;

            case PERMISSION_LIMITED_USER:
                desc = "Limited User (Combined Permission)";
                break;

            case PERMISSION_NORMAL_USER:
                desc = "Normal User (Combined Permission)";
                break;

            case PERMISSION_POWER_USER:
                desc = "Power User (Combined Permission)";
                break;

            /**************************************************************************
             * Individual permissions
             **************************************************************************/
            case PERMISSION_LOGIN:
                desc = "Can Login";
                break;

            //case PERMISSION_ADMIN_SYSTEM:
            //    desc = "Admin System";
            //    break;

            case PERMISSION_ADD_FORUM:
                desc = "Add Forum";
                break;

            case PERMISSION_EDIT_FORUM:
                desc = "Edit Forum";
                break;

            case PERMISSION_DELETE_FORUM:
                desc = "Delete Forum";
                break;

            case PERMISSION_ADD_CATEGORY:
                desc = "Add Category";
                break;

            case PERMISSION_EDIT_CATEGORY:
                desc = "Edit Category";
                break;

            case PERMISSION_DELETE_CATEGORY:
                desc = "Delete Category";
                break;

            case PERMISSION_SEND_MAIL:
                desc = "Send Mail";
                break;

            case PERMISSION_USE_MESSAGE:
                desc = "Use Message";
                break;

            case PERMISSION_USE_AVATAR:
                desc = "Use Avatar";
                break;

            case PERMISSION_READ_POST:
                desc = "Read Post";
                break;

            case PERMISSION_ADD_THREAD:
                desc = "Add Thread";
                break;

            case PERMISSION_ADD_POST:
                desc = "Add Post";
                break;

            case PERMISSION_EDIT_POST:
                desc = "Edit Post";
                break;

            case PERMISSION_DELETE_POST:
                desc = "Delete Post";
                break;

            case PERMISSION_ADD_POLL:
                desc = "Add Poll";
                break;

            case PERMISSION_EDIT_POLL:
                desc = "Edit Poll";
                break;

            case PERMISSION_DELETE_POLL:
                desc = "Delete Poll";
                break;

            case PERMISSION_ADD_ATTACHMENT:
                desc = "Add Attachment";
                break;

            case PERMISSION_GET_ATTACHMENT:
                desc = "Get Attachment";
                break;


            default:
                throw new BadInputException("Currently do not support permission = " + permission);
        }//switch

        return desc;
    }

/**************************************************************************
 * Special permissions methods
 **************************************************************************/

    public boolean isAuthenticated() {
        return authenticated;
    }
    public void ensureIsAuthenticated() throws AuthenticationException {
        if (authenticated == false) {
            throw new AuthenticationException(NotLoginException.NOT_LOGIN);
        }
    }

    public boolean isActivated() {
        return activated;
    }
    public void ensureIsActivated() throws AuthenticationException {
        if (activated == false) {
            throw new AuthenticationException(NotLoginException.NOT_ACTIVATED);
        }
    }

/**************************************************************************
 * global permissions methods
 **************************************************************************/

    public boolean canLogin() {
        return login;
    }
    public void ensureCanLogin() throws AuthenticationException {
        if (login == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canAdminSystem() {
        return adminSystem;
    }
    public void ensureCanAdminSystem() throws AuthenticationException {
        if (adminSystem == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canAddForum() {
        return addForum;
    }
    public void ensureCanAddForum() throws AuthenticationException {
        if (addForum == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canAddCategory() {
        return addCategory;
    }
    public void ensureCanAddCategory() throws AuthenticationException {
        if (addCategory == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canEditCategory() {
        return editCategory;
    }
    public void ensureCanEditCategory() throws AuthenticationException {
        if (editCategory == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canDeleteCategory() {
        return deleteCategory;
    }
    public void ensureCanDeleteCategory() throws AuthenticationException {
        if (deleteCategory == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canSendMail() {
        return sendMail;
    }
    public void ensureCanSendMail() throws AuthenticationException {
        if (sendMail == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canUseAvatar() {
        return useAvatar;
    }
    public void ensureCanUseAvatar() throws AuthenticationException {
        if (useAvatar == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canUseMessage() {
        return useMessage;
    }
    public void ensureCanUseMessage() throws AuthenticationException {
        if (useMessage == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }


/**************************************************************************
 * individual forum permissions methods
 **************************************************************************/
    // For Forum Admin only
    public boolean canEditForum(int forumID) {
        return editForum.hasPermssion(forumID);
    }
    public void ensureCanEditForum(int forumID) throws AuthenticationException {
        if (canEditForum(forumID) == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canDeleteForum(int forumID) {
        return deleteForum.hasPermssion(forumID);
    }
    public void ensureCanDeleteForum(int forumID) throws AuthenticationException {
        if (canDeleteForum(forumID) == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    // Moderator and below permission
    public boolean canReadPost(int forumID) {
        return readPost.hasPermssion(forumID);
    }
    public void ensureCanReadPost(int forumID) throws AuthenticationException {
        if (canReadPost(forumID) == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canAddThread(int forumID) {
        return addThread.hasPermssion(forumID);
    }
    public void ensureCanAddThread(int forumID) throws AuthenticationException {
        if (canAddThread(forumID) == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canAddPost(int forumID) {
        return addPost.hasPermssion(forumID);
    }
    public void ensureCanAddPost(int forumID) throws AuthenticationException {
        if (canAddPost(forumID) == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canEditPost(int forumID) {
        return editPost.hasPermssion(forumID);
    }
    public void ensureCanEditPost(int forumID) throws AuthenticationException {
        if (canEditPost(forumID) == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canDeletePost(int forumID) {
        return deletePost.hasPermssion(forumID);
    }
    public void ensureCanDeletePost(int forumID) throws AuthenticationException {
        if (canDeletePost(forumID) == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canAddPoll(int forumID) {
        return addPoll.hasPermssion(forumID);
    }
    public void ensureCanAddPoll(int forumID) throws AuthenticationException {
        if (canAddPoll(forumID) == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canEditPoll(int forumID) {
        return editPoll.hasPermssion(forumID);
    }
    public void ensureCanEditPoll(int forumID) throws AuthenticationException {
        if (canEditPoll(forumID) == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canDeletePoll(int forumID) {
        return deletePoll.hasPermssion(forumID);
    }
    public void ensureCanDeletePoll(int forumID) throws AuthenticationException {
        if (canDeletePoll(forumID) == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canAddAttachment(int forumID) {
        return addAttachment.hasPermssion(forumID);
    }
    public void ensureCanAddAttachment(int forumID) throws AuthenticationException {
        if (canAddAttachment(forumID) == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    public boolean canGetAttachment(int forumID) {
        return getAttachment.hasPermssion(forumID);
    }
    public void ensureCanGetAttachment(int forumID) throws AuthenticationException {
        if (canGetAttachment(forumID) == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

    /**************************************************************************
     * individual forum permissions methods
     **************************************************************************/
    // For Forum Admin only
    public boolean canEditAnyForum() {
        return editForum.hasPermssionInAnyForums();
    }
    public void ensureCanEditAnyForum() throws AuthenticationException {
        if (canEditAnyForum() == false) {
            throw new AuthenticationException(NotLoginException.NOT_ENOUGH_RIGHTS);
        }
    }

}
