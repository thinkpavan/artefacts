/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/CategoryWebHelper.java,v 1.7 2003/08/02 17:27:16 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.7 $
 * $Date: 2003/08/02 17:27:16 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import java.sql.*;
import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.db.DBUtils;
import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvnplugin.mvnforum.db.CategoryBean;

class CategoryWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.CategoryWebHelper {

    private static Log log = LogFactory.getLog(CategoryWebHelper.class);

    // prevent instantiation and inheritance
    private CategoryWebHelper() {
    }

    public static void createCategory(int parentCategoryID, String categoryName, String categoryDesc,
                        Timestamp categoryCreationDate, Timestamp categoryModifiedDate, int categoryOrder,
                        int categoryOption, int categoryStatus)
                        throws CreateException, DatabaseException, DuplicateKeyException, ForeignKeyNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.CategoryWebHelper.create(parentCategoryID, categoryName, categoryDesc, categoryCreationDate, categoryModifiedDate, categoryOrder, categoryOption, categoryStatus);
    }

    public static void deleteCategory(int categoryID)
        throws DatabaseException, ObjectNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.CategoryWebHelper.delete(categoryID);
    }

    public static void updateCategory(int categoryID, // primary key
                        String categoryName, String categoryDesc, Timestamp categoryModifiedDate,
                        int categoryOrder, int categoryOption, int categoryStatus)
                        throws ObjectNotFoundException, DatabaseException, DuplicateKeyException {
        net.myvietnam.mvnplugin.mvnforum.db.CategoryWebHelper.update(categoryID, // primary key
                        categoryName, categoryDesc, categoryModifiedDate,
                        categoryOrder, categoryOption, categoryStatus);
    }

    public static CategoryBean getCategory(int categoryID)
        throws ObjectNotFoundException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.CategoryWebHelper.getBean(categoryID);
    }

    public static Collection getCategories()
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.CategoryWebHelper.getBeans();
    }

/************************************************
 * Customized methods come below
 ************************************************/


    /**
     * This method should be call only when we can make sure that memberID is in database
     */
    public static void decreaseCategoryOrder(int categoryID, Timestamp categoryModifiedDate)
        throws DatabaseException, ObjectNotFoundException {

        Connection connection = null;
        PreparedStatement statement = null;
        String sql = "UPDATE " + TABLE_NAME + " SET CategoryOrder = CategoryOrder - 1, CategoryModifiedDate = ? WHERE CategoryID = ?";
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql);
            statement.setTimestamp(1, categoryModifiedDate);
            statement.setInt(2, categoryID);
            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update the CategoryOrder in table Category. Please contact Web site Administrator.");
            }
            //@todo: coi lai cho nay
            // ATTENTION !!!
            setDirty(true);
        } catch (SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error occured when update table Category: column name = CategoryOrder.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /**
     * This method should be call only when we can make sure that memberID is in database
     */
    public static void increaseCategoryOrder(int categoryID, Timestamp categoryModifiedDate)
        throws DatabaseException, ObjectNotFoundException {

        Connection connection = null;
        PreparedStatement statement = null;
        String sql = "UPDATE " + TABLE_NAME + " SET CategoryOrder = CategoryOrder + 1, CategoryModifiedDate = ? WHERE CategoryID = ?";
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql);
            statement.setTimestamp(1, categoryModifiedDate);
            statement.setInt(2, categoryID);
            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update the CategoryOrder in table Category. Please contact Web site Administrator.");
            }
            //@todo: coi lai cho nay
            // ATTENTION !!!
            setDirty(true);
        } catch (SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error occured when update table Category: column name = CategoryOrder.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }


}
