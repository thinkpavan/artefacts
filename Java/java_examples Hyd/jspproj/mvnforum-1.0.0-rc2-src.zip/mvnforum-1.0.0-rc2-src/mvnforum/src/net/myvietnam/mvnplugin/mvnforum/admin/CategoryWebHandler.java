/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/CategoryWebHandler.java,v 1.13 2003/10/30 19:18:57 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.13 $
 * $Date: 2003/10/30 19:18:57 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import java.sql.Timestamp;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;

import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.security.Encoder;
import net.myvietnam.mvncore.util.DateUtil;
import net.myvietnam.mvncore.util.ParamUtil;
import net.myvietnam.mvnplugin.mvnforum.ManagerFactory;
import net.myvietnam.mvnplugin.mvnforum.auth.*;
import net.myvietnam.mvnplugin.mvnforum.db.CategoryBean;

class CategoryWebHandler {

    private OnlineUserManager onlineUserManager = OnlineUserManager.getInstance();

    CategoryWebHandler() {
    }

    /**
     * @todo: check permission
     */
    void processAdd(HttpServletRequest request)
        throws BadInputException, CreateException, DatabaseException, DuplicateKeyException,
        ForeignKeyNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAddCategory();

        Timestamp now = DateUtil.getCurrentGMTTimestamp();

        int parentCategoryID            = 0;
        String categoryName             = ParamUtil.getParameterSafe(request, "CategoryName", true);
        String categoryDesc             = ParamUtil.getParameterSafe(request, "CategoryDesc", false);
        int categoryOption              = 0;//@todo review and support it later
        int categoryStatus              = 0;//@todo review and support it later

        CategoryWebHelper.createCategory(parentCategoryID, categoryName, categoryDesc,
                                 now/*categoryCreationDate*/, now/*categoryModifiedDate*/, 0/*categoryOrder*/,
                                 categoryOption, categoryStatus);

        request.setAttribute("CategoryName", categoryName);
    }

    void prepareDelete(HttpServletRequest request)
        throws ObjectNotFoundException, BadInputException, DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanDeleteCategory();

        // primary key column(s)
        int categoryID = ParamUtil.getParameterInt(request, "category");

        Collection forumsInCategory = ForumWebHelper.getForums_inCategory(categoryID);
        if (forumsInCategory.isEmpty() == false) {
            throw new BadInputException("Cannot delete a not-empty category. Please delete all forums in this category first.");
        }

        CategoryBean categoryBean = CategoryWebHelper.getCategory(categoryID);

        request.setAttribute("CategoryBean", categoryBean);
    }

    void processDelete(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // user must have been authenticated before he can delete
        permission.ensureIsAuthenticated();

        permission.ensureCanDeleteCategory();

        // primary key column(s)
        int categoryID = ParamUtil.getParameterInt(request, "category");

        Collection forumsInCategory = ForumWebHelper.getForums_inCategory(categoryID);
        if (forumsInCategory.isEmpty() == false) {
            throw new BadInputException("Cannot delete a not-empty category. Please delete all forums in this category first.");
        }

        // now check the password
        String memberPassword  = ParamUtil.getParameterPassword(request, "MemberMatkhau", 3, 0);
        String encodedPassword = Encoder.getMD5_Base64(memberPassword);
        int memberID = onlineUser.getMemberID();
        if (!encodedPassword.equals(ManagerFactory.getMemberDAO().getPassword(memberID))) {
            throw new BadInputException("You have typed the wrong password. Cannot proceed.");
        }
        /*
        try {
            GroupCategoryWebHelper.deleteGroupCategory_inCategory(categoryID);
        } catch (ObjectNotFoundException ex) {}
        */
        WatchWebHelper.deleteWatch_inCategory(categoryID);

        CategoryWebHelper.deleteCategory(categoryID);
    }

    /**
     * @todo: check permission
     */
    void prepareEdit(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanEditCategory();

        // primary key column(s)
        int categoryID  = ParamUtil.getParameterInt(request, "category");

        CategoryBean bean = CategoryWebHelper.getCategory(categoryID);

        request.setAttribute("CategoryBean", bean);
    }

    /**
     * @todo: check permission
     */
    void processUpdate(HttpServletRequest request)
        throws BadInputException, DatabaseException, DuplicateKeyException,
        ObjectNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanEditCategory();

        Timestamp now = DateUtil.getCurrentGMTTimestamp();

        // primary key column(s)
        int categoryID                  = ParamUtil.getParameterInt(request, "CategoryID");

        // column(s) to update
        String categoryName             = ParamUtil.getParameterSafe(request, "CategoryName", true);
        String categoryDesc             = ParamUtil.getParameterSafe(request, "CategoryDesc", false);
        int categoryOrder               = ParamUtil.getParameterInt(request, "CategoryOrder");
        if (categoryOrder < 0) {
            throw new BadInputException("CategoryOrder cannot be negative");
        }
        int categoryOption              = 0;// @todo review and support it later
        int categoryStatus              = 0;// @todo review and support it later

        CategoryWebHelper.updateCategory(categoryID, // primary key
                                 categoryName, categoryDesc, now/*categoryModifiedDate*/,
                                 categoryOrder, categoryOption, categoryStatus);
    }

    /**
     * @todo: check permission
     */
    void processUpdateCategoryOrder(HttpServletRequest request)
        throws BadInputException, DatabaseException, DuplicateKeyException,
        ObjectNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanEditCategory();

        Timestamp now = DateUtil.getCurrentGMTTimestamp();

        // primary key column(s)
        int categoryID                  = ParamUtil.getParameterInt(request, "category");

        String action                   = ParamUtil.getParameterSafe(request, "action", true);
        if (action.equals("up")) {
            CategoryWebHelper.decreaseCategoryOrder(categoryID, now);
        } else if (action.equals("down")) {
            CategoryWebHelper.increaseCategoryOrder(categoryID, now);
        } else {
            throw new BadInputException("Cannot update CategoryOrder: unknown action: " + action);
        }
    }
}
