/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/MemberPermissionWebHelper.java,v 1.2 2003/09/11 03:13:33 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.2 $
 * $Date: 2003/09/11 03:13:33 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import java.util.Collection;

import net.myvietnam.mvncore.exception.*;

class MemberPermissionWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.MemberPermissionWebHelper {

    //private static Log log = LogFactory.getLog(MemberPermissionWebHelper.class);

    // prevent instantiation and inheritance
    private MemberPermissionWebHelper() {
    }

    public static Collection getMemberPermissions_inMember(int memberID)
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.MemberPermissionWebHelper.getBeans_inMember(memberID);
    }

    public static void createMemberPermission(int memberID, int permission)
        throws CreateException, DatabaseException, DuplicateKeyException, ForeignKeyNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.MemberPermissionWebHelper.create(memberID, permission);
    }

    public static void deleteMemberPermission(int memberID, int permission)
        throws DatabaseException, ObjectNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.MemberPermissionWebHelper.delete(memberID, permission);
    }

}// end of class MemberPermissionWebHelper

