/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/MemberForumWebHelper.java,v 1.9 2003/10/29 18:57:41 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.9 $
 * $Date: 2003/10/29 18:57:41 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

//import java.sql.*;// @todo: uncomment as needed
import java.util.Collection; // @todo: uncomment as needed
//import org.apache.commons.logging.Log; // @todo: uncomment as needed
//import org.apache.commons.logging.LogFactory; // @todo: uncomment as needed
//import net.myvietnam.mvncore.db.DBUtils;// @todo: uncomment as needed
import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvnplugin.mvnforum.db.MemberForumBean;// @todo: uncomment as needed

class MemberForumWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.MemberForumWebHelper {

    //private static Log log = LogFactory.getLog(MemberForumWebHelper.class);

    // prevent instantiation and inheritance
    private MemberForumWebHelper() {
    }

    public static void deleteMemberForum_inForum(int forumID)
        throws DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.MemberForumWebHelper.delete_inForum(forumID);
    }

    public static void createMemberForum(int memberID, int forumID, int permission)
        throws CreateException, DatabaseException, ForeignKeyNotFoundException, DuplicateKeyException {
        net.myvietnam.mvnplugin.mvnforum.db.MemberForumWebHelper.create(memberID, forumID, permission);
    }

    public static void deleteMemberForum(int memberID, int forumID, int permission)
        throws DatabaseException, ObjectNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.MemberForumWebHelper.delete(memberID, forumID, permission);
    }

    public static Collection getMemberForum_inMemberForum(int memberID, int forumID)
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.MemberForumWebHelper.getBeans_inMemberForum(memberID, forumID);
    }

    public static Collection getMemberForums_inMember(int memberID)
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.MemberForumWebHelper.getBeans_inMember(memberID);
    }

    public static Collection getMemberForums_inForum(int forumID)
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.MemberForumWebHelper.getBeans_inForum(forumID);
    }
}
