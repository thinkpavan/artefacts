/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/MVNForumConfig.java,v 1.40 2003/10/31 20:19:04 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.40 $
 * $Date: 2003/10/31 20:19:04 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 * @author: Igor Manic   imanic@users.sourceforge.net
 */
package net.myvietnam.mvnplugin.mvnforum;

import java.io.*;
import java.util.Locale;
import java.util.ResourceBundle;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.exception.ObjectNotFoundException;
import net.myvietnam.mvncore.info.DatabaseInfo;
import net.myvietnam.mvncore.util.*;

public final class MVNForumConfig {

    private static Log log = LogFactory.getLog(MVNForumConfig.class);

    private MVNForumConfig() {
    }

    private static final String OPTION_FILE_NAME = "mvnplugin_mvnforum_MVNForumConfig";

    private static boolean m_shouldRun = true;
    public static boolean isShouldRun() {
        return m_shouldRun;
    }

    private static String  m_reason = "Normal System";
    public static String getReason() {
        return m_reason;
    }

    private static boolean m_guestUserInDatabase = false;
    public static boolean isGuestUserInDatabase() {
        return m_guestUserInDatabase;
    }

    private static String tempDir = "";
    private static String searchIndexDir = "";
    private static String attachmentDir = "";
    private static String backupDir = "";

    private static void setMVNForumHome(String home) {
        // now check the read/write permission by writing a temp file
        try {
            // always create a dir, if the dir already exitsted, nothing happen
            FileUtil.createDirs(home, true);

            String tempFilename = home + File.separatorChar + "mvnforum_tempfile.tmp";
            File tempFile = new File(tempFilename);
            if (log.isDebugEnabled()) {
                log.debug("Temp file = " + tempFilename);
                log.debug("Absolute filename of temp file = " + tempFile.getAbsolutePath());
            }

            FileOutputStream fos = new FileOutputStream(tempFilename);
            fos.write(tempFilename.getBytes());
            fos.close();

            tempFile.delete();

            // now create the dirs if not exitst
            tempDir = MVNFORUM_HOME + File.separatorChar + "temp";
            FileUtil.createDirs(tempDir, true);

            searchIndexDir = MVNFORUM_HOME + File.separatorChar + "search";
            FileUtil.createDirs(searchIndexDir, true);

            attachmentDir = MVNFORUM_HOME + File.separatorChar + "attachment";
            FileUtil.createDirs(attachmentDir, true);

            backupDir = MVNFORUM_HOME + File.separatorChar + "backup";
            FileUtil.createDirs(backupDir, true);

            // this dir is created as a recommended folder to store the log files
            String logDir = MVNFORUM_HOME + File.separatorChar + "log";
            FileUtil.createDirs(logDir, true);

            // now check the database
            DatabaseInfo databaseInfo = new DatabaseInfo();
            if (databaseInfo.getErrorMessage() != null) {
                log.fatal("Cannot get database connection. Please correct it first.");
                m_shouldRun = false;
                m_reason = "Check your database configuration. Detail : " + databaseInfo.getErrorMessage();
            }
        } catch (IOException ex) {
            log.fatal("Cannot setup the mvnForumHome folder. Please correct it first.", ex);
            m_shouldRun = false;
            m_reason = "Check your mvnForumHome. Detail : " + ex.getMessage();
        }
    }

    static String MVNFORUM_HOME     = "mvnForumHome";
    public static String getMVNForumHome() {
        return MVNFORUM_HOME;
    }
    public static String getTempDir() {
        return tempDir;
    }
    public static String getSearchIndexDir() {
        return searchIndexDir;
    }
    public static String getAttachmentDir() {
        return attachmentDir;
    }
    public static String getBackupDir() {
        return backupDir;
    }

    static String WEBMASTER_EMAIL  = "youremail@yourdomain.com";
    public static String getWebMasterEmail() {
        return WEBMASTER_EMAIL;
    }

    static String LOGO_URL         = "http://www.mvnForum.com";
    public static String getLogoUrl() {
        return LOGO_URL;
    }

    static String[] SUPPORTED_LOCALE_NAMES = new String[0];
    static Locale[] SUPPORTED_LOCALES = new Locale[0];
    public static String[] getSupportedLocaleNames() {
        return SUPPORTED_LOCALE_NAMES;
    }
    public static Locale[] getSupportedLocales() {
        return SUPPORTED_LOCALES;
    }

    static String DEFAULT_LOCALE_NAME = "en";
    static Locale DEFAULT_LOCALE      = null;
    public static String getDefaultLocaleName() {
        return DEFAULT_LOCALE_NAME;
    }
    public static Locale getDefaultLocale() {
        return DEFAULT_LOCALE;
    }

    /**
     * Default username of a virtual Guest user. Will be overriden with the data
     * from the database, if it exists (for the Guest user).
     * Admin can give him a name he wants, like "Guest", "Anonymous", "Surfer",
     * or even use a language different than English.
     */
    static String DEFAULT_GUEST_NAME   = "Guest";
    public static String getDefaultGuestName() {
        return DEFAULT_GUEST_NAME;
    }

    public final static boolean PRINT_STACK_TRACE = true;

    /**
     * By default, mvnForum disable passwordless authentication
     * If you want to authenticate user from realm or customized methods,
     * then set the variable to false (AT YOUR OWN RISK, authough I have not
     * found any security issues until now)
     */
    static boolean DISABLE_PASSWORDLESS_AUTH = true;
    public static boolean getDisablePasswordlessAuth() {
        return DISABLE_PASSWORDLESS_AUTH;
    }

    static boolean REQUIRE_ACTIVATION = false;
    public static boolean getRequireActivation() {
        return REQUIRE_ACTIVATION;
    }

    static boolean ENABLE_LOGIN_INFO_IN_COOKIE = true;
    public static boolean getEnableLoginInfoInCookie() {
        return ENABLE_LOGIN_INFO_IN_COOKIE;
    }

    static boolean ENABLE_LOGIN_INFO_IN_SESSION = true;
    public static boolean getEnableLoginInfoInSession() {
        return ENABLE_LOGIN_INFO_IN_SESSION;
    }

    static boolean ENABLE_LOGIN_INFO_IN_REALM = false;
    public static boolean getEnableLoginInfoInRealm() {
        return ENABLE_LOGIN_INFO_IN_REALM;
    }

    static boolean ENABLE_LOGIN_INFO_IN_CUSTOMIZATION = false;
    public static boolean getEnableLoginInfoInCustomization() {
        return ENABLE_LOGIN_INFO_IN_CUSTOMIZATION;
    }

    static boolean ENABLE_RSS = true;
    public static boolean getEnableRSS() {
        return ENABLE_RSS;
    }

    static boolean ENABLE_WATCH = true;
    public static boolean getEnableWatch() {
        return ENABLE_WATCH;
    }

    static boolean ENABLE_ATTACHMENT = true;
    public static boolean getEnableAttachment() {
        return ENABLE_ATTACHMENT;
    }

    static int MAX_ATTACHMENT_SIZE = 1024;
    public static int getMaxAttachmentSize() {
        return MAX_ATTACHMENT_SIZE;
    }

    /**
     * This is the maximum number of favorite threads that a user can add
     */
    static int MAX_FAVORITE_THREAD = 128;
    public static int getMaxFavoriteThread() {
        return MAX_FAVORITE_THREAD;
    }

    static int HOT_TOPIC_THRESHOLD = 10;
    public static int getHotTopicThreshold() {
        return HOT_TOPIC_THRESHOLD;
    }

    /** Do we allow storing backup files on the server? Currently not used. */
    static boolean ENABLE_BACKUP_ON_SERVER = true;
    public static final String BACKUP_FILE_PREFIX = "mvnForum-";
    public static final String BACKUP_FILE_MainXmlFileNameInZip = "IMPORT.xml";
    public static final String BACKUP_FILE_AvatarsDirNameInZip = "AVATARS/"; //must end with '/'
    public static final String BACKUP_FILE_AttachsDirNameInZip = "ATTACHMENTS/"; //must end with '/'

    /**
     * Maximum size of the import file (in bytes) we will allow to be uploaded
     * to server before processing.
     */
    static int MAX_IMPORT_SIZE = 4096000;
    /**
     * Maximum size of the import file (in bytes) we will allow to be uploaded
     * to server before processing.
     */
    public static int getMaxImportSize() {
        return MAX_IMPORT_SIZE;
    }

    /**
     * Type of import/export file: mvnForum XML.
     * Import only database info, no attachments, message folders, avatars, ...
     */
    public static final int IMPORTEXPORT_TYPE_MVN_XML  = 0;

    /**
     * Type of import file: mvnForum ZIP.
     * Also import attachments, avatars, message folders
     */
    public static final int IMPORTEXPORT_TYPE_MVN_ZIP  = 1;

    /**
     * Type of import file: Jive XML.
     * Using <code>http://www.jivesoftware.com/jive.dtd</code>, xmlversion="1.0".
     */
    public static final int IMPORTEXPORT_TYPE_JIVE_XML = 2;

    /**
     * Output all messages, including errors, important messages and
     * informational/status messages. This constant is used for specifing
     * the level of output in various processess throughout the application.
     */
    public static final int MESSAGE_LEVEL_ALL_MESSAGES       = 0;

    /**
     * Output only error messages and important messages (no
     * informational/status messages). This constant is used for specifing
     * the level of output in various processess throughout the application.
     */
    public static final int MESSAGE_LEVEL_IMPORTANT_MESSAGES = 1;

    /**
     * Output only error messages (no important messages, no
     * informational/status messages). This constant is used for specifing
     * the level of output in various processess throughout the application.
     */
    public static final int MESSAGE_LEVEL_ONLY_ERRORS        = 2;

    public final static int SESSION_DURATION    = 30 * DateUtil.MINUTE;// SHOULD NOT less than 15 minutes

    public static final boolean DEFAULT_MESSAGE_ENABLE  = true;
    public static final boolean DEFAULT_MEMBER_ENABLE   = true;

    /**
     * - Configable 7-days edit post/ 1 day attach file
     */
    public static int MAX_EDIT_DAYS   = 7;
    public static int MAX_ATTACH_DAYS = 1;

    public static int POSTS_PER_PAGE = 10;

    //public static final int ROWS_IN_ADMINS  = 20;

    /**
     * This is the number of rows returned when list topics
     * in MessageWebHandler.listThreads()
     * /forum/listthreads
     */
    //public static final int ROWS_IN_THREADS = 20;

    /**
     * This is the number of rows returned when list recent topics of any Forum
     * /forum/listrecentthreads
     */
    //public static final int ROWS_IN_RECENT_THREADS = 20;

    /**
     * This is the number of reply rows returned when viewthread
     * /forum/viewthread
     */
    //public static final int ROWS_IN_REPLIES = 10;

    /**
     * This is the number of reply rows returned when addpost (reply to a topic)
     * /forum/addpost
     */
    public static final int ROWS_IN_LAST_REPLIES = 5;

    /**
     * This is the number of rows returned when list recent messages in the Message table
     * /admin/listdisablemessageprocess
     */
    public static final int ROWS_IN_RECENT_MESSAGES = 20;

    /**
     * This is the number of rows returned when list members in the Member table
     */
    public static int MEMBERS_PER_PAGE = 20;

    /**
     * This is the number of rows returned when list threads for RSS
     */
    public static final int ROWS_IN_RSS = 15;//RSS 0.91

    private static boolean parseBooleanValue(String propertyValue, boolean defaultValue) {
        String result = "true";
        try {
            result = propertyValue.trim();
            if ((result.equalsIgnoreCase("false")) || (result.equalsIgnoreCase("no"))) {
                return false;
            } else if ((result.equalsIgnoreCase("true")) || (result.equalsIgnoreCase("yes"))) {
                return true;
            } else {
                log.warn("Invalid boolean value in properties file. Should be \"true\", \"false\", \"yes\" or \"no\".");
                return defaultValue;
            }
        } catch (Exception e) {
            log.warn(e.getMessage());
            return defaultValue;
        }
    }

    private static int parseIntValue(String propertyValue, int defaultValue) {
        try {
            return Integer.parseInt(propertyValue.trim());
        } catch (Exception e) {
            log.warn(e.getMessage());
            return defaultValue;
        }
    }

    private static int parseIntSizeValue(String propertyValue, int defaultValue) {
        try {
            String temp = propertyValue.trim();
            if (temp.endsWith("B")) temp=temp.substring(0, temp.length()-1);
            switch (temp.charAt(temp.length()-1)) {
                case 'K': case 'k':
                    //examples (ending 'B' was cut before): "1K", "1KB", "1k", "1kB", "1 K", "1 KB", "1 k", "1 kB"
                    return 1024*Integer.parseInt( temp.substring(0, temp.length()-1).trim() );
                case 'M': case 'm':
                    //examples (ending 'B' was cut before): "1M", "1MB", "1m", "1mB", "1 M", "1 MB", "1 m", "1 mB"
                    return 1024*1024*Integer.parseInt( temp.substring(0, temp.length()-1).trim() );
                default:
                    //examples (ending 'B' was cut before): "1", "1B", "1 B"
                    return Integer.parseInt(temp.trim());
            }
        } catch (Exception e) {
            log.warn(e.getMessage());
            return defaultValue;
        }
    }

    static {
        try {
            ResourceBundle res = ResourceBundle.getBundle(OPTION_FILE_NAME);

            MVNFORUM_HOME       = res.getString("MVNFORUM_HOME").trim();
            setMVNForumHome(MVNFORUM_HOME);

            WEBMASTER_EMAIL     = res.getString("WEBMASTER_EMAIL").trim();

            LOGO_URL            = res.getString("LOGO_URL").trim();

            String supportedLocales = res.getString("SUPPORTED_LOCALES").trim();
            SUPPORTED_LOCALE_NAMES = StringUtil.getStringArray(supportedLocales, ";");

            SUPPORTED_LOCALES = new Locale[SUPPORTED_LOCALE_NAMES.length];
            for (int i = 0; i < SUPPORTED_LOCALE_NAMES.length; i++) {
                String localeName = SUPPORTED_LOCALE_NAMES[i];
                SUPPORTED_LOCALES[i] = MyUtil.getLocale(localeName);
            }

            try {
                DEFAULT_LOCALE_NAME = res.getString("DEFAULT_LOCALE_NAME").trim();
            } catch (Exception ex) {
                log.warn(ex.getMessage());
            }
            DEFAULT_LOCALE = MyUtil.getLocale(DEFAULT_LOCALE_NAME);

            try {
                DEFAULT_GUEST_NAME = res.getString("DEFAULT_GUEST_NAME").trim();
            } catch (Exception ex) {
                log.warn(ex.getMessage());
            }

            DISABLE_PASSWORDLESS_AUTH = parseBooleanValue(res.getString("DISABLE_PASSWORDLESS_AUTH"), true);
            REQUIRE_ACTIVATION = parseBooleanValue(res.getString("REQUIRE_ACTIVATION"), false);
            ENABLE_LOGIN_INFO_IN_COOKIE = parseBooleanValue(res.getString("ENABLE_LOGIN_INFO_IN_COOKIE"), true);
            ENABLE_LOGIN_INFO_IN_SESSION = parseBooleanValue(res.getString("ENABLE_LOGIN_INFO_IN_SESSION"), true);
            ENABLE_LOGIN_INFO_IN_REALM = parseBooleanValue(res.getString("ENABLE_LOGIN_INFO_IN_REALM"), false);
            ENABLE_LOGIN_INFO_IN_CUSTOMIZATION = parseBooleanValue(res.getString("ENABLE_LOGIN_INFO_IN_CUSTOMIZATION"), false);

            ENABLE_RSS = parseBooleanValue(res.getString("ENABLE_RSS"), true);
            ENABLE_WATCH = parseBooleanValue(res.getString("ENABLE_WATCH"), true);
            ENABLE_ATTACHMENT = parseBooleanValue(res.getString("ENABLE_ATTACHMENT"), true);
            MAX_ATTACHMENT_SIZE = parseIntSizeValue(res.getString("MAX_ATTACHMENT_SIZE"), 1024);

            MEMBERS_PER_PAGE = parseIntValue(res.getString("MEMBERS_PER_PAGE"), 20);
            MAX_FAVORITE_THREAD = parseIntValue(res.getString("MAX_FAVORITE_THREAD"), 128);
            MAX_EDIT_DAYS = parseIntValue(res.getString("MAX_EDIT_DAYS"), 7);
            MAX_ATTACH_DAYS = parseIntValue(res.getString("MAX_ATTACH_DAYS"), 1);
            POSTS_PER_PAGE = parseIntValue(res.getString("POSTS_PER_PAGE"), 10);
            HOT_TOPIC_THRESHOLD = parseIntValue(res.getString("HOT_TOPIC_THRESHOLD"), 10);

            ENABLE_BACKUP_ON_SERVER = parseBooleanValue(res.getString("ENABLE_BACKUP_ON_SERVER"), true);
            MAX_IMPORT_SIZE = parseIntSizeValue(res.getString("MAX_IMPORT_SIZE"), 4096000);

            // now check if Guest user is in database or not
            try {
                ManagerFactory.getMemberDAO().getBean_forPublic(MVNForumConstant.MEMBER_ID_OF_GUEST);
                m_guestUserInDatabase = true;
            } catch (ObjectNotFoundException ex) {
                // dont have Guest user in database, just ignore
            } catch (Exception ex) {
                log.info("Error occured when get Guest user.", ex);
            }
        } catch (Exception e) {
            String message = "net.myvietnam.mvnplugin.mvnforum.MVNForumConfig: Can't read the properties file: '" + OPTION_FILE_NAME + ".properties'. Make sure the file is in your CLASSPATH";
            log.error(message, e);
        }
    }
}
