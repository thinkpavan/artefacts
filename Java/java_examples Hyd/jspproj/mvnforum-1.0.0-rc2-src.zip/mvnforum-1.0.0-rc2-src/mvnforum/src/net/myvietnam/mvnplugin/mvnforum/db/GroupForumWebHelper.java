/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/GroupForumWebHelper.java,v 1.14 2003/10/29 18:57:41 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.14 $
 * $Date: 2003/10/29 18:57:41 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.db.DBUtils;
import net.myvietnam.mvncore.exception.*;

/*
// @todo: copy this skeleton for derived class
package package_of_derived_class;

//import java.sql.*;// @todo: uncomment as needed
//import java.util.Collection; // @todo: uncomment as needed
//import net.myvietnam.mvncore.db.DBUtils;// @todo: uncomment as needed
import net.myvietnam.mvncore.exception.*;
//import net.myvietnam.mvnplugin.mvnforum.db.GroupForumBean;// @todo: uncomment as needed

class GroupForumWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.GroupForumWebHelper {
    // prevent instantiation and inheritance
    private GroupForumWebHelper() {
    }

    // @todo: add methods here
}
*/
public class GroupForumWebHelper {

    private static Log log = LogFactory.getLog(GroupForumWebHelper.class);

    public static final String TABLE_NAME = DatabaseConfig.TABLE_PREFIX + "GroupForum";

    // this variable will support caching if cache for this class is needed
    private static boolean m_dirty = true;

    // Prevent instantiation from classes other than derived classes
    protected GroupForumWebHelper() {
    }

    protected static boolean isDirty() {
        return m_dirty;
    }

    protected static void setDirty(boolean dirty) {
        m_dirty = dirty;
    }

    protected static void findByPrimaryKey(int groupID, int forumID, int permission)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT GroupID, ForumID, Permission");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE GroupID = ? AND ForumID = ? AND Permission = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, groupID);
            statement.setInt(2, forumID);
            statement.setInt(3, permission);
            resultSet = statement.executeQuery();
            if (!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the primary key (" + groupID + ", " + forumID + ", " + permission + ") in table 'GroupForum'.");
            }
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in GroupForumWebHelper.findByPrimaryKey.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }


/*
// @todo: copy this method for derived class
    public static void createGroupForum(int groupID, int forumID, int permission)
                        throws CreateException, DatabaseException, ForeignKeyNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.GroupForumWebHelper.create(groupID, forumID, permission);
    }
*/
    /*
     * Included columns: GroupID, ForumID, Permission
     * Excluded columns:
     */
    protected static void create(int groupID, int forumID, int permission)
                        throws CreateException, DatabaseException, DuplicateKeyException, ForeignKeyNotFoundException {

        // @todo: comment this try-catch block if the needed columns dont have attribute 'include'
        // If this is the case, then it is highly recommended that you regenerate this method with the attribute 'include' turned on
        // However, if primary key is a auto_increament column, then you can safely delete this block
        try {
            //Check if primary key already exists
            findByPrimaryKey(groupID, forumID, permission);
            //If so, then we have to throw an exception
            throw new DuplicateKeyException("Primary key already exists. Cannot create new GroupForum with the same <GroupID, ForumID, Permission> (" + groupID + ", " + forumID + ", " + permission + ").");
        } catch(ObjectNotFoundException e) {
            //Otherwise we can go ahead
        }

        try {
            // @todo: modify the parameter list as needed
            // You may have to regenerate this method if the needed columns dont have attribute 'include'
            ForumWebHelper.findByPrimaryKey(forumID);
        } catch(ObjectNotFoundException e) {
            throw new ForeignKeyNotFoundException("Foreign key refers to table 'Forum' does not exist. Cannot create new GroupForum.");
        }

        try {
            // @todo: modify the parameter list as needed
            // You may have to regenerate this method if the needed columns dont have attribute 'include'
            GroupsWebHelper.findByPrimaryKey(groupID);
        } catch(ObjectNotFoundException e) {
            throw new ForeignKeyNotFoundException("Foreign key refers to table 'Groups' does not exist. Cannot create new GroupForum.");
        }

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("INSERT INTO " + TABLE_NAME + " (GroupID, ForumID, Permission)");
        sql.append(" VALUES (?, ?, ?)");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            statement.setInt(1, groupID);
            statement.setInt(2, forumID);
            statement.setInt(3, permission);

            if (statement.executeUpdate() != 1) {
                throw new CreateException("Error adding a row into table 'GroupForum'.");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in GroupForumWebHelper.create.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static void deleteGroupForum(int groupID, int forumID, int permission)
        throws DatabaseException, ObjectNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.GroupForumWebHelper.delete(groupID, forumID, permission);
    }
*/
    protected static void delete(int groupID, int forumID, int permission)
        throws DatabaseException, ObjectNotFoundException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("DELETE FROM " + TABLE_NAME);
        sql.append(" WHERE GroupID = ? AND ForumID = ? AND Permission = ?");

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, groupID);
            statement.setInt(2, forumID);
            statement.setInt(3, permission);
            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot delete a row in table GroupForum where primary key = (" + groupID + ", " + forumID + ", " + permission + ").");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in GroupForumWebHelper.delete.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static void deleteGroupForum_inGroup(int groupID)
        throws DatabaseException, ObjectNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.GroupForumWebHelper.delete_inGroup(groupID);
    }
*/
    protected static void delete_inGroup(int groupID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("DELETE FROM " + TABLE_NAME);
        sql.append(" WHERE GroupID = ? ");

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, groupID);

            statement.executeUpdate();
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in GroupForumWebHelper.delete_inGroup.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static void deleteGroupForum_inForum(int forumID)
        throws DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.GroupForumWebHelper.delete_inForum(forumID);
    }
*/
    protected static void delete_inForum(int forumID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("DELETE FROM " + TABLE_NAME);
        sql.append(" WHERE ForumID = ? ");

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, forumID);

            statement.executeUpdate();
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in GroupForumWebHelper.delete_inForum.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }


/************************************************
 * Customized methods come below
 ************************************************/



/*
// @todo: copy this method for derived class
    public static Collection getGroupForums_inGroupForum(int groupID, int forumID)
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.GroupForumWebHelper.getBeans_inGroupForum(groupID, forumID);
    }
*/
    /*
     * Included columns: Permission
     * Excluded columns: GroupID, ForumID
     */
    protected static Collection getBeans_inGroupForum(int groupID, int forumID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Collection retValue = new ArrayList();
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT Permission");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE GroupID = ? AND ForumID = ?"); // @todo: uncomment as needed
        //sql.append(" ORDER BY ColumnName ASC|DESC "); // @todo: uncomment as needed
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, groupID);
            statement.setInt(2, forumID);

            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                GroupForumBean bean = new GroupForumBean();
                bean.setGroupID(groupID);
                bean.setForumID(forumID);
                bean.setPermission(resultSet.getInt("Permission"));
                retValue.add(bean);
            }
            return retValue;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in GroupForumWebHelper.getBeans.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static Collection getGroupForums_inForum(int forumID)
            throws DatabaseException {
            return net.myvietnam.mvnplugin.mvnforum.db.GroupForumWebHelper.getBeans_inForum(forumID);
        }
     */
    /*
     * Included columns: GroupID, ForumID, Permission
     * Excluded columns:
     */
    protected static Collection getBeans_inForum(int forumID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Collection retValue = new ArrayList();
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT GroupID, ForumID, Permission");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE ForumID = ? ");
        sql.append(" ORDER BY GroupID ");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, forumID);

            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                GroupForumBean bean = new GroupForumBean();
                bean.setGroupID(resultSet.getInt("GroupID"));
                bean.setForumID(resultSet.getInt("ForumID"));
                bean.setPermission(resultSet.getInt("Permission"));
                retValue.add(bean);
            }
            return retValue;
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            throw new DatabaseException("Error executing SQL in GroupForumWebHelper.getBeans_inForum.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static Collection getGroupForums_inGroup(int groupID)
            throws DatabaseException {
            return net.myvietnam.mvnplugin.mvnforum.db.GroupForumWebHelper.getBeans_inGroup(groupID);
        }
     */
    /*
     * Included columns: GroupID, ForumID, Permission
     * Excluded columns:
     */
    protected static Collection getBeans_inGroup(int groupID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Collection retValue = new ArrayList();
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT GroupID, ForumID, Permission");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE GroupID = ? ");
        sql.append(" ORDER BY ForumID ");

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, groupID);

            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                GroupForumBean bean = new GroupForumBean();
                bean.setGroupID(resultSet.getInt("GroupID"));
                bean.setForumID(resultSet.getInt("ForumID"));
                bean.setPermission(resultSet.getInt("Permission"));
                retValue.add(bean);
            }
            return retValue;
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            throw new DatabaseException("Error executing SQL in GroupForumWebHelper.getBeans_inGroup.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

}// end of class GroupForumWebHelper

