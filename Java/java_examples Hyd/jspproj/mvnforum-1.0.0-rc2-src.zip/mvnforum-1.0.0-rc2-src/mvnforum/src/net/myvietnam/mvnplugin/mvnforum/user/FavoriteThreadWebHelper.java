/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/user/FavoriteThreadWebHelper.java,v 1.4 2003/09/28 16:14:08 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.4 $
 * $Date: 2003/09/28 16:14:08 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.user;

import java.sql.*;
import java.util.Collection;
//import org.apache.commons.logging.Log; // @todo: uncomment as needed
//import org.apache.commons.logging.LogFactory; // @todo: uncomment as needed
//import net.myvietnam.mvncore.db.DBUtils;// @todo: uncomment as needed
import net.myvietnam.mvncore.exception.*;
//import net.myvietnam.mvnplugin.mvnforum.db.FavoriteThreadBean;// @todo: uncomment as needed

class FavoriteThreadWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.FavoriteThreadWebHelper {

    //private static Log log = LogFactory.getLog(FavoriteThreadWebHelper.class);

    // prevent instantiation and inheritance
    private FavoriteThreadWebHelper() {
    }

    public static void createFavoriteThread(int memberID, int threadID, int forumID,
                        Timestamp favoriteCreationDate, int favoriteType, int favoriteOption,
                        int favoriteStatus)
                        throws CreateException, DatabaseException, DuplicateKeyException, ForeignKeyNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.FavoriteThreadWebHelper.create(memberID, threadID, forumID, favoriteCreationDate, favoriteType, favoriteOption, favoriteStatus);
    }

    public static void deleteFavoriteThread(int memberID, int threadID)
        throws DatabaseException, ObjectNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.FavoriteThreadWebHelper.delete(memberID, threadID);
    }

    public static void deleteFavoriteThread_inThread(int threadID)
        throws DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.FavoriteThreadWebHelper.delete_inThread(threadID);
    }

    public static void updateFavoriteThread_ForumID_inThread(int threadID, int forumID)
        throws DatabaseException, ForeignKeyNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.FavoriteThreadWebHelper.update_ForumID_inThread(threadID, forumID);
    }

    public static int getNumberOfFavoriteThreads_inMember(int memberID)
        throws AssertionException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.FavoriteThreadWebHelper.getNumberOfBeans_inMember(memberID);
    }
}
