/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/MyUtil.java,v 1.19 2003/10/15 18:27:19 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.19 $
 * $Date: 2003/10/15 18:27:19 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum;

import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.filter.*;
import net.myvietnam.mvncore.util.ParamUtil;
import net.myvietnam.mvncore.util.StringUtil;
import net.myvietnam.mvnplugin.mvnforum.db.*;
import java.util.ArrayList;

public class MyUtil {

    private static Log log = LogFactory.getLog(MyUtil.class);

    private static RankCache rankCache = RankCache.getInstance();

    public static void prepareNavigate(HttpServletRequest request, int offset, int collectionSize, int totalRows, int rowsPerPage) {
        int startOffset = offset + 1;
        int lastOffset = offset + collectionSize;
        if (startOffset > lastOffset) startOffset = lastOffset;
        int previousOffset = -1;
        int nextOffset = -1;
        if (offset > 0) {
            previousOffset = offset - rowsPerPage;
            if (previousOffset < 0) previousOffset = 0;
        }
        if (lastOffset < totalRows) {
            nextOffset = offset + rowsPerPage;
        }
        request.setAttribute("StartOffset", new Integer(startOffset));
        request.setAttribute("LastOffset", new Integer(lastOffset));
        request.setAttribute("PreviousOffset", new Integer(previousOffset));
        request.setAttribute("NextOffset", new Integer(nextOffset));
    }

    public static String filter(String input, boolean enableHTML, boolean enableEmotion,
                                boolean enableMVNCode, boolean enableNewLine, boolean enableURL) {
        String output = input;

        if (enableHTML) {
            output = EnableHtmlTagFilter.filter(output);
        } else {
            output = DisableHtmlTagFilter.filter(output);
        }

        if (enableEmotion) {
            output = EnableEmotionFilter.filter(output, ParamUtil.getContextPath() + MVNForumGlobal.EMOTION_DIR);
        }

        if (enableMVNCode) {
            output = EnableMVNCodeFilter.filter(output);
        }

        if (enableNewLine) {
            output = HtmlNewLineFilter.filter(output);
        }

        if (enableURL) {
            output = URLFilter.filter(output);
        }
        return output;
    }

    public static String getMemberTitle(int postCount) {
        String title = "";
        try {
            ArrayList rankBeans = rankCache.getBeans();
            for (int i = 0; i < rankBeans.size(); i++) {
                RankBean rankBean = (RankBean)rankBeans.get(i);
                if (rankBean.getRankMinPosts() <= postCount) {
                    title = rankBean.getRankTitle();
                } else {
                    break;
                }
            }//for
        } catch (Exception ex) {
            log.error("Exception in getMemberTitile", ex);
        }
        return title;
    }

    public static String getForumIconName(long lastLogon, long lastPost) {
        String forumIcon = null;
        if (lastLogon > lastPost) {// no new post
            forumIcon = "f_norm_no.gif";
        } else {// new post
            forumIcon = "f_norm_new.gif";
        }
        return forumIcon;
    }

    public static String getThreadIconName(long lastLogon, long lastPost, int postCount) {
        String threadIcon = null;
        if (postCount < MVNForumConfig.getHotTopicThreshold()) {//not hot topic
            if (lastLogon > lastPost) {// no new post
                threadIcon = "f_norm_no.gif";
            } else {// new post
                threadIcon = "f_norm_new.gif";
            }
        } else {// hot topic
            if (lastLogon > lastPost) {// no new post
                threadIcon = "f_hot_no.gif";
            } else {// new post
                threadIcon = "f_hot_new.gif";
            }
        }
        return threadIcon;
    }

    /**
     * Get the String with a slash character '/' before the locale name
     * @param localeName the user's preferred locale
     * @return the String with a slash character '/' before the locale name if
     *         this locale is configed to support it. Otherwise,
     *         an empty String will be return
     */
    public static String getLocaleNameAndSlash(String localeName) {
        if ( (localeName == null) || (localeName.length() == 0) ) {
            return "";
        }

        String retValue = "";
        String[] supportedLocales = MVNForumConfig.getSupportedLocaleNames();

        if (supportedLocales == null) {
            log.error("Assertion in MyUtil.getLocaleNameAndSlash. Please check your configuration.");
            return "";
        }

        for (int i = 0; i < supportedLocales.length; i++) {
            if (localeName.equals(supportedLocales[i])) {
                retValue = "/" + localeName;
                break;
            }
        }
        return retValue;
    }

    /**
     * Get the locale from locale name
     * @param localeName : in this format la_CO_VA, eg. en_US
     * @return the locale instance of the localeName
     */
    public static Locale getLocale(String localeName) {
        // now, find out the 3 elements of a locale: language, country, variant
        String[] localeElement = StringUtil.getStringArray(localeName, "_");
        String language = "";
        String country = "";
        String variant = "";
        if (localeElement.length >= 1) {
            language = localeElement[0];
        }
        if (localeElement.length >= 2) {
            country = localeElement[1];
        }
        if (localeElement.length >= 3) {
            variant = localeElement[2];
        }
        return new Locale(language, country, variant);
    }
}