/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/RankBean.java,v 1.3 2003/10/27 19:04:33 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.3 $
 * $Date: 2003/10/27 19:04:33 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.util.Collection;
import java.util.Iterator;

import net.myvietnam.mvncore.util.StringUtil;

/*
 * Included columns: RankID, RankMinPosts, RankLevel, RankTitle, RankImage,
 *                   RankType, RankOption
 * Excluded columns:
 */
public class RankBean {
    private int rankID;
    private int rankMinPosts;
    private int rankLevel;
    private String rankTitle;
    private String rankImage;
    private int rankType;
    private int rankOption;

    public int getRankID() {
        return rankID;
    }
    public void setRankID(int rankID) {
        this.rankID = rankID;
    }

    public int getRankMinPosts() {
        return rankMinPosts;
    }
    public void setRankMinPosts(int rankMinPosts) {
        this.rankMinPosts = rankMinPosts;
    }

    public int getRankLevel() {
        return rankLevel;
    }
    public void setRankLevel(int rankLevel) {
        this.rankLevel = rankLevel;
    }

    public String getRankTitle() {
        return rankTitle;
    }
    public void setRankTitle(String rankTitle) {
        this.rankTitle = rankTitle;
    }

    public String getRankImage() {
        return rankImage;
    }
    public void setRankImage(String rankImage) {
        this.rankImage = StringUtil.getEmptyStringIfNull(rankImage);
    }

    public int getRankType() {
        return rankType;
    }
    public void setRankType(int rankType) {
        this.rankType = rankType;
    }

    public int getRankOption() {
        return rankOption;
    }
    public void setRankOption(int rankOption) {
        this.rankOption = rankOption;
    }

    public String getXML() {
        StringBuffer xml = new StringBuffer(1024);
        xml.append("<RankSection>\n");
        xml.append("  <Rows>\n");
        xml.append("    <Row>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>RankID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(rankID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>RankMinPosts</Name>\n");
        xml.append("        <Value>").append(String.valueOf(rankMinPosts)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>RankLevel</Name>\n");
        xml.append("        <Value>").append(String.valueOf(rankLevel)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>RankTitle</Name>\n");
        xml.append("        <Value>").append(String.valueOf(rankTitle)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>RankImage</Name>\n");
        xml.append("        <Value>").append(String.valueOf(rankImage)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>RankType</Name>\n");
        xml.append("        <Value>").append(String.valueOf(rankType)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>RankOption</Name>\n");
        xml.append("        <Value>").append(String.valueOf(rankOption)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("    </Row>\n");
        xml.append("  </Rows>\n");
        xml.append("</RankSection>\n");
        return xml.toString();
    }

    public static String getXML(Collection objRankBeans) {
        StringBuffer xml = new StringBuffer(1024);
        Iterator iterator = objRankBeans.iterator();
        xml.append("<RankSection>\n");
        xml.append("  <Rows>\n");
        while (iterator.hasNext()) {
            RankBean objRankBean = (RankBean)iterator.next();
            xml.append("    <Row>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>RankID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objRankBean.rankID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>RankMinPosts</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objRankBean.rankMinPosts)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>RankLevel</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objRankBean.rankLevel)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>RankTitle</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objRankBean.rankTitle)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>RankImage</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objRankBean.rankImage)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>RankType</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objRankBean.rankType)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>RankOption</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objRankBean.rankOption)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("    </Row>\n");
        }//while
        xml.append("  </Rows>\n");
        xml.append("</RankSection>\n");
        return xml.toString();
    }
} //end of class RankBean
