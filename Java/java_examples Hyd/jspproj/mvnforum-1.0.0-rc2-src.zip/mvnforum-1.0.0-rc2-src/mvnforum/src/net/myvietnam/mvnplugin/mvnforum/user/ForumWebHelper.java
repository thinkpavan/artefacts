/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/user/ForumWebHelper.java,v 1.17 2003/09/28 10:01:50 imanic Exp $
 * $Author: imanic $
 * $Revision: 1.17 $
 * $Date: 2003/09/28 10:01:50 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.user;

import java.sql.*;
import java.util.Collection;

//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
//import net.myvietnam.mvncore.db.DBUtils;
import net.myvietnam.mvncore.exception.*;
//import net.myvietnam.mvnplugin.mvnforum.db.ForumBean;

class ForumWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper {

    // static variable
    //private static Log log = LogFactory.getLog(ForumWebHelper.class);

    // prevent instantiation and inheritance
    private ForumWebHelper() {
    }

    public static Collection getForums()
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper.getBeans();
    }

    public static void updateForumLastPostMemberName(int forumID, // primary key
                        String lastPostMemberName)
                        throws ObjectNotFoundException, DatabaseException, ForeignKeyNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper.updateLastPostMemberName(forumID, // primary key
                        lastPostMemberName);
    }

    public static void updateForumLastPostDate(int forumID, // primary key
                        Timestamp forumLastPostDate)
                        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper.updateLastPostDate(forumID, // primary key
                        forumLastPostDate);
    }

    public static void updateForumStatistics(int forumID, // primary key
                        int forumThreadCount, int forumPostCount)
                        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper.updateStatistics(forumID, // primary key
                        forumThreadCount, forumPostCount);
    }

    public static void increaseForumThreadCount(int forumID) // primary key
        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper.increaseThreadCount(forumID); // primary key
    }

    public static void decreaseForumThreadCount(int forumID) // primary key
        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper.decreaseThreadCount(forumID); // primary key
    }

    public static void increaseForumPostCount(int forumID) // primary key
        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.ForumWebHelper.increasePostCount(forumID); // primary key
    }

}
