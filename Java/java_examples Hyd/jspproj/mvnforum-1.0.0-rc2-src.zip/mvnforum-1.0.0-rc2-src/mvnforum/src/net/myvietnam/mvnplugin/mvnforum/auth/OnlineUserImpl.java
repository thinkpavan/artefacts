/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/auth/OnlineUserImpl.java,v 1.25 2003/11/01 04:40:25 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.25 $
 * $Date: 2003/11/01 04:40:25 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.auth;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.util.DateUtil;
import net.myvietnam.mvnplugin.mvnforum.MVNForumConstant;
import net.myvietnam.mvnplugin.mvnforum.MyUtil;
import net.myvietnam.mvnplugin.mvnforum.db.MemberBean;
import net.myvietnam.mvnplugin.mvnforum.ManagerFactory;

class OnlineUserImpl implements OnlineUser {

    private static Log log = LogFactory.getLog(OnlineUserImpl.class);

    private int memberID = MVNForumConstant.MEMBER_ID_OF_GUEST;

    private String memberName = "";

    private int memberPostsPerPage = 10;

    private MVNForumPermission permission = null;

    private OnlineUserAction onlineUserAction = new OnlineUserAction();

    private int hourOffset = 0;

    /* private DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
     * Igor: previous line should be: new SimpleDateFormat(..., Locale.US)
     * Otherwise won't work for users who don't have en/US as default.
     */
    private DateFormat timestampFormatter = null;
    private DateFormat dateFormatter = null;

    private Timestamp lastLogonTimestamp = null;

    private String localeName = "";

    private Locale locale = null;

    private boolean gender = true;

    /**
     * default access constructor, prevent outsite creation
     */
    OnlineUserImpl() {
    }

    public int getMemberID() {
        return memberID;
    }

    public String getMemberName() {
        return memberName;
    }

    public boolean isGuest() {
        return ( (memberID==0) || (memberID==MVNForumConstant.MEMBER_ID_OF_GUEST) );
    }

    public boolean isMember() {
        return !isGuest();
    }

    public boolean isInvisibleMember() {
        // @todo: temp implementation
        return false;
    }

    public MVNForumPermission getPermission() {
        return permission;
    }

    public void reloadPermission() {
        try {
            if (isGuest()) {
                permission = MVNForumPermissionFactory.getAnonymousPermission();
            } else {
                permission = MVNForumPermissionFactory.getAuthenticatedPermission(memberID);
            }
        } catch (Exception ex) {
            log.error("Error when reload permission in OnlineUserImpl for memberID = " + memberID , ex);
        }
    }

    public void reloadProfile() {
        try {
            if (isGuest()) {
                // currently just do nothing, implement later
            } else {
                MemberBean memberBean = ManagerFactory.getMemberDAO().getBean_forViewCurrentMember(memberID);

                int timeZone = memberBean.getMemberTimeZone();
                localeName = memberBean.getMemberLanguage();
                int postsPerPage = memberBean.getMemberPostsPerPage();

                setTimeZone(timeZone);
                setLocaleName(localeName);
                setGender(memberBean.getMemberGender() != 0);
                setPostsPerPage(postsPerPage);
            }
        } catch (Exception ex) {
            log.error("Error when reload profile in OnlineUserImpl for memberID = " + memberID , ex);
        }
    }

    public OnlineUserAction getOnlineUserAction() {
        return onlineUserAction;
    }

    public java.util.Date convertGMTDate(java.util.Date gmtDate) {
        return DateUtil.convertGMTDate(gmtDate, hourOffset);
    }

    public Timestamp convertGMTTimestamp(Timestamp gmtTimestamp) {
        return DateUtil.convertGMTTimestamp(gmtTimestamp, hourOffset);
    }

    public String getGMTDateFormat(java.util.Date gmtDate) {
       return getGMTDateFormat(gmtDate, true);
    }

    public String getGMTDateFormat(java.util.Date gmtDate, boolean adjustTimeZone) {
        if (gmtDate == null) return "";

        java.util.Date date = gmtDate;
        if (adjustTimeZone) {
            date = DateUtil.convertGMTDate(gmtDate, hourOffset);
        }
        return dateFormatter.format(date);
    }

    public String getGMTTimestampFormat(Timestamp gmtTimestamp) {
       return getGMTTimestampFormat(gmtTimestamp, true);
    }

    public String getGMTTimestampFormat(Timestamp gmtTimestamp, boolean adjustTimeZone) {
        if (gmtTimestamp == null) return "";

        Timestamp timestamp = gmtTimestamp;
        if (adjustTimeZone) {
            timestamp = DateUtil.convertGMTTimestamp(gmtTimestamp, hourOffset);
        }
        return timestampFormatter.format(timestamp);
    }

    public String getLocaleName() {
        return localeName;
    }

    public Locale getLocale() {
        return locale;
    }

    public Timestamp getLastLogonTimestamp() {
        return lastLogonTimestamp;
    }

    public boolean getGender() {
        return gender;
    }

    public int getPostsPerPage() {
        return memberPostsPerPage;
    }

/*****************************************************************
 * Default-scope methods, only for internal package usage
 *****************************************************************/
    void setMemberID(int memberID) {
        if (memberID == 0) {
            this.memberID = MVNForumConstant.MEMBER_ID_OF_GUEST;
        } else {
            this.memberID = memberID;
        }
        onlineUserAction.setMemberID(this.memberID);

    }

    void setMemberName(String memberName) {
        this.memberName = memberName;
        onlineUserAction.setMemberName(memberName);
    }

    /**
     * NOTE: this method SHOULD ONLY BE CALLED from OnlineUserFactory
     */
    void setPermission(MVNForumPermission permission) {
        this.permission = permission;
    }

    void setTimeZone(int timeZone) {
        if ( (timeZone >= -12) && (timeZone <= 12) ) {
            this.hourOffset = timeZone;
        }
    }

    void setLocaleName(String localeName) {
        this.localeName = localeName;

        locale = MyUtil.getLocale(localeName);

        // now init the 2 class variables
        dateFormatter = SimpleDateFormat.getDateInstance(SimpleDateFormat.DEFAULT, locale);
        timestampFormatter = SimpleDateFormat.getDateTimeInstance(SimpleDateFormat.DEFAULT, SimpleDateFormat.DEFAULT, locale);
    }

    void setLastLogonTimestamp(Timestamp lastLogon) {
        lastLogonTimestamp = lastLogon;
    }

    void setGender(boolean gender) {
        this.gender = gender;
    }

    void setPostsPerPage(int postsPerPage) {
        if (postsPerPage < 5) {
            postsPerPage = 5;
        }
        this.memberPostsPerPage = postsPerPage;
    }
}
