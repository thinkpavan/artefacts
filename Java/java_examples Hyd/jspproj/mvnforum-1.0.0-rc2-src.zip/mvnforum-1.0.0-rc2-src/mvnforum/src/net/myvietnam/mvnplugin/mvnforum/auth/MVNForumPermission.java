/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/auth/MVNForumPermission.java,v 1.10 2003/09/12 17:37:26 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.10 $
 * $Date: 2003/09/12 17:37:26 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.auth;

public interface MVNForumPermission {

/**************************************************************************
 * Below are constant, once a constant have been assigned
 * a value, it CANNOT be changed (for compatibility).
 **************************************************************************/


/**************************************************************************
 * Special permissions, range from 0 to 99
 **************************************************************************/
    /**
     * No permission, just use to reserved the value 0
     * Normally, this permission should never be used.
     */
    public static final int PERMISSION_EMPTY                = 0;

    /**
     * All users will have this permission once they have logged in.
     */
    public static final int PERMISSION_AUTHENTICATED        = 1;

    /**
     * If a user have this permission, it means he is revoked all permissions
     * This permission is still reserved for future uses.
     */
    public static final int PERMISSION_NO_PERMISSIONS       = 2;

    /**
     * All users will have this permission once they have logged in
     * and they have activated their account using email activation process
     */
    public static final int PERMISSION_ACTIVATED            = 3;


/**************************************************************************
 * Combined permissions, range from 100 to 199
 * A permission in this range is the combination of other individual permissions
 * NOTE: values from 200 to (1000-1) are still reserved
 **************************************************************************/
    /**
     * This permission is combination of all permissions,
     * but excludes all special permissions.
     */
    public static final int PERMISSION_SYSTEM_ADMIN         = 100;

    /**
     */
    public static final int PERMISSION_GROUP_ADMIN          = 101;

    /**
     */
    public static final int PERMISSION_GROUP_MODERATOR      = 102;

    /**
     */
    public static final int PERMISSION_USER_ADMIN           = 103;

    /**
     */
    public static final int PERMISSION_USER_MODERATOR       = 104;

    /**
     */
    public static final int PERMISSION_FORUM_ADMIN          = 105;

    /**
     */
    public static final int PERMISSION_FORUM_MODERATOR      = 106;

    /**
     * Reserved
     */
    public static final int PERMISSION_CATEGORY_ADMIN       = 107;

    /**
     * Reserved
     */
    public static final int PERMISSION_CATEGORY_MODERATOR   = 108;

    /**
     * Can:
     * - login, read thread and post, reply to a thread
     */
    public static final int PERMISSION_LIMITED_USER         = 109;

    /**
     * Can:
     * - login, read thread and post, reply to a thread
     * - Add thread, use avatar, get attachment
     */
    public static final int PERMISSION_NORMAL_USER          = 110;

    /**
     * Can:
     * - login, read thread and post, reply to a thread
     * - Add thread, use avatar, get attachment
     * - use attachment, create poll
     */
    public static final int PERMISSION_POWER_USER           = 111;


/**************************************************************************
 * Individual Permissions, range begin at 1000
 * A permission in this range is an single permission
 * A Combined Permission usually includes some Individual Permissions
 **************************************************************************/

/**************************************************************************
 * Individual Permissions for global usages, range from 1000 to (2000-1)
 * NOTE: values from 2000 and above are still reserved
 **************************************************************************/
    /**************************************************************************
     * Individual Global Permissions which high-level permission, range from 1000 to (1100-1)
     **************************************************************************/
    /**
     * Login
     */
    public static final int PERMISSION_LOGIN                = 1000;

    /**
     * Admin the system, this permission should not be used
     * instead, use the combined PERMISSION_SYSTEM_ADMIN
     */
    //public static final int PERMISSION_ADMIN_SYSTEM         = 1001;

    /**
     * Add a Forum
     */
    public static final int PERMISSION_ADD_FORUM            = 1002;

    /**
     * Add a Category
     */
    public static final int PERMISSION_ADD_CATEGORY         = 1003;

    /**
     * Edit a Category
     */
    public static final int PERMISSION_EDIT_CATEGORY        = 1004;

    /**
     * Delete a Category
     */
    public static final int PERMISSION_DELETE_CATEGORY      = 1005;

    /**
     * Send Mail
     */
    public static final int PERMISSION_SEND_MAIL            = 1006;

    /**************************************************************************
     * Individual Global Permissions which low-level permission, range from 1100 to (2000-1)
     **************************************************************************/
    /**
     * Use private message
     */
    public static final int PERMISSION_USE_MESSAGE          = 1100;

    /**
     * Use private message
     */
    public static final int PERMISSION_USE_AVATAR           = 1101;


/**************************************************************************
 * Individual Permissions that can be applied for individual forum usages,
 * (of course it can be applied to all forums), range from 2000 to (3000-1)
 **************************************************************************/
    /**************************************************************************
     * Individual Permissions which high-level permission, range from 2000 to (2100-1)
     **************************************************************************/
    /**
     * Edit a Forum
     */
    public static final int PERMISSION_EDIT_FORUM           = 2000;

    /**
     * Delete a Forum
     */
    public static final int PERMISSION_DELETE_FORUM         = 2001;

    /**************************************************************************
     * Individual Permissions which low-level permission, range from (2100 to 3000-1)
     **************************************************************************/
    /**
     * Read post in the forum
     */
    public static final int PERMISSION_READ_POST            = 2100;

    /**
     * Create add thread
     */
    public static final int PERMISSION_ADD_THREAD           = 2101;

    /**
     * Add a post (reply to a thread)
     */
    public static final int PERMISSION_ADD_POST             = 2102;

    /**
     * Edit post in the forum
     * This permission allow edit all posts and attach all files to the post
     */
    public static final int PERMISSION_EDIT_POST            = 2103;

    /**
     * Delete post in the forum
     */
    public static final int PERMISSION_DELETE_POST          = 2104;

    /**
     * Add a poll
     */
    public static final int PERMISSION_ADD_POLL             = 2105;

    /**
     * Edit a poll
     */
    public static final int PERMISSION_EDIT_POLL            = 2106;

    /**
     * Delete a poll
     */
    public static final int PERMISSION_DELETE_POLL          = 2107;

    /**
     * Can attach files when posting
     */
    public static final int PERMISSION_ADD_ATTACHMENT       = 2108;

    /**
     * Can download attached files
     */
    public static final int PERMISSION_GET_ATTACHMENT       = 2109;


/**************************************************************************
 * Special permissions methods
 **************************************************************************/

    public boolean isAuthenticated();
    public void ensureIsAuthenticated() throws AuthenticationException;

    public boolean isActivated();
    public void ensureIsActivated() throws AuthenticationException;

/**************************************************************************
 * The below methods are used to check global permissions
 **************************************************************************/

    public boolean canLogin();
    public void ensureCanLogin() throws AuthenticationException;

    public boolean canAdminSystem();
    public void ensureCanAdminSystem() throws AuthenticationException;

    public boolean canAddForum();
    public void ensureCanAddForum() throws AuthenticationException;

    public boolean canAddCategory();
    public void ensureCanAddCategory() throws AuthenticationException;

    public boolean canEditCategory();
    public void ensureCanEditCategory() throws AuthenticationException;

    public boolean canDeleteCategory();
    public void ensureCanDeleteCategory() throws AuthenticationException;

    public boolean canSendMail();
    public void ensureCanSendMail() throws AuthenticationException;

    public boolean canUseAvatar();
    public void ensureCanUseAvatar() throws AuthenticationException;

    public boolean canUseMessage();
    public void ensureCanUseMessage() throws AuthenticationException;

/**************************************************************************
 * The below methods are used to check individual forum permissions
 **************************************************************************/

    public boolean canEditForum(int forumID);
    public void ensureCanEditForum(int forumID) throws AuthenticationException;

    public boolean canDeleteForum(int forumID);
    public void ensureCanDeleteForum(int forumID) throws AuthenticationException;

    public boolean canReadPost(int forumID);
    public void ensureCanReadPost(int forumID) throws AuthenticationException;

    public boolean canAddThread(int forumID);
    public void ensureCanAddThread(int forumID) throws AuthenticationException;

    public boolean canAddPost(int forumID);
    public void ensureCanAddPost(int forumID) throws AuthenticationException;

    public boolean canEditPost(int forumID);
    public void ensureCanEditPost(int forumID) throws AuthenticationException;

    public boolean canDeletePost(int forumID);
    public void ensureCanDeletePost(int forumID) throws AuthenticationException;

    public boolean canAddPoll(int forumID);
    public void ensureCanAddPoll(int forumID) throws AuthenticationException;

    public boolean canEditPoll(int forumID);
    public void ensureCanEditPoll(int forumID) throws AuthenticationException;

    public boolean canDeletePoll(int forumID);
    public void ensureCanDeletePoll(int forumID) throws AuthenticationException;

    public boolean canAddAttachment(int forumID);
    public void ensureCanAddAttachment(int forumID) throws AuthenticationException;

    public boolean canGetAttachment(int forumID);
    public void ensureCanGetAttachment(int forumID) throws AuthenticationException;

    /**************************************************************************
     * The below methods are utility methods to support checking permission
     **************************************************************************/

    public boolean canEditAnyForum();
    public void ensureCanEditAnyForum() throws AuthenticationException;

}