/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/PostWebHelper.java,v 1.8 2003/09/17 15:01:45 imanic Exp $
 * $Author: imanic $
 * $Revision: 1.8 $
 * $Date: 2003/09/17 15:01:45 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

//import java.sql.*;// @todo: uncomment as needed
//import java.util.Collection; // @todo: uncomment as needed
//import net.myvietnam.mvncore.db.DBUtils;// @todo: uncomment as needed
import java.sql.Timestamp;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import net.myvietnam.mvncore.exception.*;
//import net.myvietnam.mvnplugin.mvnforum.db.PostBean;// @todo: uncomment as needed

class PostWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.PostWebHelper {

    // static variable
    private static Log log = LogFactory.getLog(PostWebHelper.class);

    // prevent instantiation and inheritance
    private PostWebHelper() {
    }

    public static int createPost(int parentPostID, int forumID, int threadID,
                       int memberID, String memberName, String lastEditMemberName,
                       String postTopic, String postBody, Timestamp postCreationDate,
                       Timestamp postLastEditDate, String postCreationIP, String postLastEditIP,
                       int postEditCount, int postFormatOption, int postOption,
                       int postStatus, String postIcon, int postAttachCount)
                       throws CreateException, DatabaseException/*, DuplicateKeyException*/, ForeignKeyNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.PostWebHelper.create(
            parentPostID, forumID, threadID, memberID, memberName, lastEditMemberName,
            postTopic, postBody, postCreationDate, postLastEditDate,
            postCreationIP, postLastEditIP, postEditCount, postFormatOption,
            postOption, postStatus, postIcon, postAttachCount);
        int postID = 0;
        try {
            postID = findPostID(forumID, memberName, postCreationDate);
        } catch (ObjectNotFoundException ex) {
            // Hack the Oracle 9i problem
            Timestamp roundTimestamp = new Timestamp((postCreationDate.getTime()/1000)*1000);
            try {
               postID = findPostID(forumID, memberName, roundTimestamp);
            } catch (ObjectNotFoundException e) {
               throw new CreateException("Cannot find the PostID in table Post.");
            }
        }
        return postID;
    }

    public static void deletePost_inForum(int forumID)
        throws DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.PostWebHelper.delete_inForum(forumID);
    }

    public static void updatePostAttachCount(int postID, // primary key
                        int postAttachCount)
                        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.PostWebHelper.updateAttachCount(postID, // primary key
                        postAttachCount);
    }

    public static int getNumberOfPosts_inForum(int forumID)
        throws AssertionException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.PostWebHelper.getNumberOfBeans_inForum(forumID);
    }


}
