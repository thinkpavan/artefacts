/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/WatchBean.java,v 1.4 2003/09/14 14:15:39 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.4 $
 * $Date: 2003/09/14 14:15:39 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Iterator;

/*
 * Included columns: WatchID, MemberID, CategoryID, ForumID, ThreadID,
 *                   WatchType, WatchOption, WatchStatus, WatchCreationDate, WatchLastSentDate,
 *                   WatchEndDate
 * Excluded columns:
 */
public class WatchBean {
    /*************************************************************************
     * NOTE: below constants MUST NOT be changed IN ALL CASES,
     *       or it will break the compatibility
     *************************************************************************/
    public final static int WATCH_OPTION_LIVE   = 1;
    public final static int WATCH_OPTION_HOURLY = 2;
    public final static int WATCH_OPTION_DAILY  = 4;
    public final static int WATCH_OPTION_WEEKLY = 8;

    private int watchID;
    private int memberID;
    private int categoryID;
    private int forumID;
    private int threadID;
    private int watchType;
    private int watchOption;
    private int watchStatus;
    private Timestamp watchCreationDate;
    private Timestamp watchLastSentDate;
    private Timestamp watchEndDate;

    public int getWatchID() {
        return watchID;
    }
    public void setWatchID(int watchID) {
        this.watchID = watchID;
    }

    public int getMemberID() {
        return memberID;
    }
    public void setMemberID(int memberID) {
        this.memberID = memberID;
    }

    public int getCategoryID() {
        return categoryID;
    }
    public void setCategoryID(int categoryID) {
        this.categoryID = categoryID;
    }

    public int getForumID() {
        return forumID;
    }
    public void setForumID(int forumID) {
        this.forumID = forumID;
    }

    public int getThreadID() {
        return threadID;
    }
    public void setThreadID(int threadID) {
        this.threadID = threadID;
    }

    public int getWatchType() {
        return watchType;
    }
    public void setWatchType(int watchType) {
        this.watchType = watchType;
    }

    public int getWatchOption() {
        return watchOption;
    }
    public void setWatchOption(int watchOption) {
        this.watchOption = watchOption;
    }

    public int getWatchStatus() {
        return watchStatus;
    }
    public void setWatchStatus(int watchStatus) {
        this.watchStatus = watchStatus;
    }

    public Timestamp getWatchCreationDate() {
        return watchCreationDate;
    }
    public void setWatchCreationDate(Timestamp watchCreationDate) {
        this.watchCreationDate = watchCreationDate;
    }

    public Timestamp getWatchLastSentDate() {
        return watchLastSentDate;
    }
    public void setWatchLastSentDate(Timestamp watchLastSentDate) {
        this.watchLastSentDate = watchLastSentDate;
    }

    public Timestamp getWatchEndDate() {
        return watchEndDate;
    }
    public void setWatchEndDate(Timestamp watchEndDate) {
        this.watchEndDate = watchEndDate;
    }

    public String getXML() {
        StringBuffer xml = new StringBuffer(1024);
        xml.append("<WatchSection>\n");
        xml.append("  <Rows>\n");
        xml.append("    <Row>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>WatchID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(watchID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>CategoryID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(categoryID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>WatchType</Name>\n");
        xml.append("        <Value>").append(String.valueOf(watchType)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>WatchOption</Name>\n");
        xml.append("        <Value>").append(String.valueOf(watchOption)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>WatchStatus</Name>\n");
        xml.append("        <Value>").append(String.valueOf(watchStatus)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>WatchCreationDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(watchCreationDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>WatchLastSentDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(watchLastSentDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>WatchEndDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(watchEndDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("    </Row>\n");
        xml.append("  </Rows>\n");
        xml.append("</WatchSection>\n");
        return xml.toString();
    }

    public static String getXML(Collection objWatchBeans) {
        StringBuffer xml = new StringBuffer(1024);
        Iterator iterator = objWatchBeans.iterator();
        xml.append("<WatchSection>\n");
        xml.append("  <Rows>\n");
        while (iterator.hasNext()) {
            WatchBean objWatchBean = (WatchBean)iterator.next();
            xml.append("    <Row>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>WatchID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objWatchBean.watchID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objWatchBean.memberID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>CategoryID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objWatchBean.categoryID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objWatchBean.forumID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objWatchBean.threadID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>WatchType</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objWatchBean.watchType)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>WatchOption</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objWatchBean.watchOption)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>WatchStatus</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objWatchBean.watchStatus)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>WatchCreationDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objWatchBean.watchCreationDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>WatchLastSentDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objWatchBean.watchLastSentDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>WatchEndDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objWatchBean.watchEndDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("    </Row>\n");
        }//while
        xml.append("  </Rows>\n");
        xml.append("</WatchSection>\n");
        return xml.toString();
    }

    // Store the ThreadBean if this is a Thread Watch
    ThreadBean threadBean = null;

    public ThreadBean getThreadBean() {
        return threadBean;
    }
    public void setThreadBean(ThreadBean threadBean) {
        this.threadBean = threadBean;
    }

} //end of class WatchBean
