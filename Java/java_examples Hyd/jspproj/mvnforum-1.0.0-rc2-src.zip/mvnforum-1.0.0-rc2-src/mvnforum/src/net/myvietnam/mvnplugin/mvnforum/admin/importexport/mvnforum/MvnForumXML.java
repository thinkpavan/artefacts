/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/importexport/mvnforum/MvnForumXML.java,v 1.9 2003/10/21 20:04:24 imanic Exp $
 * $Author: imanic $
 * $Revision: 1.9 $
 * $Date: 2003/10/21 20:04:24 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Igor Manic   imanic@users.sourceforge.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin.importexport.mvnforum;

import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvnplugin.mvnforum.MVNForumConstant;
import net.myvietnam.mvnplugin.mvnforum.MVNForumConfig;
import net.myvietnam.mvnplugin.mvnforum.ManagerFactory;
import net.myvietnam.mvnplugin.mvnforum.admin.GroupXML;
import net.myvietnam.mvnplugin.mvnforum.admin.ImportWebHelper;
import net.myvietnam.mvnplugin.mvnforum.admin.MemberXML;
import net.myvietnam.mvnplugin.mvnforum.admin.RankXML;

/**
 * @author <a href="mailto:imanic@users.sourceforge.net">Igor Manic</a>
 * @version $Revision: 1.9 $, $Date: 2003/10/21 20:04:24 $
 * <br/>
 * <code>MvnForumXML</code> todo Igor: enter description
 *
 */
public class MvnForumXML {

    /** Did we find Admin member? If we didn't, default one will be created, with password "admin". */
    public static boolean addedAdminMember = false;
    /** Did we find Guest member? If we didn't, default one will be created. */
    public static boolean addedGuestMember = false;
    /** Did we find Registered Members group? If we didn't, default one will be created. */
    public static boolean addedRegisteredMembersGroup = false;
    
    public MvnForumXML() throws DatabaseException, CreateException, 
    DuplicateKeyException, ObjectNotFoundException, ForeignKeyNotFoundException {
        super();
        MvnForumXML.addedAdminMember=false;
        MvnForumXML.addedGuestMember=false;
        MvnForumXML.addedRegisteredMembersGroup=false;
        ImportMvnForum.createDefaultContents();
    }


// ================================================================================
// ==================== METHODS TO BE CALLED FROM THE DIGESTER ====================
// ================================================================================
    public void setMvnForumXmlVersion(String value) {
        ImportMvnForum.addMessage("mvnForum XML version = \""+value+"\"");
    }

    public void setMvnForumExportDate(String value) {
        ImportMvnForum.addMessage("mvnForum XML export date = \""+value+"\"");
    }

    public void postProcessMemberList() throws CreateException, DuplicateKeyException,
    ObjectNotFoundException, DatabaseException, ForeignKeyNotFoundException, BadInputException {
        MvnForumXML.checkAdminMember();
        MvnForumXML.checkGuestMember();
    }

    public void postProcessGroupList() throws CreateException, DuplicateKeyException,
    ObjectNotFoundException, DatabaseException, ForeignKeyNotFoundException {
        MvnForumXML.checkRegisteredMembersGroup();
    }
    
    public static void finishImport() throws CreateException, DuplicateKeyException,
    ObjectNotFoundException, DatabaseException, ForeignKeyNotFoundException, BadInputException {
        checkAdminMember();
        checkGuestMember();
        checkRegisteredMembersGroup();
    }
    
    public void addGuestGlobalPermission(String permission)
    throws CreateException, DuplicateKeyException, ObjectNotFoundException,
    DatabaseException, ForeignKeyNotFoundException {
        MvnForumXML.addGuestMemberPermission(permission);
    }

    public void addRegisteredMembersGlobalPermission(String permission)
    throws CreateException, DuplicateKeyException, ObjectNotFoundException,
    DatabaseException, ForeignKeyNotFoundException {
        MvnForumXML.addRegisteredMembersGroupPermission(permission);
    }

    public void addRank(String rankMinPosts, String rankLevel, String rankTitle,
                        String rankImage, String rankType, String rankOption)
    throws CreateException, DuplicateKeyException, ObjectNotFoundException,
    DatabaseException, ForeignKeyNotFoundException {
        ImportMvnForum.addMessage("Adding rank title \""+rankTitle+"\".");
        (new RankXML()).addRank(rankMinPosts, rankLevel, rankTitle,
                                rankImage, rankType, rankOption);
    }

// ================================================================================
// ====================== UTILITY METHODS ABOUT PERMISSIONS =======================
// ================================================================================
    /**
     * TODO Igor: enter description
     * 
     * @param username
     * @param permission
     */
    public static void addMemberPermission(String username, String permission)
    throws ObjectNotFoundException, CreateException, DatabaseException,
    ForeignKeyNotFoundException, DuplicateKeyException {
        MemberXML.addMemberPermission(username, permission);
    }

    /**
     * TODO Igor: enter description
     * 
     * @param permission
     */
    public static void addGuestMemberPermission(String permission)
    throws CreateException, DatabaseException, DuplicateKeyException,
    ForeignKeyNotFoundException {
        MemberXML.addGuestMemberPermission(permission);
    }

    /**
     * TODO Igor: enter description
     * 
     * @param permission
     */
    public static void addRegisteredMembersGroupPermission(String permission)
    throws CreateException, DatabaseException, DuplicateKeyException,
    ForeignKeyNotFoundException {
        GroupXML.addRegisteredMembersGroupPermission(permission);
    }

    /**
     * TODO Igor: enter description
     * 
     * @param groupname
     * @param permission
     */
    public static void addGroupPermission(String groupname, String permission)
    throws CreateException, DatabaseException, DuplicateKeyException,
    ForeignKeyNotFoundException, ObjectNotFoundException {
        GroupXML.addGroupPermission(groupname, permission);
    }


// ================================================================================
// ============================ OTHER PUBLIC METHODS ==============================
// ================================================================================
    public static void checkAdminMember() throws CreateException, DuplicateKeyException,
    ObjectNotFoundException, DatabaseException, ForeignKeyNotFoundException, BadInputException {
        if (!addedAdminMember) {
            ImportMvnForum.addImportantMessage("Didn't find SYSTEM_ADMIN member. Adding default one with a name \""+
                                "admin\" and password \"admin\". For your security, "+
                                "you should first change that password.");
            ImportWebHelper.createDefaultAdminMember();
            addedAdminMember=true; 
        }
    }

    public static void checkGuestMember() throws CreateException, DuplicateKeyException,
    ObjectNotFoundException, DatabaseException, ForeignKeyNotFoundException, BadInputException {
        if (!addedGuestMember) {
            ImportMvnForum.addImportantMessage("Didn't find virtual guest member. "+
                           "Adding default one with a name \""+
                           MVNForumConfig.getDefaultGuestName()+"\" and no password. "+
                           "He'll have READ_POST permissions in all forums, "+
                           "and global ADD_POST permission.");
            ImportWebHelper.createDefaultGuestMember();
            addedGuestMember=true; 
        }
    }

    public static void checkRegisteredMembersGroup() throws CreateException,
    DuplicateKeyException, ObjectNotFoundException, DatabaseException, ForeignKeyNotFoundException {
        if (!addedRegisteredMembersGroup) {
            //set GroupOwnerName to the system admin
            String groupOwnerName="";
            try {
                groupOwnerName=ManagerFactory.getMemberDAO().getBean_forPublic(MVNForumConstant.MEMBER_ID_OF_ADMIN).getMemberName();
            } catch (Exception e) {
                groupOwnerName="";
            }
            ImportMvnForum.addImportantMessage("Didn't find \"Registered Members\" group. "+
                              "Adding default one.");
            ImportWebHelper.createDefaultRegisteredMembersGroup(groupOwnerName);
            addedRegisteredMembersGroup=true;
        }
    }


}

