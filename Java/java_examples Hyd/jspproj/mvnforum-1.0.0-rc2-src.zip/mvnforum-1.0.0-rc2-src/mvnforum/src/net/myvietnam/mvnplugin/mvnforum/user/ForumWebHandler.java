/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/user/ForumWebHandler.java,v 1.14 2003/10/19 19:50:49 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.14 $
 * $Date: 2003/10/19 19:50:49 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.user;

import java.util.Collection;
import javax.servlet.http.HttpServletRequest;

import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvnplugin.mvnforum.ManagerFactory;
import net.myvietnam.mvnplugin.mvnforum.auth.*;
import net.myvietnam.mvnplugin.mvnforum.db.MemberBean;

class ForumWebHandler {

    private OnlineUserManager userManager = OnlineUserManager.getInstance();

    ForumWebHandler() {
    }

    void prepareList(HttpServletRequest request, String requestURI)
        throws AssertionException, DatabaseException, AuthenticationException, MissingURLMapEntryException {

        int numberOfThreads = ThreadWebHelper.getNumberOfThreads();
        int numberOfPosts = PostWebHelper.getNumberOfPosts();
        int numberOfMembers = ManagerFactory.getMemberDAO().getNumberOfBeans();
        Collection memberBeans = MemberWebHelper.getMembers_withSortSupport_limit(0, 1, "MemberID", "DESC");
        if (memberBeans.size() != 1) {
            throw new AssertionException("Assertion: MemberBeans size != 1");
        }
        MemberBean memberBean = (MemberBean)memberBeans.iterator().next();

        // the following 2 lines fix the bug that no online user found in the first time request
        userManager.getOnlineUser(request);
        Action action = new ActionInUserModule(request, requestURI); // may throw MissingURLMapEntryException
        userManager.updateOnlineUserAction(request, action);
        // now set the attribute
        request.setAttribute("OnlineUserActions",userManager.getOnlineUserActions(0 /*default*/)); // no permission

        request.setAttribute("NumberOfThreads", new Integer(numberOfThreads));
        request.setAttribute("NumberOfPosts", new Integer(numberOfPosts));
        request.setAttribute("MemberBean", memberBean);
        request.setAttribute("NumberOfMembers", new Integer(numberOfMembers));

    }
}
