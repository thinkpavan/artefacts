/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/auth/MVNForumPermissionImpl.java,v 1.10 2003/09/12 17:37:26 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.10 $
 * $Date: 2003/09/12 17:37:26 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.auth;

import net.myvietnam.mvncore.exception.AssertionException;

/**
 * This class is private in the package
 */
class MVNForumPermissionImpl extends AbstractPermission implements MVNForumPermission {

    MVNForumPermissionImpl() {
    }

    /**
     * The ONLY way to set permission, so this MUST have default package access
     */
    void setPermission(int permission) throws AssertionException {
        switch (permission) {
            case PERMISSION_AUTHENTICATED:
                authenticated   = true;
                break;

            case PERMISSION_ACTIVATED:
                activated   = true;
                break;
/**************************************************************************
 * Combined permissions, range from 100 to 199
 * A permission in this range is the combination of other permissions
 **************************************************************************/
            case PERMISSION_SYSTEM_ADMIN:
                adminSystem     = true;
                addForum        = true;
                editForum.setAllForumsPermission(true);
                deleteForum.setAllForumsPermission(true);
                addCategory     = true;
                editCategory    = true;
                deleteCategory  = true;
                sendMail        = true;
                useAvatar       = true;
                useMessage      = true;

                readPost.setAllForumsPermission(true);
                addThread.setAllForumsPermission(true);
                addPost.setAllForumsPermission(true);
                editPost.setAllForumsPermission(true);
                deletePost.setAllForumsPermission(true);
                addPoll.setAllForumsPermission(true);
                editPoll.setAllForumsPermission(true);
                deletePoll.setAllForumsPermission(true);
                addAttachment.setAllForumsPermission(true);
                getAttachment.setAllForumsPermission(true);
                break;

            case PERMISSION_FORUM_ADMIN:
                addForum        = true;
                editForum.setAllForumsPermission(true);
                deleteForum.setAllForumsPermission(true);
                addCategory     = true;
                editCategory    = true;
                deleteCategory  = true;

                readPost.setAllForumsPermission(true);
                addThread.setAllForumsPermission(true);
                addPost.setAllForumsPermission(true);
                editPost.setAllForumsPermission(true);
                deletePost.setAllForumsPermission(true);
                addPoll.setAllForumsPermission(true);
                editPoll.setAllForumsPermission(true);
                deletePoll.setAllForumsPermission(true);
                addAttachment.setAllForumsPermission(true);
                getAttachment.setAllForumsPermission(true);
                break;

            case PERMISSION_FORUM_MODERATOR:
                editForum.setAllForumsPermission(true);
                editCategory    = true;

                readPost.setAllForumsPermission(true);
                addThread.setAllForumsPermission(true);
                addPost.setAllForumsPermission(true);
                editPost.setAllForumsPermission(true);
                deletePost.setAllForumsPermission(true);
                addPoll.setAllForumsPermission(true);
                editPoll.setAllForumsPermission(true);
                deletePoll.setAllForumsPermission(true);
                addAttachment.setAllForumsPermission(true);
                getAttachment.setAllForumsPermission(true);
                break;

            case PERMISSION_LIMITED_USER:
                readPost.setAllForumsPermission(true);
                /** @todo at the 1.0.0 beta2/beta3/RC1/RC2 release, add post is disable*/
//                addPost         = true;
                break;

            case PERMISSION_NORMAL_USER:
                useAvatar       = true;
                useMessage      = true;

                readPost.setAllForumsPermission(true);
                addThread.setAllForumsPermission(true);
                addPost.setAllForumsPermission(true);
                getAttachment.setAllForumsPermission(true);
                break;

            /**
             * Can:
             * - login, read thread and post, reply to a thread
             * - add thread, use avatar, use private message, get attachment
             * - use attachment, create poll
             */
            case PERMISSION_POWER_USER:
                useAvatar       = true;
                useMessage      = true;

                readPost.setAllForumsPermission(true);
                addThread.setAllForumsPermission(true);
                addPost.setAllForumsPermission(true);
                addPoll.setAllForumsPermission(true);
                addAttachment.setAllForumsPermission(true);
                getAttachment.setAllForumsPermission(true);
                break;

/**************************************************************************
 * Individual Permissions for global usages, range from 1000 to 2000
 **************************************************************************/
            case PERMISSION_LOGIN:
                login           = true;
                break;
            //case PERMISSION_ADMIN_SYSTEM:
            //    adminSystem     = true;
            //    break;
            case PERMISSION_ADD_FORUM:
                addForum          = true;
                break;
            case PERMISSION_ADD_CATEGORY:
                addCategory     = true;
                break;
            case PERMISSION_EDIT_CATEGORY:
                editCategory    = true;
                break;
            case PERMISSION_DELETE_CATEGORY:
                deleteCategory  = true;
                break;
            case PERMISSION_SEND_MAIL:
                sendMail        = true;
                break;
            case PERMISSION_USE_MESSAGE:
                useMessage      = true;
                break;
            case PERMISSION_USE_AVATAR:
                useAvatar       = true;
                break;

/**************************************************************************
 * Individual Permissions that can be applied for individual forum usages,
 * (of course it can be applied to all forums), range from 2000 to 3000
 **************************************************************************/
            case PERMISSION_EDIT_FORUM:
                editForum.setAllForumsPermission(true);
                break;
            case PERMISSION_DELETE_FORUM:
                deleteForum.setAllForumsPermission(true);
                break;
            case PERMISSION_READ_POST:
                readPost.setAllForumsPermission(true);
                break;
            case PERMISSION_ADD_THREAD:
                addThread.setAllForumsPermission(true);
                break;
            case PERMISSION_ADD_POST:
                addPost.setAllForumsPermission(true);
                break;
            case PERMISSION_EDIT_POST:
                editPost.setAllForumsPermission(true);
                break;
            case PERMISSION_DELETE_POST:
                deletePost.setAllForumsPermission(true);
                break;
            case PERMISSION_ADD_POLL:
                addPoll.setAllForumsPermission(true);
                break;
            case PERMISSION_EDIT_POLL:
                editPoll.setAllForumsPermission(true);
                break;
            case PERMISSION_DELETE_POLL:
                deletePoll.setAllForumsPermission(true);
                break;
            case PERMISSION_ADD_ATTACHMENT:
                addAttachment.setAllForumsPermission(true);
                break;
            case PERMISSION_GET_ATTACHMENT:
                getAttachment.setAllForumsPermission(true);
                break;

/**************************************************************************
 * cannot find, just throw an Exception
 **************************************************************************/

            default:
                throw new AssertionException("Currently do not support permission = " + permission);
        }//switch
    }//setPermission

    /**
     * The ONLY way to set permission in forum, so this MUST have default package access
     */
    void setPermissionInForum(int forumID, int permission) throws AssertionException {
        switch (permission) {
/**************************************************************************
 * Combined permissions, range from 100 to 199
 * A permission in this range is the combination of other permissions
 **************************************************************************/
            case PERMISSION_FORUM_ADMIN:
                editForum.setForumPermission(forumID, true);
                deleteForum.setForumPermission(forumID, true);

                readPost.setForumPermission(forumID, true);
                addThread.setForumPermission(forumID, true);
                addPost.setForumPermission(forumID, true);
                editPost.setForumPermission(forumID, true);
                deletePost.setForumPermission(forumID, true);
                addPoll.setForumPermission(forumID, true);
                editPoll.setForumPermission(forumID, true);
                deletePoll.setForumPermission(forumID, true);
                addAttachment.setForumPermission(forumID, true);
                getAttachment.setForumPermission(forumID, true);
                break;

            case PERMISSION_FORUM_MODERATOR:
                editForum.setForumPermission(forumID, true);

                readPost.setForumPermission(forumID, true);
                addThread.setForumPermission(forumID, true);
                addPost.setForumPermission(forumID, true);
                editPost.setForumPermission(forumID, true);
                deletePost.setForumPermission(forumID, true);
                addPoll.setForumPermission(forumID, true);
                editPoll.setForumPermission(forumID, true);
                deletePoll.setForumPermission(forumID, true);
                addAttachment.setForumPermission(forumID, true);
                getAttachment.setForumPermission(forumID, true);
                break;

            case PERMISSION_LIMITED_USER:
                readPost.setForumPermission(forumID, true);
                /** @todo at the 1.0.0 beta2/beta3/RC1/RC2 release, add post is disable*/
                //addPost.setForumPermission(forumID, true);
                break;

            case PERMISSION_NORMAL_USER:
                readPost.setForumPermission(forumID, true);
                addThread.setForumPermission(forumID, true);
                addPost.setForumPermission(forumID, true);
                getAttachment.setForumPermission(forumID, true);
                break;

    /**
     * Can:
     * - login, read thread and post, reply to a thread
     * - add thread, use avatar, use private message, get attachment
     * - use attachment, create poll
     */
            case PERMISSION_POWER_USER:
                readPost.setForumPermission(forumID, true);
                addThread.setForumPermission(forumID, true);
                addPost.setForumPermission(forumID, true);
                addPoll.setForumPermission(forumID, true);
                addAttachment.setForumPermission(forumID, true);
                getAttachment.setForumPermission(forumID, true);
                break;

/**************************************************************************
 * Individual Permissions that can be applied for individual forum usages,
 * (of course it can be applied to all forums), range from 2000 to 3000
 **************************************************************************/
            case PERMISSION_EDIT_FORUM:
                editForum.setForumPermission(forumID, true);
                break;
            case PERMISSION_DELETE_FORUM:
                deleteForum.setForumPermission(forumID, true);
                break;
            case PERMISSION_READ_POST:
                readPost.setForumPermission(forumID, true);
                break;
            case PERMISSION_ADD_THREAD:
                addThread.setForumPermission(forumID, true);
                break;
            case PERMISSION_ADD_POST:
                addPost.setForumPermission(forumID, true);
                break;
            case PERMISSION_EDIT_POST:
                editPost.setForumPermission(forumID, true);
                break;
            case PERMISSION_DELETE_POST:
                deletePost.setForumPermission(forumID, true);
                break;
            case PERMISSION_ADD_POLL:
                addPoll.setForumPermission(forumID, true);
                break;
            case PERMISSION_EDIT_POLL:
                editPoll.setForumPermission(forumID, true);
                break;
            case PERMISSION_DELETE_POLL:
                deletePoll.setForumPermission(forumID, true);
                break;
            case PERMISSION_ADD_ATTACHMENT:
                addAttachment.setForumPermission(forumID, true);
                break;
            case PERMISSION_GET_ATTACHMENT:
                getAttachment.setForumPermission(forumID, true);
                break;


/**************************************************************************
 * cannot find, just throw an Exception
 **************************************************************************/

            default:
                throw new AssertionException("Currently do not support permission = " + permission);
        }//switch
    }//setPermissionInForum

}
