/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/search/UpdateThreadTask.java,v 1.1 2003/09/25 16:54:08 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.1 $
 * $Date: 2003/09/25 16:54:08 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.search;

import java.io.IOException;
import java.util.*;

import net.myvietnam.mvnplugin.mvnforum.db.PostBean;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.index.IndexWriter;

/**
 * Update a thread task. This task do indexing of all post in the thread
 */
public class UpdateThreadTask extends TimerTask
{
    private static Log log = LogFactory.getLog(UpdateThreadTask.class);

    private int threadID = 0;

    /*
     * Contructor with default access, prevent new an instance from outside package
     */
    UpdateThreadTask(int threadID) {
        this.threadID = threadID;
    }

    /**
     * Delete all posts in the thread first, then add it again
     */
    public void run() {
        long start = System.currentTimeMillis();

        Collection posts = null;
        try {
            //hard code 10000 post to get. is it enough???
            posts = PostWebHelper.getPosts_inThread_limit(threadID, 0, 10000);
        } catch (Exception ex) {
            log.error("UpdateThreadTask.run : cannot get all posts from a thread (" + threadID + ") for indexing", ex);
        }

        if (posts == null) return;

        IndexWriter writer = null;
        try {
            // First, delete all posts from the thread
            PostIndexer.deleteThreadFromIndex(threadID);

            // then add all posts of the thread
            writer = PostIndexer.getIndexWriter(false);
            Iterator iter = posts.iterator();
            int i = 0;
            while (iter.hasNext()) {
                PostBean post = (PostBean) iter.next();
                PostIndexer.doIndexPost(post, writer);
                i++;
            }
            writer.optimize();
            log.info("Updating thread finished successfully! " + i + " post(s) indexed.");
        } catch (Exception e) {
            log.error("Error while updating thread.", e);
        } finally {
            try {
                if (writer != null) {
                    writer.close();
                }
            } catch (IOException ignore) {
            }
        }
        log.info("UpdateThreadTask took " + (System.currentTimeMillis() - start) + " ms");
    }
}
