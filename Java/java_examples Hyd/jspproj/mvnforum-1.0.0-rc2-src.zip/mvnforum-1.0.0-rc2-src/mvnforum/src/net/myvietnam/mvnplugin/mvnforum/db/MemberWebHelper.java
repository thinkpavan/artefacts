/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/MemberWebHelper.java,v 1.22 2003/10/05 09:51:43 imanic Exp $
 * $Author: imanic $
 * $Revision: 1.22 $
 * $Date: 2003/10/05 09:51:43 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.sql.*;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.db.DBUtils;
import net.myvietnam.mvncore.exception.*;

/*
// @todo: copy this skeleton for derived class
package package_of_derived_class;

//import java.sql.*;// @todo: uncomment as needed
//import java.util.Collection; // @todo: uncomment as needed
//import net.myvietnam.mvncore.db.DBUtils;// @todo: uncomment as needed
import net.myvietnam.mvncore.exception.*;
//import net.myvietnam.mvnplugin.mvnforum.db.MemberBean;// @todo: uncomment as needed

class MemberWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper {
    // prevent instantiation and inheritance
    private MemberWebHelper() {
    }

    // @todo: add methods here
}
*/
public class MemberWebHelper implements MemberDAO {

    private static Log log = LogFactory.getLog(MemberWebHelper.class);

    public static final String TABLE_NAME = DatabaseConfig.TABLE_PREFIX + "Member";

    // this variable will support caching if cache for this class is needed
    private static boolean m_dirty = true;

    // Prevent instantiation from classes other than derived classes
    public MemberWebHelper() {
    }

    protected static boolean isDirty() {
        return m_dirty;
    }

    protected static void setDirty(boolean dirty) {
        m_dirty = dirty;
    }

    public void findByPrimaryKey(int memberID)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberID");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            resultSet = statement.executeQuery();
            if (!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the primary key (" + memberID + ") in table 'Member'.");
            }
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.findByPrimaryKey.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    public void findByAlternateKey_MemberName(String memberName)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberName");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE MemberName = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setString(1, memberName);
            resultSet = statement.executeQuery();
            if (!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the alternate key <MemberName> (" + memberName + ") in table 'Member'.");
            }
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.findByAlternateKey_MemberName.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    public void findByAlternateKey_MemberEmail(String memberEmail)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberEmail");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE MemberEmail = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setString(1, memberEmail);
            resultSet = statement.executeQuery();
            if (!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the alternate key <MemberEmail> (" + memberEmail + ") in table 'Member'.");
            }
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.findByAlternateKey_MemberEmail.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /**
     * Delete the user specified by memberID. Note that this method
     * will not fail it the given id does not exists.
     *
     * @param memberID an <code>int</code> value
     * @exception DatabaseException if an error occurs
     */
    public void deleteByPrimaryKey(int memberID) throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("DELETE");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            statement.executeUpdate();
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.deleteByPrimaryKey.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }


/*
// @todo: copy this method for derived class
    public static void createMember(String memberName, String memberPassword, String memberFirstEmail,
                        String memberEmail, int memberEmailVisible, int memberNameVisible,
                        String memberFirstIP, String memberLastIP, int memberViewCount,
                        int memberPostCount, Timestamp memberCreationDate, Timestamp memberModifiedDate,
                        Timestamp memberLastLogon, int memberOption, int memberStatus,
                        String memberActivateCode, String memberTempPassword, int memberMessageCount,
                        int memberMessageOption, int memberPostsPerPage, int memberWarnCount,
                        int memberVoteCount, int memberVoteTotalStars, int memberRewardPoints,
                        String memberTitle, int memberTimeZone, String memberSignature,
                        String memberAvatar, String memberSkin, String memberLanguage,
                        String memberFirstname, String memberLastname, int memberGender,
                        Date memberBirthday, String memberAddress, String memberCity,
                        String memberState, String memberCountry, String memberPhone,
                        String memberMobile, String memberFax, String memberCareer,
                        String memberHomepage, String memberYahoo, String memberAol,
                        String memberIcq, String memberMsn, String memberCoolLink1,
                        String memberCoolLink2)
                        throws CreateException, DatabaseException, DuplicateKeyException {
        net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.create(memberName, memberPassword, memberFirstEmail, memberEmail, memberEmailVisible, memberNameVisible, memberFirstIP, memberLastIP, memberViewCount, memberPostCount, memberCreationDate, memberModifiedDate, memberLastLogon, memberOption, memberStatus, memberActivateCode, memberTempPassword, memberMessageCount, memberMessageOption, memberPostsPerPage, memberWarnCount, memberVoteCount, memberVoteTotalStars, memberRewardPoints, memberTitle, memberTimeZone, memberSignature, memberAvatar, memberSkin, memberLanguage, memberFirstname, memberLastname, memberGender, memberBirthday, memberAddress, memberCity, memberState, memberCountry, memberPhone, memberMobile, memberFax, memberCareer, memberHomepage, memberYahoo, memberAol, memberIcq, memberMsn, memberCoolLink1, memberCoolLink2);
    }
*/
    /*
     * Included columns: MemberName, MemberPassword, MemberFirstEmail, MemberEmail, MemberEmailVisible,
     *                   MemberNameVisible, MemberFirstIP, MemberLastIP, MemberViewCount, MemberPostCount,
     *                   MemberCreationDate, MemberModifiedDate, MemberLastLogon, MemberOption, MemberStatus,
     *                   MemberActivateCode, MemberTempPassword, MemberMessageCount, MemberMessageOption, MemberPostsPerPage,
     *                   MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle,
     *                   MemberTimeZone, MemberSignature, MemberAvatar, MemberSkin, MemberLanguage,
     *                   MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress,
     *                   MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile,
     *                   MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol,
     *                   MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2
     * Excluded columns: MemberID
     */
    public void create(String memberName, String memberPassword, String memberFirstEmail,
                        String memberEmail, int memberEmailVisible, int memberNameVisible,
                        String memberFirstIP, String memberLastIP, int memberViewCount,
                        int memberPostCount, Timestamp memberCreationDate, Timestamp memberModifiedDate,
                        Timestamp memberLastLogon, int memberOption, int memberStatus,
                        String memberActivateCode, String memberTempPassword, int memberMessageCount,
                        int memberMessageOption, int memberPostsPerPage, int memberWarnCount,
                        int memberVoteCount, int memberVoteTotalStars, int memberRewardPoints,
                        String memberTitle, int memberTimeZone, String memberSignature,
                        String memberAvatar, String memberSkin, String memberLanguage,
                        String memberFirstname, String memberLastname, int memberGender,
                        Date memberBirthday, String memberAddress, String memberCity,
                        String memberState, String memberCountry, String memberPhone,
                        String memberMobile, String memberFax, String memberCareer,
                        String memberHomepage, String memberYahoo, String memberAol,
                        String memberIcq, String memberMsn, String memberCoolLink1,
                        String memberCoolLink2)
                        throws CreateException, DatabaseException, DuplicateKeyException {

        // @todo: Comment this try-catch block if the needed columns dont have attribute 'include'
        // If this is the case, then it is highly recommended that you regenerate this method with the attribute 'include' turned on
        try {
            //Check if alternate key already exists
            findByAlternateKey_MemberName(memberName);
            //If so, then we have to throw an exception
            throw new DuplicateKeyException("Alternate key already exists. Cannot create new Member with the same <MemberName> (" + memberName + ").");
        } catch(ObjectNotFoundException e) {
            //Otherwise we can go ahead
        }

        // @todo: Comment this try-catch block if the needed columns dont have attribute 'include'
        // If this is the case, then it is highly recommended that you regenerate this method with the attribute 'include' turned on
        try {
            //Check if alternate key already exists
            findByAlternateKey_MemberEmail(memberEmail);
            //If so, then we have to throw an exception
            throw new DuplicateKeyException("Alternate key already exists. Cannot create new Member with the same <MemberEmail> (" + memberEmail + ").");
        } catch(ObjectNotFoundException e) {
            //Otherwise we can go ahead
        }

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("INSERT INTO " + TABLE_NAME + " (MemberName, MemberPassword, MemberFirstEmail, MemberEmail, MemberEmailVisible, MemberNameVisible, MemberFirstIP, MemberLastIP, MemberViewCount, MemberPostCount, MemberCreationDate, MemberModifiedDate, MemberLastLogon, MemberOption, MemberStatus, MemberActivateCode, MemberTempPassword, MemberMessageCount, MemberMessageOption, MemberPostsPerPage, MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle, MemberTimeZone, MemberSignature, MemberAvatar, MemberSkin, MemberLanguage, MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress, MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile, MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol, MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2)");
        sql.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            statement.setString(1, memberName);
            statement.setString(2, memberPassword);
            statement.setString(3, memberFirstEmail);
            statement.setString(4, memberEmail);
            statement.setInt(5, memberEmailVisible);
            statement.setInt(6, memberNameVisible);
            statement.setString(7, memberFirstIP);
            statement.setString(8, memberLastIP);
            statement.setInt(9, memberViewCount);
            statement.setInt(10, memberPostCount);
            statement.setTimestamp(11, memberCreationDate);
            statement.setTimestamp(12, memberModifiedDate);
            statement.setTimestamp(13, memberLastLogon);
            statement.setInt(14, memberOption);
            statement.setInt(15, memberStatus);
            statement.setString(16, memberActivateCode);
            statement.setString(17, memberTempPassword);
            statement.setInt(18, memberMessageCount);
            statement.setInt(19, memberMessageOption);
            statement.setInt(20, memberPostsPerPage);
            statement.setInt(21, memberWarnCount);
            statement.setInt(22, memberVoteCount);
            statement.setInt(23, memberVoteTotalStars);
            statement.setInt(24, memberRewardPoints);
            statement.setString(25, memberTitle);
            statement.setInt(26, memberTimeZone);
            statement.setString(27, memberSignature);
            statement.setString(28, memberAvatar);
            statement.setString(29, memberSkin);
            statement.setString(30, memberLanguage);
            statement.setString(31, memberFirstname);
            statement.setString(32, memberLastname);
            statement.setInt(33, memberGender);
            statement.setDate(34, memberBirthday);
            statement.setString(35, memberAddress);
            statement.setString(36, memberCity);
            statement.setString(37, memberState);
            statement.setString(38, memberCountry);
            statement.setString(39, memberPhone);
            statement.setString(40, memberMobile);
            statement.setString(41, memberFax);
            statement.setString(42, memberCareer);
            statement.setString(43, memberHomepage);
            statement.setString(44, memberYahoo);
            statement.setString(45, memberAol);
            statement.setString(46, memberIcq);
            statement.setString(47, memberMsn);
            statement.setString(48, memberCoolLink1);
            statement.setString(49, memberCoolLink2);

            if (statement.executeUpdate() != 1) {
                throw new CreateException("Error adding a row into table 'Member'.");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.create.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static void updateMember(int memberID, // primary key
                        int memberEmailVisible, int memberNameVisible, Timestamp memberModifiedDate,
                        int memberOption, int memberStatus, int memberMessageOption,
                        int memberPostsPerPage, int memberTimeZone, String memberSkin,
                        String memberLanguage, String memberFirstname, String memberLastname,
                        int memberGender, Date memberBirthday, String memberAddress,
                        String memberCity, String memberState, String memberCountry,
                        String memberPhone, String memberMobile, String memberFax,
                        String memberCareer, String memberHomepage, String memberYahoo,
                        String memberAol, String memberIcq, String memberMsn,
                        String memberCoolLink1, String memberCoolLink2)
                        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.update(memberID, // primary key
                        memberEmailVisible, memberNameVisible, memberModifiedDate,
                        memberOption, memberStatus, memberMessageOption,
                        memberPostsPerPage, memberTimeZone, memberSkin,
                        memberLanguage, memberFirstname, memberLastname,
                        memberGender, memberBirthday, memberAddress,
                        memberCity, memberState, memberCountry,
                        memberPhone, memberMobile, memberFax,
                        memberCareer, memberHomepage, memberYahoo,
                        memberAol, memberIcq, memberMsn,
                        memberCoolLink1, memberCoolLink2);
    }
*/
    /*
     * Included columns: MemberEmailVisible, MemberNameVisible, MemberModifiedDate, MemberOption, MemberStatus,
     *                   MemberMessageOption, MemberPostsPerPage, MemberTimeZone, MemberSkin, MemberLanguage,
     *                   MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress,
     *                   MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile,
     *                   MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol,
     *                   MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2
     * Excluded columns: MemberID, MemberName, MemberPassword, MemberFirstEmail, MemberEmail,
     *                   MemberFirstIP, MemberLastIP, MemberViewCount, MemberPostCount, MemberCreationDate,
     *                   MemberLastLogon, MemberActivateCode, MemberTempPassword, MemberMessageCount, MemberWarnCount,
     *                   MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle, MemberSignature,
     *                   MemberAvatar
     */
    public void update(int memberID, // primary key
                        int memberEmailVisible, int memberNameVisible, Timestamp memberModifiedDate,
                        int memberOption, int memberStatus, int memberMessageOption,
                        int memberPostsPerPage, int memberTimeZone, String memberSkin,
                        String memberLanguage, String memberFirstname, String memberLastname,
                        int memberGender, Date memberBirthday, String memberAddress,
                        String memberCity, String memberState, String memberCountry,
                        String memberPhone, String memberMobile, String memberFax,
                        String memberCareer, String memberHomepage, String memberYahoo,
                        String memberAol, String memberIcq, String memberMsn,
                        String memberCoolLink1, String memberCoolLink2)
                        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("UPDATE " + TABLE_NAME + " SET MemberEmailVisible = ?, MemberNameVisible = ?, MemberModifiedDate = ?, MemberOption = ?, MemberStatus = ?, MemberMessageOption = ?, MemberPostsPerPage = ?, MemberTimeZone = ?, MemberSkin = ?, MemberLanguage = ?, MemberFirstname = ?, MemberLastname = ?, MemberGender = ?, MemberBirthday = ?, MemberAddress = ?, MemberCity = ?, MemberState = ?, MemberCountry = ?, MemberPhone = ?, MemberMobile = ?, MemberFax = ?, MemberCareer = ?, MemberHomepage = ?, MemberYahoo = ?, MemberAol = ?, MemberIcq = ?, MemberMsn = ?, MemberCoolLink1 = ?, MemberCoolLink2 = ?");
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            // // column(s) to update
            statement.setInt(1, memberEmailVisible);
            statement.setInt(2, memberNameVisible);
            statement.setTimestamp(3, memberModifiedDate);
            statement.setInt(4, memberOption);
            statement.setInt(5, memberStatus);
            statement.setInt(6, memberMessageOption);
            statement.setInt(7, memberPostsPerPage);
            statement.setInt(8, memberTimeZone);
            statement.setString(9, memberSkin);
            statement.setString(10, memberLanguage);
            statement.setString(11, memberFirstname);
            statement.setString(12, memberLastname);
            statement.setInt(13, memberGender);
            statement.setDate(14, memberBirthday);
            statement.setString(15, memberAddress);
            statement.setString(16, memberCity);
            statement.setString(17, memberState);
            statement.setString(18, memberCountry);
            statement.setString(19, memberPhone);
            statement.setString(20, memberMobile);
            statement.setString(21, memberFax);
            statement.setString(22, memberCareer);
            statement.setString(23, memberHomepage);
            statement.setString(24, memberYahoo);
            statement.setString(25, memberAol);
            statement.setString(26, memberIcq);
            statement.setString(27, memberMsn);
            statement.setString(28, memberCoolLink1);
            statement.setString(29, memberCoolLink2);

            // primary key column(s)
            statement.setInt(30, memberID);

            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update table Member where primary key = (" + memberID + ").");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.update.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static void updateMemberEmail(int memberID, // primary key
                        String memberEmail)
                        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.updateEmail(memberID, // primary key
                        memberEmail);
    }
*/
    /*
     * Included columns: MemberEmail
     * Excluded columns: MemberID, MemberName, MemberPassword, MemberFirstEmail, MemberEmailVisible,
     *                   MemberNameVisible, MemberFirstIP, MemberLastIP, MemberViewCount, MemberPostCount,
     *                   MemberCreationDate, MemberModifiedDate, MemberLastLogon, MemberOption, MemberStatus,
     *                   MemberActivateCode, MemberTempPassword, MemberMessageCount, MemberMessageOption, MemberPostsPerPage,
     *                   MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle,
     *                   MemberTimeZone, MemberSignature, MemberAvatar, MemberSkin, MemberLanguage,
     *                   MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress,
     *                   MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile,
     *                   MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol,
     *                   MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2
     */
    public void updateEmail(int memberID, // primary key
                        String memberEmail)
                        throws ObjectNotFoundException, DatabaseException, DuplicateKeyException {

        //@todo: use a more efficent method
        MemberBean bean = getBean_forViewCurrentMember(memberID); // @todo: comment or delete this line if no alternate key are included

        if ( !memberEmail.equals(bean.getMemberEmail()) ) {
            // Member tries to change its alternate key <MemberEmail>, so we must check if it already exist
            try {
                findByAlternateKey_MemberEmail(memberEmail);
                throw new DuplicateKeyException("Alternate key <MemberEmail> (" + memberEmail + ")already exists. Cannot update Member.");
            } catch(ObjectNotFoundException e) {
                //Otherwise we can go ahead
            }
        }

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("UPDATE " + TABLE_NAME + " SET MemberEmail = ?");
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            // // column(s) to update
            statement.setString(1, memberEmail);

            // primary key column(s)
            statement.setInt(2, memberID);

            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update table Member where primary key = (" + memberID + ").");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.updateEmail.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static void updateMemberPassword(int memberID, // primary key
                        String memberPassword)
                        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.updatePassword(memberID, // primary key
                        memberPassword);
    }
*/
    /*
     * Included columns: MemberPassword
     * Excluded columns: MemberID, MemberName, MemberFirstEmail, MemberEmail, MemberEmailVisible,
     *                   MemberNameVisible, MemberFirstIP, MemberLastIP, MemberViewCount, MemberPostCount,
     *                   MemberCreationDate, MemberModifiedDate, MemberLastLogon, MemberOption, MemberStatus,
     *                   MemberActivateCode, MemberTempPassword, MemberMessageCount, MemberMessageOption, MemberPostsPerPage,
     *                   MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle,
     *                   MemberTimeZone, MemberSignature, MemberAvatar, MemberSkin, MemberLanguage,
     *                   MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress,
     *                   MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile,
     *                   MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol,
     *                   MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2
     */
    public void updatePassword(int memberID, // primary key
                        String memberPassword)
                        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("UPDATE " + TABLE_NAME + " SET MemberPassword = ?");
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            // // column(s) to update
            statement.setString(1, memberPassword);

            // primary key column(s)
            statement.setInt(2, memberID);

            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update table Member where primary key = (" + memberID + ").");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.updatePassword.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static void updateMemberTempPassword(int memberID, // primary key
                        String memberTempPassword)
                        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.updateTempPassword(memberID, // primary key
                        memberTempPassword);
    }
*/
    /*
     * Included columns: MemberTempPassword
     * Excluded columns: MemberID, MemberName, MemberFirstEmail, MemberEmail, MemberEmailVisible,
     *                   MemberNameVisible, MemberFirstIP, MemberLastIP, MemberViewCount, MemberPostCount,
     *                   MemberCreationDate, MemberModifiedDate, MemberLastLogon, MemberOption, MemberStatus,
     *                   MemberActivateCode, MemberPassword, MemberMessageCount, MemberMessageOption, MemberPostsPerPage,
     *                   MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle,
     *                   MemberTimeZone, MemberSignature, MemberAvatar, MemberSkin, MemberLanguage,
     *                   MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress,
     *                   MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile,
     *                   MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol,
     *                   MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2
     */
    public void updateTempPassword(int memberID, // primary key
                        String memberTempPassword)
                        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("UPDATE " + TABLE_NAME + " SET MemberTempPassword = ?");
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            // // column(s) to update
            statement.setString(1, memberTempPassword);

            // primary key column(s)
            statement.setInt(2, memberID);

            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update table Member where primary key = (" + memberID + ").");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.updateTempPassword.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static void updateMemberActivateCode(int memberID, // primary key
                            String memberActivateCode)
                            throws ObjectNotFoundException, DatabaseException {
            net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.updateActivateCode(memberID, // primary key
                            memberActivateCode);
        }
    */
    /*
     * Included columns: MemberActivateCode
     * Excluded columns: MemberID, MemberName, MemberPassword, MemberFirstEmail, MemberEmail,
     *                   MemberEmailVisible, MemberNameVisible, MemberFirstIP, MemberLastIP, MemberViewCount,
     *                   MemberPostCount, MemberCreationDate, MemberModifiedDate, MemberLastLogon, MemberOption,
     *                   MemberStatus, MemberTempPassword, MemberMessageCount, MemberMessageOption, MemberPostsPerPage,
     *                   MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle,
     *                   MemberTimeZone, MemberSignature, MemberAvatar, MemberSkin, MemberLanguage,
     *                   MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress,
     *                   MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile,
     *                   MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol,
     *                   MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2
     */
    public void updateActivateCode(int memberID, // primary key
                        String memberActivateCode)
                        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("UPDATE " + TABLE_NAME + " SET MemberActivateCode = ?");
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            // // column(s) to update
            statement.setString(1, memberActivateCode);

            // primary key column(s)
            statement.setInt(2, memberID);

            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update table Member where primary key = (" + memberID + ").");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.updateActivateCode.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static void updateMemberAvatar(int memberID, // primary key
                        String memberAvatar)
                        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.updateAvatar(memberID, // primary key
                        memberAvatar);
    }
*/
    /*
     * Included columns: MemberAvatar
     * Excluded columns: MemberID, MemberName, MemberPassword, MemberFirstEmail, MemberEmail,
     *                   MemberEmailVisible, MemberNameVisible, MemberFirstIP, MemberLastIP, MemberViewCount,
     *                   MemberPostCount, MemberCreationDate, MemberModifiedDate, MemberLastLogon, MemberOption,
     *                   MemberStatus, MemberActivateCode, MemberTempPassword, MemberMessageCount, MemberMessageOption,
     *                   MemberPostsPerPage, MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints,
     *                   MemberTitle, MemberTimeZone, MemberSignature, MemberSkin, MemberLanguage,
     *                   MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress,
     *                   MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile,
     *                   MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol,
     *                   MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2
     */
    public void updateAvatar(int memberID, // primary key
                        String memberAvatar)
                        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("UPDATE " + TABLE_NAME + " SET MemberAvatar = ?");
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            // // column(s) to update
            statement.setString(1, memberAvatar);

            // primary key column(s)
            statement.setInt(2, memberID);

            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update table Member where primary key = (" + memberID + ").");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.updateAvatar.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static void updateMemberSignature(int memberID, // primary key
                        String memberSignature)
                        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.updateSignature(memberID, // primary key
                        memberSignature);
    }
*/
    /*
     * Included columns: MemberSignature
     * Excluded columns: MemberID, MemberName, MemberPassword, MemberFirstEmail, MemberEmail,
     *                   MemberEmailVisible, MemberNameVisible, MemberFirstIP, MemberLastIP, MemberViewCount,
     *                   MemberPostCount, MemberCreationDate, MemberModifiedDate, MemberLastLogon, MemberOption,
     *                   MemberStatus, MemberActivateCode, MemberTempPassword, MemberMessageCount, MemberMessageOption,
     *                   MemberPostsPerPage, MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints,
     *                   MemberTitle, MemberTimeZone, MemberAvatar, MemberSkin, MemberLanguage,
     *                   MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress,
     *                   MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile,
     *                   MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol,
     *                   MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2
     */
    public void updateSignature(int memberID, // primary key
                        String memberSignature)
                        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("UPDATE " + TABLE_NAME + " SET MemberSignature = ?");
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            // // column(s) to update
            statement.setString(1, memberSignature);

            // primary key column(s)
            statement.setInt(2, memberID);

            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update table Member where primary key = (" + memberID + ").");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.updateSignature.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static void updateMemberTitle(int memberID, // primary key
                            String memberTitle)
                            throws ObjectNotFoundException, DatabaseException {
            net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.updateTitle(memberID, // primary key
                            memberTitle);
        }
    */
    /*
     * Included columns: MemberTitle
     * Excluded columns: MemberID, MemberName, MemberPassword, MemberFirstEmail, MemberEmail,
     *                   MemberEmailVisible, MemberNameVisible, MemberFirstIP, MemberLastIP, MemberViewCount,
     *                   MemberPostCount, MemberCreationDate, MemberModifiedDate, MemberLastLogon, MemberOption,
     *                   MemberStatus, MemberActivateCode, MemberTempPassword, MemberMessageCount, MemberMessageOption,
     *                   MemberPostsPerPage, MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints,
     *                   MemberTimeZone, MemberSignature, MemberAvatar, MemberSkin, MemberLanguage,
     *                   MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress,
     *                   MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile,
     *                   MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol,
     *                   MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2
     */
    public void updateTitle(int memberID, // primary key
                        String memberTitle)
                        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("UPDATE " + TABLE_NAME + " SET MemberTitle = ?");
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            // // column(s) to update
            statement.setString(1, memberTitle);

            // primary key column(s)
            statement.setInt(2, memberID);

            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update table Member where primary key = (" + memberID + ").");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.updateTitle.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static void updateMemberLastLogon(int memberID, // primary key
                        Timestamp memberLastLogon)
                        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.updateLastLogon(memberID, // primary key
                        memberLastLogon);
    }
*/
    /*
     * Included columns: MemberLastLogon
     * Excluded columns: MemberID, MemberName, MemberPassword, MemberFirstEmail, MemberEmail,
     *                   MemberEmailVisible, MemberNameVisible, MemberFirstIP, MemberLastIP, MemberViewCount,
     *                   MemberPostCount, MemberCreationDate, MemberModifiedDate, MemberOption, MemberStatus,
     *                   MemberActivateCode, MemberTempPassword, MemberMessageCount, MemberMessageOption, MemberPostsPerPage,
     *                   MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle,
     *                   MemberTimeZone, MemberSignature, MemberAvatar, MemberSkin, MemberLanguage,
     *                   MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress,
     *                   MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile,
     *                   MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol,
     *                   MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2
     */
    public void updateLastLogon(int memberID, // primary key
                        Timestamp memberLastLogon)
                        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("UPDATE " + TABLE_NAME + " SET MemberLastLogon = ?");
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            // // column(s) to update
            statement.setTimestamp(1, memberLastLogon);

            // primary key column(s)
            statement.setInt(2, memberID);

            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update table Member where primary key = (" + memberID + ").");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.updateLastLogon.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static String getMemberPassword(int memberID)
        throws ObjectNotFoundException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.getPassword(memberID);
    }
*/
    /*
     * Included columns: MemberPassword
     * Excluded columns: MemberID, MemberName, MemberFirstEmail, MemberEmail, MemberEmailVisible,
     *                   MemberNameVisible, MemberFirstIP, MemberLastIP, MemberViewCount, MemberPostCount,
     *                   MemberCreationDate, MemberModifiedDate, MemberLastLogon, MemberOption, MemberStatus,
     *                   MemberActivateCode, MemberTempPassword, MemberMessageCount, MemberMessageOption, MemberPostsPerPage,
     *                   MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle,
     *                   MemberTimeZone, MemberSignature, MemberAvatar, MemberSkin, MemberLanguage,
     *                   MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress,
     *                   MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile,
     *                   MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol,
     *                   MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2
     */
    public String getPassword(int memberID)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberPassword");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            resultSet = statement.executeQuery();
            if(!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the row in table Member where primary key = (" + memberID + ").");
            }

            return resultSet.getString("MemberPassword");
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.getPassword(pk).");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static String getMemberTempPassword(int memberID)
        throws ObjectNotFoundException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.getTempPassword(memberID);
    }
*/
    /*
     * Included columns: MemberTempPassword
     * Excluded columns: MemberID, MemberName, MemberFirstEmail, MemberEmail, MemberEmailVisible,
     *                   MemberNameVisible, MemberFirstIP, MemberLastIP, MemberViewCount, MemberPostCount,
     *                   MemberCreationDate, MemberModifiedDate, MemberLastLogon, MemberOption, MemberStatus,
     *                   MemberActivateCode, MemberPassword, MemberMessageCount, MemberMessageOption, MemberPostsPerPage,
     *                   MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle,
     *                   MemberTimeZone, MemberSignature, MemberAvatar, MemberSkin, MemberLanguage,
     *                   MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress,
     *                   MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile,
     *                   MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol,
     *                   MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2
     */
    public String getTempPassword(int memberID)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberTempPassword");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            resultSet = statement.executeQuery();
            if(!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the row in table Member where primary key = (" + memberID + ").");
            }

            return resultSet.getString("MemberTempPassword");
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.getTempPassword(pk).");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static String getMemberActivateCode(int memberID)
            throws ObjectNotFoundException, DatabaseException {
            return net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.getActivateCode(memberID);
        }
    */
    /*
     * Included columns: MemberActivateCode
     * Excluded columns: MemberID, MemberName, MemberPassword, MemberFirstEmail, MemberEmail,
     *                   MemberEmailVisible, MemberNameVisible, MemberFirstIP, MemberLastIP, MemberViewCount,
     *                   MemberPostCount, MemberCreationDate, MemberModifiedDate, MemberLastLogon, MemberOption,
     *                   MemberStatus, MemberTempPassword, MemberMessageCount, MemberMessageOption, MemberPostsPerPage,
     *                   MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle,
     *                   MemberTimeZone, MemberSignature, MemberAvatar, MemberSkin, MemberLanguage,
     *                   MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress,
     *                   MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile,
     *                   MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol,
     *                   MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2
     */
    public String getActivateCode(int memberID)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberActivateCode");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            resultSet = statement.executeQuery();
            if(!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the row in table Member where primary key = (" + memberID + ").");
            }

            String retValue = resultSet.getString("MemberActivateCode");
            if (retValue == null) retValue = ""; // hack for Oracle database
            return retValue;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.getActivateCode(pk).");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static MemberBean getMember_forViewCurrentMember(int memberID)
        throws ObjectNotFoundException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.getBean_forViewCurrentMember(memberID);
    }
*/
    /*
     * Included columns: MemberName, MemberEmail, MemberEmailVisible, MemberNameVisible, MemberViewCount,
     *                   MemberPostCount, MemberCreationDate, MemberModifiedDate, MemberLastLogon, MemberOption,
     *                   MemberStatus, MemberMessageCount, MemberMessageOption, MemberPostsPerPage, MemberWarnCount,
     *                   MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle, MemberTimeZone,
     *                   MemberSignature, MemberAvatar, MemberSkin, MemberLanguage, MemberFirstname,
     *                   MemberLastname, MemberGender, MemberBirthday, MemberAddress, MemberCity,
     *                   MemberState, MemberCountry, MemberPhone, MemberMobile, MemberFax,
     *                   MemberCareer, MemberHomepage, MemberYahoo, MemberAol, MemberIcq,
     *                   MemberMsn, MemberCoolLink1, MemberCoolLink2
     * Excluded columns: MemberID, MemberPassword, MemberFirstEmail, MemberFirstIP, MemberLastIP,
     *                   MemberActivateCode, MemberTempPassword
     */
    public MemberBean getBean_forViewCurrentMember(int memberID)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberName, MemberEmail, MemberEmailVisible, MemberNameVisible, MemberViewCount, MemberPostCount, MemberCreationDate, MemberModifiedDate, MemberLastLogon, MemberOption, MemberStatus, MemberMessageCount, MemberMessageOption, MemberPostsPerPage, MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle, MemberTimeZone, MemberSignature, MemberAvatar, MemberSkin, MemberLanguage, MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress, MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile, MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol, MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            resultSet = statement.executeQuery();
            if(!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the row in table Member where primary key = (" + memberID + ").");
            }

            MemberBean bean = new MemberBean();
            // @todo: uncomment the following line(s) as needed
            bean.setMemberID(memberID);
            bean.setMemberName(resultSet.getString("MemberName"));
            bean.setMemberEmail(resultSet.getString("MemberEmail"));
            bean.setMemberEmailVisible(resultSet.getInt("MemberEmailVisible"));
            bean.setMemberNameVisible(resultSet.getInt("MemberNameVisible"));
            bean.setMemberViewCount(resultSet.getInt("MemberViewCount"));
            bean.setMemberPostCount(resultSet.getInt("MemberPostCount"));
            bean.setMemberCreationDate(resultSet.getTimestamp("MemberCreationDate"));
            bean.setMemberModifiedDate(resultSet.getTimestamp("MemberModifiedDate"));
            bean.setMemberLastLogon(resultSet.getTimestamp("MemberLastLogon"));
            bean.setMemberOption(resultSet.getInt("MemberOption"));
            bean.setMemberStatus(resultSet.getInt("MemberStatus"));
            bean.setMemberMessageCount(resultSet.getInt("MemberMessageCount"));
            bean.setMemberMessageOption(resultSet.getInt("MemberMessageOption"));
            bean.setMemberPostsPerPage(resultSet.getInt("MemberPostsPerPage"));
            bean.setMemberWarnCount(resultSet.getInt("MemberWarnCount"));
            bean.setMemberVoteCount(resultSet.getInt("MemberVoteCount"));
            bean.setMemberVoteTotalStars(resultSet.getInt("MemberVoteTotalStars"));
            bean.setMemberRewardPoints(resultSet.getInt("MemberRewardPoints"));
            bean.setMemberTitle(resultSet.getString("MemberTitle"));
            bean.setMemberTimeZone(resultSet.getInt("MemberTimeZone"));
            bean.setMemberSignature(resultSet.getString("MemberSignature"));
            bean.setMemberAvatar(resultSet.getString("MemberAvatar"));
            bean.setMemberSkin(resultSet.getString("MemberSkin"));
            bean.setMemberLanguage(resultSet.getString("MemberLanguage"));
            bean.setMemberFirstname(resultSet.getString("MemberFirstname"));
            bean.setMemberLastname(resultSet.getString("MemberLastname"));
            bean.setMemberGender(resultSet.getInt("MemberGender"));
            bean.setMemberBirthday(resultSet.getDate("MemberBirthday"));
            bean.setMemberAddress(resultSet.getString("MemberAddress"));
            bean.setMemberCity(resultSet.getString("MemberCity"));
            bean.setMemberState(resultSet.getString("MemberState"));
            bean.setMemberCountry(resultSet.getString("MemberCountry"));
            bean.setMemberPhone(resultSet.getString("MemberPhone"));
            bean.setMemberMobile(resultSet.getString("MemberMobile"));
            bean.setMemberFax(resultSet.getString("MemberFax"));
            bean.setMemberCareer(resultSet.getString("MemberCareer"));
            bean.setMemberHomepage(resultSet.getString("MemberHomepage"));
            bean.setMemberYahoo(resultSet.getString("MemberYahoo"));
            bean.setMemberAol(resultSet.getString("MemberAol"));
            bean.setMemberIcq(resultSet.getString("MemberIcq"));
            bean.setMemberMsn(resultSet.getString("MemberMsn"));
            bean.setMemberCoolLink1(resultSet.getString("MemberCoolLink1"));
            bean.setMemberCoolLink2(resultSet.getString("MemberCoolLink2"));
            return bean;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.getBean(pk).");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static MemberBean getMember_forEditCurrentMember(int memberID)
        throws ObjectNotFoundException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.getBean_forEditCurrentMember(memberID);
    }
*/
    /*
     * Included columns: MemberEmailVisible, MemberNameVisible, MemberOption, MemberStatus, MemberMessageOption,
     *                   MemberPostsPerPage, MemberTimeZone, MemberSkin, MemberLanguage, MemberFirstname,
     *                   MemberLastname, MemberGender, MemberBirthday, MemberAddress, MemberCity,
     *                   MemberState, MemberCountry, MemberPhone, MemberMobile, MemberFax,
     *                   MemberCareer, MemberHomepage, MemberYahoo, MemberAol, MemberIcq,
     *                   MemberMsn, MemberCoolLink1, MemberCoolLink2
     * Excluded columns: MemberID, MemberName, MemberPassword, MemberFirstEmail, MemberEmail,
     *                   MemberFirstIP, MemberLastIP, MemberViewCount, MemberPostCount, MemberCreationDate,
     *                   MemberModifiedDate, MemberLastLogon, MemberActivateCode, MemberTempPassword, MemberMessageCount,
     *                   MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle,
     *                   MemberSignature, MemberAvatar
     */
    public MemberBean getBean_forEditCurrentMember(int memberID)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberEmailVisible, MemberNameVisible, MemberOption, MemberStatus, MemberMessageOption, MemberPostsPerPage, MemberTimeZone, MemberSkin, MemberLanguage, MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress, MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile, MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol, MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            resultSet = statement.executeQuery();
            if(!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the row in table Member where primary key = (" + memberID + ").");
            }

            MemberBean bean = new MemberBean();
            // @todo: uncomment the following line(s) as needed
            bean.setMemberID(memberID);
            bean.setMemberEmailVisible(resultSet.getInt("MemberEmailVisible"));
            bean.setMemberNameVisible(resultSet.getInt("MemberNameVisible"));
            bean.setMemberOption(resultSet.getInt("MemberOption"));
            bean.setMemberStatus(resultSet.getInt("MemberStatus"));
            bean.setMemberMessageOption(resultSet.getInt("MemberMessageOption"));
            bean.setMemberPostsPerPage(resultSet.getInt("MemberPostsPerPage"));
            bean.setMemberTimeZone(resultSet.getInt("MemberTimeZone"));
            bean.setMemberSkin(resultSet.getString("MemberSkin"));
            bean.setMemberLanguage(resultSet.getString("MemberLanguage"));
            bean.setMemberFirstname(resultSet.getString("MemberFirstname"));
            bean.setMemberLastname(resultSet.getString("MemberLastname"));
            bean.setMemberGender(resultSet.getInt("MemberGender"));
            bean.setMemberBirthday(resultSet.getDate("MemberBirthday"));
            bean.setMemberAddress(resultSet.getString("MemberAddress"));
            bean.setMemberCity(resultSet.getString("MemberCity"));
            bean.setMemberState(resultSet.getString("MemberState"));
            bean.setMemberCountry(resultSet.getString("MemberCountry"));
            bean.setMemberPhone(resultSet.getString("MemberPhone"));
            bean.setMemberMobile(resultSet.getString("MemberMobile"));
            bean.setMemberFax(resultSet.getString("MemberFax"));
            bean.setMemberCareer(resultSet.getString("MemberCareer"));
            bean.setMemberHomepage(resultSet.getString("MemberHomepage"));
            bean.setMemberYahoo(resultSet.getString("MemberYahoo"));
            bean.setMemberAol(resultSet.getString("MemberAol"));
            bean.setMemberIcq(resultSet.getString("MemberIcq"));
            bean.setMemberMsn(resultSet.getString("MemberMsn"));
            bean.setMemberCoolLink1(resultSet.getString("MemberCoolLink1"));
            bean.setMemberCoolLink2(resultSet.getString("MemberCoolLink2"));
            return bean;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.getBean_forEditCurrentMember(pk).");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static MemberBean getMember_forPublic(int memberID)
        throws ObjectNotFoundException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.getBean_forPublic(memberID);
    }
*/
    /*
     * Included columns: MemberID, MemberName, MemberEmail, MemberEmailVisible, MemberNameVisible,
     *                   MemberViewCount, MemberPostCount, MemberCreationDate, MemberLastLogon, MemberOption,
     *                   MemberStatus, MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints,
     *                   MemberTitle, MemberSignature, MemberAvatar, MemberFirstname, MemberLastname,
     *                   MemberGender, MemberBirthday, MemberAddress, MemberCity, MemberState,
     *                   MemberCountry, MemberPhone, MemberMobile, MemberFax, MemberCareer,
     *                   MemberHomepage, MemberYahoo, MemberAol, MemberIcq, MemberMsn,
     *                   MemberCoolLink1, MemberCoolLink2
     * Excluded columns: MemberPassword, MemberFirstEmail, MemberFirstIP, MemberLastIP, MemberModifiedDate,
     *                   MemberActivateCode, MemberTempPassword, MemberMessageCount, MemberMessageOption, MemberPostsPerPage,
     *                   MemberTimeZone, MemberSkin, MemberLanguage
     */
    public MemberBean getBean_forPublic(int memberID)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberID, MemberName, MemberEmail, MemberEmailVisible, MemberNameVisible, MemberViewCount, MemberPostCount, MemberCreationDate, MemberLastLogon, MemberOption, MemberStatus, MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle, MemberSignature, MemberAvatar, MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress, MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile, MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol, MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            resultSet = statement.executeQuery();
            if(!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the row in table Member where primary key = (" + memberID + ").");
            }

            MemberBean bean = new MemberBean();
            // @todo: uncomment the following line(s) as needed
            //bean.setMemberID(memberID);
            bean.setMemberID(resultSet.getInt("MemberID"));
            bean.setMemberName(resultSet.getString("MemberName"));
            bean.setMemberEmail(resultSet.getString("MemberEmail"));
            bean.setMemberEmailVisible(resultSet.getInt("MemberEmailVisible"));
            bean.setMemberNameVisible(resultSet.getInt("MemberNameVisible"));
            bean.setMemberViewCount(resultSet.getInt("MemberViewCount"));
            bean.setMemberPostCount(resultSet.getInt("MemberPostCount"));
            bean.setMemberCreationDate(resultSet.getTimestamp("MemberCreationDate"));
            bean.setMemberLastLogon(resultSet.getTimestamp("MemberLastLogon"));
            bean.setMemberOption(resultSet.getInt("MemberOption"));
            bean.setMemberStatus(resultSet.getInt("MemberStatus"));
            bean.setMemberWarnCount(resultSet.getInt("MemberWarnCount"));
            bean.setMemberVoteCount(resultSet.getInt("MemberVoteCount"));
            bean.setMemberVoteTotalStars(resultSet.getInt("MemberVoteTotalStars"));
            bean.setMemberRewardPoints(resultSet.getInt("MemberRewardPoints"));
            bean.setMemberTitle(resultSet.getString("MemberTitle"));
            bean.setMemberSignature(resultSet.getString("MemberSignature"));
            bean.setMemberAvatar(resultSet.getString("MemberAvatar"));
            bean.setMemberFirstname(resultSet.getString("MemberFirstname"));
            bean.setMemberLastname(resultSet.getString("MemberLastname"));
            bean.setMemberGender(resultSet.getInt("MemberGender"));
            bean.setMemberBirthday(resultSet.getDate("MemberBirthday"));
            bean.setMemberAddress(resultSet.getString("MemberAddress"));
            bean.setMemberCity(resultSet.getString("MemberCity"));
            bean.setMemberState(resultSet.getString("MemberState"));
            bean.setMemberCountry(resultSet.getString("MemberCountry"));
            bean.setMemberPhone(resultSet.getString("MemberPhone"));
            bean.setMemberMobile(resultSet.getString("MemberMobile"));
            bean.setMemberFax(resultSet.getString("MemberFax"));
            bean.setMemberCareer(resultSet.getString("MemberCareer"));
            bean.setMemberHomepage(resultSet.getString("MemberHomepage"));
            bean.setMemberYahoo(resultSet.getString("MemberYahoo"));
            bean.setMemberAol(resultSet.getString("MemberAol"));
            bean.setMemberIcq(resultSet.getString("MemberIcq"));
            bean.setMemberMsn(resultSet.getString("MemberMsn"));
            bean.setMemberCoolLink1(resultSet.getString("MemberCoolLink1"));
            bean.setMemberCoolLink2(resultSet.getString("MemberCoolLink2"));
            return bean;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.getBean(pk).");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static Collection getMembers_forPublic()
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.getBeans_forPublic();
    }
*/
    /*
     * Included columns: MemberID, MemberName, MemberEmail, MemberEmailVisible, MemberNameVisible,
     *                   MemberViewCount, MemberPostCount, MemberCreationDate, MemberLastLogon, MemberOption,
     *                   MemberStatus, MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints,
     *                   MemberTitle, MemberSignature, MemberAvatar, MemberFirstname, MemberLastname,
     *                   MemberGender, MemberBirthday, MemberAddress, MemberCity, MemberState,
     *                   MemberCountry, MemberPhone, MemberMobile, MemberFax, MemberCareer,
     *                   MemberHomepage, MemberYahoo, MemberAol, MemberIcq, MemberMsn,
     *                   MemberCoolLink1, MemberCoolLink2
     * Excluded columns: MemberPassword, MemberFirstEmail, MemberFirstIP, MemberLastIP, MemberModifiedDate,
     *                   MemberActivateCode, MemberTempPassword, MemberMessageCount, MemberMessageOption, MemberPostsPerPage,
     *                   MemberTimeZone, MemberSkin, MemberLanguage
     */
    public Collection getBeans_forPublic()
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Collection retValue = new ArrayList();
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberID, MemberName, MemberEmail, MemberEmailVisible, MemberNameVisible, MemberViewCount, MemberPostCount, MemberCreationDate, MemberLastLogon, MemberOption, MemberStatus, MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle, MemberSignature, MemberAvatar, MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress, MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile, MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol, MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2");
        sql.append(" FROM " + TABLE_NAME);
        //sql.append(" WHERE "); // @todo: uncomment as needed
        //sql.append(" ORDER BY ColumnName ASC|DESC "); // @todo: uncomment as needed
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                MemberBean bean = new MemberBean();
                bean.setMemberID(resultSet.getInt("MemberID"));
                bean.setMemberName(resultSet.getString("MemberName"));
                bean.setMemberEmail(resultSet.getString("MemberEmail"));
                bean.setMemberEmailVisible(resultSet.getInt("MemberEmailVisible"));
                bean.setMemberNameVisible(resultSet.getInt("MemberNameVisible"));
                bean.setMemberViewCount(resultSet.getInt("MemberViewCount"));
                bean.setMemberPostCount(resultSet.getInt("MemberPostCount"));
                bean.setMemberCreationDate(resultSet.getTimestamp("MemberCreationDate"));
                bean.setMemberLastLogon(resultSet.getTimestamp("MemberLastLogon"));
                bean.setMemberOption(resultSet.getInt("MemberOption"));
                bean.setMemberStatus(resultSet.getInt("MemberStatus"));
                bean.setMemberWarnCount(resultSet.getInt("MemberWarnCount"));
                bean.setMemberVoteCount(resultSet.getInt("MemberVoteCount"));
                bean.setMemberVoteTotalStars(resultSet.getInt("MemberVoteTotalStars"));
                bean.setMemberRewardPoints(resultSet.getInt("MemberRewardPoints"));
                bean.setMemberTitle(resultSet.getString("MemberTitle"));
                bean.setMemberSignature(resultSet.getString("MemberSignature"));
                bean.setMemberAvatar(resultSet.getString("MemberAvatar"));
                bean.setMemberFirstname(resultSet.getString("MemberFirstname"));
                bean.setMemberLastname(resultSet.getString("MemberLastname"));
                bean.setMemberGender(resultSet.getInt("MemberGender"));
                bean.setMemberBirthday(resultSet.getDate("MemberBirthday"));
                bean.setMemberAddress(resultSet.getString("MemberAddress"));
                bean.setMemberCity(resultSet.getString("MemberCity"));
                bean.setMemberState(resultSet.getString("MemberState"));
                bean.setMemberCountry(resultSet.getString("MemberCountry"));
                bean.setMemberPhone(resultSet.getString("MemberPhone"));
                bean.setMemberMobile(resultSet.getString("MemberMobile"));
                bean.setMemberFax(resultSet.getString("MemberFax"));
                bean.setMemberCareer(resultSet.getString("MemberCareer"));
                bean.setMemberHomepage(resultSet.getString("MemberHomepage"));
                bean.setMemberYahoo(resultSet.getString("MemberYahoo"));
                bean.setMemberAol(resultSet.getString("MemberAol"));
                bean.setMemberIcq(resultSet.getString("MemberIcq"));
                bean.setMemberMsn(resultSet.getString("MemberMsn"));
                bean.setMemberCoolLink1(resultSet.getString("MemberCoolLink1"));
                bean.setMemberCoolLink2(resultSet.getString("MemberCoolLink2"));
                retValue.add(bean);
            }
            return retValue;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.getBeans_forPublic.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static int getNumberOfMembers()
        throws AssertionException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.getNumberOfBeans();
    }
*/
    /** Returns number of members in the database. Virtual guest is included. */
    public int getNumberOfBeans()
        throws AssertionException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT Count(*)");
        sql.append(" FROM " + TABLE_NAME);
        //sql.append(" WHERE "); // @todo: uncomment as needed
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            resultSet = statement.executeQuery();
            if (!resultSet.next()) {
                throw new AssertionException("Assertion in MemberWebHelper.getNumberOfMembers.");
            }
            return resultSet.getInt(1);
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.getNumberOfBeans.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }



/************************************************
 * Customized methods come below
 ************************************************/

    /* @todo check if this method work with other DBMS other than MySql (check case-sensitive) */
    public final int getMemberIDFromMemberName(String memberName)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        String sql = "SELECT MemberID FROM " + TABLE_NAME + " WHERE MemberName = ?";
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql);
            statement.setString(1, memberName);
            resultSet = statement.executeQuery();
            if(!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the row in table Member where MemberName = " + memberName);
            }
            return resultSet.getInt(1);
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("There is an error when trying to get a row in 'Member' table.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /* @todo check if this method work with other DBMS other than MySql (check case-sensitive) */
    public final int getMemberIDFromMemberEmail(String memberEmail)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        String sql = "SELECT MemberID FROM " + TABLE_NAME + " WHERE MemberEmail = ?";
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql);
            statement.setString(1, memberEmail);
            resultSet = statement.executeQuery();
            if(!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the row in table Member where MemberEmail = " + memberEmail);
            }
            return resultSet.getInt(1);
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("There is an error when trying to get a row in 'Member' table.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static Collection getMembers_withSortSupport_limit_mysql(int offset, int rowsToReturn, String sort, String order)
        throws IllegalArgumentException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.getBeans_withSortSupport_limit_mysql(offset, rowsToReturn, sort, order);
    }
*/
    /*
     * Included columns: MemberID, MemberName, MemberEmail, MemberEmailVisible, MemberNameVisible,
     *                   MemberViewCount, MemberPostCount, MemberCreationDate, MemberLastLogon, MemberOption,
     *                   MemberStatus, MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints,
     *                   MemberTitle, MemberSignature, MemberAvatar, MemberFirstname, MemberLastname,
     *                   MemberGender, MemberBirthday, MemberAddress, MemberCity, MemberState,
     *                   MemberCountry, MemberPhone, MemberMobile, MemberFax, MemberCareer,
     *                   MemberHomepage, MemberYahoo, MemberAol, MemberIcq, MemberMsn,
     *                   MemberCoolLink1, MemberCoolLink2
     * Excluded columns: MemberPassword, MemberFirstEmail, MemberFirstIP, MemberLastIP, MemberModifiedDate,
     *                   MemberActivateCode, MemberTempPassword, MemberMessageCount, MemberMessageOption, MemberPostsPerPage,
     *                   MemberTimeZone, MemberSkin, MemberLanguage
     */
    /**
     * This method support sorting and for PUBLIC view
     */
    /* @todo fix bug that cannot prepare sort and order */
    public Collection getBeans_withSortSupport_limit_mysql(int offset, int rowsToReturn, String sort, String order)
        throws IllegalArgumentException, DatabaseException {

        if (offset < 0) throw new IllegalArgumentException("The offset < 0 is not allowed.");
        if (rowsToReturn <= 0) throw new IllegalArgumentException("The rowsToReturn <= 0 is not allowed.");
    /*
     * MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints,
     * MemberTitle,
     * MemberCity, MemberState,
     * MemberCountry, MemberCareer,
     */
        if ((!sort.equals("MemberID")) &&
            (!sort.equals("MemberName")) &&
            (!sort.equals("MemberFirstname")) &&
            (!sort.equals("MemberLastname")) &&
            (!sort.equals("MemberGender")) &&
            (!sort.equals("MemberBirthday")) &&
            (!sort.equals("MemberCreationDate")) &&
            (!sort.equals("MemberLastLogon")) &&
            (!sort.equals("MemberViewCount")) &&
            (!sort.equals("MemberPostCount")) ) {
            throw new IllegalArgumentException("Cannot sort, reason: dont understand the criteria '" + sort + "'.");
        }

        if ((!order.equals("ASC")) &&
            (!order.equals("DESC")) ) {
            throw new IllegalArgumentException("Cannot sort, reason: dont understand the order '" + order + "'.");
        }

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Collection retValue = new ArrayList();
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberID, MemberName, MemberEmail, MemberEmailVisible, MemberNameVisible, MemberViewCount, MemberPostCount, MemberCreationDate, MemberLastLogon, MemberOption, MemberStatus, MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle, MemberSignature, MemberAvatar, MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress, MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile, MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol, MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" ORDER BY " + sort + " " + order);// ColumnName, ASC|DESC
        sql.append(" LIMIT ?, ?");

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, offset);
            statement.setInt(2, rowsToReturn);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                MemberBean bean = new MemberBean();
                bean.setMemberID(resultSet.getInt("MemberID"));
                bean.setMemberName(resultSet.getString("MemberName"));
                bean.setMemberEmail(resultSet.getString("MemberEmail"));
                bean.setMemberEmailVisible(resultSet.getInt("MemberEmailVisible"));
                bean.setMemberNameVisible(resultSet.getInt("MemberNameVisible"));
                bean.setMemberViewCount(resultSet.getInt("MemberViewCount"));
                bean.setMemberPostCount(resultSet.getInt("MemberPostCount"));
                bean.setMemberCreationDate(resultSet.getTimestamp("MemberCreationDate"));
                bean.setMemberLastLogon(resultSet.getTimestamp("MemberLastLogon"));
                bean.setMemberOption(resultSet.getInt("MemberOption"));
                bean.setMemberStatus(resultSet.getInt("MemberStatus"));
                bean.setMemberWarnCount(resultSet.getInt("MemberWarnCount"));
                bean.setMemberVoteCount(resultSet.getInt("MemberVoteCount"));
                bean.setMemberVoteTotalStars(resultSet.getInt("MemberVoteTotalStars"));
                bean.setMemberRewardPoints(resultSet.getInt("MemberRewardPoints"));
                bean.setMemberTitle(resultSet.getString("MemberTitle"));
                bean.setMemberSignature(resultSet.getString("MemberSignature"));
                bean.setMemberAvatar(resultSet.getString("MemberAvatar"));
                bean.setMemberFirstname(resultSet.getString("MemberFirstname"));
                bean.setMemberLastname(resultSet.getString("MemberLastname"));
                bean.setMemberGender(resultSet.getInt("MemberGender"));
                bean.setMemberBirthday(resultSet.getDate("MemberBirthday"));
                bean.setMemberAddress(resultSet.getString("MemberAddress"));
                bean.setMemberCity(resultSet.getString("MemberCity"));
                bean.setMemberState(resultSet.getString("MemberState"));
                bean.setMemberCountry(resultSet.getString("MemberCountry"));
                bean.setMemberPhone(resultSet.getString("MemberPhone"));
                bean.setMemberMobile(resultSet.getString("MemberMobile"));
                bean.setMemberFax(resultSet.getString("MemberFax"));
                bean.setMemberCareer(resultSet.getString("MemberCareer"));
                bean.setMemberHomepage(resultSet.getString("MemberHomepage"));
                bean.setMemberYahoo(resultSet.getString("MemberYahoo"));
                bean.setMemberAol(resultSet.getString("MemberAol"));
                bean.setMemberIcq(resultSet.getString("MemberIcq"));
                bean.setMemberMsn(resultSet.getString("MemberMsn"));
                bean.setMemberCoolLink1(resultSet.getString("MemberCoolLink1"));
                bean.setMemberCoolLink2(resultSet.getString("MemberCoolLink2"));
                retValue.add(bean);
            }
            return retValue;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.getBeans_withSortSupport_limit_mysql.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static Collection getMembers_withSortSupport_limit_noscroll(int offset, int rowsToReturn, String sort, String order)
            throws IllegalArgumentException, DatabaseException {
            return net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.getBeans_withSortSupport_limit_noscroll(offset, rowsToReturn, sort, order);
        }
    */
    /*
     * Included columns: MemberID, MemberName, MemberEmail, MemberEmailVisible, MemberNameVisible,
     *                   MemberViewCount, MemberPostCount, MemberCreationDate, MemberLastLogon, MemberOption,
     *                   MemberStatus, MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints,
     *                   MemberTitle, MemberSignature, MemberAvatar, MemberFirstname, MemberLastname,
     *                   MemberGender, MemberBirthday, MemberAddress, MemberCity, MemberState,
     *                   MemberCountry, MemberPhone, MemberMobile, MemberFax, MemberCareer,
     *                   MemberHomepage, MemberYahoo, MemberAol, MemberIcq, MemberMsn,
     *                   MemberCoolLink1, MemberCoolLink2
     * Excluded columns: MemberPassword, MemberFirstEmail, MemberFirstIP, MemberLastIP, MemberModifiedDate,
     *                   MemberActivateCode, MemberTempPassword, MemberMessageCount, MemberMessageOption, MemberPostsPerPage,
     *                   MemberTimeZone, MemberSkin, MemberLanguage
     */
    /**
     * This method support sorting and for PUBLIC view
     */
    /* @todo fix bug that cannot prepare sort and order */
    public Collection getBeans_withSortSupport_limit_noscroll(int offset, int rowsToReturn, String sort, String order)
        throws IllegalArgumentException, DatabaseException {
        if (offset < 0) throw new IllegalArgumentException("The offset < 0 is not allowed.");
        if (rowsToReturn <= 0) throw new IllegalArgumentException("The rowsToReturn <= 0 is not allowed.");
    /*
     * MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints,
     * MemberTitle,
     * MemberCity, MemberState,
     * MemberCountry, MemberCareer,
     */
        if ((!sort.equals("MemberID")) &&
            (!sort.equals("MemberName")) &&
            (!sort.equals("MemberFirstname")) &&
            (!sort.equals("MemberLastname")) &&
            (!sort.equals("MemberGender")) &&
            (!sort.equals("MemberBirthday")) &&
            (!sort.equals("MemberCreationDate")) &&
            (!sort.equals("MemberLastLogon")) &&
            (!sort.equals("MemberViewCount")) &&
            (!sort.equals("MemberPostCount")) ) {
            throw new IllegalArgumentException("Cannot sort, reason: dont understand the criteria '" + sort + "'.");
        }

        if ((!order.equals("ASC")) &&
            (!order.equals("DESC")) ) {
            throw new IllegalArgumentException("Cannot sort, reason: dont understand the order '" + order + "'.");
        }

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Collection retValue = new ArrayList();
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberID, MemberName, MemberEmail, MemberEmailVisible, MemberNameVisible, MemberViewCount, MemberPostCount, MemberCreationDate, MemberLastLogon, MemberOption, MemberStatus, MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle, MemberSignature, MemberAvatar, MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress, MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile, MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol, MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" ORDER BY " + sort + " " + order);// ColumnName, ASC|DESC

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setMaxRows(offset + rowsToReturn);
            resultSet = statement.executeQuery();
            int rowIndex = -1;
            while (resultSet.next()) {
                rowIndex++;
                if (rowIndex < offset) continue;
                MemberBean bean = new MemberBean();
                bean.setMemberID(resultSet.getInt("MemberID"));
                bean.setMemberName(resultSet.getString("MemberName"));
                bean.setMemberEmail(resultSet.getString("MemberEmail"));
                bean.setMemberEmailVisible(resultSet.getInt("MemberEmailVisible"));
                bean.setMemberNameVisible(resultSet.getInt("MemberNameVisible"));
                bean.setMemberViewCount(resultSet.getInt("MemberViewCount"));
                bean.setMemberPostCount(resultSet.getInt("MemberPostCount"));
                bean.setMemberCreationDate(resultSet.getTimestamp("MemberCreationDate"));
                bean.setMemberLastLogon(resultSet.getTimestamp("MemberLastLogon"));
                bean.setMemberOption(resultSet.getInt("MemberOption"));
                bean.setMemberStatus(resultSet.getInt("MemberStatus"));
                bean.setMemberWarnCount(resultSet.getInt("MemberWarnCount"));
                bean.setMemberVoteCount(resultSet.getInt("MemberVoteCount"));
                bean.setMemberVoteTotalStars(resultSet.getInt("MemberVoteTotalStars"));
                bean.setMemberRewardPoints(resultSet.getInt("MemberRewardPoints"));
                bean.setMemberTitle(resultSet.getString("MemberTitle"));
                bean.setMemberSignature(resultSet.getString("MemberSignature"));
                bean.setMemberAvatar(resultSet.getString("MemberAvatar"));
                bean.setMemberFirstname(resultSet.getString("MemberFirstname"));
                bean.setMemberLastname(resultSet.getString("MemberLastname"));
                bean.setMemberGender(resultSet.getInt("MemberGender"));
                bean.setMemberBirthday(resultSet.getDate("MemberBirthday"));
                bean.setMemberAddress(resultSet.getString("MemberAddress"));
                bean.setMemberCity(resultSet.getString("MemberCity"));
                bean.setMemberState(resultSet.getString("MemberState"));
                bean.setMemberCountry(resultSet.getString("MemberCountry"));
                bean.setMemberPhone(resultSet.getString("MemberPhone"));
                bean.setMemberMobile(resultSet.getString("MemberMobile"));
                bean.setMemberFax(resultSet.getString("MemberFax"));
                bean.setMemberCareer(resultSet.getString("MemberCareer"));
                bean.setMemberHomepage(resultSet.getString("MemberHomepage"));
                bean.setMemberYahoo(resultSet.getString("MemberYahoo"));
                bean.setMemberAol(resultSet.getString("MemberAol"));
                bean.setMemberIcq(resultSet.getString("MemberIcq"));
                bean.setMemberMsn(resultSet.getString("MemberMsn"));
                bean.setMemberCoolLink1(resultSet.getString("MemberCoolLink1"));
                bean.setMemberCoolLink2(resultSet.getString("MemberCoolLink2"));
                retValue.add(bean);
            }
            return retValue;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.getBeans_withSortSupport_limit_noscroll.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.resetStatement(statement);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static Collection getMembers_withSortSupport_limit_general(int offset, int rowsToReturn, String sort, String order)
            throws IllegalArgumentException, DatabaseException {
            return net.myvietnam.mvnplugin.mvnforum.db.MemberWebHelper.getBeans_withSortSupport_limit_general(offset, rowsToReturn, sort, order);
        }
    */
    /*
     * Included columns: MemberID, MemberName, MemberEmail, MemberEmailVisible, MemberNameVisible,
     *                   MemberViewCount, MemberPostCount, MemberCreationDate, MemberLastLogon, MemberOption,
     *                   MemberStatus, MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints,
     *                   MemberTitle, MemberSignature, MemberAvatar, MemberFirstname, MemberLastname,
     *                   MemberGender, MemberBirthday, MemberAddress, MemberCity, MemberState,
     *                   MemberCountry, MemberPhone, MemberMobile, MemberFax, MemberCareer,
     *                   MemberHomepage, MemberYahoo, MemberAol, MemberIcq, MemberMsn,
     *                   MemberCoolLink1, MemberCoolLink2
     * Excluded columns: MemberPassword, MemberFirstEmail, MemberFirstIP, MemberLastIP, MemberModifiedDate,
     *                   MemberActivateCode, MemberTempPassword, MemberMessageCount, MemberMessageOption, MemberPostsPerPage,
     *                   MemberTimeZone, MemberSkin, MemberLanguage
     */
    /**
     * This method support sorting and for PUBLIC view
     */
    /* @todo fix bug that cannot prepare sort and order */
    public Collection getBeans_withSortSupport_limit_general(int offset, int rowsToReturn, String sort, String order)
        throws IllegalArgumentException, DatabaseException {

        if (offset < 0) throw new IllegalArgumentException("The offset < 0 is not allowed.");
        if (rowsToReturn <= 0) throw new IllegalArgumentException("The rowsToReturn <= 0 is not allowed.");
    /*
     * MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints,
     * MemberTitle,
     * MemberCity, MemberState,
     * MemberCountry, MemberCareer,
     */
        if ((!sort.equals("MemberID")) &&
            (!sort.equals("MemberName")) &&
            (!sort.equals("MemberFirstname")) &&
            (!sort.equals("MemberLastname")) &&
            (!sort.equals("MemberGender")) &&
            (!sort.equals("MemberBirthday")) &&
            (!sort.equals("MemberCreationDate")) &&
            (!sort.equals("MemberLastLogon")) &&
            (!sort.equals("MemberViewCount")) &&
            (!sort.equals("MemberPostCount")) ) {
            throw new IllegalArgumentException("Cannot sort, reason: dont understand the criteria '" + sort + "'.");
        }

        if ((!order.equals("ASC")) &&
            (!order.equals("DESC")) ) {
            throw new IllegalArgumentException("Cannot sort, reason: dont understand the order '" + order + "'.");
        }

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Collection retValue = new ArrayList();
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberID, MemberName, MemberEmail, MemberEmailVisible, MemberNameVisible, MemberViewCount, MemberPostCount, MemberCreationDate, MemberLastLogon, MemberOption, MemberStatus, MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle, MemberSignature, MemberAvatar, MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress, MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile, MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol, MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" ORDER BY " + sort + " " + order);// ColumnName, ASC|DESC

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString(), ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            statement.setMaxRows(offset + rowsToReturn);
            try {
                statement.setFetchSize(rowsToReturn);
            } catch (SQLException sqle) {
                //do nothing, postgreSQL doesnt support this method
            }
            resultSet = statement.executeQuery();
            boolean loop = resultSet.absolute(offset + 1);// the absolute method begin with 1 instead of 0 as in the LIMIT clause
            while (loop) {
                MemberBean bean = new MemberBean();
                bean.setMemberID(resultSet.getInt("MemberID"));
                bean.setMemberName(resultSet.getString("MemberName"));
                bean.setMemberEmail(resultSet.getString("MemberEmail"));
                bean.setMemberEmailVisible(resultSet.getInt("MemberEmailVisible"));
                bean.setMemberNameVisible(resultSet.getInt("MemberNameVisible"));
                bean.setMemberViewCount(resultSet.getInt("MemberViewCount"));
                bean.setMemberPostCount(resultSet.getInt("MemberPostCount"));
                bean.setMemberCreationDate(resultSet.getTimestamp("MemberCreationDate"));
                bean.setMemberLastLogon(resultSet.getTimestamp("MemberLastLogon"));
                bean.setMemberOption(resultSet.getInt("MemberOption"));
                bean.setMemberStatus(resultSet.getInt("MemberStatus"));
                bean.setMemberWarnCount(resultSet.getInt("MemberWarnCount"));
                bean.setMemberVoteCount(resultSet.getInt("MemberVoteCount"));
                bean.setMemberVoteTotalStars(resultSet.getInt("MemberVoteTotalStars"));
                bean.setMemberRewardPoints(resultSet.getInt("MemberRewardPoints"));
                bean.setMemberTitle(resultSet.getString("MemberTitle"));
                bean.setMemberSignature(resultSet.getString("MemberSignature"));
                bean.setMemberAvatar(resultSet.getString("MemberAvatar"));
                bean.setMemberFirstname(resultSet.getString("MemberFirstname"));
                bean.setMemberLastname(resultSet.getString("MemberLastname"));
                bean.setMemberGender(resultSet.getInt("MemberGender"));
                bean.setMemberBirthday(resultSet.getDate("MemberBirthday"));
                bean.setMemberAddress(resultSet.getString("MemberAddress"));
                bean.setMemberCity(resultSet.getString("MemberCity"));
                bean.setMemberState(resultSet.getString("MemberState"));
                bean.setMemberCountry(resultSet.getString("MemberCountry"));
                bean.setMemberPhone(resultSet.getString("MemberPhone"));
                bean.setMemberMobile(resultSet.getString("MemberMobile"));
                bean.setMemberFax(resultSet.getString("MemberFax"));
                bean.setMemberCareer(resultSet.getString("MemberCareer"));
                bean.setMemberHomepage(resultSet.getString("MemberHomepage"));
                bean.setMemberYahoo(resultSet.getString("MemberYahoo"));
                bean.setMemberAol(resultSet.getString("MemberAol"));
                bean.setMemberIcq(resultSet.getString("MemberIcq"));
                bean.setMemberMsn(resultSet.getString("MemberMsn"));
                bean.setMemberCoolLink1(resultSet.getString("MemberCoolLink1"));
                bean.setMemberCoolLink2(resultSet.getString("MemberCoolLink2"));
                retValue.add(bean);
                loop = resultSet.next();
            }//while
            return retValue;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.getBeans_withSortSupport_limit_general.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.resetStatement(statement);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static void updateMemberStatus(int memberID, // primary key
                            int memberStatus)
                            throws ObjectNotFoundException, DatabaseException {
        manager.updateStatus(memberID, // primary key
                            memberStatus);
        }
    */
    /*
     * Included columns: MemberStatus
     * Excluded columns: MemberID, MemberName, MemberPassword, MemberFirstEmail, MemberEmail,
     *                   MemberEmailVisible, MemberNameVisible, MemberFirstIP, MemberLastIP, MemberViewCount,
     *                   MemberPostCount, MemberCreationDate, MemberModifiedDate, MemberLastLogon, MemberOption,
     *                   MemberActivateCode, MemberTempPassword, MemberMessageCount, MemberMessageOption, MemberPostsPerPage,
     *                   MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle,
     *                   MemberTimeZone, MemberSignature, MemberAvatar, MemberSkin, MemberLanguage,
     *                   MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress,
     *                   MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile,
     *                   MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol,
     *                   MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2
     */
    public void updateStatus(int memberID, // primary key
                        int memberStatus)
                        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("UPDATE " + TABLE_NAME + " SET MemberStatus = ?");
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            // // column(s) to update
            statement.setInt(1, memberStatus);

            // primary key column(s)
            statement.setInt(2, memberID);

            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update table Member where primary key = (" + memberID + ").");
            }
            setDirty(true);
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberWebHelper.update.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /**
     * This method should be call only when we can make sure that memberID is in database
     */
    public void increaseViewCount(int memberID)
        throws DatabaseException, ObjectNotFoundException {

        Connection connection = null;
        PreparedStatement statement = null;
        String sql = "UPDATE " + TABLE_NAME + " SET MemberViewCount = MemberViewCount + 1 WHERE MemberID = ?";
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql);
            statement.setInt(1, memberID);
            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update the MemberViewCount in table Member. Please contact Web site Administrator.");
            }
            //@todo: coi lai cho nay
            // ATTENTION !!!
            setDirty(true);
        } catch (SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error occured when update Member: column name = MemberViewCount.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /**
     * This method should be call only when we can make sure that memberID is in database
     */
    public void increasePostCount(int memberID)
        throws DatabaseException, ObjectNotFoundException {

        Connection connection = null;
        PreparedStatement statement = null;
        String sql = "UPDATE " + TABLE_NAME + " SET MemberPostCount = MemberPostCount + 1 WHERE MemberID = ?";
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql);
            statement.setInt(1, memberID);
            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update the MemberPostCount in table Member. Please contact Web site Administrator.");
            }
            //@todo: coi lai cho nay
            // ATTENTION !!!
            setDirty(true);
        } catch (SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error occured when update Member: column name = MemberPostCount.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

}// end of class MemberWebHelper

