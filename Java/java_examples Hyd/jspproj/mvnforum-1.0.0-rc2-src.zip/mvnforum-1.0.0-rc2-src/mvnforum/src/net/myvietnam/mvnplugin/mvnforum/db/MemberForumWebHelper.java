/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/MemberForumWebHelper.java,v 1.11 2003/10/29 18:57:41 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.11 $
 * $Date: 2003/10/29 18:57:41 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.sql.*;
import java.util.ArrayList; // @todo: uncomment as needed
import java.util.Collection; // @todo: uncomment as needed
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.db.DBUtils;
import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvnplugin.mvnforum.ManagerFactory;

/*
// @todo: copy this skeleton for derived class
package package_of_derived_class;

//import java.sql.*;// @todo: uncomment as needed
//import java.util.Collection; // @todo: uncomment as needed
//import org.apache.commons.logging.Log; // @todo: uncomment as needed
//import org.apache.commons.logging.LogFactory; // @todo: uncomment as needed
//import net.myvietnam.mvncore.db.DBUtils;// @todo: uncomment as needed
import net.myvietnam.mvncore.exception.*;
//import net.myvietnam.mvnplugin.mvnforum.db.MemberForumBean;// @todo: uncomment as needed

class MemberForumWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.MemberForumWebHelper {

    //private static Log log = LogFactory.getLog(MemberForumWebHelper.class);

    // prevent instantiation and inheritance
    private MemberForumWebHelper() {
    }

    // @todo: add methods here
}
*/
public class MemberForumWebHelper {

    private static Log log = LogFactory.getLog(MemberForumWebHelper.class);

    public static final String TABLE_NAME = DatabaseConfig.TABLE_PREFIX + "MemberForum";

    // this variable will support caching if cache for this class is needed
    private static boolean m_dirty = true;

    // Prevent instantiation from classes other than derived classes
    protected MemberForumWebHelper() {
    }

    protected static boolean isDirty() {
        return m_dirty;
    }

    protected static void setDirty(boolean dirty) {
        m_dirty = dirty;
    }

    protected static void findByPrimaryKey(int memberID, int forumID, int permission)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberID, ForumID, Permission");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE MemberID = ? AND ForumID = ? AND Permission = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            statement.setInt(2, forumID);
            statement.setInt(3, permission);
            resultSet = statement.executeQuery();
            if (!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the primary key (" + memberID + ", " + forumID + ", " + permission + ") in table 'MemberForum'.");
            }
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberForumWebHelper.findByPrimaryKey.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static void createMemberForum(int memberID, int forumID, int permission)
                            throws CreateException, DatabaseException, ForeignKeyNotFoundException {
            net.myvietnam.mvnplugin.mvnforum.db.MemberForumWebHelper.create(memberID, forumID, permission);
        }
    */
    /*
     * Included columns: MemberID, ForumID, Permission
     * Excluded columns:
     */
    protected static void create(int memberID, int forumID, int permission)
                        throws CreateException, DatabaseException, DuplicateKeyException, ForeignKeyNotFoundException {

        // @todo: comment this try-catch block if the needed columns dont have attribute 'include'
        // If this is the case, then it is highly recommended that you regenerate this method with the attribute 'include' turned on
        // However, if primary key is a auto_increment column, then you can safely delete this block
        try {
            //Check if primary key already exists
            findByPrimaryKey(memberID, forumID, permission);
            //If so, then we have to throw an exception
            throw new DuplicateKeyException("Primary key already exists. Cannot create new MemberForum with the same <MemberID, ForumID, Permission> (" + memberID + ", " + forumID + ", " + permission + ").");
        } catch(ObjectNotFoundException e) {
            //Otherwise we can go ahead
        }

        if (memberID!=0) {
            try {
                // @todo: modify the parameter list as needed
                // You may have to regenerate this method if the needed columns dont have attribute 'include'
                ManagerFactory.getMemberDAO().findByPrimaryKey(memberID);
            } catch(ObjectNotFoundException e) {
                throw new ForeignKeyNotFoundException("Foreign key refers to table 'mvnforumMember' does not exist. Cannot create new MemberForum.");
            }
        }

        try {
            // @todo: modify the parameter list as needed
            // You may have to regenerate this method if the needed columns dont have attribute 'include'
            ForumWebHelper.findByPrimaryKey(forumID);
        } catch(ObjectNotFoundException e) {
            throw new ForeignKeyNotFoundException("Foreign key refers to table 'mvnforumForum' does not exist. Cannot create new MemberForum.");
        }

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("INSERT INTO " + TABLE_NAME + " (MemberID, ForumID, Permission)");
        sql.append(" VALUES (?, ?, ?)");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            statement.setInt(1, memberID);
            statement.setInt(2, forumID);
            statement.setInt(3, permission);

            if (statement.executeUpdate() != 1) {
                throw new CreateException("Error adding a row into table 'MemberForum'.");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberForumWebHelper.create.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static void deleteMemberForum(int memberID, int forumID, int permission)
            throws DatabaseException, ObjectNotFoundException {
            net.myvietnam.mvnplugin.mvnforum.db.MemberForumWebHelper.delete(memberID, forumID, permission);
        }
    */
    protected static void delete(int memberID, int forumID, int permission)
        throws DatabaseException, ObjectNotFoundException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("DELETE FROM " + TABLE_NAME);
        sql.append(" WHERE MemberID = ? AND ForumID = ? AND Permission = ?");

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            statement.setInt(2, forumID);
            statement.setInt(3, permission);
            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot delete a row in table MemberForum where primary key = (" + memberID + ", " + forumID + ", " + permission + ").");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberForumWebHelper.delete.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static void deleteMemberForum_inForum(int forumID)
            throws DatabaseException {
            net.myvietnam.mvnplugin.mvnforum.db.MemberForumWebHelper.delete_inForum(forumID);
        }
    */
    protected static void delete_inForum(int forumID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("DELETE FROM " + TABLE_NAME);
        sql.append(" WHERE ForumID = ? ");

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, forumID);

            statement.executeUpdate();
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberForumWebHelper.delete_inForum.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }
    /*
// @todo: copy this method for derived class
        public static MemberForumBean getMemberForum_inMemberForum(int memberID, int forumID)
            throws DatabaseException {
            return net.myvietnam.mvnplugin.mvnforum.db.MemberForumWebHelper.getBeans_inMemberForum(memberID, forumID);
        }
     */
    /*
     * Included columns: Permission
     * Excluded columns: MemberID, ForumID
     */
    protected static Collection getBeans_inMemberForum(int memberID, int forumID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Collection retValue = new ArrayList();
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT Permission");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE MemberID = ? AND ForumID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            statement.setInt(2, forumID);

            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                MemberForumBean bean = new MemberForumBean();
                bean.setMemberID(memberID);
                bean.setForumID(forumID);
                bean.setPermission(resultSet.getInt("Permission"));
                retValue.add(bean);
            }
            return retValue;
        } catch (SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberForumWebHelper.getBeans_inMemberForum.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
       public static Collection getMemberForums_inMember(int memberID)
           throws DatabaseException {
           return net.myvietnam.mvnplugin.mvnforum.db.MemberForumWebHelper.getBeans_inMember(memberID);
       }
     */
    /*
     * Included columns: MemberID, ForumID, Permission
     * Excluded columns:
     */
    protected static Collection getBeans_inMember(int memberID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Collection retValue = new ArrayList();

        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberID, ForumID, Permission");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE MemberID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                MemberForumBean bean = new MemberForumBean();
                bean.setMemberID(resultSet.getInt("MemberID"));
                bean.setForumID(resultSet.getInt("ForumID"));
                bean.setPermission(resultSet.getInt("Permission"));
                retValue.add(bean);
            }
            return retValue;
        } catch (SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberForumWebHelper.getBeans_inMember.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static Collection getMemberForums_inForum(int forumID)
            throws DatabaseException {
            return net.myvietnam.mvnplugin.mvnforum.db.MemberForumWebHelper.getBeans_inForum(forumID);
        }
     */
    /*
     * Included columns: MemberID, ForumID, Permission
     * Excluded columns:
     */
    protected static Collection getBeans_inForum(int forumID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Collection retValue = new ArrayList();

        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT MemberID, ForumID, Permission");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE ForumID = ?");
        sql.append(" ORDER BY MemberID ");

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, forumID);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                MemberForumBean bean = new MemberForumBean();
                bean.setMemberID(resultSet.getInt("MemberID"));
                bean.setForumID(resultSet.getInt("ForumID"));
                bean.setPermission(resultSet.getInt("Permission"));
                retValue.add(bean);
            }
            return retValue;
        } catch (SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MemberForumWebHelper.getBeans_inForum.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }
}// end of class MemberForumWebHelper

