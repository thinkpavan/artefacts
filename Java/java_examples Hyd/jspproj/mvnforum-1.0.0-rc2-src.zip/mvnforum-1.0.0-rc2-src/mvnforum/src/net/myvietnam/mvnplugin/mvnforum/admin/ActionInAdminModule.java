/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/ActionInAdminModule.java,v 1.6 2003/08/09 17:18:06 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.6 $
 * $Date: 2003/08/09 17:18:06 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import javax.servlet.http.HttpServletRequest;

import net.myvietnam.mvncore.exception.MissingURLMapEntryException;
import net.myvietnam.mvnplugin.mvnforum.auth.Action;
import net.myvietnam.mvnplugin.mvnforum.auth.AbstractAction;

public class ActionInAdminModule extends AbstractAction implements Action {

    public ActionInAdminModule(HttpServletRequest request, String requestURI) throws MissingURLMapEntryException {
        url  = null;// url may be null after the code below
        desc = null;// but desc is never be null
        // the request SHOULD ONLY be used to get the queryString
        //String queryString = StringUtil.getEmptyStringIfNull(request.getQueryString());

        desc = "Access Admin Control Panel [N/A]";

        // check that desc is never null
        if (desc == null) {
            String errorMessage = "Cannot find matching entry in OnlineMember for '" + requestURI + "'. Please contact the administrator.";
            throw new MissingURLMapEntryException(errorMessage);
        }
    }
}
