/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/user/WatchUtil.java,v 1.6 2003/05/10 04:03:16 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.6 $
 * $Date: 2003/05/10 04:03:16 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 * @author: Cord         cord_sw@lupinex.com
 */
package net.myvietnam.mvnplugin.mvnforum.user;

import java.util.*;

import net.myvietnam.mvncore.exception.DatabaseException;
import net.myvietnam.mvncore.exception.ObjectNotFoundException;
import net.myvietnam.mvnplugin.mvnforum.db.*;

final class WatchUtil {

    private WatchUtil() {// prevent instantiation
    }

    private static boolean isCategoryInWatchs(int categoryID, ArrayList categoryWatchs) {
        for (int catIndex = 0; catIndex < categoryWatchs.size(); catIndex++) {
            WatchBean watchBean = (WatchBean) categoryWatchs.get(catIndex);
            int currentCategoryID = watchBean.getCategoryID();
            if (currentCategoryID == categoryID) {
                return true;
            }
        }
        return false;
    }

    /**
     * Optimize the watch collection, note that the thread is not optimized
     * @param watchBeans
     * @return the watch collection that has been optimized
     */
    static Collection optimize(Collection watchBeans)
        throws DatabaseException, ObjectNotFoundException {

        // now check the global watch first
        Collection globalWatchs = getGlobalWatchs(watchBeans);
        if (globalWatchs.size() == 1) {
            return globalWatchs;
        }

        ArrayList categoryWatchs = getCategoryWatchs(watchBeans);

        // next, set it to the category watch beans
        ArrayList optimizedWatchs = new ArrayList();// MUST use ArrayList for the optimizedWatchs
        optimizedWatchs.addAll(categoryWatchs);

        // now remove the redundant forum watch beans
        ArrayList forumWatchs = getForumWatchs(watchBeans);
        ForumCache forumCache = ForumCache.getInstance();
        for (int forumIndex = 0; forumIndex < forumWatchs.size(); forumIndex++) {
            WatchBean forumWatch = (WatchBean) forumWatchs.get(forumIndex);
            ForumBean forumBean = forumCache.getBean(forumWatch.getForumID());
            int categoryID = forumBean.getCategoryID();

            // now check if the categoryID is in categoryWatchs or not
            if (isCategoryInWatchs(categoryID, categoryWatchs) == false) {
                optimizedWatchs.add(forumWatch);
            }
        }

        // finally, add the thread watchs (not optimize thread)
        ArrayList threadWatchs = getThreadWatchs(watchBeans);
        optimizedWatchs.addAll(threadWatchs);

        return optimizedWatchs;
    }

    static ArrayList getGlobalWatchs(Collection watchBeans) {
        ArrayList globalWatchs = new ArrayList(1);//maximum is 1 global watch
        Iterator iterator = watchBeans.iterator();
        while (iterator.hasNext()) {
            WatchBean watchBean = (WatchBean) iterator.next();
            if ( (watchBean.getCategoryID() == 0) && (watchBean.getForumID() == 0) && (watchBean.getThreadID() == 0)) {
                globalWatchs.add(watchBean);
            }
        }
        return globalWatchs;
    }

    static ArrayList getCategoryWatchs(Collection watchBeans) {
        ArrayList categoryWatchs = new ArrayList();
        Iterator iterator = watchBeans.iterator();
        while (iterator.hasNext()) {
            WatchBean watchBean = (WatchBean) iterator.next();
            if (watchBean.getCategoryID() != 0) {
                if ( (watchBean.getForumID()==0) && (watchBean.getThreadID()==0) ) {
                    categoryWatchs.add(watchBean);
                } else {
                    //@todo: delete watch here
                }
            }
        }
        return categoryWatchs;
    }

    static ArrayList getForumWatchs(Collection watchBeans) {
        ArrayList forumWatchs = new ArrayList();
        Iterator iterator = watchBeans.iterator();
        while (iterator.hasNext()) {
            WatchBean watchBean = (WatchBean) iterator.next();
            if (watchBean.getForumID() != 0) {
                if ( (watchBean.getCategoryID()==0) && (watchBean.getThreadID()==0) ) {
                    forumWatchs.add(watchBean);
                } else {
                    //@todo: delete watch here
                }
            }
        }
        return forumWatchs;
    }

    static ArrayList getThreadWatchs(Collection watchBeans) {
        ArrayList threadWatchs = new ArrayList();
        Iterator iterator = watchBeans.iterator();
        while (iterator.hasNext()) {
            WatchBean watchBean = (WatchBean) iterator.next();
            if (watchBean.getThreadID() != 0) {
                if ( (watchBean.getCategoryID()==0) && (watchBean.getForumID()==0) ) {
                    threadWatchs.add(watchBean);
                } else {
                    //@todo: delete watch here
                }
            }
        }
        return threadWatchs;
    }
}
