/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/CategoryWebHelper.java,v 1.9 2003/08/02 17:27:16 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.9 $
 * $Date: 2003/08/02 17:27:16 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.db.DBUtils;
import net.myvietnam.mvncore.exception.*;

/*
// @todo: copy this skeleton for derived class
package package_of_derived_class;

//import java.sql.*;// @todo: uncomment as needed
//import java.util.Collection; // @todo: uncomment as needed
//import net.myvietnam.mvncore.db.DBUtils;// @todo: uncomment as needed
import net.myvietnam.mvncore.exception.*;
//import net.myvietnam.mvnplugin.mvnforum.db.CategoryBean;// @todo: uncomment as needed

class CategoryWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.CategoryWebHelper {
    // prevent instantiation and inheritance
    private CategoryWebHelper() {
    }

    // @todo: add methods here
}
*/
public class CategoryWebHelper {

    private static Log log = LogFactory.getLog(CategoryWebHelper.class);

    public static final String TABLE_NAME = DatabaseConfig.TABLE_PREFIX + "Category";

    // this variable will support caching if cache for this class is needed
    private static boolean m_dirty = true;

    // Prevent instantiation from classes other than derived classes
    protected CategoryWebHelper() {
    }

    protected static boolean isDirty() {
        return m_dirty;
    }

    protected static void setDirty(boolean dirty) {
        m_dirty = dirty;
    }

    protected static void findByPrimaryKey(int categoryID)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT CategoryID");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE CategoryID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, categoryID);
            resultSet = statement.executeQuery();
            if (!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the primary key (" + categoryID + ") in table 'Category'.");
            }
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in CategoryWebHelper.findByPrimaryKey.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    protected static void findByAlternateKey_CategoryName(String categoryName)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT CategoryName");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE CategoryName = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setString(1, categoryName);
            resultSet = statement.executeQuery();
            if (!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the alternate key <CategoryName> (" + categoryName + ") in table 'Category'.");
            }
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in CategoryWebHelper.findByAlternateKey_CategoryName.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static void createCategory(int parentCategoryID, String categoryName, String categoryDesc,
                        Timestamp categoryCreationDate, Timestamp categoryModifiedDate, int categoryOrder,
                        int categoryOption, int categoryStatus)
                        throws CreateException, DatabaseException, DuplicateKeyException, ForeignKeyNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.CategoryWebHelper.create(parentCategoryID, categoryName, categoryDesc, categoryCreationDate, categoryModifiedDate, categoryOrder, categoryOption, categoryStatus);
    }
*/
    /*
     * Included columns: ParentCategoryID, CategoryName, CategoryDesc, CategoryCreationDate, CategoryModifiedDate,
     *                   CategoryOrder, CategoryOption, CategoryStatus
     * Excluded columns: CategoryID
     */
    protected static void create(int parentCategoryID, String categoryName, String categoryDesc,
                        Timestamp categoryCreationDate, Timestamp categoryModifiedDate, int categoryOrder,
                        int categoryOption, int categoryStatus)
                        throws CreateException, DatabaseException, DuplicateKeyException, ForeignKeyNotFoundException {

        // @todo: Comment this try-catch block if the needed columns dont have attribute 'include'
        // If this is the case, then it is highly recommended that you regenerate this method with the attribute 'include' turned on
        try {
            //Check if alternate key already exists
            findByAlternateKey_CategoryName(categoryName);
            //If so, then we have to throw an exception
            throw new DuplicateKeyException("Alternate key already exists. Cannot create new Category with the same <CategoryName> (" + categoryName + ").");
        } catch(ObjectNotFoundException e) {
            //Otherwise we can go ahead
        }

        try {
            // @todo: modify the parameter list as needed
            // You may have to regenerate this method if the needed columns dont have attribute 'include'
            if (parentCategoryID != 0) {
                CategoryWebHelper.findByPrimaryKey(parentCategoryID);
            }
        } catch(ObjectNotFoundException e) {
            throw new ForeignKeyNotFoundException("Foreign key refers to table 'Category' does not exist. Cannot create new Category.");
        }

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("INSERT INTO " + TABLE_NAME + " (ParentCategoryID, CategoryName, CategoryDesc, CategoryCreationDate, CategoryModifiedDate, CategoryOrder, CategoryOption, CategoryStatus)");
        sql.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            statement.setInt(1, parentCategoryID);
            statement.setString(2, categoryName);
            statement.setString(3, categoryDesc);
            statement.setTimestamp(4, categoryCreationDate);
            statement.setTimestamp(5, categoryModifiedDate);
            statement.setInt(6, categoryOrder);
            statement.setInt(7, categoryOption);
            statement.setInt(8, categoryStatus);

            if (statement.executeUpdate() != 1) {
                throw new CreateException("Error adding a row into table 'Category'.");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in CategoryWebHelper.create.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    /*
// @todo: copy this method for derived class
        public static void deleteCategory(int categoryID)
            throws DatabaseException, ObjectNotFoundException {
            net.myvietnam.mvnplugin.mvnforum.db.CategoryWebHelper.delete(categoryID);
        }
    */
    protected static void delete(int categoryID)
        throws DatabaseException, ObjectNotFoundException {

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("DELETE FROM " + TABLE_NAME);
        sql.append(" WHERE CategoryID = ?");

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, categoryID);
            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot delete a row in table Category where primary key = (" + categoryID + ").");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in CategoryWebHelper.delete.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }
/*
// @todo: copy this method for derived class
    public static void updateCategory(int categoryID, // primary key
                        String categoryName, String categoryDesc, Timestamp categoryModifiedDate,
                        int categoryOrder, int categoryOption, int categoryStatus)
                        throws ObjectNotFoundException, DatabaseException {
        net.myvietnam.mvnplugin.mvnforum.db.CategoryWebHelper.update(categoryID, // primary key
                        categoryName, categoryDesc, categoryModifiedDate,
                        categoryOrder, categoryOption, categoryStatus);
    }
*/
    /*
     * Included columns: CategoryName, CategoryDesc, CategoryModifiedDate, CategoryOrder, CategoryOption,
     *                   CategoryStatus
     * Excluded columns: CategoryID, ParentCategoryID, CategoryCreationDate
     */
    protected static void update(int categoryID, // primary key
                        String categoryName, String categoryDesc, Timestamp categoryModifiedDate,
                        int categoryOrder, int categoryOption, int categoryStatus)
                        throws ObjectNotFoundException, DatabaseException, DuplicateKeyException {

        CategoryBean bean = getBean(categoryID); // @todo: comment or delete this line if no alternate key are included

        if ( !categoryName.equals(bean.getCategoryName()) ) {
            // Category tries to change its alternate key <CategoryName>, so we must check if it already exist
            try {
                findByAlternateKey_CategoryName(categoryName);
                throw new DuplicateKeyException("Alternate key <CategoryName> (" + categoryName + ")already exists. Cannot update Category.");
            } catch(ObjectNotFoundException e) {
                //Otherwise we can go ahead
            }
        }

        Connection connection = null;
        PreparedStatement statement = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("UPDATE " + TABLE_NAME + " SET CategoryName = ?, CategoryDesc = ?, CategoryModifiedDate = ?, CategoryOrder = ?, CategoryOption = ?, CategoryStatus = ?");
        sql.append(" WHERE CategoryID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());

            // // column(s) to update
            statement.setString(1, categoryName);
            statement.setString(2, categoryDesc);
            statement.setTimestamp(3, categoryModifiedDate);
            statement.setInt(4, categoryOrder);
            statement.setInt(5, categoryOption);
            statement.setInt(6, categoryStatus);

            // primary key column(s)
            statement.setInt(7, categoryID);

            if (statement.executeUpdate() != 1) {
                throw new ObjectNotFoundException("Cannot update table Category where primary key = (" + categoryID + ").");
            }
            m_dirty = true;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in CategoryWebHelper.update.");
        } finally {
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static CategoryBean getCategory(int categoryID)
        throws ObjectNotFoundException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.CategoryWebHelper.getBean(categoryID);
    }
*/
    /*
     * Included columns: ParentCategoryID, CategoryName, CategoryDesc, CategoryCreationDate, CategoryModifiedDate,
     *                   CategoryOrder, CategoryOption, CategoryStatus
     * Excluded columns: CategoryID
     */
    protected static CategoryBean getBean(int categoryID)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT ParentCategoryID, CategoryName, CategoryDesc, CategoryCreationDate, CategoryModifiedDate, CategoryOrder, CategoryOption, CategoryStatus");
        sql.append(" FROM " + TABLE_NAME);
        sql.append(" WHERE CategoryID = ?");
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, categoryID);
            resultSet = statement.executeQuery();
            if(!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the row in table Category where primary key = (" + categoryID + ").");
            }

            CategoryBean bean = new CategoryBean();
            // @todo: uncomment the following line(s) as needed
            bean.setCategoryID(categoryID);
            bean.setParentCategoryID(resultSet.getInt("ParentCategoryID"));
            bean.setCategoryName(resultSet.getString("CategoryName"));
            bean.setCategoryDesc(resultSet.getString("CategoryDesc"));
            bean.setCategoryCreationDate(resultSet.getTimestamp("CategoryCreationDate"));
            bean.setCategoryModifiedDate(resultSet.getTimestamp("CategoryModifiedDate"));
            bean.setCategoryOrder(resultSet.getInt("CategoryOrder"));
            bean.setCategoryOption(resultSet.getInt("CategoryOption"));
            bean.setCategoryStatus(resultSet.getInt("CategoryStatus"));
            return bean;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in CategoryWebHelper.getBean(pk).");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

/*
// @todo: copy this method for derived class
    public static Collection getCategorys()
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.CategoryWebHelper.getBeans();
    }
*/
    /*
     * Included columns: CategoryID, ParentCategoryID, CategoryName, CategoryDesc, CategoryCreationDate,
     *                   CategoryModifiedDate, CategoryOrder, CategoryOption, CategoryStatus
     * Excluded columns:
     */
    protected static Collection getBeans()
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Collection retValue = new ArrayList();
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT CategoryID, ParentCategoryID, CategoryName, CategoryDesc, CategoryCreationDate, CategoryModifiedDate, CategoryOrder, CategoryOption, CategoryStatus");
        sql.append(" FROM " + TABLE_NAME);
        //sql.append(" WHERE "); // @todo: uncomment as needed
        sql.append(" ORDER BY CategoryOrder ASC "); // @todo: uncomment as needed
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                CategoryBean bean = new CategoryBean();
                bean.setCategoryID(resultSet.getInt("CategoryID"));
                bean.setParentCategoryID(resultSet.getInt("ParentCategoryID"));
                bean.setCategoryName(resultSet.getString("CategoryName"));
                bean.setCategoryDesc(resultSet.getString("CategoryDesc"));
                bean.setCategoryCreationDate(resultSet.getTimestamp("CategoryCreationDate"));
                bean.setCategoryModifiedDate(resultSet.getTimestamp("CategoryModifiedDate"));
                bean.setCategoryOrder(resultSet.getInt("CategoryOrder"));
                bean.setCategoryOption(resultSet.getInt("CategoryOption"));
                bean.setCategoryStatus(resultSet.getInt("CategoryStatus"));
                retValue.add(bean);
            }
            return retValue;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in CategoryWebHelper.getBeans.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

}// end of class CategoryWebHelper

