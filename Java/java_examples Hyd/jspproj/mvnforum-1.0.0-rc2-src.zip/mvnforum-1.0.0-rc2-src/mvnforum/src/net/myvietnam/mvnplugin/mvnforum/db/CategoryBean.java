/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/CategoryBean.java,v 1.6 2003/09/14 14:15:39 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.6 $
 * $Date: 2003/09/14 14:15:39 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Iterator;

import net.myvietnam.mvncore.util.StringUtil;

/*
 * Included columns: CategoryID, ParentCategoryID, CategoryName, CategoryDesc, CategoryCreationDate,
 *                   CategoryModifiedDate, CategoryOrder, CategoryOption, CategoryStatus
 * Excluded columns:
 */
public class CategoryBean {
    private int categoryID;
    private int parentCategoryID;
    private String categoryName;
    private String categoryDesc;
    private Timestamp categoryCreationDate;
    private Timestamp categoryModifiedDate;
    private int categoryOrder;
    private int categoryOption;
    private int categoryStatus;

    public int getCategoryID() {
        return categoryID;
    }
    public void setCategoryID(int categoryID) {
        this.categoryID = categoryID;
    }

    public int getParentCategoryID() {
        return parentCategoryID;
    }
    public void setParentCategoryID(int parentCategoryID) {
        this.parentCategoryID = parentCategoryID;
    }

    public String getCategoryName() {
        return categoryName;
    }
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategoryDesc() {
        return categoryDesc;
    }
    public void setCategoryDesc(String categoryDesc) {
        this.categoryDesc = StringUtil.getEmptyStringIfNull(categoryDesc);
    }

    public Timestamp getCategoryCreationDate() {
        return categoryCreationDate;
    }
    public void setCategoryCreationDate(Timestamp categoryCreationDate) {
        this.categoryCreationDate = categoryCreationDate;
    }

    public Timestamp getCategoryModifiedDate() {
        return categoryModifiedDate;
    }
    public void setCategoryModifiedDate(Timestamp categoryModifiedDate) {
        this.categoryModifiedDate = categoryModifiedDate;
    }

    public int getCategoryOrder() {
        return categoryOrder;
    }
    public void setCategoryOrder(int categoryOrder) {
        this.categoryOrder = categoryOrder;
    }

    public int getCategoryOption() {
        return categoryOption;
    }
    public void setCategoryOption(int categoryOption) {
        this.categoryOption = categoryOption;
    }

    public int getCategoryStatus() {
        return categoryStatus;
    }
    public void setCategoryStatus(int categoryStatus) {
        this.categoryStatus = categoryStatus;
    }

    public String getXML() {
        StringBuffer xml = new StringBuffer(1024);
        xml.append("<CategorySection>\n");
        xml.append("  <Rows>\n");
        xml.append("    <Row>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>CategoryID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(categoryID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ParentCategoryID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(parentCategoryID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>CategoryName</Name>\n");
        xml.append("        <Value>").append(String.valueOf(categoryName)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>CategoryDesc</Name>\n");
        xml.append("        <Value>").append(String.valueOf(categoryDesc)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>CategoryCreationDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(categoryCreationDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>CategoryModifiedDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(categoryModifiedDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>CategoryOrder</Name>\n");
        xml.append("        <Value>").append(String.valueOf(categoryOrder)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>CategoryOption</Name>\n");
        xml.append("        <Value>").append(String.valueOf(categoryOption)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>CategoryStatus</Name>\n");
        xml.append("        <Value>").append(String.valueOf(categoryStatus)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("    </Row>\n");
        xml.append("  </Rows>\n");
        xml.append("</CategorySection>\n");
        return xml.toString();
    }

    public static String getXML(Collection objCategoryBeans) {
        StringBuffer xml = new StringBuffer(1024);
        Iterator iterator = objCategoryBeans.iterator();
        xml.append("<CategorySection>\n");
        xml.append("  <Rows>\n");
        while (iterator.hasNext()) {
            CategoryBean objCategoryBean = (CategoryBean)iterator.next();
            xml.append("    <Row>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>CategoryID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objCategoryBean.categoryID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ParentCategoryID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objCategoryBean.parentCategoryID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>CategoryName</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objCategoryBean.categoryName)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>CategoryDesc</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objCategoryBean.categoryDesc)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>CategoryCreationDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objCategoryBean.categoryCreationDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>CategoryModifiedDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objCategoryBean.categoryModifiedDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>CategoryOrder</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objCategoryBean.categoryOrder)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>CategoryOption</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objCategoryBean.categoryOption)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>CategoryStatus</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objCategoryBean.categoryStatus)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("    </Row>\n");
        }//while
        xml.append("  </Rows>\n");
        xml.append("</CategorySection>\n");
        return xml.toString();
    }
} //end of class CategoryBean
