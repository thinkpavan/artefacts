/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/MVNForumConstant.java,v 1.18 2003/10/30 19:18:57 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.18 $
 * $Date: 2003/10/30 19:18:57 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 * @author: Igor Manic   imanic@users.sourceforge.net
 */
package net.myvietnam.mvnplugin.mvnforum;

import net.myvietnam.mvnplugin.mvnforum.MVNForumConfig;

public final class MVNForumConstant {

    /** Cannot instantiate. */
    private MVNForumConstant() {
    }

/*************************************************************************
 * NOTE: below constants MUST NOT be changed IN ALL CASES,
 *       or it will break the compatibility
 *************************************************************************/

    /** Represents nobody. If it appears in the session object, it should be treated as a Guest. */
    public static final int MEMBER_ID_UNUSED0              = 0;
    /** System administrator. */
    public static final int MEMBER_ID_OF_ADMIN             = 1;
    /** Guest/anonymous site visitor. */
    public static final int MEMBER_ID_OF_GUEST             = 0;
    /**
     * The highest reserved MemberID.
     * All IDs from 0 through this value should not be used for "regular" members.
     */
    public static final int LAST_RESERVED_MEMBER_ID        = 2;
    /* IMPORTANT: When we have a group without group owner, GroupOwnerID is set to 0.
     * Similiar is for other IDs in the database - 0 means there is no reference.
     * Also, the other reason why MemberID=0 should not be used for Guest is
     * that DBMS could refuse to insert a record with 0 in that field, since it's
     * marked as non-null autoincrement primary key.
     */

    /** Unused GroupID. */
    public static final int GROUP_ID_UNUSED0               = 0;
    /**
     * Unused GroupID. In the previous versions of mvnForum it was used for some
     * special purposes, but should not be used anymore.
     */
    public static final int GROUP_ID_OF_GUEST              = 1;
    /** "Registered Members" virtual group. All members are listed in this group. */
    public static final int GROUP_ID_OF_REGISTERED_MEMBERS = 2;
    /**
     * The highest reserved GroupID.
     * All IDs from 0 through this value should not be used for "regular" groups.
     */
    public static final int LAST_RESERVED_GROUP_ID         = 2;

    /** "Inbox" message folder created by default for each member. */
    public static final String MESSAGE_FOLDER_INBOX        = "Inbox";
    /** "Sent" message folder created by default for each member. */
    public static final String MESSAGE_FOLDER_SENT         = "Sent";

    public static final String dtdschemaDecl=
        "<!DOCTYPE mvnforum SYSTEM \""+
        // ===== @todo: change path to the DTD here =====
        "http://www.mvnforum.com/dtd/mvnforum_1_0_rc2.dtd"+
        // ?"file://"? + MVNForumConfig.getMVNForumHome()+File.separatorChar+
        //"mvnforum_1_0_rc2.dtd"+
        // ===== end of DTD path =====
        "\">";
        // @todo Igor: for XML schema: dtdschemaDecl=
        //     "<mvnforum xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""+
        //     "xsi:noNamespaceSchemaLocation=\"mvnforum.xsd\">";


}
