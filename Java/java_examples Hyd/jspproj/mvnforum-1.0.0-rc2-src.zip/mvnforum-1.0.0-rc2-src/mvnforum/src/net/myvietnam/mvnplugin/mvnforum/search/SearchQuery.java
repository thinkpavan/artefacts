/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/search/SearchQuery.java,v 1.8 2003/10/04 02:25:31 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.8 $
 * $Date: 2003/10/04 02:25:31 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Dejan Krsmanovic dejan_krsmanovic@yahoo.com
 */
package net.myvietnam.mvnplugin.mvnforum.search;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.*;
import net.myvietnam.mvncore.exception.DatabaseException;
import net.myvietnam.mvncore.exception.ObjectNotFoundException;
import net.myvietnam.mvnplugin.mvnforum.MVNForumConfig;
import net.myvietnam.mvnplugin.mvnforum.db.PostBean;
import net.myvietnam.mvnplugin.mvnforum.db.ForumCache;
import net.myvietnam.mvnplugin.mvnforum.db.ForumBean;

/**
 * This class is used for specifying query that should be searched for. Query
 * can contain keywords and further it can be filtered by specifying member
 * name of the author, forumID as well as date interval for searching.
 *
 * searchString contains one or more keywords. Each keyword can use wildcards.
 * ? for single character and * for multiple characters.
 * For specifying boolean operators AND and OR operators can be used.....
 *
 * For all available options consult Lucene documentation http://jakarta.apache.org/lucene
 *
 * @author Dejan Krsmanovic dejan_krsmanovic@yahoo.com
 */
public class SearchQuery
{
    private static Log log = LogFactory.getLog(SearchQuery.class);

    private int memberID = -1;
    private int forumId = 0;
    private String searchString = null;
    private Timestamp fromDate = null;
    private Timestamp toDate = null;

    private String searchIndexDir = null;
    private int hitCount = 0;
    private Collection searchResult = null;

    public SearchQuery() {
        searchIndexDir = MVNForumConfig.getSearchIndexDir();
    }

    /**
     * Set name of the author that should be searched for
     * @param memberId
     */
    public void setMemberId(int memberId) {
        this.memberID = memberId;
    }

    /**
     * Id of forum where post belongs. Set to -1 if all forums should be searched
     * @param forumId
     */
    public void setForumId(int forumId) {
        this.forumId = forumId;
    }

    /**
     * Set string that should be searched for.
     * @param searchString
     */
    public void setSearchString(String searchString) {
        this.searchString = searchString;
    }

    public void setFromDate(Timestamp fromDate) {
        this.fromDate = fromDate;
    }

    public void setToDate(Timestamp toDate) {
        this.toDate = toDate;
    }

    protected IndexSearcher getSearcher() throws IOException {
        try {
            IndexSearcher searcher = new IndexSearcher(searchIndexDir);
            return searcher;
        } catch (IOException ex) {
            // we throw new IOException because the original exception
            // contain sensitive directory information
            log.error("Cannot access the lucene search index for query. Please check if you have configed mvnForumHome properly. You can also go to Admin Zone to rebuild the Lucene index files.", ex);
            throw new IOException("Cannot access the lucene search index. Please report this error to web site Administrator (check mvnForumHome or rebuild Lucene index).");
        }
    }

    public void searchDocuments(int offset, int rowsToReturn)
        throws IOException, DatabaseException, ObjectNotFoundException {
        //Build the query
        if (searchString == null || searchString.equals("")) {
            if (memberID == -1) {
                return;
            }
        }
        Analyzer analyzer = PostIndexer.getAnalyzer();
        BooleanQuery query = new BooleanQuery();
        try {
            Query topicBodyQuery = getTopicBodyQuery();
            if (topicBodyQuery != null) {
                query.add(topicBodyQuery, true, false);
                log.debug("topicBodyQuery = " + topicBodyQuery);
            }

            Query categoryForumQuery = getCategoryForumQuery();
            if (categoryForumQuery != null) {
                log.debug("categoryForumQuery = " + categoryForumQuery);
                query.add(categoryForumQuery, true, false);
            }

            Query memberQuery = getMemberQuery();
            if (memberQuery != null) {
                log.debug("memberQuery = " + memberQuery);
                query.add(memberQuery, true, false);
            }
        } catch (ParseException pe) {
            log.error("Cannot parse the search query", pe);
        }
        log.debug("booleanQuery = " + query);

        DateFilter dateFilter = null;
        //Add date filter if some of dates provided
        if (fromDate != null && toDate != null) {
            dateFilter = new DateFilter(PostIndexer.FIELD_POST_DATE, fromDate, toDate);
        } else if (fromDate != null) {
            dateFilter = DateFilter.After(PostIndexer.FIELD_POST_DATE, fromDate);
        } else if (toDate != null) {
            dateFilter = DateFilter.Before(PostIndexer.FIELD_POST_DATE, toDate);
        }

        //Now search the documents
        IndexSearcher searcher = null;
        try {
            searcher = getSearcher();

            //If dateFilter set then use it
            Hits postHits = null;
            if (dateFilter != null) {
                postHits = searcher.search(query, dateFilter);
            } else {
                postHits = searcher.search(query);
            }
            hitCount = postHits.length();
            searchResult = getPosts(postHits, offset, rowsToReturn);
        } catch (IOException ex) {
            throw ex;
        } finally {
            try {
                if (searcher != null) {
                    searcher.close();
                }
            } catch (Exception ex) {}
        }
    }

    public int getHitCount() {
        return hitCount;
    }

    public Collection getPostResult() {
        return searchResult;
    }

    private Collection getPosts(Hits postHits, int offset, int rowsToReturn)
        throws IOException, ObjectNotFoundException, DatabaseException {

        if (offset < 0) throw new IllegalArgumentException("The offset < 0 is not allowed.");
        if (rowsToReturn <= 0) throw new IllegalArgumentException("The rowsToReturn <= 0 is not allowed.");

        int hitCount = getHitCount();
        ArrayList retValue = new ArrayList(hitCount);

        for (int i = offset; (i < offset + rowsToReturn) && (i < hitCount); i++) {
            Document postDocument = postHits.doc(i);
            int postID = Integer.parseInt(postDocument.get(PostIndexer.FIELD_POST_ID));
            PostBean postBean = PostWebHelper.getPost(postID);
            retValue.add(postBean);
        }
        return retValue;
    }

    private Query getTopicBodyQuery() throws ParseException {
        if (searchString == null || searchString.equals("")) {
            return null;
        }
        Analyzer analyzer = PostIndexer.getAnalyzer();
        BooleanQuery topicBodyQuery = new BooleanQuery();

        //add topic query
        Query topicQuery = QueryParser.parse(searchString,
                                             PostIndexer.FIELD_POST_TOPIC,
                                             analyzer);
        topicBodyQuery.add(topicQuery, false, false);

        //add body query
        Query bodyQuery = QueryParser.parse(searchString,
                                            PostIndexer.FIELD_POST_BODY,
                                            analyzer);
        topicBodyQuery.add(bodyQuery, false, false);

        return topicBodyQuery;
    }

    private Query getMemberQuery() throws ParseException {
        Query memberQuery = null;
        if (memberID > 0) {
            Term memberTerm = new Term(PostIndexer.FIELD_MEMBER_ID, String.valueOf(memberID));
            memberQuery = new TermQuery(memberTerm);
        }
        return memberQuery;
    }

    private Query getCategoryForumQuery() throws ParseException, DatabaseException {
        BooleanQuery categoryForumQuery = new BooleanQuery();
        if (forumId == 0) {
            // search all forum
            return null;
        } else if (forumId > 0) {
            // search in forum
            Term forumTerm = new Term(PostIndexer.FIELD_FORUM_ID, String.valueOf(forumId));
            Query forumQuery = new TermQuery(forumTerm);
            categoryForumQuery.add(forumQuery, true, false);
        } else if (forumId < 0) {
            // search in category
            int categoryID = -forumId;
            ForumCache forumCache = ForumCache.getInstance();
            ArrayList forumBeans = forumCache.getBeans();
            for (int i = 0; i < forumBeans.size(); i++) {
                ForumBean forumBean = (ForumBean) forumBeans.get(i);
                if (forumBean.getCategoryID() == categoryID) {
                    int currentForumID = forumBean.getForumID();
                    Term forumTerm = new Term(PostIndexer.FIELD_FORUM_ID, String.valueOf(currentForumID));
                    Query forumQuery = new TermQuery(forumTerm);
                    categoryForumQuery.add(forumQuery, false, false);
                }
            }
        }
        return categoryForumQuery;
    }
}