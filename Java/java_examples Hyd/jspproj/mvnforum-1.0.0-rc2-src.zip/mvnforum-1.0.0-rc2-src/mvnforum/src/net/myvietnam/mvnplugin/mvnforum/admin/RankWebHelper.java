/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/RankWebHelper.java,v 1.4 2003/09/16 16:58:25 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.4 $
 * $Date: 2003/09/16 16:58:25 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 * @author: Igor Manic   imanic@users.sourceforge.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import java.sql.*;// @todo: remove this when you update db.RankWebHelper

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import net.myvietnam.mvncore.db.DBUtils;
import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvnplugin.mvnforum.db.RankBean;

class RankWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.RankWebHelper {

    private static Log log = LogFactory.getLog(RankWebHelper.class);

    // prevent instantiation and inheritance
    private RankWebHelper() {
    }

    public static void createRank(int rankMinPosts, int rankLevel, String rankTitle,
                        String rankImage, int rankType, int rankOption)
                        throws CreateException, DatabaseException, DuplicateKeyException {
        net.myvietnam.mvnplugin.mvnforum.db.RankWebHelper.create(rankMinPosts, rankLevel, rankTitle, rankImage, rankType, rankOption);
    }

    //TODO: this method should be moved to db.RankWebHelper as protected and made public here
    public static int getRankIDFromRankTitle(String rankTitle)
        throws ObjectNotFoundException, DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        String sql = "SELECT RankID FROM " + TABLE_NAME +
                     " WHERE RankTitle = ?";
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql);
            statement.setString(1, rankTitle);
            resultSet = statement.executeQuery();
            if (!resultSet.next()) {
                throw new ObjectNotFoundException("Cannot find the alternate key <RankTitle> (" + rankTitle + ") in table 'Rank'.");
            }
            return resultSet.getInt(1);
        } catch (SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in RankWebHelper.getRankIDFromRankTitle.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    public static void updateRank(int rankID, // primary key
                        int rankMinPosts, int rankLevel, String rankTitle,
                        String rankImage, int rankType, int rankOption)
                        throws ObjectNotFoundException, DatabaseException, DuplicateKeyException {
        net.myvietnam.mvnplugin.mvnforum.db.RankWebHelper.update(rankID, // primary key
                        rankMinPosts, rankLevel, rankTitle,
                        rankImage, rankType, rankOption);
    }

    public static void deleteRank(int rankID)
        throws DatabaseException, ObjectNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.RankWebHelper.delete(rankID);
    }

    public static RankBean getRank(int rankID)
        throws ObjectNotFoundException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.RankWebHelper.getBean(rankID);
    }

}
