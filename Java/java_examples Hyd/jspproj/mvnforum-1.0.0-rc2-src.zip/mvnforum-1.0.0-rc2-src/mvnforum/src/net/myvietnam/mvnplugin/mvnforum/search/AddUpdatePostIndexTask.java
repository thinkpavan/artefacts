/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/search/AddUpdatePostIndexTask.java,v 1.3 2003/05/11 19:16:38 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.3 $
 * $Date: 2003/05/11 19:16:38 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Dejan Krsmanovic dejan_krsmanovic@yahoo.com
 */
package net.myvietnam.mvnplugin.mvnforum.search;

import java.util.TimerTask;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvnplugin.mvnforum.db.PostBean;

//This class is used for indexing single post
public class AddUpdatePostIndexTask extends TimerTask
{
    private static Log log = LogFactory.getLog(AddUpdatePostIndexTask.class);

    //Constants used for operations
    public static final int OPERATION_ADD    = 0;
    public static final int OPERATION_UPDATE = 1;

    private PostBean post;
    private int operation;

    /*
     * Contructor with default access, prevent new an instance from outside package
     */
    AddUpdatePostIndexTask(PostBean post, int operation) {
        this.post = post;
        this.operation = operation;
    }

    public void run() {
        log.debug("AddUpdatePostIndexTask.run : op = " + operation + " for PostID = " + post.getPostID());
        try {
            switch (operation) {
                case OPERATION_UPDATE:
                    PostIndexer.deletePostFromIndex(post.getPostID());
                    // fall through
                case OPERATION_ADD:
                    PostIndexer.addPostToIndex(post);
                    break;
                default:
                    log.warn("Cannot process the AddUpdatePostIndexTask with operation = " + operation);
            }
        } catch (Exception ex) {
            log.error("Error while performing index operation", ex);
        }
    }
}

