/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/user/WatchWebHandler.java,v 1.13 2003/09/14 14:15:39 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.13 $
 * $Date: 2003/09/14 14:15:39 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.user;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Iterator;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.util.*;
import net.myvietnam.mvnplugin.mvnforum.MVNForumConfig;
import net.myvietnam.mvnplugin.mvnforum.ManagerFactory;
import net.myvietnam.mvnplugin.mvnforum.auth.*;
import net.myvietnam.mvnplugin.mvnforum.db.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

class WatchWebHandler {

    private static Log log = LogFactory.getLog(WatchWebHandler.class);

    private OnlineUserManager userManager = OnlineUserManager.getInstance();

    //private DateFormat dateFormat = SimpleDateFormat.getDateTimeInstance(SimpleDateFormat.DEFAULT, SimpleDateFormat.DEFAULT);

    WatchWebHandler() {
    }

    void sendMail()
        throws DatabaseException, MessagingException, BadInputException, ObjectNotFoundException {

        if (MVNForumConfig.getEnableWatch() == false) {
            log.warn("Ingore Watch sendMail because this feature is disabled.");
            return;
        }
        String forumBase = ParamUtil.getServerPath() + ParamUtil.getContextPath() + UserModuleConfig.getUrlPattern();
        //log.debug("Forum base = " + forumBase);

        Collection beans = WatchWebHelper.getMemberWatchs();
        //log.debug("Watch: total member = " + beans.size());
        Iterator iterator = beans.iterator();
        while (iterator.hasNext()) {
            WatchBean watchBean = (WatchBean)iterator.next();
            int memberID = watchBean.getMemberID();

            // check if member is enable here
            if (ManagerFactory.getMemberDAO().getActivateCode(memberID).equals(MemberBean.MEMBER_ACTIVATECODE_ACTIVATED) == false) {
                // Not activated, then we continue with the next user
                continue;
            }

            // Check the frequency of the update
            Timestamp lastSent = watchBean.getWatchLastSentDate();
            Timestamp now = DateUtil.getCurrentGMTTimestamp();

            // We will now support a single watch standard, but should be
            // bitmasked in future to support multiple watch schedule for the same
            // thread or forum
            long minimumWaitTime = 0;
            switch (watchBean.getWatchOption()) {
                case WatchBean.WATCH_OPTION_LIVE:
                    minimumWaitTime = 0;
                    break;
                case WatchBean.WATCH_OPTION_HOURLY:
                    minimumWaitTime = DateUtil.HOUR;
                    break;
                case WatchBean.WATCH_OPTION_DAILY:
                    minimumWaitTime = DateUtil.DAY;
                    break;
                case WatchBean.WATCH_OPTION_WEEKLY:
                    minimumWaitTime = DateUtil.WEEK;
                    break;
                default:// currently only default is processed (WatchOption = 0)
                    minimumWaitTime = DateUtil.DAY;
                    break;
            }
            if ( (now.getTime() - lastSent.getTime()) > minimumWaitTime ) {
                sendMail_forMember(memberID, forumBase, lastSent);
            }
        }
    }

    void sendMail_forMember(int memberID, String forumBase, Timestamp lastSent)
        throws DatabaseException, MessagingException, BadInputException, ObjectNotFoundException {

        Collection watchBeans = WatchWebHelper.getWatchs_forMember(memberID);
        //log.debug("Watch size = " + watchBeans.size() + " for memberid = " + memberID);
        Timestamp now = DateUtil.getCurrentGMTTimestamp();

        //then optimize the watchBeans
        watchBeans = WatchUtil.optimize(watchBeans);

        WatchMail watchMail = new WatchMail(forumBase, lastSent, now);
        watchMail.appendSummary();
        Iterator watchIterator = watchBeans.iterator();
        while (watchIterator.hasNext()) {
            WatchBean watchBean = (WatchBean)watchIterator.next();
            watchMail.appendWatch(watchBean);
        }
        if (watchMail.haveAtLeastOneNewThread()) {
            // send mail now
            String from = MVNForumConfig.getWebMasterEmail(); //use the default MailFrom value
            String to = ManagerFactory.getMemberDAO().getBean_forPublic(memberID).getMemberEmail();
            String subject = watchMail.getWatchSubject();
            String content = watchMail.getMailContent();

            MailUtil.sendMail(from, to, "" /*cc*/, "" /*bcc*/, subject, content);

            // finally, update the lastsent
            WatchWebHelper.updateWatchLastSentDate_forMember(memberID, now);
        } else {
            log.debug("No new thread for MemberID = " + memberID);
        }
    }

    void prepareList(HttpServletRequest request)
        throws DatabaseException, AuthenticationException, AssertionException, ObjectNotFoundException {

        OnlineUser onlineUser = userManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();

        int memberID = onlineUser.getMemberID();
        Collection watchBeans = WatchWebHelper.getWatchs_forMember(memberID);

        Collection globalWatchBeans = WatchUtil.getGlobalWatchs(watchBeans);
        Collection categoryWatchBeans = WatchUtil.getCategoryWatchs(watchBeans);
        Collection forumWatchBeans = WatchUtil.getForumWatchs(watchBeans);
        Collection threadWatchBeans = WatchUtil.getThreadWatchs(watchBeans);

        // @todo Improve the performance of the below code
        for (Iterator iter = threadWatchBeans.iterator(); iter.hasNext(); ) {
            WatchBean threadWatchBean = (WatchBean)iter.next();
            int threadID = threadWatchBean.getThreadID();
            ThreadBean threadBean = ThreadWebHelper.getThread(threadID);
            threadWatchBean.setThreadBean(threadBean);
        }

        request.setAttribute("WatchBeans", watchBeans);
        request.setAttribute("GlobalWatchBeans", globalWatchBeans);
        request.setAttribute("CategoryWatchBeans", categoryWatchBeans);
        request.setAttribute("ForumWatchBeans", forumWatchBeans);
        request.setAttribute("ThreadWatchBeans", threadWatchBeans);
    }

    void prepareAdd(HttpServletRequest request)
        throws DatabaseException, AuthenticationException, AssertionException {

        if (MVNForumConfig.getEnableWatch() == false) {
            throw new AssertionException("Cannot add Watch because Watch feature is disabled.");
        }

        OnlineUser onlineUser = userManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();
        permission.ensureIsActivated();
    }

    void processAdd(HttpServletRequest request)
        throws BadInputException, CreateException, DatabaseException, ObjectNotFoundException,
        ForeignKeyNotFoundException, AuthenticationException, AssertionException {

        if (MVNForumConfig.getEnableWatch() == false) {
            throw new AssertionException("Cannot add Watch because Watch feature is disabled.");
        }

        OnlineUser onlineUser = userManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();
        permission.ensureIsActivated();

        Timestamp now = DateUtil.getCurrentGMTTimestamp();

        int memberID = onlineUser.getMemberID();
        int categoryID              = 0;
        int forumID                 = 0;
        int threadID                = 0;
        int watchType               = 0;//ParamUtil.getParameterInt(request, "WatchType");
        int watchOption             = 0;//ParamUtil.getParameterInt(request, "WatchOption");
        int watchStatus             = 0;//ParamUtil.getParameterInt(request, "WatchStatus");
        Timestamp watchCreationDate = now;
        Timestamp watchLastSentDate = now;
        Timestamp watchEndDate      = now;// @todo: check it !!!

        int watchSelector = ParamUtil.getParameterInt(request, "WatchSelector");
        switch (watchSelector) {
            case 0:
                break;
            case 1:
                categoryID = ParamUtil.getParameterInt(request, "category");
                break;
            case 2:
                forumID = ParamUtil.getParameterInt(request, "forum");
                break;
            case 3:
                threadID = ParamUtil.getParameterInt(request, "thread");
                ThreadWebHelper.findByPrimaryKey(threadID);
                break;
            default:
                throw new AssertionException("Cannot process WatchSelector = " + watchSelector);
        }

        try {
            WatchWebHelper.createWatch(memberID, categoryID, forumID,
                                       threadID, watchType, watchOption,
                                       watchStatus, watchCreationDate, watchLastSentDate,
                                       watchEndDate);
        } catch (DuplicateKeyException ex) {
            // User try to create a duplicate watch, just ignore
        }
    }

    void processDelete(HttpServletRequest request)
        throws BadInputException, DatabaseException, AuthenticationException,
               AssertionException, ObjectNotFoundException {

        OnlineUser onlineUser = userManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();

        int memberID = onlineUser.getMemberID();

        // primary key column(s)
        int watchID = ParamUtil.getParameterInt(request, "watch");

        WatchBean watchBean = WatchWebHelper.getWatch(watchID);

        // check if the watch is owned by the current member
        if (watchBean.getMemberID() != memberID) {
            throw new BadInputException("Cannot delete watch: this watch is not owned by the current member.");
        }

        //now delete the watch
        WatchWebHelper.deleteWatch(watchID);
    }
}
