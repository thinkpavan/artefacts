/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/GeneralAdminTasksWebHandler.java,v 1.16 2003/10/05 09:51:44 imanic Exp $
 * $Author: imanic $
 * $Revision: 1.16 $
 * $Date: 2003/10/05 09:51:44 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 * @author: Igor Manic   imanic@users.sourceforge.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.util.MailUtil;
import net.myvietnam.mvncore.util.ParamUtil;
import net.myvietnam.mvnplugin.mvnforum.auth.*;
import net.myvietnam.mvnplugin.mvnforum.db.CategoryCache;
import net.myvietnam.mvnplugin.mvnforum.db.ForumCache;
import net.myvietnam.mvnplugin.mvnforum.search.PostIndexer;

class GeneralAdminTasksWebHandler {

    private ForumCache        forumCache        = ForumCache.getInstance();
    private CategoryCache     categoryCache     = CategoryCache.getInstance();
    private OnlineUserManager onlineUserManager = OnlineUserManager.getInstance();

    GeneralAdminTasksWebHandler() {
    }

    void prepareShowIndex(HttpServletRequest request)
        throws DatabaseException, AssertionException, AuthenticationException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();
    }

    void prepareTestSystem(HttpServletRequest request)
        throws DatabaseException, AssertionException, AuthenticationException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();
    }

    void prepareImportExport(HttpServletRequest request)
        throws DatabaseException, AssertionException, AuthenticationException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        request.setAttribute("BackupFilesOnServer", ImportWebHandler.getBackupFilesOnServer());
    }

    void importXmlZip(HttpServletRequest request, HttpServletResponse response)
        throws DatabaseException, AssertionException, AuthenticationException, ImportException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        ImportWebHandler.importXmlZip(request, response);
    }

    void exportXmlZip(HttpServletRequest request)
        throws DatabaseException, AssertionException, AuthenticationException, ExportException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        ExportWebHandler.exportXmlZip(request);
    }

    void getExportXmlZip(HttpServletRequest request, HttpServletResponse response)
        throws DatabaseException, AssertionException, AuthenticationException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        ExportWebHandler.getExportXmlZip(request, response);
    }

    void deleteExportXmlZip(HttpServletRequest request)
        throws DatabaseException, AssertionException, AuthenticationException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        ExportWebHandler.deleteExportXmlZip(request);
        //now prepare all for redirection to "/importexport"
        request.setAttribute("BackupFilesOnServer", ImportWebHandler.getBackupFilesOnServer());
    }

    void rebuildIndex(HttpServletRequest request)
        throws DatabaseException, AssertionException, AuthenticationException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        PostIndexer.scheduleRebuildIndexTask();
    }

    void prepareSendMail(HttpServletRequest request)
        throws DatabaseException, AssertionException, AuthenticationException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanSendMail();
    }

    void sendMail(HttpServletRequest request)
        throws BadInputException, javax.mail.MessagingException, DatabaseException,
        AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanSendMail();

        String from    = ParamUtil.getParameterEmail(request, "From");
        String to      = ParamUtil.getParameter(request, "To");
        String cc      = ParamUtil.getParameter(request, "Cc");
        String bcc     = ParamUtil.getParameter(request, "Bcc");
        String subject = ParamUtil.getParameter(request, "Subject", true);
        String message = ParamUtil.getParameter(request, "Message", true);

        if ( (to.length() == 0) && (cc.length() == 0) && (bcc.length() == 0)) {
            throw new BadInputException("Please enter at least To, CC or BCC.");
        }
        MailUtil.sendMail(from, to, cc, bcc, subject, message);
    }

    /*
    void prepareShowAdminHomepage(HttpServletRequest request)
        throws DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureCanAdminSystem();

        int numberOfForums = forumCache.getBeans().size();
        request.setAttribute("NumberOfForums", new Integer(numberOfForums));

        int numberOfCategories = categoryCache.getBeans().size();
        request.setAttribute("NumberOfCategories", new Integer(numberOfCategories));

        int numberOfMembers = MemberWebHelper.getNumberOfMembers(); //virtual guest included
        request.setAttribute("NumberOfMembers", new Integer(numberOfMembers));
    }
    */
}
