/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/auth/OnlineUser.java,v 1.17 2003/11/01 04:40:25 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.17 $
 * $Date: 2003/11/01 04:40:25 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.auth;

import java.sql.Timestamp;
import java.util.Locale;

public interface OnlineUser {

    public int getMemberID();

    public String getMemberName();

    public boolean isGuest();

    public boolean isMember();

    public boolean isInvisibleMember();

    public MVNForumPermission getPermission();

    public void reloadPermission();

    public void reloadProfile();

    public OnlineUserAction getOnlineUserAction();

    public java.util.Date convertGMTDate(java.util.Date gmtDate);

    public Timestamp convertGMTTimestamp(Timestamp gmtTimestamp);

    public String getGMTDateFormat(java.util.Date gmtDate);

    public String getGMTDateFormat(java.util.Date gmtDate, boolean adjustTimeZone);

    public String getGMTTimestampFormat(Timestamp gmtTimestamp);

    public String getGMTTimestampFormat(Timestamp gmtTimestamp, boolean adjustTimeZone);

    public Locale getLocale();

    public String getLocaleName();

    //public boolean getGender();

    //@todo: remove this method from interface
    //public void setLocaleName(String localeName);

    //@todo: remove this method from interface
    //public void setTimeZone(int timeZone);

    public Timestamp getLastLogonTimestamp();

    public int getPostsPerPage();

}