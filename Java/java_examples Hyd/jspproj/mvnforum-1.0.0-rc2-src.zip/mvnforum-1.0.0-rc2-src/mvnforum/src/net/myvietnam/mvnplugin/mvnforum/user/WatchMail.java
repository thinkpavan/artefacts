/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/user/WatchMail.java,v 1.3 2003/05/10 04:03:16 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.3 $
 * $Date: 2003/05/10 04:03:16 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 * @author: Cord         cord_sw@lupinex.com
 */
package net.myvietnam.mvnplugin.mvnforum.user;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.exception.DatabaseException;
import net.myvietnam.mvncore.exception.ObjectNotFoundException;
import net.myvietnam.mvnplugin.mvnforum.db.*;

//@todo: use PrintWriter for the mailContent
class WatchMail {

    // static variable
    private static Log log = LogFactory.getLog(WatchMail.class);

    private ArrayList m_threadList = new ArrayList();
    private StringBuffer m_mailContent = new StringBuffer(4096);
    private DateFormat dateFormat = SimpleDateFormat.getDateTimeInstance(SimpleDateFormat.DEFAULT, SimpleDateFormat.DEFAULT);

    private String m_forumBase = null;
    private Timestamp m_lastSent = null;
    private Timestamp m_now = null;

    WatchMail(String forumBase, Timestamp lastSent, Timestamp now) {
        m_forumBase = forumBase;
        m_lastSent = lastSent;
        m_now = now;
    }

    boolean haveAtLeastOneNewThread() {
        return (m_threadList.size() > 0);
    }

    String getMailContent() {
        return m_mailContent.toString();
    }

    void appendSummary() {
        String watchSummary = getWatchSummary();
        m_mailContent.append(watchSummary);
    }

    void appendWatch(WatchBean watchBean)
        throws ObjectNotFoundException, DatabaseException {

        Timestamp lastSent = watchBean.getWatchLastSentDate();
        int categoryID = watchBean.getCategoryID();
        int forumID = watchBean.getForumID();
        int threadID = watchBean.getThreadID();

        log.debug("appendWatch called!!! c = " + categoryID + " f = " + forumID + " t = " + threadID);

        Collection threadBeans = null;
        if (categoryID != 0) {
            threadBeans = ThreadWebHelper.getBeans_inCategory(categoryID, lastSent);
        } else if (forumID != 0) {
            threadBeans = ThreadWebHelper.getBeans_inForum(forumID, lastSent);
        } else if (threadID != 0) {
            if (shouldProcessThread(threadID)) {
                threadBeans = ThreadWebHelper.getBeans_inThread(threadID, lastSent);
            } else {
                return;//ignore the reduntdant thread
            }
        } else {
            threadBeans = ThreadWebHelper.getBeans(lastSent);
        }

        if (threadBeans.size() == 0) {
            return;// no new thread
        }

        // remember that this WatchMail has process these thread
        rememberThread(threadBeans);

        String watchMessage = getWatchMessage(threadBeans);
        if (watchMessage != null) {
            m_mailContent.append(watchMessage);
        }
    }

    private boolean shouldProcessThread(int threadID) {
        int size = m_threadList.size();
        for (int i = 0; i < size; i++) {
            int currentThreadID = ((Integer)m_threadList.get(i)).intValue();
            if (currentThreadID == threadID) {
                return false;
            }
        }
        return true;
    }

    /**
     * Also remove the redundant thread in this threadBeans
     * @param threadBeans : the threads to remember
     */
    private void rememberThread(Collection threadBeans) {
        Iterator iter = threadBeans.iterator();
        while (iter.hasNext()) {
            int currentThreadID = ((ThreadBean)iter.next()).getThreadID();
            if (shouldProcessThread(currentThreadID)) {
                m_threadList.add(new Integer(currentThreadID));
            } else {
                iter.remove();
            }
        }
    }

    String getWatchSubject() {
        StringBuffer watchSubject = new StringBuffer(128);
        watchSubject.append("[mvnForum] - Mail update from ").append(dateFormat.format(m_lastSent)).append(" to ").append(dateFormat.format(m_now));
        return watchSubject.toString();
    }

    String getWatchSummary() {
        StringBuffer watchSummary = new StringBuffer(1024);
        watchSummary.append("mvnForum Watch Summary\n");
        watchSummary.append("New Threads since: ").append(dateFormat.format(m_lastSent)).append("\n");
        watchSummary.append("Compiled at: ").append(dateFormat.format(m_now)).append("\n");
        watchSummary.append("---------------------------------------\n");
        watchSummary.append("For the latest Forum updates, visit : ").append(m_forumBase).append("/index\n");
        watchSummary.append("---------------------------------------\n");
        return watchSummary.toString();
    }

    protected String getWatchMessage(Collection threadBeans)
        throws DatabaseException, ObjectNotFoundException {

        // now, has at least one new thread, then we get the mail content
        StringBuffer mailContent = new StringBuffer(1024);
        Iterator iterator = threadBeans.iterator();
        int lastForumID = -1;//init it to a not existed forumID
        while (iterator.hasNext()) {
            ThreadBean thread = (ThreadBean)iterator.next();

            // if move to a new forum, then we print the summary of category and forum
            if (thread.getForumID() != lastForumID) {
                lastForumID = thread.getForumID();
                ForumBean forumBean = ForumCache.getInstance().getBean(lastForumID);
                CategoryBean categoryBean = CategoryCache.getInstance().getBean(forumBean.getCategoryID());
                String forumName = forumBean.getForumName();
                String categoryName = categoryBean.getCategoryName();
                mailContent.append("[Category: ").append(categoryName).append("] ").append("[Forum: ").append(forumName).append("]\n");
            }

            //finally, print the thread content
            mailContent.append("    Thread [").append(thread.getThreadTopic()).append("] given to us by ").append(thread.getMemberName()).append("\n");
            mailContent.append("      last posted by ").append(thread.getLastPostMemberName()).append(" on ").append(dateFormat.format(thread.getThreadLastPostDate())).append("\n");
            mailContent.append("      ").append(m_forumBase).append("/viewthread?thread=").append(thread.getThreadID()).append("\n");
            mailContent.append("\n");
        }
        return mailContent.toString();
    }
}