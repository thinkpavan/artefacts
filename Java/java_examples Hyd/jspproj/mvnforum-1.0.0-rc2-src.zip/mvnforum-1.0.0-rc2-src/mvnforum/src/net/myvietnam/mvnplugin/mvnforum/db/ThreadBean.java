/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/db/ThreadBean.java,v 1.6 2003/09/14 14:15:39 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.6 $
 * $Date: 2003/09/14 14:15:39 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.db;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Iterator;

import net.myvietnam.mvncore.util.StringUtil;

/*
 * Included columns: ThreadID, ForumID, MemberName, LastPostMemberName, ThreadTopic,
 *                   ThreadBody, ThreadVoteCount, ThreadVoteTotalStars, ThreadCreationDate, ThreadLastPostDate,
 *                   ThreadType, ThreadOption, ThreadStatus, ThreadHasPoll, ThreadViewCount,
 *                   ThreadReplyCount, ThreadIcon, ThreadDuration
 * Excluded columns:
 */
public class ThreadBean {
    private int threadID;
    private int forumID;
    private String memberName;
    private String lastPostMemberName;
    private String threadTopic;
    private String threadBody;
    private int threadVoteCount;
    private int threadVoteTotalStars;
    private Timestamp threadCreationDate;
    private Timestamp threadLastPostDate;
    private int threadType;
    private int threadOption;
    private int threadStatus;
    private int threadHasPoll;
    private int threadViewCount;
    private int threadReplyCount;
    private String threadIcon;
    private int threadDuration;

    public int getThreadID() {
        return threadID;
    }
    public void setThreadID(int threadID) {
        this.threadID = threadID;
    }

    public int getForumID() {
        return forumID;
    }
    public void setForumID(int forumID) {
        this.forumID = forumID;
    }

    public String getMemberName() {
        return memberName;
    }
    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getLastPostMemberName() {
        return lastPostMemberName;
    }
    public void setLastPostMemberName(String lastPostMemberName) {
        this.lastPostMemberName = lastPostMemberName;
    }

    public String getThreadTopic() {
        return threadTopic;
    }
    public void setThreadTopic(String threadTopic) {
        this.threadTopic = threadTopic;
    }

    public String getThreadBody() {
        return threadBody;
    }
    public void setThreadBody(String threadBody) {
        this.threadBody = threadBody;
    }

    public int getThreadVoteCount() {
        return threadVoteCount;
    }
    public void setThreadVoteCount(int threadVoteCount) {
        this.threadVoteCount = threadVoteCount;
    }

    public int getThreadVoteTotalStars() {
        return threadVoteTotalStars;
    }
    public void setThreadVoteTotalStars(int threadVoteTotalStars) {
        this.threadVoteTotalStars = threadVoteTotalStars;
    }

    public Timestamp getThreadCreationDate() {
        return threadCreationDate;
    }
    public void setThreadCreationDate(Timestamp threadCreationDate) {
        this.threadCreationDate = threadCreationDate;
    }

    public Timestamp getThreadLastPostDate() {
        return threadLastPostDate;
    }
    public void setThreadLastPostDate(Timestamp threadLastPostDate) {
        this.threadLastPostDate = threadLastPostDate;
    }

    public int getThreadType() {
        return threadType;
    }
    public void setThreadType(int threadType) {
        this.threadType = threadType;
    }

    public int getThreadOption() {
        return threadOption;
    }
    public void setThreadOption(int threadOption) {
        this.threadOption = threadOption;
    }

    public int getThreadStatus() {
        return threadStatus;
    }
    public void setThreadStatus(int threadStatus) {
        this.threadStatus = threadStatus;
    }

    public int getThreadHasPoll() {
        return threadHasPoll;
    }
    public void setThreadHasPoll(int threadHasPoll) {
        this.threadHasPoll = threadHasPoll;
    }

    public int getThreadViewCount() {
        return threadViewCount;
    }
    public void setThreadViewCount(int threadViewCount) {
        this.threadViewCount = threadViewCount;
    }

    public int getThreadReplyCount() {
        return threadReplyCount;
    }
    public void setThreadReplyCount(int threadReplyCount) {
        this.threadReplyCount = threadReplyCount;
    }

    public String getThreadIcon() {
        return threadIcon;
    }
    public void setThreadIcon(String threadIcon) {
        this.threadIcon = StringUtil.getEmptyStringIfNull(threadIcon);
    }

    public int getThreadDuration() {
        return threadDuration;
    }
    public void setThreadDuration(int threadDuration) {
        this.threadDuration = threadDuration;
    }

    public String getXML() {
        StringBuffer xml = new StringBuffer(1024);
        xml.append("<ThreadSection>\n");
        xml.append("  <Rows>\n");
        xml.append("    <Row>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ForumID</Name>\n");
        xml.append("        <Value>").append(String.valueOf(forumID)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>MemberName</Name>\n");
        xml.append("        <Value>").append(String.valueOf(memberName)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>LastPostMemberName</Name>\n");
        xml.append("        <Value>").append(String.valueOf(lastPostMemberName)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadTopic</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadTopic)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadBody</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadBody)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadVoteCount</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadVoteCount)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadVoteTotalStars</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadVoteTotalStars)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadCreationDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadCreationDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadLastPostDate</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadLastPostDate)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadType</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadType)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadOption</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadOption)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadStatus</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadStatus)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadHasPoll</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadHasPoll)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadViewCount</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadViewCount)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadReplyCount</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadReplyCount)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadIcon</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadIcon)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("      <Column>\n");
        xml.append("        <Name>ThreadDuration</Name>\n");
        xml.append("        <Value>").append(String.valueOf(threadDuration)).append("</Value>\n");
        xml.append("      </Column>\n");
        xml.append("    </Row>\n");
        xml.append("  </Rows>\n");
        xml.append("</ThreadSection>\n");
        return xml.toString();
    }

    public static String getXML(Collection objThreadBeans) {
        StringBuffer xml = new StringBuffer(1024);
        Iterator iterator = objThreadBeans.iterator();
        xml.append("<ThreadSection>\n");
        xml.append("  <Rows>\n");
        while (iterator.hasNext()) {
            ThreadBean objThreadBean = (ThreadBean)iterator.next();
            xml.append("    <Row>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.threadID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ForumID</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.forumID)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>MemberName</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.memberName)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>LastPostMemberName</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.lastPostMemberName)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadTopic</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.threadTopic)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadBody</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.threadBody)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadVoteCount</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.threadVoteCount)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadVoteTotalStars</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.threadVoteTotalStars)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadCreationDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.threadCreationDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadLastPostDate</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.threadLastPostDate)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadType</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.threadType)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadOption</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.threadOption)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadStatus</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.threadStatus)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadHasPoll</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.threadHasPoll)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadViewCount</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.threadViewCount)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadReplyCount</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.threadReplyCount)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadIcon</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.threadIcon)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("      <Column>\n");
            xml.append("        <Name>ThreadDuration</Name>\n");
            xml.append("        <Value>").append(String.valueOf(objThreadBean.threadDuration)).append("</Value>\n");
            xml.append("      </Column>\n");
            xml.append("    </Row>\n");
        }//while
        xml.append("  </Rows>\n");
        xml.append("</ThreadSection>\n");
        return xml.toString();
    }
} //end of class ThreadBean
