/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/user/UserModuleProcessor.java,v 1.39 2003/10/28 19:20:49 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.39 $
 * $Date: 2003/10/28 19:20:49 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.user;

import java.io.IOException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.util.ParamUtil;
import net.myvietnam.mvncore.util.StringUtil;
import net.myvietnam.mvnplugin.mvnforum.URLMap;
import net.myvietnam.mvnplugin.mvnforum.auth.*;

public class UserModuleProcessor {

    private static Log log = LogFactory.getLog(UserModuleProcessor.class);

    private final String ORIGINAL_REQUEST = "mvnforum.user.OriginalRequest";

    private HttpServlet     mainServlet     = null;
    private ServletContext  servletContext  = null;

    private UserModuleURLMapHandler  urlMapHandler            = new UserModuleURLMapHandler();
    private ForumWebHandler          forumWebHandler          = new ForumWebHandler();
    private ThreadWebHandler         threadWebHandler         = new ThreadWebHandler();
    private PostWebHandler           postWebHandler           = new PostWebHandler();
    private AttachmentWebHandler     attachmentWebHandler     = new AttachmentWebHandler();
    private MemberWebHandler         memberWebHandler         = new MemberWebHandler();
    private WatchWebHandler          watchWebHandler          = new WatchWebHandler();
    private FavoriteThreadWebHandler favoriteThreadWebHandler = new FavoriteThreadWebHandler();
    private OnlineUserManager        onlineUserManager        = OnlineUserManager.getInstance();

    public UserModuleProcessor(HttpServlet servlet) {
        mainServlet     = servlet;
        servletContext  = servlet.getServletContext();
    }

    public String process(HttpServletRequest request, HttpServletResponse response)
        throws IOException, ServletException {

        long start = 0;
        String requestURI = StringUtil.getEmptyStringIfNull(request.getPathInfo());
        String responseURI = null;
        OnlineUser onlineUser = null;
        if (log.isDebugEnabled()) {
            start = System.currentTimeMillis();
            log.debug("UserModuleProcessor : requestURI  = " + requestURI);
        }

        // step 1: some command need to be processed before we do the URI mapping (of the MODAL)
        // MODAL processing
        try {
            onlineUser = onlineUserManager.getOnlineUser(request);
            if (requestURI.equals("/index")) {
                forumWebHandler.prepareList(request, requestURI);//no permission
            } else if (requestURI.equals("/listforums")) {
                forumWebHandler.prepareList(request, requestURI);//no permission
            } else if (requestURI.equals("/listthreads")) {
                threadWebHandler.prepareList_limit(request);
            } else if (requestURI.equals("/listrecentthreads")) {
                threadWebHandler.prepareListRecentThreads_limit(request);//no permission
            } else if (requestURI.equals("/viewthread")) {
                postWebHandler.listPosts_inThread(request);
            } else if (requestURI.equals("/printthread")) {
                postWebHandler.listPosts_inThread(request);

            } else if (requestURI.equals("/deletethread")) {
                threadWebHandler.prepareDelete(request);
            } else if (requestURI.equals("/deletethreadprocess")) {
                threadWebHandler.processDelete(request);

            } else if (requestURI.equals("/movethread")) {
                threadWebHandler.prepareMoveThread(request);
            } else if (requestURI.equals("/movethreadprocess")) {
                threadWebHandler.processMoveThread(request);

            } else if (requestURI.equals("/addpost")) {
                postWebHandler.prepareAdd(request);
            } else if (requestURI.equals("/addpostprocess")) {
                postWebHandler.processAdd(request);
            } else if (requestURI.equals("/editpost")) {
                postWebHandler.prepareEdit(request);
            } else if (requestURI.equals("/updatepost")) {
                postWebHandler.processUpdate(request);
            } else if (requestURI.equals("/printpost")) {
                postWebHandler.preparePrintPost(request);
            } else if (requestURI.equals("/deletepost")) {
                postWebHandler.prepareDelete(request);
            } else if (requestURI.equals("/deletepostprocess")) {
                postWebHandler.processDelete(request);
            } else if (requestURI.equals("/deleteownpost")) {
                postWebHandler.prepareOwnDelete(request);
            } else if (requestURI.equals("/deleteownpostprocess")) {
                postWebHandler.processOwnDelete(request);

            } else if (requestURI.equals("/addattachment")) {
                attachmentWebHandler.prepareAdd(request);
            } else if (requestURI.equals("/addattachmentprocess")) {
                attachmentWebHandler.processAdd(mainServlet.getServletConfig(), request);
            } else if (requestURI.equals("/getattachment")) {
                attachmentWebHandler.downloadAttachment(request, response);
                return null;//download attachment, no further process is needed
            } else if (requestURI.equals("/deleteattachment")) {
                attachmentWebHandler.prepareDelete(request);
            } else if (requestURI.equals("/deleteattachmentprocess")) {
                attachmentWebHandler.processDelete(request);

            } else if (requestURI.equals("/myfavoritethread")) {
                threadWebHandler.prepareList_inFavorite(request);
            } else if (requestURI.equals("/addfavoritethreadprocess")) {
                favoriteThreadWebHandler.processAdd(request);
            } else if (requestURI.equals("/deletefavoritethreadprocess")) {
                favoriteThreadWebHandler.processDelete(request);

            } else if (requestURI.equals("/registermemberprocess")) {
                memberWebHandler.processAdd(request);// no permission
            } else if (requestURI.equals("/viewmember")) {
                memberWebHandler.prepareView_forPublic(request);// no permission
            } else if (requestURI.equals("/listmembers")) {
                memberWebHandler.prepareListMembers_forPublic(request);// no permission
            } else if (requestURI.equals("/editmember")) {
                memberWebHandler.prepareEdit_forCurrentMember(request);
            } else if (requestURI.equals("/updatemember")) {
                memberWebHandler.processUpdate(request);
            } else if (requestURI.equals("/myprofile")) {
                memberWebHandler.prepareView_forCurrentMember(request);
            } else if (requestURI.equals("/changepassword")) {
                onlineUser.getPermission().ensureIsAuthenticated();// check if login
            } else if (requestURI.equals("/changepasswordprocess")) {
                memberWebHandler.processUpdatePassword(request);
            } else if (requestURI.equals("/changeemail")) {
                memberWebHandler.prepareEditEmail(request);
            } else if (requestURI.equals("/changeemailprocess")) {
                memberWebHandler.processUpdateEmail(request);
            } else if (requestURI.equals("/changesignature")) {
                memberWebHandler.prepareEditSignature(request);
            } else if (requestURI.equals("/changesignatureprocess")) {
                memberWebHandler.processUpdateSignature(request);
            } else if (requestURI.equals("/changeavatar")) {
                memberWebHandler.prepareEditAvatar(request);
            } else if (requestURI.equals("/uploadavatar")) {
                memberWebHandler.uploadAvatar(mainServlet.getServletConfig(), request);
            } else if (requestURI.equals("/updateavatar")) {
                memberWebHandler.updateMemberAvatar(servletContext, request);
            } else if (requestURI.equals("/mywatch")) {
                watchWebHandler.prepareList(request);
            } else if (requestURI.equals("/addwatch")) {
                watchWebHandler.prepareAdd(request);
            } else if (requestURI.equals("/addwatchprocess")) {
                watchWebHandler.processAdd(request);
            } else if (requestURI.equals("/deletewatchprocess")) {
                watchWebHandler.processDelete(request);

            } else if (requestURI.equals("/searchprocess")) {
                postWebHandler.processSearch(request);
            } else if (requestURI.equals("/rss")) {
                threadWebHandler.prepareListRSS(request);

            } else if (requestURI.equals("/forgotpasswordprocess")) {
                memberWebHandler.forgotPassword(request);//no permission
            } else if (requestURI.equals("/resetpasswordprocess")) {
                memberWebHandler.resetPassword(request);//no permission

            } else if (requestURI.equals("/sendactivationcodeprocess")) {
                memberWebHandler.sendActivateCode(request);//no permission
            } else if (requestURI.equals("/activatememberprocess")) {
                memberWebHandler.activateMember(request);//no permission

            } else if (requestURI.equals("/listonlineusers")) {
                // This will ensure removing all time-out users (if there is)
                onlineUserManager.getOnlineUser(request);

                // the following 2 lines fix the bug that no online user found in the first time request
                Action action = new ActionInUserModule(request, requestURI);// may throw MissingURLMapEntryException
                onlineUserManager.updateOnlineUserAction(request, action);

                // now set the attribute
                request.setAttribute("OnlineUserActions", onlineUserManager.getOnlineUserActions(0/*default*/));// no permission

            } else if (requestURI.equals("/loginprocess")) {
                onlineUserManager.processLogin(request, response);
                String originalRequest = ParamUtil.getAttribute(request.getSession(), ORIGINAL_REQUEST);
                if (originalRequest.length() > 0) {
                    request.getSession().setAttribute(ORIGINAL_REQUEST, "");
                    responseURI = originalRequest;
                }
            } else if (requestURI.equals("/logout")) {
                onlineUserManager.logout(request, response);
                request.setAttribute("Reason", "Logout successfully.");
            } else if (requestURI.equals("/deletecookieprocess")) {
                onlineUserManager.deleteCookie(request, response);
            }
        } catch (AuthenticationException e) {
            // make sure not from login page, we cannot set original request in this situation
            // and also make sure the request's method must be GET to set the OriginalRequest
            boolean shouldSaveOriginalRequest = (e.getReason()==NotLoginException.NOT_LOGIN) || (e.getReason()==NotLoginException.NOT_ENOUGH_RIGHTS);
            if (shouldSaveOriginalRequest && (request.getMethod().equals("GET"))) {
                String url = UserModuleConfig.URL_PATTERN + requestURI + "?" + StringUtil.getEmptyStringIfNull(request.getQueryString());
                request.getSession().setAttribute(ORIGINAL_REQUEST, url);
            }
            requestURI = "/login";
            request.setAttribute("Reason", e.getReasonExplanation());
        } catch (Exception e) {
            if (e instanceof BadInputException) {
                // we log in WARN level if this is the exception from user input
                log.warn("Exception in UserModuleProcessor e = " + e.getMessage(), e);
            } else {
                log.error("Exception in UserModuleProcessor e = " + e.getMessage(), e);
            }
            requestURI = "/error";
            String message = StringUtil.getEmptyStringIfNull(e.getMessage());
            if (message.length() == 0) {
                message = e.getClass().getName();
            }
            request.getSession().setAttribute("ErrorMessage", message);
        }

        // step 2: map the URI (of the CONTROLLER)
        try {
            // NOTE 1:  there is one situation when responseURI != null (after login successfully for the first time),
            //          but since it will make a NEW request via sendRedirect, so we dont count
            // NOTE 2:  there are 2 situation when requestURI is different from the original requestURI
            //          that is /login and /error, because of this so we must pass the requestURI
            /* @todo Could below the MapHandler ??? */
            Action action = new ActionInUserModule(request, requestURI);// may throw MissingURLMapEntryException
            onlineUserManager.updateOnlineUserAction(request, action);

            // now updateOnlineUserAction is ok, we go ahead
            if (responseURI == null) {
                URLMap map = urlMapHandler.getMap(requestURI, request, onlineUser.getLocaleName());
                responseURI = map.getResponse();
            }// if
        } catch (MissingURLMapEntryException e) {
            log.error("Exception: missing urlmap entry in forum module: requestURI = " + requestURI);
            responseURI = "/mvnplugin/mvnforum/user/error.jsp";
            request.getSession().setAttribute("ErrorMessage", e.getMessage());
        } catch (Exception e) {
            // This will catch AuthenticationException, AssertionException, DatabaseException
            // in the method onlineUserManager.updateOnlineUserAction(request, action)
            responseURI = "/mvnplugin/mvnforum/user/error.jsp";
            request.getSession().setAttribute("ErrorMessage", e.getMessage());
        }

        // step 3: forward or dispatch to the VIEW
        if (log.isDebugEnabled()) {
            long duration = System.currentTimeMillis() - start;
            log.debug("UserModuleProcessor : responseURI = " + responseURI + ". (" + duration + " ms)\n");
        }

        return responseURI;
/*
        if (responseURI.endsWith(".jsp")) {
            servletContext.getRequestDispatcher(responseURI).forward(request, response);
        } else {
            response.sendRedirect(ParamUtil.getContextPath() + responseURI);
        }*/
    }
}
