/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/user/AttachmentWebHandler.java,v 1.21 2003/10/22 19:22:36 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.21 $
 * $Date: 2003/10/22 19:22:36 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.user;

import java.io.*;
import java.sql.Timestamp;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.fileupload.*;
import net.myvietnam.mvncore.filter.DisableHtmlTagFilter;
import net.myvietnam.mvncore.util.*;
import net.myvietnam.mvnplugin.mvnforum.MVNForumConfig;
import net.myvietnam.mvnplugin.mvnforum.MVNForumConstant;
import net.myvietnam.mvnplugin.mvnforum.ManagerFactory;
import net.myvietnam.mvnplugin.mvnforum.auth.*;
import net.myvietnam.mvnplugin.mvnforum.common.AttachmentUtil;
import net.myvietnam.mvnplugin.mvnforum.db.AttachmentBean;
import net.myvietnam.mvnplugin.mvnforum.db.PostBean;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

class AttachmentWebHandler {

    private static Log log = LogFactory.getLog(AttachmentWebHandler.class);

    private OnlineUserManager userManager = OnlineUserManager.getInstance();

    AttachmentWebHandler() {
    }

    public void prepareAdd(HttpServletRequest request)
        throws BadInputException, DatabaseException, ObjectNotFoundException,
        AuthenticationException, AssertionException {

        if (MVNForumConfig.getEnableAttachment() == false) {
            throw new AssertionException("Cannot add Attachment because Attachment feature is disabled.");
        }

        OnlineUser onlineUser = userManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        /* was: permission.ensureIsAuthenticated();
         * That didn't allow guests to add attachments even if admin tried to
         * explicitly allow them to. So, we only need ensureCanAddAttachment(forumID),
         * and the admin will be responsible if he gets flooded (as he has to
         * explicitly allow them that anyway).
         * Same goes for processAdd() method below.
         */

        // primary key column(s)
        int postID  = ParamUtil.getParameterInt(request, "post");

        PostBean postBean = PostWebHelper.getPost(postID);

        int forumID       = postBean.getForumID();
        permission.ensureCanAddAttachment(forumID);

        int logonMemberID = onlineUser.getMemberID();
        int authorID      = postBean.getMemberID();

        // check constraint
        if (permission.canEditPost(forumID)) {//@todo is this the correct permission checking ??? Igor: yes it is
            // have permission, just do nothing, that is dont check the max day contraint
        } else if ( (logonMemberID==authorID) && onlineUser.isMember() ) {
            // same author, but not guest
            Timestamp now = DateUtil.getCurrentGMTTimestamp();
            // check date here, usually must not older than 1 days
            Timestamp postDate = postBean.getPostCreationDate();
            int maxDays = MVNForumConfig.MAX_ATTACH_DAYS;
            if ( (now.getTime() - postDate.getTime()) > (DateUtil.DAY * maxDays) ) {
                /** @todo choose a better Exception here */
                throw new BadInputException("You cannot attach a file to a post which is older than " + maxDays + " days.");
            }
            /** @todo check status of this post */
            /*
            if (postBean.getPostStatus() == ?) {
                throw new BadInputException("Cannot attach a file to disabled post.");
            }*/
        } else {//not an author, so this user must have Edit Permission
            //@todo is this the correct permission checking ??? Igor: yes it is
            permission.ensureCanEditPost(forumID);// this method ALWAYS throws AuthenticationException
        }

        request.setAttribute("PostBean", postBean);
    }

    void processAdd(javax.servlet.ServletConfig config, HttpServletRequest request)
        throws BadInputException, CreateException, DatabaseException, IOException,
        ForeignKeyNotFoundException, AuthenticationException, AssertionException, ObjectNotFoundException {

        if (MVNForumConfig.getEnableAttachment() == false) {
            throw new AssertionException("Cannot add Attachment because Attachment feature is disabled.");
        }

        OnlineUser onlineUser = userManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        /* was: permission.ensureIsAuthenticated();
         * See prepareAdd() method above.
         */

        String tempDir = MVNForumConfig.getTempDir();
        log.debug("AttachmentWebHandler : process upload with temp dir = " + tempDir);

        FileUpload fileUpload = new FileUpload();
        fileUpload.setSizeMax(MVNForumConfig.getMaxAttachmentSize());
        fileUpload.setSizeThreshold(100000);// max memory used = 100K
        fileUpload.setRepositoryPath(tempDir);
        List fileItems;
        try {
            fileItems = fileUpload.parseRequest(request);
        } catch (FileUploadException ex) {
            log.error("Cannot upload", ex);
            throw new IOException("Cannot upload. Detailed reason: " + ex.getMessage());
        }

        // values that must get from the form
        int offset                  = 0;
        int postID                  = 0;
        String attachFilename       = null;
        int attachFileSize          = 0;
        String attachMimeType       = null;
        String attachDesc           = null;

        FileItem attachFileItem = null;
        boolean attachMore = false;
        for (int i = 0; i < fileItems.size(); i++ ) {
            FileItem currentFileItem = (FileItem)fileItems.get(i);
//            System.out.println(
//                "ContentType = " + currentFileItem.getContentType() +
//                " Fieldname = " + currentFileItem.getFieldName() +
//                " Name = " + currentFileItem.getName() +
//                " Size = " + currentFileItem.getSize()
//                //" String = " + currentFileItem.getString()
//                );

            String fieldName = currentFileItem.getFieldName();
            boolean isFormField = currentFileItem.isFormField();
            if (fieldName.equals("offset")) {
                String content = currentFileItem.getString("utf-8");
                offset = Integer.parseInt(content);
                log.debug("offset = " + offset);
            } else if (fieldName.equals("AttachMore")) {
                String content = currentFileItem.getString("utf-8");
                attachMore = (content.length() > 0);
                log.debug("attachMore = " + attachMore);
            } else if (fieldName.equals("PostID")) {
                String content = currentFileItem.getString("utf-8");
                postID = Integer.parseInt(content);
                log.debug("postID = " + postID);
            } else if (fieldName.equals("AttachDesc")) {
                String content = currentFileItem.getString("utf-8");
                attachDesc = DisableHtmlTagFilter.filter(content);
                log.debug("attachDesc = " + attachDesc);
            } else if (fieldName.equals("vnselector")) {
                //ignore
            } else if (fieldName.equals("AttachFilename")) {
                if (currentFileItem.isFormField() == true) {
                    throw new AssertionException("Cannot process uploaded attach file with a form field.");
                }
                attachMimeType = currentFileItem.getContentType();
                attachMimeType = DisableHtmlTagFilter.filter(attachMimeType);
                attachFileSize = (int)currentFileItem.getSize();
                if (attachFileSize == 0) {
                    throw new BadInputException("Cannot process an attach file with size = 0. Please check the file size or check if your file is missing.");
                }
                String fullFilePath = currentFileItem.getName();
                attachFilename = FileUtil.getFileName(fullFilePath);
                attachFilename = DisableHtmlTagFilter.filter(attachFilename);
                log.debug("attachFilename = " + attachFilename);

                // now save to attachFileItem
                attachFileItem = currentFileItem;
            } else {
                throw new AssertionException("Cannot process field name = " + fieldName);
            }
        }
        Timestamp now = DateUtil.getCurrentGMTTimestamp();

        // check constraint
        PostBean postBean = PostWebHelper.getPost(postID);
        int forumID = postBean.getForumID();
        permission.ensureCanAddAttachment(forumID);

        int    logonMemberID    = onlineUser.getMemberID();
        //String logonMemberName  = onlineUser.getMemberName();
        int    authorID         = postBean.getMemberID();

        // check constraint
        if (permission.canEditPost(forumID)) { //@todo is this the correct permission checking ??? Igor: yes it is
            // have permission, just do nothing, that is dont check the max day contraint
        } else if ( (logonMemberID==authorID) && onlineUser.isMember() ) {
            // same author, but not guest
            // check date here, usually must not older than 1 days
            Timestamp postDate = postBean.getPostCreationDate();
            /** @todo config maxDays */
            int maxDays = 1;
            if ( (now.getTime() - postDate.getTime()) > (DateUtil.DAY * maxDays) ) {
                /** @todo choose a better Exception here */
                throw new BadInputException("You cannot attach a file to a post which is older than " + maxDays + " days.");
            }
            /** @todo check status of this post */
            /*
            if (postBean.getPostStatus() == ?) {
                throw new BadInputException("Cannot attach a file to disabled post.");
            }*/
        } else {//not an author, so this user must have Edit Permission
            //@todo is this the correct permission checking ??? Igor: yes it is
            permission.ensureCanEditPost(forumID);// this method ALWAYS throws AuthenticationException
        }

        // now all contraints/permission have been checked
        // values that we can init now
        String attachCreationIP     = request.getRemoteAddr();
        Timestamp attachCreationDate= now;
        Timestamp attachModifiedDate= now;
        int attachDownloadCount     = 0;
        int attachOption            = 0;// check it
        int attachStatus            = 0;// check it

        int attachID = AttachmentWebHelper.createAttachment(postID, logonMemberID, attachFilename,
                                         attachFileSize, attachMimeType, attachDesc,
                                         attachCreationIP, attachCreationDate, attachModifiedDate,
                                         attachDownloadCount, attachOption, attachStatus);

        try {
            String filename = AttachmentUtil.getAttachFilenameOnDisk(attachID);
            log.debug("Attach filename to save to file system = " + filename);
            attachFileItem.write(filename);
        } catch (Exception ex) {
            log.error("Cannot save the attachment file", ex);
            AttachmentWebHelper.deleteAttachment(attachID);
            throw new IOException("Cannot save the attachment file to the file system.");
        }

        // we dont want the exception to throw below this
        int attachCount = AttachmentWebHelper.getNumberOfAttachments_inPost(postID);
        PostWebHelper.updatePostAttachCount(postID, attachCount);

        request.setAttribute("ForumID", String.valueOf(forumID));
        request.setAttribute("ThreadID", String.valueOf(postBean.getThreadID()));
        request.setAttribute("PostID", String.valueOf(postID));
        request.setAttribute("offset", String.valueOf(offset));
        request.setAttribute("AttachMore", new Boolean(attachMore));
    }

    void prepareDelete(HttpServletRequest request)
        throws ObjectNotFoundException, BadInputException, DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = userManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // primary key column(s)
        int attachID = ParamUtil.getParameterInt(request, "attach");

        AttachmentBean attachmentBean = AttachmentWebHelper.getAttachment(attachID);
        int postID = attachmentBean.getPostID();
        PostBean postBean = PostWebHelper.getPost(postID);

        // now, check the permission
        permission.ensureCanDeletePost(postBean.getForumID());

        request.setAttribute("AttachmentBean", attachmentBean);
        request.setAttribute("PostBean", postBean);
    }

    void processDelete(HttpServletRequest request)
        throws BadInputException, DatabaseException, AuthenticationException, AssertionException, ObjectNotFoundException {

        OnlineUser onlineUser = userManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // user must have been authenticated before he can delete
        permission.ensureIsAuthenticated();

        // primary key column(s)
        int attachID = ParamUtil.getParameterInt(request, "attach");

        AttachmentBean attachmentBean = AttachmentWebHelper.getAttachment(attachID);
        int postID = attachmentBean.getPostID();

        PostBean postBean = PostWebHelper.getPost(postID);

        // now, check the permission
        permission.ensureCanDeletePost(postBean.getForumID());

        // now check the password
        try {
        String memberPassword  = ParamUtil.getParameterPassword(request, "MemberMatkhau", 3, 0);
            ManagerFactory.getOnlineUserFactory().validatePassword(onlineUser.getMemberName(),
                                                                   memberPassword, false);
        } catch (AuthenticationException e) {
            throw new BadInputException("You have typed the wrong password. Cannot proceed.");
        }

        // delete in database
        AttachmentWebHelper.deleteAttachment(attachID);

        // delete on disk
        AttachmentUtil.deleteAttachFilenameOnDisk(attachID);

        // we dont want the exception to throw below this
        int attachCount = AttachmentWebHelper.getNumberOfAttachments_inPost(postID);
        PostWebHelper.updatePostAttachCount(postID, attachCount);

        int threadID = postBean.getThreadID();
        request.setAttribute("ThreadID", String.valueOf(threadID));
    }

    /**
     * @todo find a way to cache the file based on the http protocal
     * @todo check permission
     */
    void downloadAttachment(HttpServletRequest request, HttpServletResponse response)
        throws BadInputException, DatabaseException, ObjectNotFoundException, IOException {

        int attachID  = ParamUtil.getParameterInt(request, "attach");
        AttachmentBean attachBean = AttachmentWebHelper.getAttachment(attachID);

        InputStream inputStream = null;
        OutputStream outputStream = null;
        try {
            String attachFilename = AttachmentUtil.getAttachFilenameOnDisk(attachID);
            try {
                inputStream = new FileInputStream(attachFilename);
            } catch (IOException ex) {
                // we dont want to show the filename on file system in the original exception for security
                log.error("Cannot open attach file on file system with attach id = " + attachID, ex);
                throw new IOException("Cannot open attach file on file system with attach id = " + attachID + ". Please report this error to the Web site Administrator.");
            }
            byte[]buffer = FileUtil.getBytes(inputStream);
            inputStream.close();
            inputStream = null;// no close twice

            // we should not call this method after done the outputStream
            // because we dont want exception after download
            AttachmentWebHelper.increaseDownloadCount(attachID);

            outputStream = response.getOutputStream();
            response.setContentType(attachBean.getAttachMimeType());
            response.setHeader("Location", attachBean.getAttachFilename());

                                                //added by Dejan
                                                response.setHeader("Content-Disposition", "attachment; filename=" + attachBean.getAttachFilename());

            //response.setHeader("Location", attachBean.getAttachFilename());
            outputStream.write(buffer);
            outputStream.flush();
            outputStream.close();
            outputStream = null;// no close twice
        } catch (IOException ex) {
            throw ex;
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException ex) { }
            }
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException ex) { }
            }
        }
    }

    /**
     * NOTE: This method should be called before any attemp to delete a post
     * because it require the post is exited
     * After calling this method, go ahead and delete the post
     */
    static void deleteAttachments_inPost(int postID) throws DatabaseException {

        // First, try to delete attachment in database
        Collection attachmentBeans = AttachmentWebHelper.getAttachments_inPost(postID);
        AttachmentWebHelper.deleteAttachments_inPost(postID);

        //now delete files on disk
        for (Iterator iter = attachmentBeans.iterator(); iter.hasNext(); ) {
            AttachmentBean attachmentBean = (AttachmentBean)iter.next();
            AttachmentUtil.deleteAttachFilenameOnDisk(attachmentBean.getAttachID());
        }
    }

    /**
     * NOTE: This method should be called before any attemp to delete a thread
     * because it require the thread is exited
     * After calling this method, go ahead and delete the thread
     */
    static void deleteAttachments_inThread(int threadID) throws DatabaseException {

        // First, try to delete attachment in database
        Collection attachmentBeans = AttachmentWebHelper.getAttachments_inThread(threadID);
        //AttachmentWebHelper.deleteAttachments_inThread(threadID);

        //now delete files on disk
        for (Iterator iter = attachmentBeans.iterator(); iter.hasNext(); ) {
            AttachmentBean attachmentBean = (AttachmentBean)iter.next();
            int attachID = attachmentBean.getAttachID();
            AttachmentUtil.deleteAttachFilenameOnDisk(attachID);
            try {
                AttachmentWebHelper.deleteAttachment(attachID);
            } catch (Exception ex) {
                log.warn("Cannot delete attachment (id = " + attachID + ") in database", ex);
            }
        }
    }

}
