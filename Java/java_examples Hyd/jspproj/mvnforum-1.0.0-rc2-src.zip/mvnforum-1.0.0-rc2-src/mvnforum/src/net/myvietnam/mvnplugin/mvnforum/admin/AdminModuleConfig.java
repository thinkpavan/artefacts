/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/AdminModuleConfig.java,v 1.6 2003/05/10 04:03:14 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.6 $
 * $Date: 2003/05/10 04:03:14 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import java.util.ResourceBundle;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public final class AdminModuleConfig {

    private static Log log = LogFactory.getLog(AdminModuleConfig.class);

    private AdminModuleConfig() {
    }

    private static final String OPTION_FILE_NAME = "mvnplugin_mvnforum_admin_AdminModuleConfig";

    static String URL_PATTERN = "/admin";

    public static String getPathPrefix() {
        return URL_PATTERN;
    }

    static {
        try {
            ResourceBundle res = ResourceBundle.getBundle(OPTION_FILE_NAME);
            URL_PATTERN = res.getString("URL_PATTERN").trim();
        } catch (Exception e) {
            String message = "net.myvietnam.mvnplugin.mvnforum.admin.AdminModuleConfig: Can't read the properties file: '" + OPTION_FILE_NAME + ".properties'. Make sure the file is in your CLASSPATH";
            log.error(message, e);
        }
    }
}