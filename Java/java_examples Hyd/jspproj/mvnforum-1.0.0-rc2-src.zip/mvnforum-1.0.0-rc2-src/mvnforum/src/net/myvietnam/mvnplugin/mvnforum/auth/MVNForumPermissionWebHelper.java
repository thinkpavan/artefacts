/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/auth/MVNForumPermissionWebHelper.java,v 1.19 2003/10/30 19:18:57 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.19 $
 * $Date: 2003/10/30 19:18:57 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.auth;

import java.sql.*;
import java.util.ArrayList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvncore.db.DBUtils;
import net.myvietnam.mvncore.exception.DatabaseException;
import net.myvietnam.mvnplugin.mvnforum.MVNForumConstant;
import net.myvietnam.mvnplugin.mvnforum.db.*;

/** @todo support table prefix */
class MVNForumPermissionWebHelper {

    private static Log log = LogFactory.getLog(MVNForumPermissionWebHelper.class);

    private static final String MemberGroup     = MemberGroupWebHelper.TABLE_NAME;
    private static final String GroupPermission = GroupPermissionWebHelper.TABLE_NAME;
    private static final String GroupForum      = GroupForumWebHelper.TABLE_NAME;
    private static final String MemberPermission= MemberPermissionWebHelper.TABLE_NAME;
    private static final String MemberForum     = MemberForumWebHelper.TABLE_NAME;

    private MVNForumPermissionWebHelper() {
    }

    static ArrayList getMemberPermissions(int memberID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        ArrayList retValue = new ArrayList();
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT DISTINCT Permission");
        sql.append(" FROM ").append(MemberPermission);
        sql.append(" WHERE MemberID = ?");

        //for testing
        //log.debug("getMemberPermissions sql = " + sql.toString());

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Integer perm = new Integer(resultSet.getInt("Permission"));
                retValue.add(perm);
            }
            return retValue;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MVNForumPermissionWebHelper.getMemberPermissions.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    static ArrayList getGroupPermissions(int memberID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        ArrayList retValue = new ArrayList();
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT DISTINCT Permission");
        sql.append(" FROM ").append(GroupPermission).append(", ").append(MemberGroup);
        sql.append(" WHERE ( (").append(GroupPermission).append(".GroupID = ").append(MemberGroup).append(".GroupID) AND (").append(MemberGroup).append(".MemberID = ?) )");
        if ((memberID!=0) && (memberID!=MVNForumConstant.MEMBER_ID_OF_GUEST)) {
            sql.append(" OR ").append(GroupPermission).append(".GroupID = ").append(MVNForumConstant.GROUP_ID_OF_REGISTERED_MEMBERS);
        }

        //for testing
        //log.debug("getGroupPermissions sql = " + sql.toString());

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Integer perm = new Integer(resultSet.getInt("Permission"));
                retValue.add(perm);
            }
            return retValue;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MVNForumPermissionWebHelper.getGroupPermissions.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    static ArrayList getMemberPermissionsInForums(int memberID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        ArrayList retValue = new ArrayList();
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT DISTINCT ForumID, Permission");
        sql.append(" FROM ").append(MemberForum);
        sql.append(" WHERE MemberID = ?");

        //for testing
        //log.debug("getMemberPermissionsInForums sql = " + sql.toString());

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                ForumPermission forumPermission = new ForumPermission();
                forumPermission.setForumID(resultSet.getInt("ForumID"));
                forumPermission.setPermission(resultSet.getInt("Permission"));
                retValue.add(forumPermission);
            }
            return retValue;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MVNForumPermissionWebHelper.getMemberPermissionsInForums.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    static ArrayList getGroupPermissionsInForums(int memberID)
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        ArrayList retValue = new ArrayList();
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT DISTINCT ForumID, Permission");// belong to table GroupForum
        sql.append(" FROM ").append(GroupForum).append(", ").append(MemberGroup);
        sql.append(" WHERE ( (").append(GroupForum).append(".GroupID = ").append(MemberGroup).append(".GroupID) AND (").append(MemberGroup).append(".MemberID = ?) )");
        if ((memberID!=0) && (memberID!=MVNForumConstant.MEMBER_ID_OF_GUEST)) {
            sql.append(" OR ").append(GroupForum).append(".GroupID = ").append(MVNForumConstant.GROUP_ID_OF_REGISTERED_MEMBERS);
        }

        //for testing
        //log.debug("getGroupPermissionsInForums sql = " + sql.toString());

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            statement.setInt(1, memberID);
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                ForumPermission forumPermission = new ForumPermission();
                forumPermission.setForumID(resultSet.getInt("ForumID"));
                forumPermission.setPermission(resultSet.getInt("Permission"));
                retValue.add(forumPermission);
            }
            return retValue;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MVNForumPermissionWebHelper.getGroupPermissionsInForums.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    static ArrayList getPermissionsForGroupGuest()
        throws DatabaseException {

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        ArrayList retValue = new ArrayList();
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT Permission");
        sql.append(" FROM ").append(GroupPermission);
        sql.append(" WHERE GroupID = ").append(MVNForumConstant.GROUP_ID_OF_GUEST);
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Integer perm = new Integer(resultSet.getInt("Permission"));
                retValue.add(perm);
            }
            return retValue;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MVNForumPermissionWebHelper.getPermissionsForGroupGuest.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

    static ArrayList getPermissionsForGroupGuestInForums()
        throws DatabaseException {

        ArrayList retValue = new ArrayList();//getMemberPermissionsInForums(MVNForumConstant.MEMBER_ID_OF_GUEST);

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        StringBuffer sql = new StringBuffer(512);
        sql.append("SELECT ForumID, Permission");
        sql.append(" FROM ").append(GroupForum);
        sql.append(" WHERE GroupID = ").append(MVNForumConstant.GROUP_ID_OF_GUEST);

        //for testing
        //log.debug("getPermissionsForGroupGuestInForums sql = " + sql.toString());

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement(sql.toString());
            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                ForumPermission forumPermission = new ForumPermission();
                forumPermission.setForumID(resultSet.getInt("ForumID"));
                forumPermission.setPermission(resultSet.getInt("Permission"));
                retValue.add(forumPermission);
            }
            return retValue;
        } catch(SQLException sqle) {
            log.error("Sql Execution Error!", sqle);
            throw new DatabaseException("Error executing SQL in MVNForumPermissionWebHelper.getPermissionsForGroupGuestInForum.");
        } finally {
            DBUtils.closeResultSet(resultSet);
            DBUtils.closeStatement(statement);
            DBUtils.closeConnection(connection);
        }
    }

}
