/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/user/ActionInUserModule.java,v 1.26 2003/10/15 18:27:19 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.26 $
 * $Date: 2003/10/15 18:27:19 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.user;

import javax.servlet.http.HttpServletRequest;
import net.myvietnam.mvncore.exception.MissingURLMapEntryException;
import net.myvietnam.mvncore.exception.BadInputException;
import net.myvietnam.mvncore.util.StringUtil;
import net.myvietnam.mvncore.util.ParamUtil;
import net.myvietnam.mvnplugin.mvnforum.auth.Action;
import net.myvietnam.mvnplugin.mvnforum.auth.AbstractAction;

public class ActionInUserModule extends AbstractAction implements Action {

    public ActionInUserModule(HttpServletRequest request, String requestURI) throws MissingURLMapEntryException {
//        lastRequestTime = System.currentTimeMillis();
//        firstRequestTime = lastRequestTime;// be very careful
        url  = null;// url may be null after the code below
        desc = null;// but desc is never be null
        // the request SHOULD ONLY be used to get the queryString
        String queryString = StringUtil.getEmptyStringIfNull(request.getQueryString());

        if (requestURI.equals("/error")) {
            desc = "Have an error [N/A]";
        } else if (requestURI.equals("/index") || requestURI.equals("") || requestURI.equals("/")) {
            url = "index";
            desc = "View forum index";
        } else if (requestURI.equals("/listonlineusers")) {
            url = "listonlineusers";
            desc = "View all online users";
        } else if (requestURI.equals("/listforums")) {
            url = "listforums";
            desc = "View list of all forums";
        } else if (requestURI.equals("/listthreads")) {
            url = "listthreads" + "?" + queryString;
            try {
                int forum = ParamUtil.getParameterInt(request, "forum");
                desc = "View list of threads in forum [forum=" + forum + "]";
            } catch (BadInputException ex) {
                desc = "View list of threads in forum";
            }
        } else if (requestURI.equals("/listrecentthreads")) {
            url = "listrecentthreads" + "?" + queryString;
            desc = "View list of recent threads in all forums";

        } else if (requestURI.equals("/addpost")) {
            //url = "addpost";//@todo review and support it later
            desc = "Add new thread or reply to a post [N/A]";// write a better desc here
        } else if (requestURI.equals("/addpostprocess")) {
            desc = "Have just created a new post successfully [N/A]";
        } else if (requestURI.equals("/editpost")) {
            //url = "editpost";
            // maybe we can allow other users to view the post
            desc = "Edit a post. You can click here to view that post [N/A]";
        } else if (requestURI.equals("/updatepost")) {
            // maybe we can allow other users to view the post
            desc = "Have just updated a post successfully. You can click here to view that post [N/A]";
        } else if (requestURI.equals("/addattachment")) {
            desc = "Attach file to a post [N/A]";
        } else if (requestURI.equals("/addattachmentprocess")) {
            desc = "Have just attached a file successfully [N/A]";

        } else if (requestURI.equals("/myfavoritethread")) {
            url = "myfavoritethread";
            desc = "Manage Favorite Threads";
        } else if (requestURI.equals("/addfavoritethreadprocess")) {
            url = "addfavoritethreadprocess" + "?" + queryString;
            desc = "Have just added new Favorite Thread successfully";
        } else if (requestURI.equals("/deletefavoritethreadprocess")) {
            desc = "Have just deleted a thread from Favorite successfully [N/A]";

        } else if (requestURI.equals("/viewthread")) {
            url = "viewthread" + "?" + queryString;
            try {
                int thread = ParamUtil.getParameterInt(request, "thread");
                desc = "View thread [thread=" + thread + "]";
            } catch (BadInputException ex) {
                desc = "View thread";
            }
        } else if (requestURI.equals("/printthread")) {
            url = "printthread" + "?" + queryString;
            try {
                int thread = ParamUtil.getParameterInt(request, "thread");
                desc = "Print thread [thread=" + thread + "]";
            } catch (BadInputException ex) {
                desc = "Print thread";
            }
        } else if (requestURI.equals("/printpost")) {
            url = "printpost" + "?" + queryString;
            try {
                int post = ParamUtil.getParameterInt(request, "post");
                desc = "Print post [post=" + post + "]";
            } catch (BadInputException ex) {
                desc = "Print post";
            }

        } else if (requestURI.equals("/viewmember")) {
            url = "viewmember" + "?" + queryString;
            desc = "View information of member [" + queryString + "]";
        } else if (requestURI.equals("/listmembers")) {
            url = "listmembers" + "?" + queryString;
            desc = "View list of members";
        } else if (requestURI.equals("/editmember")) {
            desc = "Edit his/her own information [N/A]";
        } else if (requestURI.equals("/updatemember")) {
            desc = "Have just updated his/her information successfully [N/A]";
        } else if (requestURI.equals("/login")) {
            url = "login";
            desc = "About to login";
        } else if (requestURI.equals("/loginprocess")) {// will be sendRedirect
            desc = "Have just logged in successfully [N/A]";
        } else if (requestURI.equals("/logout")) {
            desc = "Have just logged out [N/A]";
        } else if (requestURI.equals("/deletecookieprocess")) {
            desc = "Have just deleted cookie successfully [N/A]";
        } else if (requestURI.equals("/rss")) {
            url = "rss" + "?" + queryString;
            desc = "Get RSS Feed";
        } else if (requestURI.equals("/help")) {
            url = "help";
            desc = "View forum help";
        } else if (requestURI.equals("/docs")) {
            url = "docs";
            desc = "View online documentation";
        } else if (requestURI.equals("/faq")) {
            url = "faq";
            desc = "View FAQ";
        } else if (requestURI.equals("/search")) {
            url = "search";
            desc = "Search the forum";
        } else if (requestURI.equals("/searchprocess")) {
            url = "searchprocess" + "?" + queryString;
            desc = "Searching the forum";
        } else if (requestURI.equals("/registermember")) {
            url = "registermember";
            desc = "Sign up to be a member";
        } else if (requestURI.equals("/registermemberprocess")) {
            desc = "Have just signed up successfully [N/A]";
        } else if (requestURI.equals("/myprofile")) {
            desc = "Edit his/her profile [N/A]";
        } else if (requestURI.equals("/changepassword")) {
            desc = "About to change password [N/A]";
        } else if (requestURI.equals("/changepasswordprocess")) {
            desc = "Have just changed password successfully [N/A]";

        } else if (requestURI.equals("/changeemail")) {
            desc = "About to change email [N/A]";
        } else if (requestURI.equals("/changeemailprocess")) {
            desc = "Have just changed email successfully [N/A]";
        } else if (requestURI.equals("/changesignature")) {
            desc = "About to change signature [N/A]";
        } else if (requestURI.equals("/changesignatureprocess")) {
            desc = "Have just changed signature successfully [N/A]";
        } else if (requestURI.equals("/changeavatar")) {
            desc = "About to change/upload avatar [N/A]";
        } else if (requestURI.equals("/uploadavatar")) {
            desc = "Have just uploaded new avatar [N/A]";
        } else if (requestURI.equals("/updateavatar")) {
            desc = "Have just changed avatar from predefined avatars [N/A]";
        } else if (requestURI.equals("/mywatch")) {
            desc = "Manage Watch [N/A]";
        } else if (requestURI.equals("/addwatch")) {
            desc = "Add new Watch [N/A]";
        } else if (requestURI.equals("/addwatchprocess")) {
            desc = "Have just added new Watch [N/A]";
        } else if (requestURI.equals("/deletewatchprocess")) {
            desc = "Have just deleted a Watch [N/A]";

        } else if (requestURI.equals("/deletethread")) {
            desc = "Moderate the forum [N/A]";
        } else if (requestURI.equals("/deletethreadprocess")) {
            desc = "Moderate the forum [N/A]";

        } else if (requestURI.equals("/movethread")) {
            desc = "Moderate the forum [N/A]";
        } else if (requestURI.equals("/movethreadprocess")) {
            desc = "Moderate the forum [N/A]";

        } else if (requestURI.equals("/deletepost")) {
            desc = "Moderate the forum [N/A]";
        } else if (requestURI.equals("/deletepostprocess")) {
            desc = "Moderate the forum [N/A]";
        } else if (requestURI.equals("/deleteownpost")) {
            desc = "Moderate the forum [N/A]";
        } else if (requestURI.equals("/deleteownpostprocess")) {
            desc = "Moderate the forum [N/A]";

        } else if (requestURI.equals("/deleteattachment")) {
            desc = "Moderate the forum [N/A]";
        } else if (requestURI.equals("/deleteattachmentprocess")) {
            desc = "Moderate the forum [N/A]";

        } else if (requestURI.equals("/iforgotpasswords")) {
            url = "iforgotpasswords";
            desc = "Use forgot password functionality";
        } else if (requestURI.equals("/forgotpasswordprocess")) {
            desc = "Have just received password reset via email [N/A]";
        } else if (requestURI.equals("/resetpassword")) {
            url = "resetpassword";
            desc = "Use reset password functionality";
        } else if (requestURI.equals("/resetpasswordprocess")) {
            desc = "Have just resetted password [N/A]";

        } else if (requestURI.equals("/sendactivationcode")) {
            url = "sendactivationcode";
            desc = "Use account activation functionality";
        } else if (requestURI.equals("/sendactivationcodeprocess")) {
            desc = "Have just received account activation via email [N/A]";
        } else if (requestURI.equals("/activatemember")) {
            url = "activatemember";
            desc = "Use account activation functionality";
        } else if (requestURI.equals("/activatememberprocess")) {
            desc = "Have just activated account [N/A]";
        }

        // check that desc is never null
        if (desc == null) {
            String errorMessage = "Cannot find matching entry in OnlineMember for '" + requestURI + "'. Please contact the administrator.";
            throw new MissingURLMapEntryException(errorMessage);
        }
    }
}
