/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/auth/OnlineUserFactoryImpl.java,v 1.11 2003/10/30 19:18:57 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.11 $
 * $Date: 2003/10/30 19:18:57 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.auth;

import java.sql.Timestamp;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.security.Encoder;
import net.myvietnam.mvncore.util.DateUtil;
import net.myvietnam.mvnplugin.mvnforum.MVNForumConfig;
import net.myvietnam.mvnplugin.mvnforum.MVNForumConstant;
import net.myvietnam.mvnplugin.mvnforum.db.MemberBean;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import net.myvietnam.mvnplugin.mvnforum.ManagerFactory;

public class OnlineUserFactoryImpl implements OnlineUserFactory {

    private static Log log = LogFactory.getLog(OnlineUserFactoryImpl.class);

    public OnlineUserFactoryImpl() {
    }

    public OnlineUser getAuthenticatedUser(HttpServletRequest request,
                                           HttpServletResponse response,
                                           String memberName, String password,
                                           boolean isPasswordEncoded)
        throws AuthenticationException, DatabaseException, AssertionException {

        int memberID = 0;
        int timeZone = 0;
        String localeName = "";
        Timestamp lastLogon = null;
        int postsPerPage = 10;

        try {
            memberID = ManagerFactory.getMemberDAO().getMemberIDFromMemberName(memberName);
        } catch (ObjectNotFoundException e) {
            throw new AuthenticationException(NotLoginException.WRONG_NAME);
        } catch (Exception e) {
            log.error("Unexpected error validating user", e);
            /** @todo find a beter one than NotLoginException.NOT_LOGIN */
            throw new AuthenticationException(NotLoginException.NOT_LOGIN);
        }

        try {
            MemberBean memberBean = ManagerFactory.getMemberDAO().getBean_forViewCurrentMember(memberID);

            if (memberBean.getMemberStatus() != MemberBean.MEMBER_STATUS_ENABLE) {
                if (memberID != MVNForumConstant.MEMBER_ID_OF_ADMIN) {// Admin cannot be disabled
                    throw new AuthenticationException(NotLoginException.ACCOUNT_DISABLED);
                }
            }

            if (ManagerFactory.getMemberDAO().getActivateCode(memberID).equals(MemberBean.MEMBER_ACTIVATECODE_ACTIVATED) == false) {
                // not activated
                if (MVNForumConfig.getRequireActivation()) {
                    if (memberID != MVNForumConstant.MEMBER_ID_OF_ADMIN) {// Admin dont have to activate to login
                        throw new AuthenticationException(NotLoginException.NOT_ACTIVATED);
                    }
                }
            }

            if (!validatePassword(memberName, password, isPasswordEncoded)) {
                if (MVNForumConfig.getDisablePasswordlessAuth() || (password.length() > 0) ) {
                    throw new AuthenticationException(NotLoginException.WRONG_PASSWORD);
                }
            }

            timeZone = memberBean.getMemberTimeZone();
            localeName = memberBean.getMemberLanguage();
            lastLogon = memberBean.getMemberLastLogon();
            postsPerPage = memberBean.getMemberPostsPerPage();

            // now we have checked the authentication, then we update the lastlogon date
            Timestamp now = DateUtil.getCurrentGMTTimestamp();
            ManagerFactory.getMemberDAO().updateLastLogon(memberID, now);

            // next, get the correct name from database
            // Eg: if in database the MemberName is "Admin", and user enter "admin"
            // We will convert "admin" to "Admin"
            memberName = memberBean.getMemberName();

            OnlineUserImpl authenticatedUser = new OnlineUserImpl();
            authenticatedUser.getOnlineUserAction().initRemoteAddr_UserAgent(request);
            authenticatedUser.setMemberID(memberID);
            authenticatedUser.setMemberName(memberName);
            authenticatedUser.setTimeZone(timeZone);
            //NOTE: This MUST be the only way to get permission for a member,
            // so we prevent getPermission for one user and set for other user
            // Note: this method might throw AssertionException
            MVNForumPermission permission = MVNForumPermissionFactory.getAuthenticatedPermission(memberID);
            authenticatedUser.setPermission(permission);
            authenticatedUser.setLocaleName(localeName);
            authenticatedUser.setLastLogonTimestamp(lastLogon);
            authenticatedUser.setGender(memberBean.getMemberGender() != 0);
            authenticatedUser.setPostsPerPage(postsPerPage);
            return authenticatedUser;
        } catch (ObjectNotFoundException e) {
            throw new AuthenticationException(NotLoginException.WRONG_NAME);//we dont want this line to happen
        } catch (DatabaseException e) {
            log.error("Unexpected error validating user", e);
            throw new AuthenticationException(NotLoginException.NOT_LOGIN);//we dont want this line to happen
        }
    }

    public OnlineUser getAnonymousUser(HttpServletRequest request)
        throws DatabaseException, AssertionException {

        int memberID = MVNForumConstant.MEMBER_ID_OF_GUEST;
        String memberName = MVNForumConfig.getDefaultGuestName();
        int timeZone = 0;
        String localeName = "";
        Timestamp lastLogon = null;
        int postsPerPage = 10;

        try {
            MemberBean memberBean = ManagerFactory.getMemberDAO().getBean_forViewCurrentMember(memberID);
            if (memberBean.getMemberStatus() != MemberBean.MEMBER_STATUS_ENABLE) {
                //@todo: for now, Guest is always enabled
            }
            memberName = memberBean.getMemberName();
            timeZone = memberBean.getMemberTimeZone();
            localeName = memberBean.getMemberLanguage();
            lastLogon = memberBean.getMemberLastLogon();
            postsPerPage = memberBean.getMemberPostsPerPage();

            //@todo: Should we update LastLogon? I think we should, so we know when we had last guest visiting the site.
            Timestamp now = DateUtil.getCurrentGMTTimestamp();
            ManagerFactory.getMemberDAO().updateLastLogon(memberID, now);

            OnlineUserImpl anonymousUser = new OnlineUserImpl();
            anonymousUser.getOnlineUserAction().initRemoteAddr_UserAgent(request);
            anonymousUser.setMemberID(memberID);
            anonymousUser.setMemberName(memberName);
            anonymousUser.setTimeZone(timeZone);
            MVNForumPermission permission = MVNForumPermissionFactory.getAnonymousPermission();
            anonymousUser.setPermission(permission);
            anonymousUser.setLocaleName(localeName);
            anonymousUser.setLastLogonTimestamp(lastLogon);
            //no gender; anonymousUser.setGender(memberBean.getMemberGender() != 0);
            anonymousUser.setPostsPerPage(postsPerPage);
            return anonymousUser;
        } catch (ObjectNotFoundException e) {
            OnlineUserImpl anonymousUser = new OnlineUserImpl();
            anonymousUser.getOnlineUserAction().initRemoteAddr_UserAgent(request);
            anonymousUser.setMemberID(MVNForumConstant.MEMBER_ID_OF_GUEST);
            anonymousUser.setMemberName(MVNForumConfig.getDefaultGuestName());
            MVNForumPermission permission = MVNForumPermissionFactory.getAnonymousPermission();
            anonymousUser.setPermission(permission);
            anonymousUser.setLocaleName("");
            anonymousUser.setLastLogonTimestamp(new Timestamp(0));
            anonymousUser.setPostsPerPage(10);
            return anonymousUser;
        } catch (DatabaseException e) {
            OnlineUserImpl anonymousUser = new OnlineUserImpl();
            anonymousUser.getOnlineUserAction().initRemoteAddr_UserAgent(request);
            anonymousUser.setMemberID(MVNForumConstant.MEMBER_ID_OF_GUEST);
            anonymousUser.setMemberName(MVNForumConfig.getDefaultGuestName());
            MVNForumPermission permission = MVNForumPermissionFactory.getAnonymousPermission();
            anonymousUser.setPermission(permission);
            anonymousUser.setLocaleName("");
            anonymousUser.setLastLogonTimestamp(new Timestamp(0));
            anonymousUser.setPostsPerPage(10);
            return anonymousUser;
        }
    }

    public void logout(HttpServletRequest request,
                       HttpServletResponse response) {
        //do nothing
    }

    public String getEncodedPassword(String login, String password) {
        return Encoder.getMD5_Base64(password);
    }

    public boolean validatePassword(String loginName, String password, boolean isEncoded)
        throws AuthenticationException {
        try {
            int memberId = ManagerFactory.getMemberDAO().getMemberIDFromMemberName(loginName);
            if ((memberId==0) || (memberId==MVNForumConstant.MEMBER_ID_OF_GUEST)) return true;

            String encodedPassword;
            if (isEncoded) {
                encodedPassword = password;
            } else {
                encodedPassword = getEncodedPassword(loginName, password);
            }

            if (isEncoded && ( password.equals("Remote") || password.equals("Realm") )) {
                return true;
            } else {
                return encodedPassword.equals(ManagerFactory.getMemberDAO().getPassword(memberId));
            }
        } catch (ObjectNotFoundException e) {
            throw new AuthenticationException(NotLoginException.WRONG_NAME);
        } catch (Exception e) {
            /** @todo find a beter one than NotLoginException.NOT_LOGIN */
            throw new AuthenticationException(NotLoginException.NOT_LOGIN);
        }
    }
}
