/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/admin/AttachmentWebHelper.java,v 1.6 2003/09/17 14:59:09 imanic Exp $
 * $Author: imanic $
 * $Revision: 1.6 $
 * $Date: 2003/09/17 14:59:09 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 * @author: Igor Manic   imanic@users.sourceforge.net
 */
package net.myvietnam.mvnplugin.mvnforum.admin;

import java.sql.Timestamp;
import java.util.Collection;

//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;

//import net.myvietnam.mvncore.db.DBUtils; //@todo: uncomment as needed
import net.myvietnam.mvncore.exception.*;

class AttachmentWebHelper extends net.myvietnam.mvnplugin.mvnforum.db.AttachmentWebHelper {

   // private static Log log = LogFactory.getLog(AttachmentWebHelper.class);

   // prevent instantiation and inheritance
   private AttachmentWebHelper() {
   }

   public static int createAttachment(int postID, int memberID, String attachFilename,
                       int attachFileSize, String attachMimeType, String attachDesc,
                       String attachCreationIP, Timestamp attachCreationDate, Timestamp attachModifiedDate,
                       int attachDownloadCount, int attachOption, int attachStatus)
                       throws CreateException, DatabaseException, ForeignKeyNotFoundException, ObjectNotFoundException {

        net.myvietnam.mvnplugin.mvnforum.db.AttachmentWebHelper.create(postID, memberID, attachFilename, attachFileSize, attachMimeType, attachDesc, attachCreationIP, attachCreationDate, attachModifiedDate, attachDownloadCount, attachOption, attachStatus);

       int attachID = 0;
       try {
           attachID = findAttachID(postID, memberID, attachCreationDate);
       } catch (ObjectNotFoundException ex) {
           // Hack the Oracle 9i problem
           Timestamp roundTimestamp = new Timestamp((attachCreationDate.getTime()/1000)*1000);
           attachID = findAttachID(postID, memberID, roundTimestamp);
       }
       return attachID;
   }

    public static void deleteAttachment(int attachID)
        throws DatabaseException, ObjectNotFoundException {
        net.myvietnam.mvnplugin.mvnforum.db.AttachmentWebHelper.delete(attachID);
    }

    public static Collection getAttachments_inForum(int forumID)
        throws DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.AttachmentWebHelper.getBeans_inForum(forumID);
    }
    
    public static int getNumberOfAttachments_inPost(int postID)
        throws AssertionException, DatabaseException {
        return net.myvietnam.mvnplugin.mvnforum.db.AttachmentWebHelper.getNumberOfBeans_inPost(postID);
    }
    
}
