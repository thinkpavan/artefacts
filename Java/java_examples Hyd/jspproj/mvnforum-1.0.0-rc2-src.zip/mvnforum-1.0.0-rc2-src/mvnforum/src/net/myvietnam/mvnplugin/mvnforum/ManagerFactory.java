/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/ManagerFactory.java,v 1.4 2003/09/01 17:42:35 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.4 $
 * $Date: 2003/09/01 17:42:35 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Luis Miguel Hernanz <luish@germinus.com>
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum; // Generated package name

import net.myvietnam.mvnplugin.mvnforum.auth.Authenticator;
import net.myvietnam.mvnplugin.mvnforum.auth.OnlineUserFactory;
import net.myvietnam.mvnplugin.mvnforum.db.MemberDAO;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Instance that returns the right implementation for the different
 * parts of the mvnforum system.
 *
 * @author <a href="luish@germinus.com">Luis Miguel Hernanz</a>
 * @version $Revision: 1.4 $
 */
// @todo : split this class to new class DAOFactory
public class ManagerFactory {

    private static Log log = LogFactory.getLog(ManagerFactory.class);

    /**
     * Creates a new <code>ManagerFactory</code> instance.
     */
    protected ManagerFactory() {}

    private static MemberDAO memberDAO = null;
    private static OnlineUserFactory onlineUserFactory = null;
    private static Authenticator authenticator = null;
    private static RequestProcessor requestProcessor = null;

    public static MemberDAO getMemberDAO() {
        try {
            if (memberDAO == null) {
                Class c = Class.forName(MVNForumFactoryConfig.getMemberManagerClassName());
                memberDAO = (MemberDAO) c.newInstance();
                log.info("memberDAO = " + memberDAO);
            }
            return memberDAO;
        } catch (Exception e) {
            log.error("Error returning the member manager.", e);
            throw new RuntimeException(e.getMessage());
        }
    }

    public static OnlineUserFactory getOnlineUserFactory() {
        try {
            if (onlineUserFactory == null) {
                Class c = Class.forName(MVNForumFactoryConfig.getOnlineUserFactoryClassName());
                onlineUserFactory = (OnlineUserFactory) c.newInstance();
                log.info("onlineUserFactory = " + onlineUserFactory);
            }
            return onlineUserFactory;
        } catch (Exception e) {
            log.error("Error returning the online user factory.", e);
            throw new RuntimeException(e.getMessage());
        }
    }

    public static Authenticator getAuthenticator() {
        try {
            String authenticatorClass = MVNForumFactoryConfig.getAuthenticatorClassName();
            if ((null != authenticatorClass) && !authenticatorClass.trim().equals("")) {
                log.debug("Using the authenticator: " + authenticatorClass);
                if (authenticator == null) {
                    Class c = Class.forName(authenticatorClass);
                    authenticator = (Authenticator) c.newInstance();
                    log.info("authenticator = " + authenticator);
                }
                return authenticator;
            }
        } catch (Exception e){
            log.error("Error getting the authentication object", e);
        }
        return null;
    }

    public static RequestProcessor getRequestProcessor() {
        try {
            if (requestProcessor == null) {
                Class c = Class.forName(MVNForumFactoryConfig.getRequestProcessorClassName());
                requestProcessor = (RequestProcessor) c.newInstance();
                log.info("requestProcessor = " + requestProcessor);
            }
            return requestProcessor;
        } catch (Exception e) {
            // This should never happen
            log.error("Error returning the requestProcessor.", e);
            throw new RuntimeException(e.getMessage());
        }
    }
}
