/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/auth/MVNForumPermissionFactory.java,v 1.12 2003/10/30 19:18:57 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.12 $
 * $Date: 2003/10/30 19:18:57 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.auth;

import java.util.ArrayList;

import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvnplugin.mvnforum.MVNForumConstant;
import net.myvietnam.mvnplugin.mvnforum.ManagerFactory;
import net.myvietnam.mvnplugin.mvnforum.db.MemberBean;

class MVNForumPermissionFactory {

    private MVNForumPermissionFactory() {
    }

    static MVNForumPermission getAnonymousPermission()
        throws DatabaseException, AssertionException {

        MVNForumPermissionImpl permission = new MVNForumPermissionImpl();

        ArrayList permList = MVNForumPermissionWebHelper.getPermissionsForGroupGuest();
        for (int i = 0; i < permList.size(); i++) {
            int perm = ((Integer)permList.get(i)).intValue();
            permission.setPermission(perm);
        }

        ArrayList forumPermList = MVNForumPermissionWebHelper.getPermissionsForGroupGuestInForums();
        for (int i = 0; i < forumPermList.size(); i++) {
            ForumPermission perm = (ForumPermission)forumPermList.get(i);
            permission.setPermissionInForum(perm.getForumID(), perm.getPermission());
        }

        return permission;
    }

    static MVNForumPermission getAuthenticatedPermission(int memberID)
        throws DatabaseException, AssertionException, ObjectNotFoundException {

        if (memberID == MVNForumConstant.MEMBER_ID_OF_GUEST || memberID == 0) {
            throw new AssertionException("Cannot get authenticated permission for user Guest.");
        }

        MVNForumPermissionImpl permission = new MVNForumPermissionImpl();

        ArrayList memberPermList = MVNForumPermissionWebHelper.getMemberPermissions(memberID);
        for (int i = 0; i < memberPermList.size(); i++) {
            int perm = ((Integer)memberPermList.get(i)).intValue();
            permission.setPermission(perm);
        }

        ArrayList groupPermList = MVNForumPermissionWebHelper.getGroupPermissions(memberID);
        for (int i = 0; i < groupPermList.size(); i++) {
            int perm = ((Integer)groupPermList.get(i)).intValue();
            permission.setPermission(perm);
        }

        ArrayList forumMemberPermList = MVNForumPermissionWebHelper.getMemberPermissionsInForums(memberID);
        for (int i = 0; i < forumMemberPermList.size(); i++) {
            ForumPermission perm = (ForumPermission)forumMemberPermList.get(i);
            permission.setPermissionInForum(perm.getForumID(), perm.getPermission());
        }

        ArrayList forumGroupPermList = MVNForumPermissionWebHelper.getGroupPermissionsInForums(memberID);
        for (int i = 0; i < forumGroupPermList.size(); i++) {
            ForumPermission perm = (ForumPermission)forumGroupPermList.get(i);
            permission.setPermissionInForum(perm.getForumID(), perm.getPermission());
        }

        // user after logined always have PERMISSION_AUTHENTICATED
        permission.setPermission(MVNForumPermission.PERMISSION_AUTHENTICATED);

        // now check if user account is activated or not
        if (ManagerFactory.getMemberDAO().getActivateCode(memberID).equals(MemberBean.MEMBER_ACTIVATECODE_ACTIVATED)) {
            permission.setPermission(MVNForumPermission.PERMISSION_ACTIVATED);
        }

        // The Admin (id = 1) always has SystemAdmin permission
        if (memberID == MVNForumConstant.MEMBER_ID_OF_ADMIN) {
            permission.setPermission(MVNForumPermission.PERMISSION_SYSTEM_ADMIN);
        }
        return permission;
    }
}
