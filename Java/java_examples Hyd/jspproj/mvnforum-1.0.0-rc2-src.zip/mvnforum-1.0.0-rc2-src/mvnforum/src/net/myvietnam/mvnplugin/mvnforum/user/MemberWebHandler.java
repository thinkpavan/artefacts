/*
 * $Header: /cvsroot/mvnforum/mvnforum/src/net/myvietnam/mvnplugin/mvnforum/user/MemberWebHandler.java,v 1.39 2003/11/01 04:40:25 minhnn Exp $
 * $Author: minhnn $
 * $Revision: 1.39 $
 * $Date: 2003/11/01 04:40:25 $
 *
 * ====================================================================
 *
 * Copyright (C) 2002, 2003 by MyVietnam.net
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * All copyright notices regarding mvnForum MUST remain intact
 * in the scripts and in the outputted HTML.
 * The "powered by" text/logo with a link back to
 * http://www.mvnForum.com and http://www.MyVietnam.net in the
 * footer of the pages MUST remain visible when the pages
 * are viewed on the internet or intranet.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Support can be obtained from support forums at:
 * http://www.mvnForum.com/mvnforum/index
 *
 * Correspondence and Marketing Questions can be sent to:
 * info@MyVietnam.net
 *
 * @author: Minh Nguyen  minhnn@MyVietnam.net
 * @author: Mai  Nguyen  mai.nh@MyVietnam.net
 */
package net.myvietnam.mvnplugin.mvnforum.user;

import java.io.*;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.List;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import net.myvietnam.mvncore.exception.*;
import net.myvietnam.mvncore.fileupload.*;
import net.myvietnam.mvncore.filter.DisableHtmlTagFilter;
import net.myvietnam.mvncore.security.Encoder;
import net.myvietnam.mvncore.util.*;
import net.myvietnam.mvnplugin.mvnforum.*;
import net.myvietnam.mvnplugin.mvnforum.auth.*;
import net.myvietnam.mvnplugin.mvnforum.db.MemberBean;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

class MemberWebHandler {

    private static Log log = LogFactory.getLog(MemberWebHandler.class);

    private OnlineUserManager onlineUserManager = OnlineUserManager.getInstance();

    MemberWebHandler() {
    }

    void processAdd(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, CreateException,
        DatabaseException, DuplicateKeyException, ForeignKeyNotFoundException, MessagingException {

        Timestamp now = DateUtil.getCurrentGMTTimestamp();

        String memberName           = ParamUtil.getParameterSafe(request, "MemberName", true);// check good name
        /** @todo move to a name filter */
        if ( memberName.equalsIgnoreCase(MVNForumConfig.getDefaultGuestName()) ||
             memberName.equalsIgnoreCase("Guest") ||
             memberName.equalsIgnoreCase("Administrator") ||
             memberName.equalsIgnoreCase("Moderator") ) {
            throw new BadInputException("Cannot register member with a reserved name : " + memberName);
        }
        StringUtil.checkGoodName(memberName);

        String memberPassword1      = ParamUtil.getParameterPassword(request, "MemberMatkhau", 3, 0);
        String memberPassword2      = ParamUtil.getParameterPassword(request, "MemberMatkhauConfirm", 3, 0);
        if (!memberPassword1.equals(memberPassword2)) {
            throw new BadInputException("Password and confirmed password are not the same, please try again.");
        }
        String memberPassword       = Encoder.getMD5_Base64(memberPassword1);

        String memberEmail          = ParamUtil.getParameterEmail(request, "MemberEmail");
        String memberEmailConfirm   = ParamUtil.getParameterEmail(request, "MemberEmailConfirm");
        if (!memberEmail.equals(memberEmailConfirm)) {
            throw new BadInputException("Email and confirmed email are not the same, please try again.");
        }
        String memberFirstEmail     = memberEmail;

        int memberEmailVisible      = ParamUtil.getParameterBoolean(request, "MemberEmailVisible")? 1 : 0;
        int memberNameVisible       = ParamUtil.getParameterBoolean(request, "MemberNameVisible") ? 1 : 0;
        String memberFirstIP        = request.getRemoteAddr();
        String memberLastIP         = memberFirstIP;
        Timestamp memberCreationDate= now;
        Timestamp memberModifiedDate= now;
        Timestamp memberLastLogon   = now;// @todo review and support it later
        int memberOption            = 0;//@todo review and support it later
        int memberStatus            = 0;// @todo review and support it later, ex: should it be active or not?
        String memberActivateCode   = "";// not activated
        int memberMessageOption     = 0;// @todo review and support it later
        int memberPostsPerPage      = ParamUtil.getParameterInt(request, "MemberPostsPerPage", 10);
        if (memberPostsPerPage < 5) {
            memberPostsPerPage = 5;
        }
        String memberTitle          = "";
        int memberTimeZone          = ParamUtil.getParameterTimeZone(request, "MemberTimeZone");
        String memberSkin           = "";
        String memberLanguage       = ParamUtil.getParameterSafe(request, "MemberLanguage", false);
        String memberFirstname      = ParamUtil.getParameterSafe(request, "MemberFirstname", true);
        String memberLastname       = ParamUtil.getParameterSafe(request, "MemberLastname", true);
        int memberGender            = ParamUtil.getParameterBoolean(request, "MemberGender") ? 1 : 0;

        //Date memberBirthday         = ParamUtil.getParameterDate(request, "MemberBirthday");
        Date memberBirthday         = ParamUtil.getParameterDate(request, "day", "month", "year");
        /** @todo : rewrite this code */
        /*
        long nowtime = System.currentTimeMillis();
        long oldest = nowtime - 100*DateUtil.YEAR;
        long youngest = nowtime - 10*DateUtil.YEAR;
        long age = (nowtime - memberBirthday.getTime())/DateUtil.YEAR;
        if (memberBirthday.getTime() > youngest || memberBirthday.getTime() < oldest) {
            log.debug("age = " + age + " date = " + memberBirthday + " gettime = " + memberBirthday.getTime());
            throw new BadInputException("Your age is not allow: " + age);
        }*/

        String memberAddress        = ParamUtil.getParameterSafe(request, "MemberAddress", false);
        String memberCity           = ParamUtil.getParameterSafe(request, "MemberCity", false);
        String memberState          = ParamUtil.getParameterSafe(request, "MemberState", false);
        String memberCountry        = ParamUtil.getParameterSafe(request, "MemberCountry", false);
        String memberPhone          = ParamUtil.getParameterSafe(request, "MemberPhone", false);
        String memberMobile         = ParamUtil.getParameterSafe(request, "MemberMobile", false);
        String memberFax            = ParamUtil.getParameterSafe(request, "MemberFax", false);
        String memberCareer         = ParamUtil.getParameterSafe(request, "MemberCareer", false);
        String memberHomepage       = ParamUtil.getParameterSafe(request, "MemberHomepage", false);
        String memberYahoo          = ParamUtil.getParameterSafe(request, "MemberYahoo", false);
        String memberAol            = ParamUtil.getParameterSafe(request, "MemberAol", false);
        String memberIcq            = ParamUtil.getParameterSafe(request, "MemberIcq", false);
        String memberMsn            = ParamUtil.getParameterSafe(request, "MemberMsn", false);
        String memberCoolLink1      = ParamUtil.getParameterSafe(request, "MemberCoolLink1", false);
        String memberCoolLink2      = ParamUtil.getParameterSafe(request, "MemberCoolLink2", false);

        ManagerFactory.getMemberDAO().create(memberName, memberPassword, memberFirstEmail,
                                   memberEmail, memberEmailVisible, memberNameVisible,
                                   memberFirstIP, memberLastIP, 0/*memberViewCount*/,
                                   0/*memberPostCount*/, memberCreationDate, memberModifiedDate,
                                   memberLastLogon, memberOption, memberStatus,
                                   memberActivateCode, ""/*memberTempPassword*/, 0/*memberMessageCount*/,
                                   memberMessageOption, memberPostsPerPage, 0/*memberWarnCount*/,
                                   0/*memberVoteCount*/, 0/*memberVoteTotalStars*/, 0/*memberRewardPoints*/,
                                   memberTitle, memberTimeZone, ""/*memberSignature*/,
                                   ""/*memberAvatar*/, memberSkin, memberLanguage,
                                   memberFirstname, memberLastname, memberGender,
                                   memberBirthday, memberAddress, memberCity,
                                   memberState, memberCountry, memberPhone,
                                   memberMobile, memberFax, memberCareer,
                                   memberHomepage, memberYahoo, memberAol,
                                   memberIcq, memberMsn, memberCoolLink1,
                                   memberCoolLink2);

        // Now, create 2 default folders for each member
        int memberID = ManagerFactory.getMemberDAO().getMemberIDFromMemberName(memberName);
        MessageFolderWebHelper.createMessageFolder(MVNForumConstant.MESSAGE_FOLDER_INBOX, memberID, 0, now, now);
        MessageFolderWebHelper.createMessageFolder(MVNForumConstant.MESSAGE_FOLDER_SENT, memberID, 0, now, now);

        // now, if require activation, then we will send mail
        if (MVNForumConfig.getRequireActivation() == true) {
            String serverName = ParamUtil.getServer2(request);
            sendActivationCodeEmail(memberID, serverName);
        }
    }

    void processUpdate(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();

        int memberID = onlineUser.getMemberID();

        Timestamp now = DateUtil.getCurrentGMTTimestamp();

        // column(s) to update
        int memberEmailVisible      = ParamUtil.getParameterBoolean(request, "MemberEmailVisible")? 1 : 0;
        int memberNameVisible       = ParamUtil.getParameterBoolean(request, "MemberNameVisible") ? 1 : 0;
        int memberOption            = ParamUtil.getParameterInt(request, "MemberOption");
        int memberStatus            = 0;//@todo review and support it later
        int memberMessageOption     = ParamUtil.getParameterInt(request, "MemberMessageOption");
        int memberPostsPerPage      = ParamUtil.getParameterInt(request, "MemberPostsPerPage");
        if (memberPostsPerPage < 5) {
            memberPostsPerPage = 5;
        }
        int memberTimeZone          = ParamUtil.getParameterTimeZone(request, "MemberTimeZone");
        String memberSkin           = ParamUtil.getParameterSafe(request, "MemberSkin", false);
        String memberLanguage       = ParamUtil.getParameterSafe(request, "MemberLanguage", false);
        String memberFirstname      = ParamUtil.getParameterSafe(request, "MemberFirstname", true);
        String memberLastname       = ParamUtil.getParameterSafe(request, "MemberLastname", true);
        int memberGender            = ParamUtil.getParameterBoolean(request, "MemberGender")? 1 : 0;
        Date memberBirthday         = ParamUtil.getParameterDate(request, "MemberBirthday");
        String memberAddress        = ParamUtil.getParameterSafe(request, "MemberAddress", false);
        String memberCity           = ParamUtil.getParameterSafe(request, "MemberCity", false);
        String memberState          = ParamUtil.getParameterSafe(request, "MemberState", false);
        String memberCountry        = ParamUtil.getParameterSafe(request, "MemberCountry", false);
        String memberPhone          = ParamUtil.getParameterSafe(request, "MemberPhone", false);
        String memberMobile         = ParamUtil.getParameterSafe(request, "MemberMobile", false);
        String memberFax            = ParamUtil.getParameterSafe(request, "MemberFax", false);
        String memberCareer         = ParamUtil.getParameterSafe(request, "MemberCareer", false);
        String memberHomepage       = ParamUtil.getParameterSafe(request, "MemberHomepage", false);
        String memberYahoo          = ParamUtil.getParameterSafe(request, "MemberYahoo", false);
        String memberAol            = ParamUtil.getParameterSafe(request, "MemberAol", false);
        String memberIcq            = ParamUtil.getParameterSafe(request, "MemberIcq", false);
        String memberMsn            = ParamUtil.getParameterSafe(request, "MemberMsn", false);
        String memberCoolLink1      = ParamUtil.getParameterSafe(request, "MemberCoolLink1", false);
        String memberCoolLink2      = ParamUtil.getParameterSafe(request, "MemberCoolLink2", false);

        ManagerFactory.getMemberDAO().update(memberID, // primary key
                               memberEmailVisible, memberNameVisible, now/*memberModifiedDate*/,
                               memberOption, memberStatus, memberMessageOption,
                               memberPostsPerPage, memberTimeZone, memberSkin,
                               memberLanguage, memberFirstname, memberLastname,
                               memberGender, memberBirthday, memberAddress,
                               memberCity, memberState, memberCountry,
                               memberPhone, memberMobile, memberFax,
                               memberCareer, memberHomepage, memberYahoo,
                               memberAol, memberIcq, memberMsn,
                               memberCoolLink1, memberCoolLink2);

        // now, update the new displayed language option
        onlineUser.reloadProfile();
        //onlineUser.setLocaleName(memberLanguage);
        //onlineUser.setTimeZone(memberTimeZone);
    }

    /** @todo: use new method of WebHelper */
    void prepareEditEmail(HttpServletRequest request)
        throws DatabaseException, ObjectNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();

        int memberID = onlineUser.getMemberID();
        MemberBean memberBean   = ManagerFactory.getMemberDAO().getBean_forViewCurrentMember(memberID);
        request.setAttribute("MemberEmail", memberBean.getMemberEmail());
    }

    void processUpdateEmail(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException,
        DuplicateKeyException, AuthenticationException, AssertionException, MessagingException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();

        int memberID = onlineUser.getMemberID();

        // column(s) to update
        String memberEmail          = ParamUtil.getParameterEmail(request, "MemberEmail");
        String memberEmailConfirm   = ParamUtil.getParameterEmail(request, "MemberEmailConfirm");
        String memberMatKhau   = ParamUtil.getParameter(request, "MemberMatkhau",true);

        String encodedPassword      = Encoder.getMD5_Base64(memberMatKhau);
        String currentPassword      = ManagerFactory.getMemberDAO().getPassword(memberID);

        if (!currentPassword.equals(encodedPassword)) {
            throw new BadInputException("You have typed the wrong current password, please try again.");
        }

        if (!memberEmail.equals(memberEmailConfirm)) throw new BadInputException("Email and confirmed email are not the same, please try again.");

        // invalidate the activate status
        ManagerFactory.getMemberDAO().updateActivateCode(memberID, "");

        ManagerFactory.getMemberDAO().updateEmail(memberID, memberEmail);

        // now reload the permission if this online user change email (not activated now)
        onlineUser.reloadPermission();

        // now, if require activation, then we will send mail
        if (MVNForumConfig.getRequireActivation() == true) {
            String serverName = ParamUtil.getServer2(request);
            sendActivationCodeEmail(memberID, serverName);
        }
    }

    void processUpdatePassword(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();

        int memberID = onlineUser.getMemberID();

        // NOTE: that we dont use getParameterPassword here since it will not forward-compatible
        String memberOldPassword    = ParamUtil.getParameter(request, "MemberOldMatkhau", true);
        String oldEncodedPassword   = Encoder.getMD5_Base64(memberOldPassword);
        String currentPassword      = ManagerFactory.getMemberDAO().getPassword(memberID);
        if (!currentPassword.equals(oldEncodedPassword)) {
            throw new BadInputException("You have typed the wrong current password, please try again.");
        }

        // column(s) to update
        String memberPassword1      = ParamUtil.getParameterPassword(request, "MemberMatkhau", 3, 0);
        String memberPassword2      = ParamUtil.getParameterPassword(request, "MemberMatkhauConfirm", 3, 0);
        if (!memberPassword1.equals(memberPassword2)) {
            throw new BadInputException("Password and confirmed password are not the same, please try again.");
        }
        String memberPassword       = Encoder.getMD5_Base64(memberPassword1);

        if (currentPassword.equals(memberPassword)) {
            throw new BadInputException("Old password and new password cannot equal, please try again.");
        }

        ManagerFactory.getMemberDAO().updatePassword(memberID, // primary key
                               memberPassword);
    }

    void prepareView_forCurrentMember(HttpServletRequest request)
        throws DatabaseException, ObjectNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();

        int memberID = onlineUser.getMemberID();
        MemberBean memberBean = ManagerFactory.getMemberDAO().getBean_forViewCurrentMember(memberID);
        request.setAttribute("MemberBean", memberBean);
    }

    void prepareEdit_forCurrentMember(HttpServletRequest request)
        throws DatabaseException, ObjectNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();

        int memberID = onlineUser.getMemberID();
        MemberBean memberBean = ManagerFactory.getMemberDAO().getBean_forEditCurrentMember(memberID);
        request.setAttribute("MemberBean", memberBean);
    }

    /** @todo: use new method of WebHelper */
    void prepareEditSignature(HttpServletRequest request)
        throws DatabaseException, ObjectNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();

        boolean isPreviewing = ParamUtil.getParameterBoolean(request, "preview");
        if (isPreviewing) {
            String signature = ParamUtil.getParameter(request, "MemberSignature");
            request.setAttribute("MemberSignature", signature);
        } else {
            int memberID = onlineUser.getMemberID();
            MemberBean memberBean   = ManagerFactory.getMemberDAO().getBean_forViewCurrentMember(memberID);
            request.setAttribute("MemberSignature", memberBean.getMemberSignature());
        }
    }

    void processUpdateSignature(HttpServletRequest request)
        throws ObjectNotFoundException, DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();

        int memberID = onlineUser.getMemberID();

        // column(s) to update
        String memberSignature      = ParamUtil.getParameter(request, "MemberSignature");
        memberSignature = DisableHtmlTagFilter.filter(memberSignature);

        ManagerFactory.getMemberDAO().updateSignature(memberID, // primary key
                               memberSignature);
    }

    /** @todo: use new method of WebHelper */
    void prepareEditAvatar(HttpServletRequest request)
        throws DatabaseException, ObjectNotFoundException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();
        permission.ensureCanUseAvatar();

        int memberID = onlineUser.getMemberID();
        MemberBean memberBean = ManagerFactory.getMemberDAO().getBean_forViewCurrentMember(memberID);
        request.setAttribute("MemberBean", memberBean);
    }

    /**
     * Change picture from our predefined picture
     * NOTE: this method will delete uploaded image (if any) of the member
     */
    void updateMemberAvatar(javax.servlet.ServletContext context, HttpServletRequest request)
        throws ObjectNotFoundException, DatabaseException, AuthenticationException, AssertionException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();
        permission.ensureCanUseAvatar();

        int memberID        = onlineUser.getMemberID();
        String memberName   = onlineUser.getMemberName();

        // first, we delete uploaded image if there is one
        StringBuffer bufferPicFile = new StringBuffer(128);
        bufferPicFile.append(context.getRealPath(MVNForumGlobal.UPLOADED_AVATAR_DIR));
        bufferPicFile.append(File.separatorChar).append(memberName).append(".jpg");
        String picFile =  bufferPicFile.toString();

        log.trace("Delete avatar = " + picFile);
        log.trace("String length = " + picFile.length());
        File file = new File(picFile);
        file.delete();// we dont need to check the returned value

        // then we update the database with new one
        String memberPicture = ParamUtil.getParameter(request, "MemberAvatar");
        ManagerFactory.getMemberDAO().updateAvatar(memberID, memberPicture);
    }

    /**
     * upload user own avatar
     */
    void uploadAvatar(javax.servlet.ServletConfig config, HttpServletRequest request)
        throws BadInputException, AuthenticationException, IOException,
        AssertionException, ObjectNotFoundException, DatabaseException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();
        permission.ensureIsAuthenticated();
        permission.ensureCanUseAvatar();

        int memberID        = onlineUser.getMemberID();
        String memberName   = onlineUser.getMemberName();

        FileUpload fileUpload = new FileUpload();
        fileUpload.setSizeMax(60000);//60K
        fileUpload.setSizeThreshold(100000);// max memory used = 100K (more than needed)

        List fileItems;
        try {
            fileItems = fileUpload.parseRequest(request);
        } catch (FileUploadException ex) {
            log.error("Cannot upload", ex);
            throw new IOException("Cannot upload. Detailed reason: " + ex.getMessage());
        }

        // make sure only one file upload
        if (fileItems.size() != 1) {
            throw new AssertionException("Assertion: Cannot upload more than 1 file while processing upload avatar for Member.");
        }

        //get the first and only file
        FileItem myFile = (FileItem)fileItems.get(0);
        if (myFile.isFormField() == true) {
            throw new AssertionException("Cannot process uploaded avatar with a form field.");
        }

        // now everything all right, go ahead and create thumbnail
        InputStream inputStream = myFile.getInputStream();

        StringBuffer bufferPicFile = new StringBuffer(128);
        bufferPicFile.append(config.getServletContext().getRealPath(MVNForumGlobal.UPLOADED_AVATAR_DIR));
        bufferPicFile.append(File.separatorChar).append(memberName).append(".jpg");
        String thumbnailFile =  bufferPicFile.toString();

        log.trace("uploaded file = " + thumbnailFile);
        //log.trace("String length = " + thumbnailFile.length());

        //The below method closes the inputStream after it have done its work.
        ImageUtil.createThumbnail(inputStream, thumbnailFile, 150/*maxWidth*/, 150/*maxHeight*/);// can throw BadInputException

        // now the image has been save, go ahead and update database
        StringBuffer bufferVirtualFile = new StringBuffer(128);
        bufferVirtualFile.append(MVNForumGlobal.UPLOADED_AVATAR_DIR);
        bufferVirtualFile.append("/").append(memberName).append(".jpg");
        String virtualFile =  bufferVirtualFile.toString();

        try {
            ManagerFactory.getMemberDAO().updateAvatar(memberID, virtualFile);
        } catch (DatabaseException ex) {// we dont need to catch BadInputException since the memberID is already exits
            log.fatal("Assertion in MemberWebHandler.uploadPicture");// we dont want it to be here
            // need to delete the file if the above database task failed
            FileUtil.deleteFile(thumbnailFile);
            throw ex;
        }
    }

    void forgotPassword(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException,
        javax.mail.MessagingException, AssertionException {

        int memberID = 0;
        String memberName       = ParamUtil.getParameter(request, "MemberName");
        StringUtil.checkGoodName(memberName);
        String memberEmail      = ParamUtil.getParameter(request, "MemberEmail");
        if (memberEmail.length() > 0) {
            memberEmail = ParamUtil.getParameterEmail(request, "MemberEmail");
        }

        if (memberName.length() > 0) {// user enter his MemberName
            // we find the email of this memberID, not the provided email
            memberID = ManagerFactory.getMemberDAO().getMemberIDFromMemberName(memberName);
            MemberBean bean = ManagerFactory.getMemberDAO().getBean_forPublic(memberID);
            memberEmail     = bean.getMemberEmail();
        } else if (memberEmail.length() > 0) {// user enter his email
            // we find the MemberID of this mail, now we sure that user didnt enter his MemberID
            memberID = ManagerFactory.getMemberDAO().getMemberIDFromMemberEmail(memberEmail);
            MemberBean bean = ManagerFactory.getMemberDAO().getBean_forPublic(memberID);
            memberName      = bean.getMemberName();
        } else {// user didnt enter any thing
            throw new BadInputException("You must enter at least your MemberName or email");
        }

        // now we have the correct pair of MemberID and MemberEmail

        // Check the  assumption above
        MemberBean bean = ManagerFactory.getMemberDAO().getBean_forPublic(memberID);
        if (!memberEmail.equalsIgnoreCase(bean.getMemberEmail())) {
            throw new AssertionException("Assertion when process forgot password. This is a serious bug. Please contact the Web site administrator to report the bug.");
        }
        // end check

        //generate a temp password
        String tempPassword = Encoder.getMD5_Base64(String.valueOf(System.currentTimeMillis()));
        // The following line will cause a warning if compile with jdk1.4
        // However, we cannot use the new method String encode(String s, String enc)
        // in jdk1.4, because it wont be compiled with jdk1.3
        // Currently, there is no way to get rid of this wanring
        String urlEncodedTempPassword = Encoder.encodeURL(tempPassword);

        ManagerFactory.getMemberDAO().updateTempPassword(memberID, tempPassword);

        // we have pass the assertion check, go ahead
        String serverName = ParamUtil.getServer2(request);

        StringBuffer passwordResetUrl = new StringBuffer(256);
        passwordResetUrl.append(serverName);
        passwordResetUrl.append(ParamUtil.getContextPath());
        passwordResetUrl.append(UserModuleConfig.getUrlPattern());
        passwordResetUrl.append("/resetpassword?temppassword=");
        passwordResetUrl.append(urlEncodedTempPassword);
        passwordResetUrl.append("&member=");
        passwordResetUrl.append(memberName);

        /** @todo use StringBuffer */
        String subject= "Your MEMBER password of website " + serverName;
        String body =   "This email is sent to you because you (or someone) have requested PASSWORD RESET from web site " + serverName + ".\n" +
                        "If you did not request this password reset feature, just ignore and DELETE this email.\n" +
                        "If you do want to reset your password, please use this url to reset your password:\n" +
                        passwordResetUrl.toString() + "\n" +
                        "Thank you for using " + MVNForumInfo.getProductDesc() + " and we hope that you enjoy our forum.\n" +
                        serverName + " webmaster\n\n" +
                        "Your Member Name = " + memberName + "\n" +
                        "Your temporary password = " + tempPassword + "\n";

        log.debug("subject = " + subject);
        log.debug("body = " + body);
        MailUtil.sendMail(MVNForumConfig.getWebMasterEmail()/*use the default MailFrom value*/,
                          memberEmail/*to*/, ""/*cc*/, ""/*bcc*/, subject, body);
    }

    void resetPassword(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException {

        String memberName           = ParamUtil.getParameter(request, "member", true);
        StringUtil.checkGoodName(memberName);
        // IMPORTANT: MUST check that temp password is not empty, because temppassword = empty
        // means cannot reset password
        String memberTempPassword   = ParamUtil.getParameter(request, "temppassword", true);

        int memberID = ManagerFactory.getMemberDAO().getMemberIDFromMemberName(memberName);

        String currentTempPassword = ManagerFactory.getMemberDAO().getTempPassword(memberID);
        if (memberTempPassword.equals(currentTempPassword) == false) {
            throw new BadInputException("Your temporary password is not correct, please try the forgot password feature.");
        }

        String memberPassword1      = ParamUtil.getParameterPassword(request, "MemberMatkhau", 3, 0);
        String memberPassword2      = ParamUtil.getParameterPassword(request, "MemberMatkhauConfirm", 3, 0);
        if (!memberPassword1.equals(memberPassword2)) {
            throw new BadInputException("Password and confirmed password are not the same, please try again.");
        }
        String memberPassword       = Encoder.getMD5_Base64(memberPassword1);

        ManagerFactory.getMemberDAO().updatePassword(memberID, memberPassword);
        ManagerFactory.getMemberDAO().updateTempPassword(memberID, "");// reset the temp password
    }

    void sendActivateCode(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException,
        MessagingException, AssertionException {

        int memberID = 0;
        String memberName       = ParamUtil.getParameter(request, "MemberName", true);
        StringUtil.checkGoodName(memberName);
        String memberEmail = ParamUtil.getParameterEmail(request, "MemberEmail");

        // we find the email of this memberID, not the provided email
        memberID = ManagerFactory.getMemberDAO().getMemberIDFromMemberName(memberName);

        // Check if the email is correct
        MemberBean bean = ManagerFactory.getMemberDAO().getBean_forPublic(memberID);
        if (!memberEmail.equalsIgnoreCase(bean.getMemberEmail())) {
            throw new AssertionException("Your provided email does not equals to the member's email in our database. Please try again.");
        }

        // end check, send mail now
        String serverName = ParamUtil.getServer2(request);
        sendActivationCodeEmail(memberID, serverName);
    }

    private void sendActivationCodeEmail(int memberID, String serverName)
        throws ObjectNotFoundException, DatabaseException, BadInputException, MessagingException {

        // Now, check that this member is not activated, to prevent the
        // situation that other people try to annoy this member
        if (ManagerFactory.getMemberDAO().getActivateCode(memberID).equals(MemberBean.MEMBER_ACTIVATECODE_ACTIVATED)) {
            throw new BadInputException("Cannot activate an already activated member.");
        }

        MemberBean memberBean = ManagerFactory.getMemberDAO().getBean_forPublic(memberID);
        String memberName = memberBean.getMemberName();
        String memberEmail = memberBean.getMemberEmail();

        // generate a Activation code
        // Note that the activation code does not need security MD5 as in the Password Reset
        String activateCode = String.valueOf(System.currentTimeMillis());

        ManagerFactory.getMemberDAO().updateActivateCode(memberID, activateCode);

        // we have pass the assertion check, go ahead
        StringBuffer activationUrl = new StringBuffer(256);
        activationUrl.append(serverName);
        activationUrl.append(ParamUtil.getContextPath());
        activationUrl.append(UserModuleConfig.getUrlPattern());
        activationUrl.append("/activatemember?activatecode=");
        activationUrl.append(activateCode);
        activationUrl.append("&member=");
        activationUrl.append(memberName);

        /** @todo use StringBuffer */
        String subject= "Your Member Activation Code of website " + serverName;
        String body =   "This email is sent to you because you (or someone/administrator) have requested MEMBER ACTIVATION from web site " + serverName + ".\n" +
                        "To activate your member account, please use this url:\n" +
                        activationUrl.toString() + "\n" +
                        "Thank you for using " + MVNForumInfo.getProductDesc() + " and we hope that you enjoy our forum.\n" +
                        serverName + " webmaster\n\n" +
                        "Your Member Name = " + memberName + "\n" +
                        "Your Activation Code = " + activateCode + "\n";

        log.debug("subject = " + subject);
        log.debug("body = " + body);
        MailUtil.sendMail(MVNForumConfig.getWebMasterEmail()/*use the default MailFrom value*/,
                          memberEmail/*to*/, ""/*cc*/, ""/*bcc*/, subject, body);
    }

    void activateMember(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException,
        AuthenticationException, AssertionException {

        String memberName = ParamUtil.getParameter(request, "member", true);
        StringUtil.checkGoodName(memberName);

        // IMPORTANT: MUST check that ActivateCode is not empty, because ActivateCode = empty
        // means invalid
        String memberActivateCode   = ParamUtil.getParameter(request, "activatecode", true);
        if (memberActivateCode.equals(MemberBean.MEMBER_ACTIVATECODE_ACTIVATED)) {
            throw new BadInputException("Cannot activate member with invalid activation code.");
        }

        int memberID = ManagerFactory.getMemberDAO().getMemberIDFromMemberName(memberName);

        // Now, check that this member is not activated, to prevent the
        // situation that other people try to annoy this member
        if (ManagerFactory.getMemberDAO().getActivateCode(memberID).equals(MemberBean.MEMBER_ACTIVATECODE_ACTIVATED)) {
            throw new BadInputException("Cannot activate an activated member.");
        }

        String currentActivateCode = ManagerFactory.getMemberDAO().getActivateCode(memberID);
        if (memberActivateCode.equals(currentActivateCode) == false) {
            throw new BadInputException("Your activation code is not correct, please try the Member Account Activation feature.");
        }

        ManagerFactory.getMemberDAO().updateActivateCode(memberID, MemberBean.MEMBER_ACTIVATECODE_ACTIVATED);// activate member

        // now reload the permission if this online user is the activated user
        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        if (memberID == onlineUser.getMemberID()) {
            onlineUser.reloadPermission();
        }
    }

/*************************************************
 * For public view
 *************************************************/
    void prepareView_forPublic(HttpServletRequest request)
        throws BadInputException, ObjectNotFoundException, DatabaseException, AssertionException {

        String memberName = ParamUtil.getParameter(request, "member", false);
        // primary key column(s)
        int memberID;
        if (memberName.length() == 0) {
            memberID = ParamUtil.getParameterInt(request, "memberid");
        } else {// has MemberName
            /**@todo: improve this for better performance(dont use this method,
             * and write 2 new methods)*/
            StringUtil.checkGoodName(memberName);// check for better security
            memberID = ManagerFactory.getMemberDAO().getMemberIDFromMemberName(memberName);
        }

        ManagerFactory.getMemberDAO().increaseViewCount(memberID);
        MemberBean bean = ManagerFactory.getMemberDAO().getBean_forPublic(memberID);

        request.setAttribute("MemberBean", bean);
    }

    /**
     * This method supports sorting base on many criteria
     */
    void prepareListMembers_forPublic(HttpServletRequest request)
        throws DatabaseException, AssertionException, BadInputException, AuthenticationException {

        OnlineUser onlineUser = onlineUserManager.getOnlineUser(request);
        MVNForumPermission permission = onlineUser.getPermission();

        // for sort and order stuff
        String sort  = ParamUtil.getParameter(request, "sort");
        String order = ParamUtil.getParameter(request, "order");
        if (sort.length() == 0) sort = "MemberCreationDate";
        if (order.length()== 0) order = "DESC";

        // we continue
        int postsPerPage = onlineUser.getPostsPerPage();
        int offset = 0;
        try {
            offset = ParamUtil.getParameterInt(request, "pager.offset");
        } catch (BadInputException e) {
            // do nothing
        }

        int totalMembers = ManagerFactory.getMemberDAO().getNumberOfBeans();
        if (offset > totalMembers) {
            throw new BadInputException("The offset is not allowed to be greater than total members.");
        }

        Collection memberRows = MemberWebHelper.getMembers_withSortSupport_limit(offset, postsPerPage, sort, order);

        request.setAttribute("MemberBeans", memberRows);
        request.setAttribute("TotalMembers", new Integer(totalMembers));
    }
}
