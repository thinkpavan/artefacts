The content of this directory:

NOTE: If this folder does not contain the driver for your database, please 
      look at the short guide in the header of sql/mvnForum_<yourdatabase>.sql
      Ex: The driver for Oracle is in sql/mvnForum_oracle9.sql


mysql-connector-java-3.0.9-stable-bin.jar 
    Description: driver for Mysql (Connector/J)
    Driver     : com.mysql.jdbc.Driver
    Url        : jdbc:mysql://<host>/<database>?useUnicode=true&characterEncoding=utf-8
    Version    : 3.0.9-stable



mysql-connector-java-3.0.8-stable-bin.jar 
    Description: driver for Mysql (Connector/J)
    Driver     : com.mysql.jdbc.Driver
    Url        : jdbc:mysql://<host>/<database>?useUnicode=true&characterEncoding=utf-8
    Version    : 3.0.8-stable



mm.mysql-2.0.14-bin.jar
    Description: driver for Mysql 
    Driver     : org.gjt.mm.mysql.Driver
    Url        : jdbc:mysql://<host>/<database>?useUnicode=true&characterEncoding=utf-8
    Version    : 2.0.14



hsqldb.jar 
    Description: driver and database engine for hsqldb
    Driver     : org.hsqldb.jdbcDriver
    Url        : jdbc:hsqldb:<database>
    Version    : 1.7.1



postgresql.jar 
    Description: driver for PostgreSql 
    Driver     : org.postgresql.Driver
    Url        : jdbc:postgresql://host:port/database
    Version    : 7.3

