
-- $Header: /cvsroot/mvnforum/mvnforum/sql/mvnForum_hsqldb.sql,v 1.9 2003/10/26 19:16:25 minhnn Exp $
-- $Author: minhnn $
-- $Revision: 1.9 $
-- $Date: 2003/10/26 19:16:25 $
-- Database : hsqldb 1.7.1
-- Driver   : org.hsqldb.jdbcDriver
-- Url      : jdbc:hsqldb:<database>
--            Example: if your MVNFORUM_HOME is c:\mvnForumHome and you copy the
--            folder hsqldb (in the sql folder) to the mvnForumHome folder,
--            then your url is : 
--            DATABASE_URL = jdbc:hsqldb:c:\\mvnForumHome\\hsqldb\\mvnforum
-- User     : sa
-- Password : 

-- Note: Due to strange behaviour of hsqldb's IDENTITY column (begin with 0 instead of 1)
--       then you cannot reply to the first post, which has id = 0 in this case.
--       If you know how to start an IDENTITY column with 1, please let me know
-- Note: Latest hsqldb beta 1.7.2 support IDENTITY START WITH 1 , Please use script file
--       mvnForum_hsqldb_1.7.2.sql and download latest hsqldb at hsqldb.sourceforge.net
-- Read more on  http://sourceforge.net/forum/forum.php?thread_id=838632&forum_id=73673

-- Things should be considered when port this file to other database
-- AUTO_INCREMENT : IDENTITY
-- LONGVARCHAR    : LONGVARCHAR
-- DATE           : DATE
-- TIMESTAMP      : TIMESTAMP
-- Dont use primary key if the key is IDENTITY 

-- Uncomment the following drop table command if you want to drop the tables
-- Note: drop tables will delete all the data in them.
-- Note: you should always backup your data before run the script

-- drop table mvnforumCategory;
-- drop table mvnforumForum;
-- drop table mvnforumGroupForum;
-- drop table mvnforumGroupPermission;
-- drop table mvnforumGroups;
-- drop table mvnforumMember;
-- drop table mvnforumMemberGroup;
-- drop table mvnforumMemberPermission;
-- drop table mvnforumMessageFolder;
-- drop table mvnforumPost;
-- drop table mvnforumThread;
-- drop table mvnforumWatch;
-- drop table mvnforumAttachment;
-- drop table mvnforumMemberForum;
-- drop table mvnforumFavoriteThread;
-- drop table mvnforumRank;

create table mvnforumCategory
(
   CategoryID                     INT                            not null IDENTITY,
   ParentCategoryID               INT                            not null,
   CategoryName                   VARCHAR(250)                   not null,
   CategoryDesc                   LONGVARCHAR                    not null,
   CategoryCreationDate           TIMESTAMP                      not null,
   CategoryModifiedDate           TIMESTAMP                      not null,
   CategoryOrder                  SMALLINT                       not null,
   CategoryOption                 INT                            not null,
   CategoryStatus                 INT                            not null,
   unique (CategoryName)
);

create table mvnforumForum
(
   ForumID                        INT                            not null IDENTITY,
   CategoryID                     INT                            not null,
   LastPostMemberName             VARCHAR(30)                    not null,
   ForumName                      VARCHAR(250)                   not null,
   ForumDesc                      LONGVARCHAR                    not null,
   ForumCreationDate              TIMESTAMP                      not null,
   ForumModifiedDate              TIMESTAMP                      not null,
   ForumLastPostDate              TIMESTAMP                      not null,
   ForumOrder                     SMALLINT                       not null,
   ForumType                      INT                            not null,
   ForumFormatOption              INT                            not null,
   ForumOption                    INT                            not null,
   ForumStatus                    INT                            not null,
   ForumModerationMode            INT                            not null,
   ForumPassword                  VARCHAR(40)                    not null,
   ForumThreadCount               INT                            not null,
   ForumPostCount                 INT                            not null,
   unique (ForumName, CategoryID)
);

create index INDEX_2 on mvnforumForum
(
   CategoryID
);

create table mvnforumGroupForum
(
   GroupID                        INT                            not null,
   ForumID                        INT                            not null,
   Permission                     INT                            not null,
   primary key (GroupID, ForumID, Permission)
);

create index INDEX_17 on mvnforumGroupForum
(
   GroupID
);

create index INDEX_18 on mvnforumGroupForum
(
   ForumID
);

create table mvnforumGroupPermission
(
   GroupID                        INT                            not null,
   Permission                     INT                            not null,
   primary key (GroupID, Permission)
);

create index INDEX_19 on mvnforumGroupPermission
(
   GroupID
);

create table mvnforumGroups
(
   GroupID                        INT                            not null IDENTITY,
   GroupOwnerID                   INT                            not null,
   GroupOwnerName                 VARCHAR(30)                    not null,
   GroupName                      VARCHAR(250)                   not null,
   GroupDesc                      LONGVARCHAR                    not null,
   GroupOption                    INT                            not null,
   GroupCreationDate              TIMESTAMP                      not null,
   GroupModifiedDate              TIMESTAMP                      not null,
   unique (GroupName)
);

create table mvnforumMember
(
   MemberID                       INT                            not null IDENTITY,
   MemberName                     VARCHAR_IGNORECASE(30)         not null,
   MemberPassword                 VARCHAR(40)                    not null,
   MemberFirstEmail               VARCHAR(60)                    not null,
   MemberEmail                    VARCHAR(60)                    not null,
   MemberEmailVisible             SMALLINT                       not null,
   MemberNameVisible              SMALLINT                       not null,
   MemberFirstIP                  VARCHAR(20)                    not null,
   MemberLastIP                   VARCHAR(20)                    not null,
   MemberViewCount                INT                            not null,
   MemberPostCount                INT                            not null,
   MemberCreationDate             TIMESTAMP                      not null,
   MemberModifiedDate             TIMESTAMP                      not null,
   MemberLastLogon                TIMESTAMP                      not null,
   MemberOption                   INT                            not null,
   MemberStatus                   INT                            not null,
   MemberActivateCode             VARCHAR(40)                    not null,
   MemberTempPassword             VARCHAR(40)                    not null,
   MemberMessageCount             INT                            not null,
   MemberMessageOption            INT                            not null,
   MemberPostsPerPage             SMALLINT                       not null,
   MemberWarnCount                SMALLINT                       not null,
   MemberVoteCount                INT                            not null,
   MemberVoteTotalStars           INT                            not null,
   MemberRewardPoints             INT                            not null,
   MemberTitle                    VARCHAR(250)                   not null,
   MemberTimeZone                 INT                            not null,
   MemberSignature                VARCHAR(250)                   not null,
   MemberAvatar                   VARCHAR(200)                   not null,
   MemberSkin                     VARCHAR(70)                    not null,
   MemberLanguage                 VARCHAR(70)                    not null,
   MemberFirstname                VARCHAR(70)                    not null,
   MemberLastname                 VARCHAR(70)                    not null,
   MemberGender                   SMALLINT                       not null,
   MemberBirthday                 DATE                           not null,
   MemberAddress                  VARCHAR(150)                   not null,
   MemberCity                     VARCHAR(70)                    not null,
   MemberState                    VARCHAR(70)                    not null,
   MemberCountry                  VARCHAR(70)                    not null,
   MemberPhone                    VARCHAR(40)                    not null,
   MemberMobile                   VARCHAR(40)                    not null,
   MemberFax                      VARCHAR(40)                    not null,
   MemberCareer                   VARCHAR(50)                    not null,
   MemberHomepage                 VARCHAR(200)                   not null,
   MemberYahoo                    VARCHAR(70)                    not null,
   MemberAol                      VARCHAR(70)                    not null,
   MemberIcq                      VARCHAR(70)                    not null,
   MemberMsn                      VARCHAR(70)                    not null,
   MemberCoolLink1                VARCHAR(200)                   not null,
   MemberCoolLink2                VARCHAR(200)                   not null,
   unique (MemberEmail),
   unique (MemberName)
);

create table mvnforumMemberGroup
(
   GroupID                        INT                            not null,
   MemberID                       INT                            not null,
   MemberName                     VARCHAR(30)                    not null,
   Privilege                      INT                            not null,
   CreationDate                   TIMESTAMP                      not null,
   ModifiedDate                   TIMESTAMP                      not null,
   primary key (GroupID, MemberID)
);

create index INDEX_20 on mvnforumMemberGroup
(
   MemberID
);

create index INDEX_21 on mvnforumMemberGroup
(
   GroupID
);

create table mvnforumMemberPermission
(
   MemberID                       INT                            not null,
   Permission                     INT                            not null,
   primary key (MemberID, Permission)
);

create index INDEX_22 on mvnforumMemberPermission
(
   MemberID
);

create table mvnforumMessageFolder
(
   FolderName                     VARCHAR(30)                    not null,
   MemberID                       INT                            not null,
   FolderOrder                    SMALLINT                       not null,
   FolderCreationDate             TIMESTAMP                      not null,
   FolderModifiedDate             TIMESTAMP                      not null,
   primary key (FolderName, MemberID)
);

create index INDEX_32 on mvnforumMessageFolder
(
   MemberID
);

create table mvnforumPost
(
   PostID                         INT                            not null IDENTITY,
   ParentPostID                   INT                            not null,
   ForumID                        INT                            not null,
   ThreadID                       INT                            not null,
   MemberID                       INT                            not null,
   MemberName                     VARCHAR(30)                    not null,
   LastEditMemberName             VARCHAR(30)                    not null,
   PostTopic                      VARCHAR(250)                   not null,
   PostBody                       LONGVARCHAR                    not null,
   PostCreationDate               TIMESTAMP                      not null,
   PostLastEditDate               TIMESTAMP                      not null,
   PostCreationIP                 VARCHAR(20)                    not null,
   PostLastEditIP                 VARCHAR(20)                    not null,
   PostEditCount                  SMALLINT                       not null,
   PostFormatOption               INT                            not null,
   PostOption                     INT                            not null,
   PostStatus                     INT                            not null,
   PostIcon                       VARCHAR(10)                    not null,
   PostAttachCount                SMALLINT                       not null
);

create index INDEX_7 on mvnforumPost
(
   ForumID
);

create index INDEX_8 on mvnforumPost
(
   ThreadID
);

create index INDEX_9 on mvnforumPost
(
   MemberID
);

create index INDEX_37 on mvnforumPost
(
   ParentPostID
);

create table mvnforumThread
(
   ThreadID                       INT                            not null IDENTITY,
   ForumID                        INT                            not null,
   MemberName                     VARCHAR(30)                    not null,
   LastPostMemberName             VARCHAR(30)                    not null,
   ThreadTopic                    VARCHAR(250)                   not null,
   ThreadBody                     LONGVARCHAR                    not null,
   ThreadVoteCount                INT                            not null,
   ThreadVoteTotalStars           INT                            not null,
   ThreadCreationDate             TIMESTAMP                      not null,
   ThreadLastPostDate             TIMESTAMP                      not null,
   ThreadType                     INT                            not null,
   ThreadOption                   INT                            not null,
   ThreadStatus                   INT                            not null,
   ThreadHasPoll                  INT                            not null,
   ThreadViewCount                INT                            not null,
   ThreadReplyCount               INT                            not null,
   ThreadIcon                     VARCHAR(10)                    not null,
   ThreadDuration                 INT                            not null
);

create index INDEX_4 on mvnforumThread
(
   ForumID
);

create table mvnforumWatch
(
   WatchID                        INT                            not null IDENTITY,
   MemberID                       INT                            not null,
   CategoryID                     INT                            not null,
   ForumID                        INT                            not null,
   ThreadID                       INT                            not null,
   WatchType                      INT                            not null,
   WatchOption                    INT                            not null,
   WatchStatus                    INT                            not null,
   WatchCreationDate              TIMESTAMP                      not null,
   WatchLastSentDate              TIMESTAMP                      not null,
   WatchEndDate                   TIMESTAMP                      not null,
   unique (MemberID, CategoryID, ForumID, ThreadID)
);

create index Watch_MemberID_idx on mvnforumWatch
(
   MemberID
);

create index Watch_CategoryID_idx on mvnforumWatch
(
   CategoryID
);

create index Watch_ForumID_idx on mvnforumWatch
(
   ForumID
);

create index Watch_ThreadID_idx on mvnforumWatch
(
   ThreadID
);

create table mvnforumAttachment
(
   AttachID                       INT                            not null IDENTITY,
   PostID                         INT                            not null,
   MemberID                       INT                            not null,
   AttachFilename                 VARCHAR(250)                   not null,
   AttachFileSize                 INT                            not null,
   AttachMimeType                 VARCHAR(70)                    not null,
   AttachDesc                     VARCHAR(250)                   not null,
   AttachCreationIP               VARCHAR(20)                    not null,
   AttachCreationDate             TIMESTAMP                      not null,
   AttachModifiedDate             TIMESTAMP                      not null,
   AttachDownloadCount            INT                            not null,
   AttachOption                   INT                            not null,
   AttachStatus                   INT                            not null
);

create index Attachment_PostID_idx on mvnforumAttachment
(
   PostID
);

create index Attachment_MemberID_idx on mvnforumAttachment
(
   MemberID
);

create table mvnforumMemberForum
(
   MemberID                       INT                            not null,
   ForumID                        INT                            not null,
   Permission                     INT                            not null,
   primary key (MemberID, ForumID, Permission)
);

create index MemberForum_1_idx on mvnforumMemberForum
(
   MemberID
);

create index MemberForum_2_idx on mvnforumMemberForum
(
   ForumID
);

create table mvnforumFavoriteThread
(
   MemberID                       INT                            not null,
   ThreadID                       INT                            not null,
   ForumID                        INT                            not null,
   FavoriteCreationDate           TIMESTAMP                      not null,
   FavoriteType                   INT                            not null,
   FavoriteOption                 INT                            not null,
   FavoriteStatus                 INT                            not null,
   primary key (MemberID, ThreadID)
);

create index FavorThread_1_idx on mvnforumFavoriteThread
(
   MemberID
);

create index FavorThread_2_idx on mvnforumFavoriteThread
(
   ThreadID
);

create table mvnforumRank
(
   RankID                         INT                            not null IDENTITY,
   RankMinPosts                   INT                            not null,
   RankLevel                      INT                            not null,
   RankTitle                      VARCHAR(250)                   not null,
   RankImage                      VARCHAR(250)                   not null,
   RankType                       INT                            not null,
   RankOption                     INT                            not null,
   unique (RankMinPosts),
   unique (RankTitle)
);

--
-- data for table mvnforumMember
--
INSERT INTO mvnforumMember (MemberID, MemberName, MemberPassword, MemberFirstEmail, MemberEmail, MemberEmailVisible, MemberNameVisible, MemberFirstIP, MemberLastIP, MemberViewCount, MemberPostCount, MemberCreationDate, MemberModifiedDate, MemberLastLogon, MemberOption, MemberStatus, MemberActivateCode, MemberTempPassword, MemberMessageCount, MemberMessageOption, MemberPostsPerPage, MemberWarnCount, MemberVoteCount, MemberVoteTotalStars, MemberRewardPoints, MemberTitle, MemberTimeZone, MemberSignature, MemberAvatar, MemberSkin, MemberLanguage, MemberFirstname, MemberLastname, MemberGender, MemberBirthday, MemberAddress, MemberCity, MemberState, MemberCountry, MemberPhone, MemberMobile, MemberFax, MemberCareer, MemberHomepage, MemberYahoo, MemberAol, MemberIcq, MemberMsn, MemberCoolLink1, MemberCoolLink2)
                    VALUES (1, 'admin', 'ISMvKXpXpadDiUoOSoAfww==', 'admin@yourdomain.com', 'admin@yourdomain.com', '0', '1',         '127.0.0.1',   '127.0.0.1',  '0',             '0',             now(),              now(),              now(),           '0',          '0',          '',                 '',                 '0',                '0',                 '10',               '0',             '0',             '0',                  '0',                '',          '0',            '',              '',           '',         '',             '',              '',             '1',          now(),          '',            '',         '',          '',            '',          '',           '',        '',           '',             '',          '',        '',        '',        '',              '');


--
-- data for table mvnforumMessageFolder
--
INSERT INTO mvnforumMessageFolder (FolderName, MemberID, FolderOrder, FolderCreationDate, FolderModifiedDate)
                           VALUES ('Inbox',    '1',      '0',         now(),              now());
INSERT INTO mvnforumMessageFolder (FolderName, MemberID, FolderOrder, FolderCreationDate, FolderModifiedDate)
                           VALUES ('Sent',     '1',      '0',         now(),              now());


--
-- data for table mvnforumGroups
--
INSERT INTO mvnforumGroups (GroupID, GroupOwnerID, GroupOwnerName, GroupName, GroupDesc,                                                GroupOption, GroupCreationDate, GroupModifiedDate)
                    VALUES ('1',     '0',          '',             'Guest',   'All anonymous users belong to this group.',              '0',         now(),             now());
INSERT INTO mvnforumGroups (GroupID, GroupOwnerID, GroupOwnerName, GroupName, GroupDesc,                                                GroupOption, GroupCreationDate, GroupModifiedDate)
                    VALUES ('2',     '0',          '',             'Member',  'All registered users belong to this group.',             '0',         now(),             now());
INSERT INTO mvnforumGroups (GroupID, GroupOwnerID, GroupOwnerName, GroupName, GroupDesc,                                                GroupOption, GroupCreationDate, GroupModifiedDate)
                    VALUES ('3',     '1',          'admin',        'Admin',   'This group have SystemAdmin permission by default.',     '0',         now(),             now());
INSERT INTO mvnforumGroups (GroupID, GroupOwnerID, GroupOwnerName, GroupName, GroupDesc,                                                GroupOption, GroupCreationDate, GroupModifiedDate)
                    VALUES ('4',     '1',          'admin',        'Forum Admin', 'This group have ForumAdmin permission by default.',  '0',         now(),             now());
INSERT INTO mvnforumGroups (GroupID, GroupOwnerID, GroupOwnerName, GroupName, GroupDesc,                                                GroupOption, GroupCreationDate, GroupModifiedDate)
                    VALUES ('5',     '1',          'admin',        'Forum Moderator', 'This group have ForumModerator permission by default.','0',   now(),             now());


--
-- data for table mvnforumMemberGroup
--
INSERT INTO mvnforumMemberGroup (GroupID, MemberID, MemberName, Privilege, CreationDate, ModifiedDate)
                         VALUES ('3',     '1',      'admin',    '0',       now(),        now());



--
-- data for table mvnforumMemberPermission
--
INSERT INTO mvnforumMemberPermission (MemberID, Permission) 
                              VALUES ('1',      '100');


--
-- data for table mvnforumGroupPermission
--
INSERT INTO mvnforumGroupPermission (GroupID, Permission) 
                             VALUES ('1',     '109');
INSERT INTO mvnforumGroupPermission (GroupID, Permission) 
                             VALUES ('2',     '110');
INSERT INTO mvnforumGroupPermission (GroupID, Permission) 
                             VALUES ('3',     '100');
INSERT INTO mvnforumGroupPermission (GroupID, Permission) 
                             VALUES ('4',     '105');
INSERT INTO mvnforumGroupPermission (GroupID, Permission) 
                             VALUES ('5',     '106');


--
-- data for table mvnforumRank
--
INSERT INTO mvnforumRank (RankMinPosts, RankLevel, RankTitle, RankImage, RankType, RankOption) 
                  VALUES (0, 0, 'Stranger',                   '',        0,        0);
INSERT INTO mvnforumRank (RankMinPosts, RankLevel, RankTitle, RankImage, RankType, RankOption) 
                  VALUES (20, 0, 'Newbie',                    '',        0,        0);
INSERT INTO mvnforumRank (RankMinPosts, RankLevel, RankTitle, RankImage, RankType, RankOption) 
                  VALUES (50, 0, 'Member',                    '',        0,        0);
INSERT INTO mvnforumRank (RankMinPosts, RankLevel, RankTitle, RankImage, RankType, RankOption) 
                  VALUES (100, 0, 'Advanced Member',          '',        0,        0);

