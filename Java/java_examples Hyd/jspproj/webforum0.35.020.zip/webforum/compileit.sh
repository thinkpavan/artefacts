# no ant? no, not yet
javac -target 1.1 -classpath .:servlet.zip -d classes -sourcepath sources sources/com/ondelette/servlet/*.java sources/com/ondelette/servlet/webforum/*.java sources/com/ondelette/servlet/laf/*.java sources/*.java



