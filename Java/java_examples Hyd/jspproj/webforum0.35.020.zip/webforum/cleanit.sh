rm -r -f classes/com classes/*.class
rm -r -f sources/*.class sources/*~
rm -r -f sources/com/ondelette/servlet/*.class sources/com/ondelette/servlet/*~
rm -r -f sources/com/ondelette/servlet/laf/*.class sources/com/ondelette/servlet/laf/*~
rm -r -f sources/com/ondelette/servlet/webforum/*.class sources/com/ondelette/servlet/webforum/*~
rm -r -f sources/com/ondelette/servlet/webannonces/*.class sources/com/ondelette/servlet/webannonces/*~


