These files are meant to be sample files to help you build your own
forum as fast as possible.

Normally, you would put the English.properties (French.properties is
not needed for this sample) together with forumsample.properties.

Then, forumsample.css and forumsample.html would go into the /sample
directory of your web server (so that http://mydomain/sample/forumsample.html
points to forumsample.html).

See the readme.html file in the root directory for more details.

Note: the provided forumsample.html is not part of the documentation.
It is only a sample HTML file and you don't need to read it. 
It is in French, but it could be in any language since only
the HTML codes are meant to serve as an example. To
know exactly how to call the servlet from HTML using 
your servlet engine configuration, check the servlet
engine documentation.

Daniel Lemire, Ph.D.
http://www.ondelette.com
December 29th,2000

