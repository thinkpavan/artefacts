# **-----------------------------------------------------------------**
# ** Creates MySQL table to store binary files                       **
# **                                                                 **
# ** UploadBean/MySQL sample script.                                 **
# ** http://www.javazoom.net/jzservlets/uploadbean/uploadbean.html   **
# ** Copyright JavaZOOM 1999-2002.                                   **
# **-----------------------------------------------------------------**
# DROP TABLE UPLOADS;
CREATE TABLE UPLOADS (
	UPLOADID INT NOT NULL, 
	FILENAME VARCHAR(255), 
	BINARYFILE LONGBLOB,
	PRIMARY KEY (UPLOADID)
);
