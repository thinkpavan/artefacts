UploadBean 1.3
Copyright JavaZOOM 1999-2003
http://www.javazoom.net

==========================================================
UploadBean support page :
http://www.javazoom.net/jzservlets/uploadbean/uploadbean.html

UploadBean add-ons homepage : 
http://www.javazoom.net/jzservlets/uploadbean/uploadbeantools.html

JSP Forums :
http://www.javazoom.net/services/forums/index.jsp
==========================================================

* Open documentation/index.html for instructions *

-----------------
02/17/2003 : v1.3
-----------------
- Recursive folders creation added for FOLDERSTORE.
- getLastId() added for DefaultDBStore.
- DefaultDBStore lock bug fixed.

> ProgressStatus add-on updated : 
  Progress bar added for multiple uploads (multipleupload.jsp)

> NotifyMe add-on updated : 
  JavaMail session getDefaultInstance() bug fixed.

+ WebSphere 5.0 support added.
+ WebLogic 7.0 support added.
+ SunOne 7.0 support added.
+ Tomcat 4.1.18 support added.
+ Struts 1.1b3 support added.


-------------------
12/02/2002 : v1.2.1
-------------------
- Minor bugs fixed.
+ ProgressStatus add-on available : 
  This open source add-on allows to add a real-time progress bar while uploading.
+ Tomcat 4.1.12 support added.


-----------------
09/02/2002 : v1.2
-----------------
- Struts 1.1 multipart parser support added.
- Large file support improved.
- Whitelist feature added.
- API improved (UploadFile, UploadListener, Parsing package).
+ New add-ons available : 
  > NotifyMe :
    This add-on allows to send an email on each upload. Uploaded file could be attached 
    in the email. It's an open source add-on.
  > ChineseUpload :
    This add-on is a sample JSP allowing to upload chinese (big5) files.


-----------------
08/05/2002 : v1.1
-----------------
- Overwrite property added :
  Duplicates entries could be overwritten.
- DBStore API added :
  Developers can now add their own database store implementation if
  the default one (schema, SQL ...) doesn't suit to their needs.
- DatabaseUpload.jsp sample added.
- New Add-Ons section opened : OracleBlobDBStore Add-on available.

Engines/Application servers :
~~~~~~~~~~~~~~~~~~~~~~~~~~~
+ Tomcat 4.0.4-LE support added.
+ JRun 4.0 support added.
+ WebSphereAE 4.0.3 support added.
+ Weblogic 6.1 support added.
+ JRun 4.0 support added.

Database :
~~~~~~~~
+ Oracle8i support added.
+ Oracle9i support added.
+ IBM DB2 7.2 support added.
+ MySQL 3.23.51 support added.


-----------------
02/02/2002 : v1.0
-----------------
UploadBean - Upload component for JAVA/JSP/Servlets.
Multiple stores supported (Folder, Zip, Database, Memory).
Security features (Blacklist, FileSizeLimit, Max. Uploaded files).
Notification and history features.
Documentation (Requirements, Installation, Developer Guide, API&Design, License)
JSP Samples.

+ Tomcat 4.0.1 support.
+ Tomcat 3.2.x support.
+ JRun 3.1 support.
+ Resin 2.0.5 support.
+ WebSphere 3.5.3.
+ VisualAgeForJava 4.0.

Note :
UploadBean supports both COS and STRUTS Multipart Parsers.
Learn more about COS : http://www.servlets.com/cos/index.html
Learn more about STRUTS 1.1 : http://jakarta.apache.org/struts