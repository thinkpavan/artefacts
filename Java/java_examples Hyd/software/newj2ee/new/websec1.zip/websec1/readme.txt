To run this examples on tomcat copy tomcat-users.xml file to 

$TOMCAT_HOME\conf directory.