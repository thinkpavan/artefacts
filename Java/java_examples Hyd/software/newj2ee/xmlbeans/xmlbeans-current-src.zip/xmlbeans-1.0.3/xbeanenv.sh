export XMLBEANS_HOME=`pwd`
