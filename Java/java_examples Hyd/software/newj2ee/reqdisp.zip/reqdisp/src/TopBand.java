/* Servlet generates the top portion (Header) of the web page
* Author : Team -J
* Version : 1.0
*/

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;


public class TopBand extends HttpServlet
{ 
    int i=0;
    public void doGet (
	HttpServletRequest	request,
	HttpServletResponse	response
    ) throws ServletException, IOException
    {
	String advts[]={"one.jpg","two.bmp","three.gif"};
	i++;
	i=i%3;
	PrintWriter out = response.getWriter();
	out.println("<IMG  SRC=" + advts[i] +">");
	// generate links for various pages
	out.println("<A href=home>HOME</A>&nbsp;&nbsp;<A href=products>PRODUCTS</A>&nbsp;&nbsp;<A href=services>SERVICES</A><br><br><br>");
 	
    }
}
