/* Sample servlet to demonstrate requestdispatcher's use
* Author : Team -J
* Version : 1.0
*/

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;


public class fwd extends HttpServlet
{ 
    public void doGet (
	HttpServletRequest	request,
	HttpServletResponse	response
    ) throws ServletException, IOException
    {
	PrintWriter out = response.getWriter();
	out.println("<html><body>");
	ServletContext sc = getServletContext();
System.out.println("From fwd line 1");
	out.println("one <br>");
	RequestDispatcher rd = sc.getRequestDispatcher("/tb");
	rd.forward(request,response);
System.out.println("From fwd line 2");
	out.println("two <br>");
	out.println("</body></html>");
 	
    }
}
