/* Sample servlet to demonstrate requestdispatcher's use
* Author : Team -J
* Version : 1.0
*/

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;


public class Home extends HttpServlet
{ 
    public void doGet (
	HttpServletRequest	request,
	HttpServletResponse	response
    ) throws ServletException, IOException
    {
	PrintWriter out = response.getWriter();
	out.println("<html><body>");
	ServletContext sc = getServletContext();
	RequestDispatcher rd = sc.getRequestDispatcher("/tb");
	rd.include(request,response);
	// here is the content generation code
	out.println(" This is the home page of my site<br>");
	out.println(" This is the home page of my site<br>");
	out.println(" This is the home page of my site<br>");
	out.println(" This is the home page of my site<br>");
	out.println(" This is the home page of my site<br>");
	out.println("</body></html>");
 	
    }
}
