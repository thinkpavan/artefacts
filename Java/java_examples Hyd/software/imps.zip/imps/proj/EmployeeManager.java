import java.sql.*;
import java.util.Vector;

public class EmployeeManager{
	Employee getEmployee(String empno){
		Employee employee=null;
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott","tiger");
		String sqlstmt="select empno,ename,sal,job from emp where empno='"+empno+"'";
		Statement stmt=con.createStatement();
		ResultSet rs= stmt.executeQuery(sqlstmt);
		if(rs.next()){
			employee=new Employee();
			employee.setEmpNo(rs.getString(1));
			employee.setEmpName(rs.getString(2));
			employee.setSalary(rs.getString(3));
			employee.setJob(rs.getString(4));
		}
		con.close();
		}catch(Exception e){
		System.out.println("exception "+e);
		}
		return employee;
	}
	Vector getEmployees(){
		Vector emplist=new Vector();
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott","tiger");
		String sqlstmt="select empno,ename,sal,job from emp";
		Statement stmt=con.createStatement();
		ResultSet rs= stmt.executeQuery(sqlstmt);
		while(rs.next()){
			Employee employee;
			employee=new Employee();
			employee.setEmpNo(rs.getString(1));
			employee.setEmpName(rs.getString(2));
			employee.setSalary(rs.getString(3));
			employee.setJob(rs.getString(4));
			emplist.add(employee);
		}
		con.close();
		}catch(Exception e){
		}
		return emplist;
	}
}