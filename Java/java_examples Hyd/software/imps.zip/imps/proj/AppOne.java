public class AppOne{
	public static void main(String a[]){
		EmployeeManager em=new EmployeeManager();
		Employee e=em.getEmployee("7369");
		System.out.println(e);
	}
}