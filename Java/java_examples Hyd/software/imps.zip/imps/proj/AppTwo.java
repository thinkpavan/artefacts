import java.util.*;

public class AppTwo{
	public static void main(String a[]){
		EmployeeManager em=new EmployeeManager();
		Vector  el=em.getEmployees();
		Enumeration e=el.elements();
		while(e.hasMoreElements()){
			Employee emp=(Employee)e.nextElement();
			System.out.println(emp.getEmpName());
			System.out.println(emp.getSalary());
			System.out.println("*******************************");
		}
	}
}