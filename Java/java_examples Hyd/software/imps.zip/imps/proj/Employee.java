public class Employee{
	private String empName;
	private String empNo;
	private String salary;
	private String job;
	public Employee(){
		empNo=null;
		empName=null;
		salary=null;
		job=null;
	}
	public Employee(String no,String name,String sal,String ejob){
		empNo=no;
		empName=name;
		salary=sal;
		job=ejob;
	}
	public void setEmpNo(String eno){
		empNo=eno;
	}
	public void setEmpName(String ename){
		empName=ename;
	}
	public void setSalary(String sal){
		salary=sal;
	}
	public void setJob(String job){
		this.job=job;
	}
	public String getEmpNo(){
		return empNo;
	}
	public String getEmpName(){
		return empName;
	}
	public String getSalary(){
		return salary;
	}
	public String getJob(){
		return job;
	}
	public String toString(){
		return empNo+":"+empName+":"+salary+":"+job;
	}



}