package org.jboss.chap2.ex1;

/**
 * @author Scott.Stark@jboss.org
 * @version $Revision: 1.2 $
 */
public interface MyClassMBean
{
   public Integer getState();
   public void setState(Integer s);
   public void reset();
}
