package org.jboss.chap8.ex10;

/**
 *
 * @author  Scott.Stark@jboss.org
 * @version $Revision: 1.1.1.1 $
 */
public class TimedCachePolicy
{

   /** Creates new TimedCachePolicy */
    public TimedCachePolicy()
    {
    }

}
