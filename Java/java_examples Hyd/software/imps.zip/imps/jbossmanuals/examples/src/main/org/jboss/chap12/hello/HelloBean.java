/*
 * JBoss, the OpenSource J2EE webOS
 *
 * Distributable under LGPL license.
 * See terms of license at gnu.org.
 */
package org.jboss.chap12.hello;


import javax.ejb.EJBException;

/**
 * The typical Hello Session Bean this time
 * as a web-service.
 * @author jung
 * @version $Revision: 1.1 $
 * @ejb:bean name="Hello"
 *           display-name="Hello World Bean"
 *           type="Stateless"
 *           view-type="remote"
 *           jndi-name="Hello"
 * @ejb:interface remote-class="org.jboss.chap12.hello.Hello" extends="javax.ejb.EJBObject"
 * @ejb:home remote-class="org.jboss.chap12.hello.HelloHome" extends="javax.ejb.EJBHome"
 * @ejb:transaction type="Required"
 * @jboss-net:web-service urn="Hello"
 */
public class HelloBean
   extends BaseSession implements javax.ejb.SessionBean
{
   /**
    * @jboss-net:web-method
    * @ejb:interface-method view-type="remote"
    */
   public String hello(String name)
   {
      return "Hello "+name+"!";
   }

   /**
    * @jboss-net:web-method
    * @ejb:interface-method view-type="remote"
    */
   public Object[] complexHello(Object[] query)
   {
      Object[] reply = new Object[query.length];
      for(int n = 0; n < query.length; n ++)
      {
         HelloObj hello = (HelloObj) query[n];
         System.out.println("hello, "+hello.getMsg());
         reply[n] = new HelloReplyObj(n+": "+hello.getMsg());
      }
      return reply;
   }
}
