package org.jboss.chap2.ex3;

import javax.ejb.EJBLocalObject;

/**
 * @author Scott.Stark@jboss.org
 * @version $Revision: 1.1 $
 */
public interface EchoInfoLocal extends EJBLocalObject
{
   public String getInfo();
}
