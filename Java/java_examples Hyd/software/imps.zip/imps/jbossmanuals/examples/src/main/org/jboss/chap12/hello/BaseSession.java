/*
 * JBoss, the OpenSource J2EE webOS
 *
 * Distributable under LGPL license.
 * See terms of license at gnu.org.
 */

package org.jboss.chap12.hello;

import javax.ejb.CreateException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import org.apache.log4j.Category;

/**
 * 
 *   @version $Revision: 1.1 $
 */
public abstract class BaseSession
   implements SessionBean
{
   protected transient Category log = Category.getInstance(getClass());

   protected SessionContext sessionCtx;
   
   public void ejbCreate()
      throws CreateException
   {
   }
   
   public void setSessionContext(SessionContext ctx) 
   {
      sessionCtx = ctx;
   }
	
   public void ejbActivate() 
   {
   }
	
   public void ejbPassivate() 
   {
   }
	
   public void ejbRemove() 
   {
   }

   private void writeObject(java.io.ObjectOutputStream stream)
   {
      // nothing
   }
   
   private void readObject(java.io.ObjectInputStream stream)
      throws ClassNotFoundException
   {
      // reset logging
      log = Category.getInstance(getClass());
   }
}
