package org.jboss.chap8.ex2.service;

/**
 *
 * @author Scott.Stark@jboss.org
 * @version $Revision: 1.1.1.1 $
 */
public interface JndiStoreMBean
{
   public void start() throws Exception;
   public void stop();
}
