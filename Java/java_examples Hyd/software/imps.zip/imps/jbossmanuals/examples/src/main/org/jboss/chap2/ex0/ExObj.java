package org.jboss.chap2.ex0;

import java.io.Serializable;

/**
 * @author Scott.Stark@jboss.org
 * @version $Revision: 1.2 $
 */
public class ExObj implements Serializable
{
   public ExObj2 ivar = new ExObj2();
}
