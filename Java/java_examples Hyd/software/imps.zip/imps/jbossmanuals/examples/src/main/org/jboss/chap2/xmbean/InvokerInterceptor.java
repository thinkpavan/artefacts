package org.jboss.chap2.xmbean;

import java.lang.reflect.Method;
import java.util.HashMap;

import org.jboss.invocation.MarshalledInvocation;
import org.jboss.logging.Logger;
import org.jboss.mx.interceptor.AbstractInterceptor;
import org.jboss.mx.server.AttributeDispatcher;
import org.jboss.mx.server.Dispatcher;
import org.jboss.mx.server.Invocation;
import org.jboss.mx.server.InvocationException;
import org.jboss.mx.server.MBeanInvoker;
import org.jboss.mx.server.ReflectedDispatcher;

/** An interceptor that handles the ClientInterface methods
 *
 * @author Scott.Stark@jboss.org
 * @version $Revision: 1.3 $
 */
public class InvokerInterceptor extends AbstractInterceptor
{
   private static Logger log = Logger.getLogger(InvokerInterceptor.class);
   private Class exposedInterface = ClientInterface.class;
   private HashMap methodMap = null;
   private HashMap invokeMap = null;

   public Object invoke(Invocation invocation) throws InvocationException
   {
      String opName = invocation.getName();
      // If this is not the invoke(Invocation) op just pass it along
      if( opName == null || opName.equals("invoke") == false )
         return invocation.nextInterceptor().invoke(invocation);

      Object[] args = invocation.getArgs();
      // See what operation is being attempted
      if( methodMap == null )
         initMethodMap(invocation);

      org.jboss.invocation.Invocation invokeInfo =
         (org.jboss.invocation.Invocation) args[0];
      // Set the method hash to Method mapping
      if (invokeInfo instanceof MarshalledInvocation)
      {
         MarshalledInvocation mi = (MarshalledInvocation) invokeInfo;
         mi.setMethodMap(methodMap);
      }

      // Invoke the exposedInterface method via reflection if this is an invoke
      Method method = invokeInfo.getMethod();
      Object[] methodArgs = invokeInfo.getArguments();
      InvocationInfo info = (InvocationInfo) invokeMap.get(method);
      Object returnValue = info.invoke(methodArgs);
      return returnValue;
   }

   private void initMethodMap(Invocation invocation) throws InvocationException
   {
      methodMap = new HashMap();
      invokeMap = new HashMap();
      MBeanInvoker invoker = invocation.getInvoker();
      try
      {
         Object resource = invoker.getResource();
         Class[] getInitialValuesSig = {};
         Method getInitialValues = exposedInterface.getDeclaredMethod("getInitialValues",
            getInitialValuesSig);
         Class[] setInitialValuesSig = {String[].class};
         Method setInitialValues = exposedInterface.getDeclaredMethod("setInitialValues",
            setInitialValuesSig);

         Long hash = new Long(MarshalledInvocation.calculateHash(getInitialValues));
         InvocationInfo invokeInfo = new InvocationInfo("InitialValues",
            getInitialValues, setInitialValues, resource);
         methodMap.put(hash, getInitialValues);
         invokeMap.put(getInitialValues, invokeInfo);
         log.debug("getInitialValues hash:"+hash);

         hash = new Long(MarshalledInvocation.calculateHash(setInitialValues));
         methodMap.put(hash, setInitialValues);
         invokeMap.put(setInitialValues, invokeInfo);
         log.debug("setInitialValues hash:"+hash);

         Class[] getSig = {Object.class};
         Method get = exposedInterface.getDeclaredMethod("get",
            getSig);
         hash = new Long(MarshalledInvocation.calculateHash(get));
         invokeInfo = new InvocationInfo("get", get, resource);
         methodMap.put(hash, get);
         invokeMap.put(get, invokeInfo);
         log.debug("get hash:"+hash);

         Class[] putSig = {Object.class, Object.class};
         Method put = exposedInterface.getDeclaredMethod("put",
            putSig);
         invokeInfo = new InvocationInfo("put", put, resource);
         hash = new Long(MarshalledInvocation.calculateHash(put));
         methodMap.put(hash, put);
         invokeMap.put(put, invokeInfo);
         log.debug("put hash:"+hash);
      }
      catch(Exception e)
      {
         throw new InvocationException(e, "Failed to init InvokerInterceptor");
      }
   }

   /** A class that holds the ClientInterface method info needed to build
    * the JMX Invocation to pass down the interceptor stack.
    */
   private class InvocationInfo
   {
      private String name;
      Dispatcher dispatcher;

      InvocationInfo(String name, Method getter, Method setter, Object resource)
         throws Exception
      {
         this.name = name;
         Class resourceClass = resource.getClass();
         Method resourceGetter = resourceClass.getMethod(getter.getName(),
            getter.getParameterTypes());
         Method resourceSetter = resourceClass.getMethod(setter.getName(),
            setter.getParameterTypes());
         dispatcher = new AttributeDispatcher(resource, resourceGetter, resourceSetter);
      }
      InvocationInfo(String name, Method op, Object resource)
         throws Exception
      {
         this.name = name;
         Class resourceClass = resource.getClass();
         Method resourceOp = resourceClass.getMethod(op.getName(),
            op.getParameterTypes());
         dispatcher = new ReflectedDispatcher(resource, resourceOp);
      }
      Object invoke(Object[] args) throws InvocationException
      {
         log.debug("Dispatching: "+name);
         // The AttributeDispatcher needs to see null for a no-args getter
         if( args != null && args.length == 0 )
            args = null;
         return dispatcher.dispatch(args);
      }
   }
}
