package org.jboss.chap2.xmbean;

import java.security.Principal;

import org.jboss.logging.Logger;
import org.jboss.mx.interceptor.AbstractInterceptor;
import org.jboss.mx.server.Invocation;
import org.jboss.mx.server.InvocationException;
import org.jboss.security.SimplePrincipal;

/** A simple security interceptor example that restricts access to a single
 * principal
 *
 * @author Scott.Stark@jboss.org
 * @version $Revision: 1.3 $
 */
public class ServerSecurityInterceptor extends AbstractInterceptor
{
   private static Logger log = Logger.getLogger(ServerSecurityInterceptor.class);
   private SimplePrincipal admin = new SimplePrincipal("admin");

   public String getAdminName()
   {
      return admin.getName();
   }
   public void setAdminName(String name)
   {
      admin = new SimplePrincipal(name);
   }

   public Object invoke(Invocation invocation) throws InvocationException
   {
      String opName = invocation.getName();
      log.info("invoke, opName="+opName);

      // If this is not the invoke(Invocation) op just pass it along
      if( opName == null || opName.equals("invoke") == false )
         return invocation.nextInterceptor().invoke(invocation);

      Object[] args = invocation.getArgs();
      org.jboss.invocation.Invocation invokeInfo =
         (org.jboss.invocation.Invocation) args[0];
      Principal caller = invokeInfo.getPrincipal();
      log.info("invoke, opName="+opName+", caller="+caller);
      // Only the admin caller is allowed access
      if( caller == null || caller.equals(admin) == false )
      {
         throw new InvocationException(
               new SecurityException("Caller="+caller+" is not allowed access")
         );
      }
      // Let the invocation go
      return invocation.nextInterceptor().invoke(invocation);
   }
}
