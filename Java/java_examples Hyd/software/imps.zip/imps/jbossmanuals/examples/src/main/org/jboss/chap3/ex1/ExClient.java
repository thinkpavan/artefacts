package org.jboss.chap3.ex1;

import java.security.Security;
import java.util.Properties;
import java.net.URL;
import java.net.MalformedURLException;
import javax.naming.Context;
import javax.naming.InitialContext;

/** A simple JNDI client that uses HTTPS as the transport. 
 *
 * @author  Scott.Stark@jboss.org
 * @version $Revision: 1.2 $
 */
public class ExClient
{
   public static void main(String args[]) throws Exception
   {
      // Install the Sun JSSE provider since we may not have JSSE installed
      try
      {
         URL https = new URL("https://localhost");
         System.out.println("JSSE already available");
      }
      catch(MalformedURLException e)
      {
         Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
         System.out.println("Added JSSE security provider");
         // Install the extension JSSE package https handler
         System.setProperty("java.protocol.handler.pkgs",
            "com.sun.net.ssl.internal.www.protocol"); 
      }

      Properties env = new Properties();
      env.setProperty(Context.INITIAL_CONTEXT_FACTORY,
         "org.jboss.naming.HttpNamingContextFactory");
      env.setProperty(Context.PROVIDER_URL,
         "https://localhost:8443/invoker/JNDIFactorySSL");
      Context ctx = new InitialContext(env);
      System.out.println("Created InitialContext, env="+env);
      Object data = ctx.lookup("jmx/rmi/RMIAdaptor");
      System.out.println("lookup(jmx/rmi/RMIAdaptor): "+data);
   }
}

