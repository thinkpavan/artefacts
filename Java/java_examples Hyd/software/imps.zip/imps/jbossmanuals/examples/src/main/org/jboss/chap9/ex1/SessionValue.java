package org.jboss.chap9.ex1;

import java.io.Serializable;

/**
 * @author Scott.Stark@jboss.org
 * @version $Revision: 1.2 $
 */
public class SessionValue implements Serializable
{
   public String username;
   public String lastAccessHost;
   public int accessCount;

   public String toString()
   {
      StringBuffer tmp = new StringBuffer("SessionValue[");
      tmp.append("\tusername: ");
      tmp.append(username);
      tmp.append("\n\tlastAccessHost: ");
      tmp.append(lastAccessHost);
      tmp.append("\n\taccessCount: ");
      tmp.append(accessCount);
      tmp.append("]");
      return tmp.toString();
   }
}
