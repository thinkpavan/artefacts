/*
 * JBoss, the OpenSource J2EE webOS
 *
 * Distributable under LGPL license.
 * See terms of license at gnu.org.
 */
package org.jboss.chap12.hello;


/** A custom data object class that needs to specify a custom serializer
 *  
 *  @jboss-net.xml-schema urn="hello:HelloObj"
 */
public class HelloObj implements java.io.Serializable
{
   private String msg;

   public HelloObj()
   {
   }
   public HelloObj(String msg)
   {
      this.msg = msg;
   }

   public String getMsg()
   {
      return this.msg;
   }
   public void setMsg(String msg)
   {
      this.msg = msg;
   }
}
