package org.jboss.chap12.client;

import org.jboss.chap12.hello.xml.HelloObj;
import org.jboss.chap12.hello.xml.HelloReplyObj;
import org.jboss.chap12.hello.xml.Hello;
import org.jboss.chap12.hello.xml.HelloServiceLocator;

/**
 * @author Scott.Stark@jboss.org
 * @version $Revision: 1.1 $
 */
public class HelloClient
{
   public static void main(String[] args) throws Exception
   {
      HelloServiceLocator locator = new HelloServiceLocator();
      Hello hello = locator.getHello();
      System.out.println("hello.hello(" + args[0] + ")");
      System.out.println("output:" + hello.hello(args[0]));
      Object[] query = new Object[3];
      HelloObj ho = new HelloObj();
      ho.setMsg("Hello index 0");
      query[0] = ho;
      ho = new HelloObj();
      ho.setMsg("Hello index 1");
      query[1] = ho;
      ho = new HelloObj();
      ho.setMsg("Hello index 2");
      query[2] = ho;
      Object[] reply = hello.complexHello(query);
      for(int n = 0; n < reply.length; n ++)
      {
         HelloReplyObj r = (HelloReplyObj) reply[n];
         System.out.println(r.getMsg());
      }
   }
}
