import java.lang.Package;
import java.io.File;
import java.io.FileNotFoundException;
import java.net.URL;
import java.net.URLClassLoader;

/** A class that obtains the jboss server version from the org.jboss package
information from the JBOSS_DIST/bin/run.jar. If the version does not match
is complains.

@since 3.0.5
@author Scott.Stark@jboss.org
@version $Revision: 1.2 $
*/
public class Version
{
   /** Usage: (Path to: JBOSS_DIST/bin/run.jar) [version].
   If the version argument is given then the org.jboss.Main class Package version
   as obtained via the getSpecificationVersion is compared to the argument and
   a warning is printed if the version does not match.
   */
   public static void main(String[] args) throws Exception
   {
      if( args.length == 0 )
      {
         throw new IllegalArgumentException("Usage: Version (Path to: JBOSS_DIST/bin/run.jar) [version]");
      }
      File runjar = new File(args[0]);
      if( runjar.exists() == false )
         throw new FileNotFoundException("run.jar: "+runjar.getAbsolutePath()+" does not exist");
      URL[] cp = {runjar.toURL()};
      URLClassLoader ucl = new URLClassLoader(cp);
      Class main = ucl.loadClass("org.jboss.Main");
      Package pkg = main.getPackage();
      String version = pkg.getSpecificationVersion();
      System.out.println("ImplementationTitle: "+pkg.getImplementationTitle());
      System.out.println("ImplementationVendor: "+pkg.getImplementationVendor());
      System.out.println("ImplementationVersion: "+pkg.getImplementationVersion());
      System.out.println("SpecificationTitle: "+pkg.getSpecificationTitle());
      System.out.println("SpecificationVendor: "+pkg.getSpecificationVendor());
      System.out.println("SpecificationVersion: "+pkg.getSpecificationVersion());

      System.out.println("JBoss version is: "+version);
      if( args.length == 2 )
      {
         String expectedVersion = args[1];
         if( version.startsWith(expectedVersion) == false )
         {
            System.err.println("WARNING: requested version: "+args[1]
               +" does not match the run.jar version: "+version);
            System.exit(1);
         }
      }
      System.exit(0);
   }
}

