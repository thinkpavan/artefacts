
/* Show how to get the reference of initial context in JBOSS
Version : 1.0
Author : Team-J
*/
import java.util.*;
import javax.naming.Context;
import javax.naming.InitialContext;

public class jbossjndi1
{
   public static void main(String args[]) throws Exception
   {
      Hashtable h = new Hashtable();
      h.put(Context.INITIAL_CONTEXT_FACTORY,
         "org.jnp.interfaces.NamingContextFactory");
      h.put(Context.PROVIDER_URL,
         "jnp://localhost:1099/");
      h.put("java.naming.factory.url.pkgs",
         "org.jboss.naming:org.jnp.interfaces");
      Context ic = new InitialContext(h);
      System.out.println("Created InitialContext, env="+ic);
   }
}


