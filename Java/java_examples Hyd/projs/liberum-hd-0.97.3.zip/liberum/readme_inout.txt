In/Out Board ToDo
=================

Here is a list of features etc that isn't implemented yet.

1. Possibility to select date format
2. Possibility to list additional entries on In/Out Board
   without a real user account (like public phones etc.)
3. Upload of User images (As it is now, it only uses the {userid}.jpg
   image if it exists in the ./image/ directory
4. Preselect "Out-of-office" texts
5. Select several formats for showing Phone numbers
   Now Home phone is ## ## ## ## and Mobile is ### ## ###
   (If lenght of phonenumber is equal 8, if not it's left
   as it is)
6. Add footer text to the page
