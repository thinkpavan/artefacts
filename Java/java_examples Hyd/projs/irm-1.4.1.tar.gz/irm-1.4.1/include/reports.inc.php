<?php

# The IRM Reports System
# See docs/REPORTS for information.


$report_list["default"]["name"] = "Default Report";
$report_list["default"]["file"] = "reports/default.php";
$report_list["tracking"]["name"] = "Tracking Report";
$report_list["tracking"]["file"] = "reports/tracking.php";

?>
