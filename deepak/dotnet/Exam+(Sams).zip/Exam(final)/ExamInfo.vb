Imports System.Data.OleDb

Public Class ExamInfo
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Excenter_no As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ExCenter_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ExCand_Status As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents ExStud_Id As System.Windows.Forms.ComboBox
    Friend WithEvents Exprov_name As System.Windows.Forms.TextBox
    Friend WithEvents label7 As System.Windows.Forms.Label
    Friend WithEvents ExExam_Dt As System.Windows.Forms.DateTimePicker
    Friend WithEvents ExProv_No As System.Windows.Forms.TextBox
    Friend WithEvents ExExam_No As System.Windows.Forms.TextBox
    Friend WithEvents ExExam_Pap_Lang As System.Windows.Forms.ComboBox
    Friend WithEvents ExLast_Exam_Tp As System.Windows.Forms.TextBox
    Friend WithEvents ExCert_Lang As System.Windows.Forms.ComboBox
    Friend WithEvents ExSgSub As System.Windows.Forms.CheckedListBox
    Friend WithEvents ExHgSub As System.Windows.Forms.CheckedListBox
    Friend WithEvents Exsave As System.Windows.Forms.Button
    Friend WithEvents ExCancel As System.Windows.Forms.Button
    Friend WithEvents ExSeq_No As System.Windows.Forms.TextBox
    Friend WithEvents ExMedium As System.Windows.Forms.ComboBox
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(ExamInfo))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ExMedium = New System.Windows.Forms.ComboBox()
        Me.ExCert_Lang = New System.Windows.Forms.ComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.ExLast_Exam_Tp = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.ExExam_Pap_Lang = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.ExExam_No = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.ExSeq_No = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.ExProv_No = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.ExExam_Dt = New System.Windows.Forms.DateTimePicker()
        Me.label7 = New System.Windows.Forms.Label()
        Me.Exprov_name = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ExCand_Status = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ExCenter_Name = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Excenter_no = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ExStud_Id = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.ExSgSub = New System.Windows.Forms.CheckedListBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.ExHgSub = New System.Windows.Forms.CheckedListBox()
        Me.Exsave = New System.Windows.Forms.Button()
        Me.ExCancel = New System.Windows.Forms.Button()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.ExMedium, Me.ExCert_Lang, Me.Label13, Me.ExLast_Exam_Tp, Me.Label12, Me.ExExam_Pap_Lang, Me.Label11, Me.ExExam_No, Me.Label10, Me.ExSeq_No, Me.Label9, Me.ExProv_No, Me.Label8, Me.ExExam_Dt, Me.label7, Me.Exprov_name, Me.Label6, Me.ExCand_Status, Me.Label5, Me.Label4, Me.ExCenter_Name, Me.Label3, Me.Excenter_no, Me.Label2, Me.ExStud_Id, Me.Label1})
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(776, 200)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Exam Information"
        '
        'ExMedium
        '
        Me.ExMedium.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ExMedium.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExMedium.Location = New System.Drawing.Point(120, 64)
        Me.ExMedium.Name = "ExMedium"
        Me.ExMedium.Size = New System.Drawing.Size(136, 23)
        Me.ExMedium.TabIndex = 26
        '
        'ExCert_Lang
        '
        Me.ExCert_Lang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ExCert_Lang.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExCert_Lang.Items.AddRange(New Object() {"A-Afrikaans", "E-English", "X-isiXhosa", "Z-isiZulu"})
        Me.ExCert_Lang.Location = New System.Drawing.Point(576, 160)
        Me.ExCert_Lang.Name = "ExCert_Lang"
        Me.ExCert_Lang.Size = New System.Drawing.Size(144, 23)
        Me.ExCert_Lang.TabIndex = 25
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(424, 160)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(120, 24)
        Me.Label13.TabIndex = 24
        Me.Label13.Text = "Cerificate Language"
        '
        'ExLast_Exam_Tp
        '
        Me.ExLast_Exam_Tp.Enabled = False
        Me.ExLast_Exam_Tp.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExLast_Exam_Tp.Location = New System.Drawing.Point(224, 160)
        Me.ExLast_Exam_Tp.Name = "ExLast_Exam_Tp"
        Me.ExLast_Exam_Tp.Size = New System.Drawing.Size(136, 21)
        Me.ExLast_Exam_Tp.TabIndex = 23
        Me.ExLast_Exam_Tp.Text = ""
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(56, 160)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(144, 32)
        Me.Label12.TabIndex = 22
        Me.Label12.Text = "Last Examination Type"
        '
        'ExExam_Pap_Lang
        '
        Me.ExExam_Pap_Lang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ExExam_Pap_Lang.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExExam_Pap_Lang.Items.AddRange(New Object() {"A-Afrikaans", "E-English"})
        Me.ExExam_Pap_Lang.Location = New System.Drawing.Point(576, 128)
        Me.ExExam_Pap_Lang.Name = "ExExam_Pap_Lang"
        Me.ExExam_Pap_Lang.Size = New System.Drawing.Size(144, 23)
        Me.ExExam_Pap_Lang.TabIndex = 21
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(424, 128)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(112, 24)
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "Exam Paper Lang"
        '
        'ExExam_No
        '
        Me.ExExam_No.Enabled = False
        Me.ExExam_No.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExExam_No.Location = New System.Drawing.Point(224, 128)
        Me.ExExam_No.Name = "ExExam_No"
        Me.ExExam_No.Size = New System.Drawing.Size(136, 21)
        Me.ExExam_No.TabIndex = 19
        Me.ExExam_No.Text = ""
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(56, 136)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(160, 24)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "Previous Exam Number"
        '
        'ExSeq_No
        '
        Me.ExSeq_No.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExSeq_No.Location = New System.Drawing.Point(616, 96)
        Me.ExSeq_No.Name = "ExSeq_No"
        Me.ExSeq_No.Size = New System.Drawing.Size(144, 21)
        Me.ExSeq_No.TabIndex = 17
        Me.ExSeq_No.Text = ""
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(512, 96)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(96, 24)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "Sequence No"
        '
        'ExProv_No
        '
        Me.ExProv_No.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExProv_No.Location = New System.Drawing.Point(392, 96)
        Me.ExProv_No.Name = "ExProv_No"
        Me.ExProv_No.Size = New System.Drawing.Size(104, 21)
        Me.ExProv_No.TabIndex = 15
        Me.ExProv_No.Text = ""
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(280, 96)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(112, 24)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Province No"
        '
        'ExExam_Dt
        '
        Me.ExExam_Dt.CustomFormat = "MMM - dd - yyyy"
        Me.ExExam_Dt.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExExam_Dt.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.ExExam_Dt.Location = New System.Drawing.Point(120, 96)
        Me.ExExam_Dt.Name = "ExExam_Dt"
        Me.ExExam_Dt.Size = New System.Drawing.Size(136, 21)
        Me.ExExam_Dt.TabIndex = 13
        '
        'label7
        '
        Me.label7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label7.Location = New System.Drawing.Point(8, 96)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(152, 32)
        Me.label7.TabIndex = 12
        Me.label7.Text = "Exam Date"
        '
        'Exprov_name
        '
        Me.Exprov_name.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Exprov_name.Location = New System.Drawing.Point(616, 64)
        Me.Exprov_name.Name = "Exprov_name"
        Me.Exprov_name.Size = New System.Drawing.Size(144, 21)
        Me.Exprov_name.TabIndex = 11
        Me.Exprov_name.Text = ""
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(512, 64)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(96, 24)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Province Name"
        '
        'ExCand_Status
        '
        Me.ExCand_Status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ExCand_Status.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExCand_Status.Items.AddRange(New Object() {"Full Time"})
        Me.ExCand_Status.Location = New System.Drawing.Point(392, 64)
        Me.ExCand_Status.Name = "ExCand_Status"
        Me.ExCand_Status.Size = New System.Drawing.Size(104, 23)
        Me.ExCand_Status.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(280, 64)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(112, 24)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Candidate Status"
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(8, 64)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 16)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Medium"
        '
        'ExCenter_Name
        '
        Me.ExCenter_Name.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExCenter_Name.Location = New System.Drawing.Point(616, 32)
        Me.ExCenter_Name.Name = "ExCenter_Name"
        Me.ExCenter_Name.Size = New System.Drawing.Size(144, 21)
        Me.ExCenter_Name.TabIndex = 5
        Me.ExCenter_Name.Text = ""
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(512, 32)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 24)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Center Name"
        '
        'Excenter_no
        '
        Me.Excenter_no.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Excenter_no.Location = New System.Drawing.Point(392, 32)
        Me.Excenter_no.Name = "Excenter_no"
        Me.Excenter_no.Size = New System.Drawing.Size(104, 21)
        Me.Excenter_no.TabIndex = 3
        Me.Excenter_no.Text = ""
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(280, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(112, 24)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Center Number:"
        '
        'ExStud_Id
        '
        Me.ExStud_Id.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ExStud_Id.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExStud_Id.Location = New System.Drawing.Point(120, 32)
        Me.ExStud_Id.Name = "ExStud_Id"
        Me.ExStud_Id.Size = New System.Drawing.Size(136, 23)
        Me.ExStud_Id.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(144, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Select Student Id"
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(184, 224)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(424, 24)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Mark Subjects You Wish To Enter For, Check In The Appropriate Block"
        '
        'ExSgSub
        '
        Me.ExSgSub.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExSgSub.Location = New System.Drawing.Point(104, 280)
        Me.ExSgSub.Name = "ExSgSub"
        Me.ExSgSub.Size = New System.Drawing.Size(560, 116)
        Me.ExSgSub.TabIndex = 2
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(104, 256)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(40, 24)
        Me.Label15.TabIndex = 3
        Me.Label15.Text = "SG"
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(280, 256)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(120, 24)
        Me.Label16.TabIndex = 4
        Me.Label16.Text = "Description"
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(104, 408)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(112, 24)
        Me.Label17.TabIndex = 5
        Me.Label17.Text = "HG"
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(280, 408)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(104, 24)
        Me.Label18.TabIndex = 6
        Me.Label18.Text = "Description"
        '
        'ExHgSub
        '
        Me.ExHgSub.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExHgSub.Location = New System.Drawing.Point(104, 432)
        Me.ExHgSub.Name = "ExHgSub"
        Me.ExHgSub.Size = New System.Drawing.Size(560, 124)
        Me.ExHgSub.TabIndex = 7
        '
        'Exsave
        '
        Me.Exsave.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Exsave.Location = New System.Drawing.Point(696, 376)
        Me.Exsave.Name = "Exsave"
        Me.Exsave.Size = New System.Drawing.Size(80, 24)
        Me.Exsave.TabIndex = 8
        Me.Exsave.Text = "Save"
        '
        'ExCancel
        '
        Me.ExCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExCancel.Location = New System.Drawing.Point(696, 416)
        Me.ExCancel.Name = "ExCancel"
        Me.ExCancel.Size = New System.Drawing.Size(80, 24)
        Me.ExCancel.TabIndex = 9
        Me.ExCancel.Text = "Cancel"
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.DataMember = Nothing
        Me.ErrorProvider1.Icon = CType(resources.GetObject("ErrorProvider1.Icon"), System.Drawing.Icon)
        '
        'ExamInfo
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(792, 566)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.ExCancel, Me.Exsave, Me.ExHgSub, Me.Label18, Me.Label17, Me.Label16, Me.Label15, Me.ExSgSub, Me.Label14, Me.GroupBox1})
        Me.Name = "ExamInfo"
        Me.Text = "Exam Infoormation"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
    Enum Mode
        Insert
        Edit
    End Enum

    Public mode_of_opening As Mode

    Dim cmd As New OleDbCommand()
    Dim dreader As OleDbDataReader
    Dim eid As Integer

    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Excenter_no.MaxLength = 4
        cmd.Connection = Dbconnection.connection

        If mode_of_opening = Mode.Edit Then
            dreader = ReaderManipulation.GetReader("select name,id from student where id  in (select studentid from exammst) order by name", cmd)
        ElseIf mode_of_opening = Mode.Insert Then
            ExSeq_No.Text = Format(ReaderManipulation.GenerateAutoNumber("exammst", "sequenceno", cmd), "0000")
            dreader = ReaderManipulation.GetReader("select name, id from student where id not  in (select studentid from exammst) order by name ", cmd)
            Exsave.Enabled = False
        End If

        ReaderManipulation.BindToCombo(ExStud_Id, dreader, True, 1, 0, 1)

        dreader = ReaderManipulation.GetReader("select langid, description from lngmst", cmd)
        ReaderManipulation.BindToCombo(ExMedium, dreader, True, 0, 1)

        dreader = ReaderManipulation.GetReader("select  exno,desc from submst where type='S'", cmd)
        ReaderManipulation.BindToCombo(ExSgSub, dreader, True, 0, 0, 1)

        dreader = ReaderManipulation.GetReader("select exno,desc from submst where type='H'", cmd)
        ReaderManipulation.BindToCombo(ExHgSub, dreader, True, 0, 0, 1)

        cmd.Cancel()
    End Sub

    Private Sub CheckForNumbers(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Excenter_no.KeyPress, ExProv_No.KeyPress, ExExam_No.KeyPress, ExSeq_No.KeyPress

        If sender Is ExSeq_No Then
            ' for exseq_no restriction
            e.Handled = True
        Else
            ' only for numbers
            e.Handled = Not Validations.AllowOnlyNumbers(e.KeyChar)
        End If

        'entery restriction for excenter_no when opened in edit mode
        If mode_of_opening = Mode.Edit And sender Is Excenter_no Then
            e.Handled = True
        End If

    End Sub


    Private Sub CheckForCharacters(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ExCenter_Name.KeyPress, Exprov_name.KeyPress
        e.Handled = Not Validations.AllowOnlyCharacters(e.KeyChar)
    End Sub

    Public Function SetError(ByVal Ctrl As Control, ByVal Text_To_Compare As String) As Boolean

        If Trim(Ctrl.Text) = Text_To_Compare Then
            ErrorProvider1.SetError(Ctrl, "Invalid Entry")
            Return True
        Else
            ErrorProvider1.SetError(Ctrl, "")
            Return False
        End If

    End Function

    Private Sub TextEntryValidation(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles ExStud_Id.Validating, Excenter_no.Validating, ExCenter_Name.Validating, ExMedium.Validating, ExCand_Status.Validating, Exprov_name.Validating, ExExam_Dt.Validating, ExProv_No.Validating, ExSeq_No.Validating, ExExam_Pap_Lang.Validating, ExCert_Lang.Validating, ExSgSub.Validating, ExHgSub.Validating  'ExExam_No.Validating, ExLast_Exam_Tp.Validating,
        ' did not check for exsgsub and exhgsub ie., Or ExSgSub.SelectedIndex = -1 Or ExHgSub.SelectedIndex = -1 
        If Trim(ExStud_Id.Text) = "" Or Trim(Excenter_no.Text) = "" Or Trim(ExCenter_Name.Text) = "" Or Trim(ExMedium.Text) = "" Or Trim(ExCand_Status.Text) = "" Or Trim(Exprov_name.Text) = "" Or Trim(ExExam_Dt.Text) = "" Or Trim(ExProv_No.Text) = "" Or Trim(ExSeq_No.Text) = "" Or Trim(ExExam_Pap_Lang.Text) = "" Then  'Or Trim(ExExam_No.Text) = ""
            Exsave.Enabled = False
        Else
            Exsave.Enabled = True
        End If

        If sender Is Excenter_no Or sender Is ExProv_No Or sender Is ExExam_No Then
            sender.text = Format(Val(sender.text), "0000")
        End If

        e.Cancel = SetError(sender, "")

    End Sub

    Private Sub Exsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Exsave.Click

        Dim sql As String



        If mode_of_opening = Mode.Insert Then
            eid = ReaderManipulation.GenerateAutoNumber("exammst", "id", cmd)

            sql = "insert into ExamMst values(" & eid & "," & CInt(ExStud_Id.SelectedValue) & ",'" & ExCenter_Name.Text & "','" _
                    & Excenter_no.Text & "'," & CInt(ExMedium.SelectedValue) & ",'" & ExCert_Lang.Text & "','" & ExCand_Status.Text _
                    & "','" & CDate(ExExam_Dt.Text) & "','" & ExProv_No.Text & "','" & Exprov_name.Text & "'," & CInt(ExSeq_No.Text) _
                    & ",'" & ExExam_Pap_Lang.Text & "')"

            cmd.CommandType = CommandType.Text
            cmd.CommandText = sql
            cmd.ExecuteNonQuery()
            cmd.Cancel()




            MsgBox("Exam Entered Successfully")
        Else

            sql = "UPDATE ExamMST SET StudentID =" & CInt(ExStud_Id.SelectedValue) & " , CenterName = '" & ExCenter_Name.Text _
                    & "', CenterNo = '" & Excenter_no.Text & "', Medium  =" & CInt(ExMedium.SelectedValue) & ",CertificateLang = '" & _
                    ExCert_Lang.Text & " ',CandidateStatus = '" & ExCand_Status.Text & "',ExDate = '" & CDate(ExExam_Dt.Text) & _
                    "',ProvinceNumber = '" & ExProv_No.Text & "', ProvinceName = '" & Exprov_name.Text & "',Sequenceno = " & _
                    CInt(ExSeq_No.Text) & ",ExamPaperLang = '" & ExExam_Pap_Lang.Text & "' where id=" & eid
            MsgBox(sql)
            cmd.CommandType = CommandType.Text
            cmd.CommandText = sql
            cmd.ExecuteNonQuery()
            cmd.Cancel()



            cmd.CommandText = "delete from examreg where id=" & eid
            cmd.ExecuteNonQuery()

            
            MsgBox("Exam Modified SuccessFully")
        End If

        Dim item


        Dim adap As New OleDbDataAdapter("select * from examreg where 1=2", Dbconnection.connection)
        Dim ds As New DataSet()

        adap.Fill(ds, "examreg")

        For Each item In ExSgSub.CheckedItems
            Dim nrow As DataRow = ds.Tables(0).NewRow()
            nrow(0) = eid

            nrow(1) = item.seconditem
            ds.Tables(0).Rows.Add(nrow)
        Next


        For Each item In ExHgSub.CheckedItems
            Dim nrow As DataRow = ds.Tables(0).NewRow()
            nrow(0) = eid

            nrow(1) = item.seconditem
            ds.Tables(0).Rows.Add(nrow)

        Next



        cmd.CommandText = "insert into examreg values(@id,@sub_id)"


        Dim p1 As OleDbParameter
        p1 = cmd.Parameters.Add("@id", OleDbType.Integer, 4, "id")

        Dim p2 As OleDbParameter
        p2 = cmd.Parameters.Add("@sub_id", OleDbType.VarChar, 10, "sub_id")

        'cmd.Parameters.Add(p1)
        'cmd.Parameters.Add(p2)

        adap.InsertCommand = cmd
        adap.Update(ds, "examreg")


        'For Each item In ExSgSub.CheckedItems
        '    cmd.CommandText = "insert into examreg values(" & eid & ",'" & item.seconditem & "')"
        '    cmd.ExecuteNonQuery()
        'Next

        'For Each item In ExHgSub.CheckedItems
        '    cmd.CommandText = "insert into examreg values(" & eid & ",'" & item.seconditem & "')"
        '    cmd.ExecuteNonQuery()
        'Next
    End Sub

    Private Sub ExCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExCancel.Click
    End Sub

    Private Sub ExStud_Id_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExStud_Id.SelectedIndexChanged



        If ExStud_Id.SelectedIndex <> 0 Then
            If mode_of_opening = Mode.Edit Then

                Dim i%

                For i = 0 To ExSgSub.Items.Count - 1
                    ExSgSub.SetItemChecked(i, False)
                Next

                For i = 0 To ExHgSub.Items.Count - 1
                    ExHgSub.SetItemChecked(i, False)
                Next


                cmd.Cancel()

                dreader = ReaderManipulation.GetReader("select * from exammst where studentid=" & Val(ExStud_Id.SelectedValue), cmd)
                dreader.Read()

                eid = dreader(0)
                ExCenter_Name.Text = checknull(dreader(2))
                Excenter_no.Text = checknull(dreader(3))

                ExMedium.SelectedIndex = GetIndex(ExMedium, checknull(dreader(4)))
                ExCert_Lang.SelectedIndex = ExCert_Lang.Items.IndexOf(checknull(dreader(5)))
                ExCand_Status.SelectedIndex = ExCand_Status.Items.IndexOf(checknull(dreader(6)))
                ExExam_Pap_Lang.SelectedIndex = ExExam_Pap_Lang.Items.IndexOf(checknull(dreader(11)))

                ExExam_Dt.Text = CDate(checknull(dreader(7)))
                ExProv_No.Text = checknull(dreader(8))
                Exprov_name.Text = checknull(dreader(9))
                ExSeq_No.Text = checknull(dreader(10))



                dreader.Close()
                cmd.Cancel()

                dreader = ReaderManipulation.GetReader("select * from examreg where id=" & eid, cmd)


                While dreader.Read

                    Dim fndindx As Integer = GetIndex(ExSgSub, checknull(dreader(1)))

                    If fndindx <> -1 Then
                        ExSgSub.SetItemChecked(fndindx, True)
                    End If

                    fndindx = GetIndex(ExHgSub, checknull(dreader(1)))

                    If fndindx <> -1 Then
                        ExHgSub.SetItemChecked(fndindx, True)
                    End If

                End While
                dreader.Close()

            End If
        End If
    End Sub


    Public Function checknull(ByVal vl As Object) As Object
        If Microsoft.VisualBasic.IsDBNull(vl) = True Then
            Return Nothing
        Else
            Return vl
        End If
    End Function

    Public Function GetIndex(ByVal combo_box As Object, ByVal ValueMember_To_Search As String) As Integer
        If ValueMember_To_Search Is Nothing Then
            Return -1
        End If

        Dim i%
        For i = 0 To combo_box.Items.Count - 1
            If combo_box.Items.Item(i).seconditem = ValueMember_To_Search Then
                Return i
            End If
        Next
        Return -1
    End Function

    'Public Function GetText(ByVal combo_box As Object, ByVal ValueMember_To_Search As String) As String

    '    If ValueMember_To_Search Is Nothing Then
    '        Return ""
    '    End If

    '    Dim item
    '    For Each item In combo_box.items
    '        If item.seconditem = ValueMember_To_Search Then
    '            MsgBox(item.firstitem)
    '            Return item.firstitem
    '        End If
    '    Next
    'End Function

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ExExam_Pap_Lang_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExExam_Pap_Lang.SelectedIndexChanged

    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub
End Class