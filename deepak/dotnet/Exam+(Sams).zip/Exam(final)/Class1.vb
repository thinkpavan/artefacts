Imports System.Data.OleDb

Public Class DataBaseConnection
    Public Shared Path As String
    Public con As OleDbConnection

    Public Sub OpenConnection()
        con = New OleDbConnection(Path)
        con.Open()
    End Sub
End Class