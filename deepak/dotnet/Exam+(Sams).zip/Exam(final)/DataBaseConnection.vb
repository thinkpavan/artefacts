Imports System.Data.OleDb

Public Class DataBaseConnection

    Public Shared Path As String
    Private con As OleDbConnection

    Public ReadOnly Property connection() As OleDbConnection
        Get

            Return con

        End Get
    End Property

    Public Sub OpenConnection()

        con = New OleDbConnection("provider=microsoft.jet.oledb.4.0;data source=" & Path)
        con.Open()

    End Sub

End Class

Public Class ReaderManipulation

    Public Shared Function BindToCombo(ByVal Combo_Box As Object, ByVal dreader As OleDbDataReader, ByVal Bind_Value_Member As Boolean, ByVal Value_Member_To_Bind As Integer, ByVal ParamArray idx() As Integer) As Boolean
        Dim i%
        Dim key As String
        Dim value As String

        Dim btext As New ArrayList()

        If dreader.Read = False Then
            Return False
        Else
            Do
                If idx.Length > 1 Then
                    key = ""
                    For i = 0 To idx.Length - 1
                        key = key & dreader(idx(i))
                        If i <> idx.Length - 1 Then
                            key = key & " - "
                        End If
                    Next
                Else
                    key = dreader(idx(0))
                End If

                If Bind_Value_Member = True Then
                    value = dreader(Value_Member_To_Bind)
                Else
                    value = ""
                End If

                btext.Add(New MultipleItems(key, value))

            Loop While dreader.Read

            Combo_Box.datasource = btext
            Combo_Box.displaymember = "FirstItem"
            Combo_Box.valuemember = "SecondItem"
            dreader.Close()

        End If

    End Function

    Public Shared Function GetReader(ByVal Command_Text As String, ByVal Command_Object As OleDbCommand) As OleDbDataReader

        Command_Object.CommandText = Command_Text
        Dim dreader As OleDbDataReader = Command_Object.ExecuteReader()
        Return dreader

    End Function

    Public Shared Function GenerateAutoNumber(ByVal table_name As String, ByVal field_name As String, ByVal command_object As OleDbCommand) As Integer

        Dim dreader As OleDbDataReader
        Dim num As Integer

        command_object.CommandText = "select max(" & field_name & ") from " & table_name
        dreader = command_object.ExecuteReader

        If dreader.Read = False Then
            num = 1
        Else
            num = dreader(0) + 1
        End If

        dreader.Close()
        Return num
    End Function
End Class

Public Class Validations

    Public Shared Function AllowOnlyNumbers(ByVal KeyCode As Char) As Boolean

        If Asc(KeyCode) <> 8 Then
            If KeyCode Like "[0-9]" Then
                Return True
            Else
                Return False
            End If
        End If

    End Function

    Public Shared Function AllowOnlyCharacters(ByVal KeyCode As Char) As Boolean

        If Asc(KeyCode) <> 8 And Asc(KeyCode) <> 32 Then
            If Not KeyCode Like "[0-9]" Then
                Return True
            Else
                Return False
            End If
        End If

    End Function
End Class


Public Class MultipleItems

    Private First As String
    Private Second As String

    Public ReadOnly Property FirstItem() As String
        Get
            Return First
        End Get
    End Property

    Public ReadOnly Property SecondItem() As String
        Get
            Return Second
        End Get
    End Property

    Public Sub New(ByVal first As String, ByVal second As String)
        Me.First = first
        Me.Second = second
    End Sub

End Class

