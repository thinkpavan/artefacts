Module mymodule

    Public Dbconnection As New DataBaseConnection()

    Public Sub CallConnection()

        Dbconnection.Path = Environment.CurrentDirectory & "\school.mdb"
        Dbconnection.OpenConnection()

    End Sub

End Module
